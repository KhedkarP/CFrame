
package com.selenium.utility;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.http.client.ClientProtocolException;
import org.apache.logging.log4j.*;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

public class ProjectSpecificMethods {

	static Logger log = LogManager.getLogger(ProjectSpecificMethods.class);

	// ************************** Mail Handling Variables Details
	// ***************************************//
	public static String too = "";
	public static String too2 = "";
	public static String from = "";
	final public static String USERNAME_mail = "";
	final public static String PASSWORD_mail = "";
	static String host = "smtp.office365.com";

	// ************************** JIRA Handling Variables Details
	// ***************************************//
	public static String username1 = "";
	public static String password1 = "";
	public static String Project = "";
	public static String assignee = "";
	public static String issuetype = "Bug";
	public static String components = "SERVICING";
	public static String Module = "All";
	public static String Feature = "All";
	public static String description = "Please refer .html and .mp4 file to reproduce issues";
	public static String Jira_Creation_URL = "https://jira.cassiopae.com/jira/rest/api/2/issue"; // http://172.29.248.52:8080/jira/rest/api/2/issue

	// ************ Issue Jira Creation and Attached Attachment Methods
	// *************//
	public synchronized static String NewIssueCreation(String Project, String summary, String username, String password,
			String description, String assignee, String issuetype, String components, String Module, String Feature)
			throws ClientProtocolException, IOException {
		String output = null;
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(username, password));
			WebResource webResource = client.resource(Jira_Creation_URL);
			String input = "{\"fields\":{" + "\"project\":{\"key\":\"" + Project + "\"}," + "\"summary\":\"" + summary
					+ "\"," + "\"description\":\"" + description + "\", " + "\"assignee\": {\"name\": \"" + assignee
					+ "\"}," + "\"issuetype\":{\"name\":\"" + issuetype + "\"}," + "\"components\":[{\"name\":\""
					+ components + "\"}]," + "\"customfield_15200\": {\"value\": \"" + Module
					+ "\", \"child\": {\"value\":\"" + Feature + "\"} }" + "}}";
			ClientResponse response = webResource.type("application/json").post(ClientResponse.class, input);
			output = response.getEntity(String.class).split("\"key\":\"")[1];
			output = output.split("\"")[0];
			return output;
		} catch (Exception e) {
			e.printStackTrace();
			return output;
		}
	}

	// ************** Mail Sending Definition Method *************//
	// ******** ***** E Mail Methods ***********************//
	public synchronized static void Mail_To_Recipents(String Method, String Issues, String app_ver, Logger logger)
			throws InterruptedException, FileNotFoundException, IOException {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "587");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(USERNAME_mail, PASSWORD_mail);
			}
		});
		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage(session);
			// Set From: header field of the header.
			message.setFrom(new InternetAddress(from));
			// Set To: header field of the header.
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(too));
			// Set CC: header field of the header.
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(too2));
			// Set Subject: header field
			message.setSubject(Method + " Failing due to Issue -" + Issues + " [" + app_ver + "]");
			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			messageBodyPart.setText("Hi,\n\n" + "Please refer Issue ticket  - " + Issues
					+ "  in JIRA to reproduce issue .\n\n" + "Regards,\n" + "Cassiopae Automation Team");
			// Create a multipart message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);
			/*
			 * // Part two is attachment messageBodyPart=new MimeBodyPart(); String
			 * filename="C://SeleniumWebDriver//Cass4_5//Trunk4_5//test-output.zip"; String
			 * filename2="Trunk45 Automation Execution Report On" + app_ver + " Time : " +
			 * ReportDateTime() + ".zip"; DataSource source=new FileDataSource(filename);
			 * messageBodyPart.setDataHandler(new DataHandler(source));
			 * messageBodyPart.setFileName(filename2);
			 * multipart.addBodyPart(messageBodyPart);
			 */
			// Send the complete message parts
			message.setContent(multipart);
			logger.info("Sending Report...");
			// Send message
			Transport.send(message);
			logger.info("Report Sent successfully on Issue");
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	public synchronized static void Mail_To_Recipents_BeforeTest()
			throws InterruptedException, FileNotFoundException, IOException {
		/*
		 * Properties props=new Properties(); props.put("mail.smtp.auth","true");
		 * props.put("mail.smtp.starttls.enable","true");
		 * props.put("mail.smtp.host",MailCon_SMTPHOST);
		 * props.put("mail.smtp.port",MailCon_Port); Session
		 * session=Session.getInstance(props,new javax.mail.Authenticator() { protected
		 * PasswordAuthentication getPasswordAuthentication() { return new
		 * PasswordAuthentication(MailCon_UserName, MailCon_Passoword); } }); try { //
		 * Create a default MimeMessage object. Message message=new
		 * MimeMessage(session); // Set From: header field of the header.
		 * message.setFrom(new InternetAddress(MailCon_From)); // Set To: header field
		 * of the header.
		 * message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(
		 * MailCon_To)); // Set CC: header field of the header.
		 * message.setRecipients(Message.RecipientType.CC,InternetAddress.parse(
		 * MailCon_CC)); // Set Subject: header field
		 * message.setSubject(MailCon_Subject_BeforeExecution); // Create the message
		 * part BodyPart messageBodyPart=new MimeBodyPart(); // Now set the actual
		 * message messageBodyPart.setText(MailCon_Body_BeforeExecution); // Create a
		 * multipart message Multipart multipart=new MimeMultipart(); // Set text
		 * message part multipart.addBodyPart(messageBodyPart); // Part two is
		 * attachment messageBodyPart=new MimeBodyPart(); String
		 * filename="d:\\Profiles\\mshaik\\Desktop\\TEST_File_Input.txt"; //String
		 * filename2="Trunk45 Automation Execution Report On" + app_ver + " Time : " +
		 * ReportDateTime() + ".zip"; DataSource source=new FileDataSource(filename);
		 * messageBodyPart.setDataHandler(new DataHandler(source));
		 * //messageBodyPart.setFileName(filename2);
		 * multipart.addBodyPart(messageBodyPart); // Send the complete message parts
		 * message.setContent(multipart); //logger.info("Sending Report..."); // Send
		 * message Transport.send(message);
		 * //logger.info("Report Sent successfully on Issue"); } catch
		 * (MessagingException e) { throw new RuntimeException(e); }
		 */
	}

	public synchronized static void Mail_To_Recipents_AfterTest()
			throws InterruptedException, FileNotFoundException, IOException {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "587");
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return null;
				// return new PasswordAuthentication(MailCon_UserName, MailCon_Passoword);
			}
		});
		/*
		 * try { // Create a default MimeMessage object. Message message=new
		 * MimeMessage(session); // Set From: header field of the header.
		 * message.setFrom(new InternetAddress(MailCon_From)); // Set To: header field
		 * of the header.
		 * message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(
		 * MailCon_To)); // Set CC: header field of the header.
		 * message.setRecipients(Message.RecipientType.CC,InternetAddress.parse(
		 * MailCon_CC)); // Set Subject: header field
		 * message.setSubject(MailCon_Subject_AfterExecution); // Create the message
		 * part BodyPart messageBodyPart=new MimeBodyPart(); // Now set the actual
		 * message messageBodyPart.setText(MailCon_Body_AfterExecution); // Create a
		 * multipart message Multipart multipart=new MimeMultipart(); // Set text
		 * message part multipart.addBodyPart(messageBodyPart); // Part two is
		 * attachment if(MailCon_FileToAttach_1.equalsIgnoreCase("TestData.xls") &&
		 * MailCon_FileToAttach_2.equalsIgnoreCase("emailable-report.html")){
		 * addAttachment(multipart,excelpath,MailCon_FileToAttach_1);
		 * addAttachment(multipart,TestNGPathEmailableReport,MailCon_FileToAttach_2);
		 * }else if(MailCon_FileToAttach_1.equalsIgnoreCase("TestData.xls") &&
		 * MailCon_FileToAttach_2.equalsIgnoreCase("NA")){
		 * addAttachment(multipart,excelpath,MailCon_FileToAttach_1); }else
		 * if(MailCon_FileToAttach_1.equalsIgnoreCase("NA") &&
		 * MailCon_FileToAttach_2.equalsIgnoreCase("emailable-report.html")){
		 * addAttachment(multipart,TestNGPathEmailableReport,MailCon_FileToAttach_2); }
		 * // Send the complete message parts message.setContent(multipart);
		 * //logger.info("Sending Report..."); // Send message Transport.send(message);
		 * //logger.info("Report Sent successfully on Issue"); } catch
		 * (MessagingException e) { throw new RuntimeException(e); }
		 */
	}

	private synchronized static void addAttachment(Multipart multipart, String Filepath, String FileName)
			throws MessagingException {
		DataSource source = new FileDataSource(Filepath);
		BodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setDataHandler(new DataHandler(source));
		messageBodyPart.setFileName(FileName);
		multipart.addBodyPart(messageBodyPart);
	}

}
