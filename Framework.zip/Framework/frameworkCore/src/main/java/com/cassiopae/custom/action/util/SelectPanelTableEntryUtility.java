/**
 * 
 */
package com.cassiopae.custom.action.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;

/**
 * @author jraut
 *
 */
public class SelectPanelTableEntryUtility {

	private static Logger logger = LogManager.getLogger(SelectPanelTableEntryUtility.class);

	private SelectPanelTableEntryUtility() {

	}

	/**
	 * 
	 * @param xpath
	 * @param selActInput
	 * @param reqValue
	 * @param clickableRowNum
	 * @param totalEntryCountinTable
	 * @param testCaseDetailTO
	 * @param rowNumber
	 * @return
	 */
	public static int executeSelectEntryFromTable(List<PanelTableDetails> panelTableDetailList, String clickableRowNum,
			int totalEntryCountinTable, TestCaseDetail testCaseDetailTO) {
		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());

		String elementXpathForGettingreferencValue = null;
		String elementXpathForClick = null;
		boolean isElementExist = false;
		String reference = null;
		for (int rowNumber = 0; rowNumber < totalEntryCountinTable; rowNumber++) {
			elementXpathForGettingreferencValue = constructXPath(rowNumber, prefixSufixID[0], prefixSufixID[1]);
			elementXpathForClick = constructXPath(clickableRowNum, elementXpathForGettingreferencValue);

			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			if (null != reference) {
				isElementExist = isFirstReferenceMatches(testCaseDetailTO, requiredValue, elementXpathForClick,
						reference);
			}
			if (isElementExist) {
				if (panelTableDetailList.size() > 1) {
					isElementExist = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (isElementExist) {
						testCaseDetailTO.getReportingLogger()
								.info(reference + " - Entry Found on Row Number - " + rowNumber);
						testCaseDetailTO.getReportingLogger().info(
								"Click on row number -" + (rowNumber + 1) + ", and column number -" + clickableRowNum);
						clickOnEntry(testCaseDetailTO, requiredValue, elementXpathForClick, reference);
						return rowNumber;
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.info(reference + " - Entry Found on Row Number : " + (rowNumber + 1));
					testCaseDetailTO.getReportingLogger().info(
							"Click on row number : " + (rowNumber + 1) + ", and column number : " + clickableRowNum);
					clickOnEntry(testCaseDetailTO, requiredValue, elementXpathForClick, reference);
					return rowNumber;
				}
			}
		}
		return -1;

	}

	/**
	 * 
	 * @param xpath
	 * @param selActInput
	 * @param reqValue
	 * @param clickableRowNum
	 * @param totalEntryCountinTable
	 * @param testCaseDetailTO
	 * @param rowNumber
	 * @return
	 */
	public static int executeCheckEntryInTable(List<PanelTableDetails> panelTableDetailList, boolean recordStatus,
			int totalEntryCountinTable, TestCaseDetail testCaseDetailTO) {
		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());
		boolean elementExists = false;
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		for (int rowNumber = 0; rowNumber < totalEntryCountinTable; rowNumber++) {
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
				elementXpathForGettingreferencValue = constructXPath(rowNumber, prefixSufixID[0], prefixSufixID[1]);
			} else {
				String[] rowArray = { String.valueOf(rowNumber) };
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), rowArray);
			}
			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			logger.info(ReportLoggerConstant.RETRIEVED_MSG + reference);
			if (null != reference && reference.equals(requiredValue)) {
				elementExists = true;
			}
			if (elementExists) {
				if (panelTableDetailList.size() > 1) {
					elementExists = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (elementExists) {
						testCaseDetailTO.getReportingLogger()
								.info(reference + " - Entry found on row number : " + rowNumber);
						recordStatus = true;
						return rowNumber;
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.info(reference + " - Entry found on row number : " + (rowNumber + 1));
					recordStatus = true;
					return rowNumber;
				}
			}
		}
		return -1;

	}

	/**
	 * 
	 * @param xpath
	 * @param selActInput
	 * @param reqValue
	 * @param clickableRowNum
	 * @param totalEntryCountinTable
	 * @param testCaseDetailTO
	 * @param rowNumber
	 * @return
	 */
	public static int executeCheckPaginateEntryInTable(List<PanelTableDetails> panelTableDetailList,
			boolean recordStatus, int totalEntryCountinTable, TestCaseDetail testCaseDetailTO, String paginationKey) {
		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());
		boolean elementExists = false;
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		for (int rowNumber = 0; rowNumber < totalEntryCountinTable; rowNumber++) {
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
				elementXpathForGettingreferencValue = constructXPath(rowNumber, prefixSufixID[0], prefixSufixID[1]);
			} else {
				String[] rowArray = { String.valueOf(rowNumber) };
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), rowArray);
			}
			
			try {
				testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue)).isDisplayed();
			} catch (NoSuchElementException e) {
				logger.error(e);
				WebElement paginationElement = testCaseDetailTO.getDriver().findElement(By.xpath(paginationKey));
				Boolean elementStauts = GenericAction.checkElementOnUI(paginationElement,testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(), logger);
				if (elementStauts == true) {
					testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.CLICK_ON_PAGINATIONICON);
					paginationElement.click();
				}
			}
			if (rowNumber == 74) {
				testCaseDetailTO.getReportingLogger().warn(ReportLoggerConstant.PAGINAION_LOG_RANGE_MESSAGE);
				break;
			}
			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			logger.info(ReportLoggerConstant.RETRIEVED_MSG + reference);
			if (null != reference && reference.equals(requiredValue)) {
				elementExists = true;
			}
			if (elementExists) {
				if (panelTableDetailList.size() > 1) {
					elementExists = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (elementExists) {
						testCaseDetailTO.getReportingLogger()
								.info(reference + " - Entry found on row number : " + rowNumber);
						recordStatus = true;
						return rowNumber;
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.info(reference + " - Entry found on row number : " + (rowNumber + 1));
					recordStatus = true;
					return rowNumber;
				}
			}
		}
		return -1;

	}

	public static int validateEnrtyInTable(List<PanelTableDetails> panelTableDetailList,
			List<PanelTableDetails> checkPointsDetailList, String clickableRowNum, int totalEntryCountinTable,
			TestCaseDetail testCaseDetailTO) {

		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());

		String elementXpathForGettingreferencValue = null;
		String elementXpathForClick = null;
		boolean isElementExist = false;
		String reference = null;
		boolean validationStatus = true;
		int finalRowNum = -1;
		for (int rowNumber = 0; rowNumber < totalEntryCountinTable; rowNumber++) {
			elementXpathForGettingreferencValue = constructXPath(rowNumber, prefixSufixID[0], prefixSufixID[1]);
			elementXpathForClick = constructXPath(clickableRowNum, elementXpathForGettingreferencValue);

			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			if (null != reference) {
				isElementExist = isFirstReferenceMatches(testCaseDetailTO, requiredValue, elementXpathForClick,
						reference);
			}
			if (isElementExist) {
				if (panelTableDetailList.size() > 1) {
					isElementExist = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (isElementExist) {
						logger.info(reference + " - Entry Found on Row Number - " + rowNumber);
					}
				} else {
					logger.info(reference + " - Entry Found on Row Number - " + (rowNumber + 1));
				}

				// checkpoints logic
				validationStatus = SelectPanelTableEntryUtility.validateColumnDataForRowFromTable(checkPointsDetailList,
						rowNumber, testCaseDetailTO);
				if (validationStatus) {
					testCaseDetailTO.getReportingLogger().info("Validation is passed for the row - " + rowNumber);
				}
			}
			finalRowNum = rowNumber;
		}
		if (validationStatus) {
			return finalRowNum;
		} else {
			logger.info("Validation Failed");
		}
		return -1;

	}

	public static boolean validateColumnDataForRowFromTable(List<PanelTableDetails> checkPointsDetailList,
			int dataRowNumber, TestCaseDetail testCaseDetailTO) {
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		boolean flag = true;
		for (int totalColumn = 0; totalColumn < checkPointsDetailList.size(); totalColumn++) {
			PanelTableDetails checkPointsDetails = checkPointsDetailList.get(totalColumn);
			String[] prefixSufixID = getPrefixAndSuffixID(checkPointsDetails.getxPath());
			elementXpathForGettingreferencValue = constructXPath(dataRowNumber, prefixSufixID[0], prefixSufixID[1]);
			reference = getValueForXPath(checkPointsDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + reference);
			if (!checkPointsDetailList.get(totalColumn).getReqValue().equals(reference)) {
				flag = false;
			}
		}
		return flag;
	}

	/**
	 * 
	 * @param panelTableDetailList
	 * @param dataRowNumber
	 * @param testCaseDetailTO
	 * @return
	 */
	public static List<String> executeGetColumnDataFromTable(List<PanelTableDetails> panelTableDetailList,
			String dataRowNumber, TestCaseDetail testCaseDetailTO, String[] storeValuesInVariable) {
		List<String> referenceValues = new ArrayList<>();
		int rowNum = Integer.parseInt(dataRowNumber);
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		for (int totalColumn = 0; totalColumn < panelTableDetailList.size(); totalColumn++) {
			PanelTableDetails panelTableDetails = panelTableDetailList.get(totalColumn);
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
				elementXpathForGettingreferencValue = constructXPath(rowNum, prefixSufixID[0], prefixSufixID[1]);
			} else {
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), dataRowNumber);
			}
			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			if (!(panelTableDetails.getSelAction().equals(CommonConstant.CLICK_ACTION))) {
				testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + reference);
				testCaseDetailTO.getVariableHolder().put(storeValuesInVariable[totalColumn], reference);
				referenceValues.add(reference);
			}
		}
		return referenceValues;
	}

	/**
	 * @param testCaseDetailTO
	 * @param requiredValue
	 * @param elementXpathForClick
	 * @param reference
	 * @param flag
	 * @return
	 */
	private static boolean isFirstReferenceMatches(TestCaseDetail testCaseDetailTO, String requiredValue,
			String elementXpathForClick, String reference) {
		if (reference.equals(requiredValue)) {
			// testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForClick)).click();
			return true;
		}
		return false;
	}

	/**
	 * @param testCaseDetailTO
	 * @param requiredValue
	 * @param elementXpathForClick
	 * @param reference
	 * @param flag
	 * @return
	 */
	private static boolean clickOnEntry(TestCaseDetail testCaseDetailTO, String requiredValue,
			String elementXpathForClick, String reference) {
		if (reference.equals(requiredValue)) {
			testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForClick)).click();
			return true;
		}
		return false;
	}

	/**
	 * @param testCaseDetailTO
	 * @param xpath
	 * @return
	 */
	public static int getCountOfPOSEntries(TestCaseDetail testCaseDetailTO, String xpath) {
		String tablerowCountXpath = null;
		String newXpath = null;
		if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			tablerowCountXpath = xpath + "//ancestor::table[1]";
		} else {
			String[] rowArray = { "1" };
			newXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetailTO.getVariableHolder(), rowArray);
			tablerowCountXpath = newXpath + "//ancestor::table[1]";
		}
		int totalEntryCount = testCaseDetailTO.getDriver().findElement(By.xpath(tablerowCountXpath))
				.findElements(By.tagName("tr")).size();
		testCaseDetailTO.getReportingLogger().info("Total Entries in list are - " + totalEntryCount);
		return totalEntryCount;
	}

	/**
	 * @param testCaseDetailTO
	 * @param xpath
	 * @return
	 */
	public static String getCountOfEntries(TestCaseDetail testCaseDetailTO, String xpath) {
		String tablerowCountXpath = null;
		String newXpath = null;
		if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			tablerowCountXpath = xpath + "//ancestor::table[1]";
		} else {
			String[] rowArray = { "0" };
			newXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetailTO.getVariableHolder(), rowArray);
			tablerowCountXpath = newXpath + "//ancestor::table[1]";
		}
		String totalEntryCount = null;
		totalEntryCount = testCaseDetailTO.getDriver().findElement(By.xpath(tablerowCountXpath))
				.getAttribute("_rowcount");
		testCaseDetailTO.getReportingLogger().info("Total Entries in list are - " + totalEntryCount);
		return totalEntryCount;
	}

	/**
	 * @param selActInput
	 * @param testCaseDetailTO
	 * @param elementXpathForGettingreferencValue
	 * @param reference
	 * @return
	 */
	public static String getValueForXPath(String selActInput, TestCaseDetail testCaseDetailTO,
			String elementXpathForGettingreferencValue) {
		String reference = null;
		if (selActInput.equalsIgnoreCase(CommonConstant.GET_TEXT)) {
			reference = testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue))
					.getText();
		} else if (selActInput.equalsIgnoreCase(CommonConstant.GET_ATTRIBUTE_VALUE)) {
			reference = testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue))
					.getAttribute("value");
		} else if (selActInput.equalsIgnoreCase(CommonConstant.GET_ATTRIBUTE_TITLE)) {
			reference = testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue))
					.getAttribute("title");
		} else if (selActInput.equalsIgnoreCase(CommonConstant.GET_ATTRIBUTE_DATA_AFR_TLEN)) {
			reference = testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue))
					.getAttribute("data-afr-tlen");
		} else if (selActInput.equalsIgnoreCase(CommonConstant.CLICK_ACTION)) {
			testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue)).click();
		}
		else if (selActInput.equalsIgnoreCase(CommonConstant.GET_ATTRIBUTE_HREF)) {
			reference = testCaseDetailTO.getDriver().findElement(By.xpath(elementXpathForGettingreferencValue))
					.getAttribute("href");
		}
		return reference;
	}

	/**
	 * @param clickableRowNum
	 * @param elementXpathForGettingreferencValue
	 * @return
	 */
	public static String constructXPath(String clickableRowNum, String elementXpathForGettingreferencValue) {
		String elementXpathForClick;
		elementXpathForClick = elementXpathForGettingreferencValue + "/ancestor::tr/td[" + clickableRowNum + "]/span";
		return elementXpathForClick;
	}

	/**
	 * @param rowNumber
	 * @param prefixId
	 * @param suffixId
	 * @return
	 */
	public static String constructXPath(int rowNumber, String prefixId, String suffixId) {
		String elementXpathForGettingreferencValue;
		elementXpathForGettingreferencValue = prefixId + CommonConstant.TABLE_SEPARATOR_CONSTANT + rowNumber + suffixId;
		return elementXpathForGettingreferencValue;
	}

	private static boolean checkCondition(List<PanelTableDetails> panelTableDetailList, TestCaseDetail testCaseDetailTO,
			int rowNumber) {
		boolean resultValue = true;
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		List<String> requiredValueList = new ArrayList<>();
		List<String> referenceValueList = new ArrayList<>();

		for (int i = 1; i < panelTableDetailList.size(); i++) {
			PanelTableDetails panelTableDetails = panelTableDetailList.get(i);
			String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
			String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
					panelTableDetails.getReqValue());
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				elementXpathForGettingreferencValue = SelectPanelTableEntryUtility.constructXPath(rowNumber,
						prefixSufixID[0], prefixSufixID[1]);
			} else {
				String[] rowArray = { String.valueOf(rowNumber) };
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), rowArray);
			}
			reference = SelectPanelTableEntryUtility.getValueForXPath(panelTableDetails.getSelAction(),
					testCaseDetailTO, elementXpathForGettingreferencValue);

			requiredValueList.add(requiredValue);
			referenceValueList.add(reference);

			logger.info((rowNumber + 1) + ". row validation check: Value required - " + requiredValue
					+ ", Value found - " + reference);
		}
		for (int j = 0; j < requiredValueList.size(); j++) {
			if (!requiredValueList.get(j).equals(referenceValueList.get(j))) {
				resultValue = false;
			}
		}

		return resultValue;

	}

	/**
	 * 
	 * @param locatorMap
	 * @param locatorKeys
	 * @param seleniumActions
	 * @param reqValues
	 * @return
	 */
	public static List<PanelTableDetails> getPanelTableDetails(Map<String, List<String>> locatorMap,
			String[] locatorKeys, String[] seleniumActions, String[] reqValues, TestCaseDetail testCaseDetail) {
		List<PanelTableDetails> tableList = new ArrayList<>();
		PanelTableDetails tableDetails = null;
		int i = 0;
		for (; i < locatorKeys.length; i++) {
			tableDetails = new PanelTableDetails();
			String xPath = locatorMap.get(locatorKeys[i].trim()).get(0);
			String selActInput = seleniumActions[i].trim();
			String reqValue = reqValues[i].trim();
			tableDetails.setxPath(xPath);
			tableDetails.setReqValue(
					VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), reqValue));
			tableDetails.setSelAction(selActInput);
			tableList.add(tableDetails);
		}
		return tableList;
	}

	public static List<PanelTableDetails> getPanelTableColumnDetails(Map<String, List<String>> locatorMap,
			String[] locatorKeys, String[] seleniumActions) {
		List<PanelTableDetails> tableList = new ArrayList<>();
		PanelTableDetails tableDetails = null;
		int i = 0;
		for (; i < locatorKeys.length; i++) {
			tableDetails = new PanelTableDetails();
			String xPath = locatorMap.get(locatorKeys[i].trim()).get(0);
			String selActInput = seleniumActions[i].trim();
			tableDetails.setxPath(xPath);
			tableDetails.setSelAction(selActInput);
			tableList.add(tableDetails);
		}
		return tableList;
	}

	/**
	 * This method will return prefix and suffix ID.
	 * 
	 * @param xpath String
	 * @return String[]
	 */
	public static String[] getPrefixAndSuffixID(String xpath) {
		String[] prefixSufixID = new String[2];
		String[] holder = xpath.split(CommonConstant.TABLE_SEPARATOR_CONSTANT);
		String prefixId = holder[0];
		String suffixId = holder[1].substring(holder[1].indexOf(':'), holder[1].length());
		prefixSufixID[0] = prefixId;
		prefixSufixID[1] = suffixId;

		return prefixSufixID;
	}

	public static int executeCheckEntryInPOSTable(List<PanelTableDetails> panelTableDetailList, boolean recordStatus,
			int totalEntryCountinTable, TestCaseDetail testCaseDetailTO) {
		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());
		boolean elementExists = false;
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		for (int rowNumber = 1; rowNumber < totalEntryCountinTable; rowNumber++) {
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				String[] prefixSufixID = getPrefixAndSuffixID(panelTableDetails.getxPath());
				elementXpathForGettingreferencValue = constructXPath(rowNumber, prefixSufixID[0], prefixSufixID[1]);
			} else {
				String[] rowArray = { String.valueOf(rowNumber) };
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), rowArray);
			}
			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			logger.info(ReportLoggerConstant.RETRIEVED_MSG + reference);
			if (null != reference && reference.equals(requiredValue)) {
				elementExists = true;
			}
			if (elementExists) {
				if (panelTableDetailList.size() > 1) {
					elementExists = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (elementExists) {
						testCaseDetailTO.getReportingLogger()
								.info(reference + " - Entry found on row number : " + rowNumber);
						recordStatus = true;
						return rowNumber;
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.info(reference + " - Entry found on row number : " + (rowNumber + 2));
					recordStatus = true;
					return rowNumber;
				}
			}
		}
		return -1;
	}

	public static int getCountOfUnorderListEntries(TestCaseDetail testCaseDetailTO, String xpath) {
		String tablerowCountXpath = null;
		String newXpath = null;
		if (xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			String[] rowArray = { "1" };
			newXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetailTO.getVariableHolder(), rowArray);
		}
		if (xpath.contains(CommonConstant.LI_TAG)) {
			tablerowCountXpath = newXpath + "//ancestor::table[1]//li";
		} else if (xpath.contains(CommonConstant.UL_TAG)) {
			tablerowCountXpath = newXpath + "//ancestor::table[1]//ui";
		}
		int totalEntryCount = testCaseDetailTO.getDriver().findElements(By.xpath(tablerowCountXpath)).size();
		testCaseDetailTO.getReportingLogger().info("Total Entries in list are - " + totalEntryCount);
		return totalEntryCount;
	}

	public static int executeCheckEntryInTableforUnorderedList(List<PanelTableDetails> panelTableDetailList,
			boolean recordStatus, int totalEntryCountinTable, TestCaseDetail testCaseDetailTO) {
		PanelTableDetails panelTableDetails = panelTableDetailList.get(0);
		String requiredValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				panelTableDetails.getReqValue());
		boolean elementExists = false;
		String elementXpathForGettingreferencValue = null;
		String reference = null;
		for (int rowNumber = 1; rowNumber <= totalEntryCountinTable; rowNumber++) {
			if (!panelTableDetails.getxPath().contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				/*
				 * Not used String[] prefixSufixID =
				 * getPrefixAndSuffixID(panelTableDetails.getxPath());
				 * elementXpathForGettingreferencValue = constructXPath(rowNumber,
				 * prefixSufixID[0], prefixSufixID[1]);
				 */
			} else {
				String[] rowArray = { String.valueOf(rowNumber) };
				elementXpathForGettingreferencValue = CommonFunctions.parseQuestionMarkString(
						panelTableDetails.getxPath(), testCaseDetailTO.getVariableHolder(), rowArray);
			}
			reference = getValueForXPath(panelTableDetails.getSelAction(), testCaseDetailTO,
					elementXpathForGettingreferencValue);
			logger.info(ReportLoggerConstant.RETRIEVED_MSG + reference);
			if (null != reference && reference.equals(requiredValue)) {
				elementExists = true;
			}
			if (elementExists) {
				if (panelTableDetailList.size() > 1) {
					elementExists = checkCondition(panelTableDetailList, testCaseDetailTO, rowNumber);
					if (elementExists) {
						testCaseDetailTO.getReportingLogger()
								.info(reference + " - Entry found on row number : " + rowNumber);
						recordStatus = true;
						return rowNumber;
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.info(reference + " - Entry found on row number : " + (rowNumber + 1));
					recordStatus = true;
					return rowNumber;
				}
			}
		}
		return -1;

	}

}
