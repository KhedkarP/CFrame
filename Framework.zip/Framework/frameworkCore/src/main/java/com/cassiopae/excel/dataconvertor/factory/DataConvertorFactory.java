/**
 * 
 */
package com.cassiopae.excel.dataconvertor.factory;

import com.cassiopae.excel.dataconvertor.DataConvertor;
import com.cassiopae.excel.dataconvertor.FormulaDataConvertor;
import com.cassiopae.excel.dataconvertor.NumericDataConvertor;
import com.cassiopae.excel.dataconvertor.StringDataConvertor;
import com.cassiopae.excel.dataconvertor.constant.ConvertorConstant;

/**
 * @author nbhil
 *
 */
public class DataConvertorFactory {

	private DataConvertorFactory() {

	}

	public static DataConvertor getDataConvertorInstance(String type) {
		DataConvertor dataConvertor = null;
		if (ConvertorConstant.STRING_DATA_CONVERTOR.equals(type)) {
			dataConvertor = new StringDataConvertor();
		} else if (ConvertorConstant.NUMERIC_DATA_CONVERTOR.equals(type)) {
			dataConvertor = new NumericDataConvertor();
		} else if (ConvertorConstant.FORMULA_DATA_CONVERTOR.equals(type)) {
			dataConvertor = new FormulaDataConvertor();
		}

		return dataConvertor;
	}

}
