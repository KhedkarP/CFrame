/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class CreateExecuteDynamicXpath implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {

		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());

		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDatas = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] seleniumActions = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		
		String[] storeValuesInVariable = excelTestCaseFields.getStoreValuesInVariable()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));

		String dataRowNumber = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				inputTestDatas[0].trim());
		
		List<PanelTableDetails> panelTableDetailList = SelectPanelTableEntryUtility
				.getPanelTableColumnDetails(locatorMap, locatorKeys, seleniumActions);
		SelectPanelTableEntryUtility
				.executeGetColumnDataFromTable(panelTableDetailList, dataRowNumber, testCaseDetail,storeValuesInVariable);
	}
}
