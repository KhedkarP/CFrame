/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import java.util.HashSet;
import java.util.Set;

/**
 * @author nbhil
 *
 */
public enum ValidationType {

	SLVD_IsDisplayed,
	SLVD_AssertNotEquals, 
	SLVD_AssertEquals,
	SLVD_IsSelected,
	SLVD_IsEnabled,
	XLS_ValidateExcelData,
	SLVD_AssertEquals_CaseInSentitive,
	SLVD_AssertEquals_Contains,
	SLVD_AssertEquals_StartsWith,
	XLS_PaymentScheduleValidation,
	SLVD_TableColumnDataValidation,
	SLVD_CheckDropDownValueIsPresent,
	SLVD_CompareDate,
	SLVD_GenerateXpath_IsCheckboxSelected,
	SLVD_CheckDropDownValueIsSorted;
	
	private static HashSet<String> validationTypeSet = null;

	public static Set<String> getValidationType() {
		if (validationTypeSet == null) {
			validationTypeSet = new HashSet<>();
			for (ValidationType validation : ValidationType.values()) {
				validationTypeSet.add(validation.name());
			}
		}
		return validationTypeSet;
	}

}
