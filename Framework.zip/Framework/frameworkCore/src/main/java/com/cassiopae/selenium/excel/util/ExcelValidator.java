/**
 * 
 */
package com.cassiopae.selenium.excel.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.ss.usermodel.Workbook;

import com.cassiopae.custom.action.CustomType;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ErrorValidation;
import com.cassiopae.framework.to.ExcelMasterData;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.operator.OperationType;
import com.cassiopae.selenium.operator.constant.OperatorConstant;
import com.cassiopae.selenium.ui.actions.ActionType;
import com.cassiopae.selenium.ui.functions.FunctionType;
import com.cassiopae.selenium.ui.validator.ValidationType;
import com.cassiopae.webservices.action.WSCustomType;

/**
 * This java Utility class will validate the excel fields for given test data
 * file.
 * 
 * @author nbhil
 */
public class ExcelValidator {
	private static Logger logger = LogManager.getLogger(ExcelValidator.class);

	private ExcelValidator() {
	}

	public static void validateExcelData(final ExcelMasterData excelMasterData) {
		List<ErrorValidation> errorValidatorList = new ArrayList<>();
		if (excelMasterData.getExcelTestCaseFieldsList() == null
				|| excelMasterData.getExcelTestCaseFieldsList().isEmpty()
				|| excelMasterData.getExcelTestCaseFieldsList().size() == 1) {
			ErrorValidation errorValidation = getErrorValidation("1", ErrorMessageConstant.WORK_BOOK_EMPTY,
					excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
			excelMasterData.setStatus(CommonConstant.FAILUARE_STATUS);
			excelMasterData.setErroValidationList(errorValidatorList);
			return;
		}

		for (ExcelTestCaseFields excelTestCaseFieldsTO : excelMasterData.getExcelTestCaseFieldsList()) {
			validateLocatorKey(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
			validateTestCaseStep(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
			validateAction(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
			ExcelActionInputDataValidator.validateInputTestData(excelMasterData, errorValidatorList,
					excelTestCaseFieldsTO);
			if (!errorValidatorList.isEmpty()) {
				excelMasterData.setStatus(CommonConstant.FAILUARE_STATUS);
				excelMasterData.setErroValidationList(errorValidatorList);
			}
		}
	}

	/**
	 * This method validate test case step data in test data file.
	 * 
	 * @param excelMasterData       ExcelMasterData
	 * @param errorValidatorList    List<ErrorValidation>
	 * @param excelTestCaseFieldsTO ExcelTestCaseFieldsTO
	 */
	private static void validateTestCaseStep(final ExcelMasterData excelMasterData,
			final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (StringUtils.isEmpty(excelTestCaseFieldsTO.getTestCaseSteps())) {
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					ErrorMessageConstant.TEST_CASE_STEP_IS_MANDATORY, excelMasterData.getWorkSheetName(),
					excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
	}

	/**
	 * This method will return the ErrorValidation instance.
	 * 
	 * @param rowNumber     String
	 * @param errorMessage  String
	 * @param workSheetName String
	 * @param workBookName  String
	 * @return ErrorValidation
	 */
	private static ErrorValidation getErrorValidation(String rowNumber, String errorMessage, String workSheetName,
			String workBookName) {

		ErrorValidation errorValidation = new ErrorValidation();
		errorValidation.setRowNumber(rowNumber);
		errorValidation.setErrorMassage(errorMessage);
		errorValidation.setWorkSheetName(workSheetName);
		errorValidation.setWorkBookName(workBookName);
		return errorValidation;
	}

	/**
	 * This method validate locator key data in test data file.
	 * 
	 * @param excelMasterData       ExcelMasterData
	 * @param errorValidatorList    List<ErrorValidation>
	 * @param excelTestCaseFieldsTO ExcelTestCaseFieldsTO
	 */
	private static void validateLocatorKey(final ExcelMasterData excelMasterData,
			final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getLocatorKey())
				&& StringUtils.isEmpty(excelTestCaseFieldsTO.getModule())) {
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					ErrorMessageConstant.LOCATOR_KEY_IS_MANDATORY, excelMasterData.getWorkSheetName(),
					excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
	}

	/**
	 * This method validate Action in test data file.
	 * 
	 * @param excelMasterData       ExcelMasterData
	 * @param errorValidatorList    List<ErrorValidation>
	 * @param excelTestCaseFieldsTO ExcelTestCaseFieldsTO
	 */
	private static void validateAction(final ExcelMasterData excelMasterData,
			final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (!ActionType.getActionType().contains(excelTestCaseFieldsTO.getAction())
				&& !ValidationType.getValidationType().contains(excelTestCaseFieldsTO.getAction())
				&& !OperationType.getOperationType().contains(excelTestCaseFieldsTO.getAction())
				&& !FunctionType.getFunctionType().contains(excelTestCaseFieldsTO.getAction())
				&& !CustomType.getActionType().contains(excelTestCaseFieldsTO.getAction())
				&& !WSCustomType.getWSActionType().contains(excelTestCaseFieldsTO.getAction())
				&& !StringUtils.isEmpty(excelTestCaseFieldsTO.getAction())
				&& !excelTestCaseFieldsTO.getAction().equals(CommonConstant.EXCEL_ACTION_COLUMN_HEADER)) {
			StringBuilder errorMessage = new StringBuilder();
			errorMessage.append(ErrorMessageConstant.INVALID_ACTION_ENTERED).append(excelTestCaseFieldsTO.getAction());
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
		if (excelTestCaseFieldsTO.getAction().contains(OperatorConstant.RELATIONAL_OPERATION)
				&& !(excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR))) {
			StringBuilder errorMessage = new StringBuilder();
			errorMessage.append(ErrorMessageConstant.ARTHMTC_RLTNL_OPERATION_ACTION_INPUTDATA_INCORRECT)
					.append(excelTestCaseFieldsTO.getInputTestData());
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}

	}
	
	/** This method is used to check that given sheet is present in excel OR not.
	 * @param workSheetName
	 * @param workBookName
	 * @param workbook
	 *  @return If sheet is not present in given excel , then it will terminate the execution
	 */
	public static void isSheetPresentInExcel(String workSheetName, String workBookName, Workbook workbook) {
		boolean flag=false;
		for(int noOfsheet=0; noOfsheet<workbook.getNumberOfSheets();noOfsheet++)
		{
			String sheetName=workbook.getSheetAt(noOfsheet).getSheetName();
			if(sheetName.equals(workSheetName)) {
				flag=true;
			}
		}
		if(!flag) {
			logger.info(workSheetName+" - Sheet is not exists in excel file - "+workBookName);
			throw new CATTException(workSheetName+" - Sheet is not exists in excel file - "+workBookName);
		}
	}

	/**
	 * This method is added to check the row coming in file is empty or not. Need to
	 * restrict those rows.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @return boolean
	 */
	public static boolean validateExcelTestCaseFields(final ExcelTestCaseFields excelTestCaseFieldsTO) {
		boolean returnValue = false;

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getSrNo())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getModule())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getLocatorKey())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getTestCaseSteps())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getAction())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getInputTestData())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getActualValue())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getExpectedResult())) {
			return true;
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getErrorMessage())) {
			return true;
		}

		return returnValue;

	}
}
