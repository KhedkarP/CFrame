/**
 *
 */
package com.cassiopae.custom.action.constant;

/**
 * @author nbhil
 *
 */
public interface CustomConstant {

	static String METHOD_CALL = "CSMZ_UserMethodCall";

	static String GENERATE_XPATH_PERFORM_CLICK_ACTION = "CSMZ_GenerateXpath_PerformClickAction";
	static String GENERATE_XPATH_SELECT_DROPDOWN_ACTION = "CSMZ_GenerateXpath_SelectDropdownAction";
	static String GENERATE_XPATH_ENTER_TEXTBOX_VALUE_ACTION = "CSMZ_GenerateXpath_EnterTextBoxValueAction";
	static String GENERATE_XPATH_CHECK_FIELD_ISENABLED = "CSMZ_GenerateXpath_CheckFieldIsEnabled";
	static String GENERATE_XPATH_CHECK_FIELD_ISSELECTED = "CSMZ_GenerateXpath_CheckFieldIsSelected";
	static String GENERATE_XPATH_SELECT_CHECKBOX = "CSMZ_GenerateXpath_SelectCheckboxAction";
	static String GENERATE_XPATH_UNSELECT_CHECKBOX = "CSMZ_GenerateXpath_UnSelectCheckboxAction";
	static String CSMZ_CHECK_FILE_AVAILABLE_OR_NOT = "CSMZ_IsFileDownloaded";
	static final String START_STATEMENT = "StartStatement";
	static final String STOP_STATEMENT = "StopStatement";
	public String GENERATE_DYNAMIC_DATE = "CSMZ_CalculateDate";
	static String RENAME_FILE = "CSMZ_RenameUploadFile";
	static String DOWNLOAD_FILE = "CSMZ_DownloadFile";
	static String CHANGE_DATE_FORMAT = "CSMZ_ChangeDateFormat";
	static String Get_STRING_VALUE_FROM_TEXT = "CSMZ_GetValueFromText";
	static String CLEAR_TEXTBOX_VALUE_ACTION = "CSMZ_GenerateXpath_ClearTextBoxValueAction";
	static String CSMZ_ISDOWNLOADED_FILE_EMPTY = "CSMZ_IsDownloadedFileEmpty";
	static String READ_DATA_FROM_JASPEREXCEL = "CSMZ_ReadDataFromJasperExcel";
	static String CSMZ_READ_DATA_FROM_JASPERPDF_CONVERT_EXCEL = "CSMZ_ReadDataFromJasperPDFAndConvertToExcel";
	public String CSMZ_REPLACE_VALUE_FROMS_STRING = "CSMZ_ReplaceValueFromString";
	public String CSMZ_EXECUTE_BATCH = "CSMZ_ExecuteBatch";
	public String CSMZ_FILE_UPLOAD_ON_SERVER = "CSMZ_FileUploadOnServer";
	public String CSMZ_UPDATE_XML_FILE = "CSMZ_UpdateXMLFile";
	public String CSMZ_GET_TEXT_VALUE_FROM_FILE = "CSMZ_GetTextValueFromFile";
	public String CSMZ_DOWNLOAD_FILE_FROM_SERVER = "CSMZ_DownloadFileFromServer";
	public String CSMZ_CHECK_FILE_IS_PRESENT_ON_SERVER = "CSMZ_CheckFileIsPresentOnServer";
	public String CSMZ_CHECK_PAGINATE_TABLE_ENTERY = "CSMZ_CheckTableEntryWithPagination";
	public String CSMZ_GET_COMPARED_VALUE = "CSMZ_GetComparedValue";
	public String CSMZ_EXTRACT_PDF_DATA_AND_COMPARE = "CSMZ_ValidatePDF";
	public String CSMZ_UPDATE_LOCATOR_PERFORM_CLICK_ACTION = "CSMZ_UpdateLocatorPerformClickAction";
	public String CSMZ_GET_DROPDOWN_INDEX_NUMBER = "CSMZ_GetDropDownIndexNumber";

}
