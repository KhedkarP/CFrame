/**
 * 
 */
package com.cassiopae.selenium.util.common;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.excel.dataconvertor.AbstractDataConvertor;
import com.cassiopae.excel.dataconvertor.constant.ConvertorConstant;
import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.cassiopae.selenium.utils.excel.ExcelOperation;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;
import com.neotys.selenium.proxies.NLWebDriver;

import net.bytebuddy.dynamic.DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial;

/**
 * @author nbhil
 *
 */
public class CommonUtility {

	private CommonUtility() {
	}

	private static Logger logger = LogManager.getLogger(CommonUtility.class);

	/**
	 * This method will update the reference value to status sheet.
	 * 
	 * @param referenceKey               String
	 * @param excelGeneratedReferenceCol int
	 * @param testCaseCommonData         TestCaseCommonData
	 */
	public static void updateReferenceToStatusSheet(String referenceKey, final int excelGeneratedReferenceCol,
			final TestCaseCommonData testCaseCommonData) {
		ExcelOperation.excelAction(CommonConstant.WRITE_OPERATION, testCaseCommonData.getExcelRowNo(),
				excelGeneratedReferenceCol, ApplicationConstant.excelStatusSheetName,
				testCaseCommonData.getDomainName(), referenceKey);
	}

	/**
	 * This method will fetch the reference value from status sheet.
	 * 
	 * @param referenceKey          String
	 * @param GeneratedReferenceCol int
	 * @param testCaseCommonData    TestCaseCommonData
	 * @return String
	 */
	public static String getReferenceFromStatusSheet(final int GeneratedReferenceCol, String worksheetName,
			final TestCaseCommonData testCaseCommonData) {
		int dashboardRowNum = ExcelReader.dashboardRowNumber(testCaseCommonData.getDomainName(), worksheetName,
				ApplicationConstant.excelStatusSheetName);
		return ExcelOperation.excelAction(CommonConstant.READ_OPERATION, dashboardRowNum, GeneratedReferenceCol,
				ApplicationConstant.excelStatusSheetName, testCaseCommonData.getDomainName(), null);
	}

	/**
	 * This method will provide input data. Data might
	 * 
	 * @param excelTestCaseFields
	 * @param testCaseDetail
	 * @return String[]
	 */
	public static String[] getInputData(final ExcelTestCaseFields excelTestCaseFields,
			final TestCaseDetail testCaseDetail) {
		String[] inputData = new String[5];
		if (excelTestCaseFields.getInputTestData() != null && excelTestCaseFields.getInputTestData()
				.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
			inputData[0] = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					excelTestCaseFields.getInputTestData());
		} else {
			inputData = excelTestCaseFields.getInputTestData() != null
					? excelTestCaseFields.getInputTestData().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))
					: null;
		}
		return inputData;
	}

	/**
	 * This method will provide generated reference number.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 * @param referenceValue        String
	 * @return String
	 * @author nbhil
	 */
	public static String getReferenceNumber(final ExcelTestCaseFields excelTestCaseFieldsTO,
			final TestCaseDetail testCaseDetailTO, final String referenceValue) {
		String returnValue = null;
		if (FunctionConstant.ACTOR.equals(excelTestCaseFieldsTO.getModule())
				|| FunctionConstant.ASSET.equals(excelTestCaseFieldsTO.getModule())
				|| FunctionConstant.CONSTRUCTION.equals(excelTestCaseFieldsTO.getModule())
				|| FunctionConstant.CONTRACT.equals(excelTestCaseFieldsTO.getModule())) {
			String[] value = referenceValue.trim().replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING)
					.split(CommonConstant.COLON_SEPERATOR);
			returnValue = value[1].substring((value[1].indexOf(CommonConstant.LESS_THAN_SEPERATOR)) + 1,
					(value[1].indexOf(CommonConstant.GREATER_THAN_SEPERATOR)));
		} else if (FunctionConstant.EXPENSE.equals(excelTestCaseFieldsTO.getModule())
				|| FunctionConstant.CASHFLOW.equals(excelTestCaseFieldsTO.getModule())
				|| FunctionConstant.PROPERTY.equals(excelTestCaseFieldsTO.getModule())) {
			String value = referenceValue.trim().replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
			returnValue = value.substring((value.indexOf(CommonConstant.LESS_THAN_SEPERATOR)) + 1,
					(value.indexOf(CommonConstant.GREATER_THAN_SEPERATOR)));
		} else if (FunctionConstant.DEAL.equals(excelTestCaseFieldsTO.getModule())) {
			String value = referenceValue.trim().replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
			returnValue = value.substring(0, (value.indexOf(CommonConstant.HYPHEN_SEPERATOR)));
		} else if (FunctionConstant.RECEIVABLE.equals(excelTestCaseFieldsTO.getModule())) {
			String value = referenceValue.trim().replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
			returnValue = value.substring(value.indexOf(CommonConstant.HASH_SEPERATOR) + 1, value.length());
		}
		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getModule() + " reference is - " + returnValue);

		return returnValue;
	}

	/**
	 * This method get called to execute the method call using reflection.
	 * 
	 * @param className        String
	 * @param methodName       String
	 * @param parameterTypes   Class[]
	 * @param parameterValue   Object[]
	 * @param isInstanceMethod boolean
	 * @return Object
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object reflectionCall(final String className, final String methodName, final Class[] parameterTypes,
			final Object[] parameterValue, final boolean isInstanceMethod) {
		Object returnObject = null;
		Object objectInstance = null;
		try {
			Class classObjectInstance = Class.forName(className);
			if (isInstanceMethod) {
				objectInstance = classObjectInstance.newInstance();
			}
			Method methodObjectInstance = null;
			if (parameterTypes != null && parameterTypes.length > 0) {
				methodObjectInstance = classObjectInstance.getDeclaredMethod(methodName, parameterTypes);
			} else {
				methodObjectInstance = classObjectInstance.getDeclaredMethod(methodName);
			}
			final Method methodObjectFinalInstance = methodObjectInstance;

			AccessController.doPrivileged(new PrivilegedAction() {
				public Object run() {
					methodObjectFinalInstance.setAccessible(true);
					return null;
				}
			});
			if (parameterValue != null && parameterValue.length > 0) {
				returnObject = methodObjectFinalInstance.invoke(objectInstance, parameterValue);
			} else {
				returnObject = methodObjectFinalInstance.invoke(objectInstance);
			}

		} catch (final Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTException(exception.getMessage());
		}
		return returnObject;
	}

	/**
	 * This method update the argument types.
	 * 
	 * @param methodArgumentType String[]
	 * @param parameterTypes     Class[]
	 */
	public static void getMethodArgumentType(final String[] methodArgumentType, final Class[] parameterTypes) {
		int count = 0;
		for (String parameter : methodArgumentType) {
			try {
				Class classTypePar = Class.forName(parameter);
				parameterTypes[count] = classTypePar;
				count++;
			} catch (ClassNotFoundException exception) {
				throw new CATTException(exception.getMessage());
			}

		}
	}

	/**
	 * This method will return the formated date as per Locale.
	 * 
	 * @param cellvalue Cell
	 * @param locale    String
	 * @return String
	 */
	public static String getFormatedDate(final Cell cellvalue, final String locale) {
		String calculatedValue;
		if (!StringUtils.isEmpty(locale)) {
			String dateformate = AbstractDataConvertor.getLocaleMap().get(locale)
					.get(ConvertorConstant.DATE_FORMATE_KEY);
			SimpleDateFormat dateFormat = new SimpleDateFormat(dateformate);
			calculatedValue = dateFormat.format(cellvalue.getDateCellValue());
		} else {
			SimpleDateFormat dateFormat = new SimpleDateFormat(CommonConstant.DATE_FORMATE);
			calculatedValue = dateFormat.format(cellvalue.getDateCellValue());
		}
		return calculatedValue;
	}

	/**
	 * This method will return the formated data value for Numeric data.
	 * 
	 * @param cellvalue     Cell
	 * @param dataFormatter DataFormatter
	 * @param locale        String
	 * @return String
	 */
	public static String getNumericDataFormatted(final Cell cellvalue, final DataFormatter dataFormatter, String locale,
			String worksSheetName) {
		String calculatedValue;
		if (worksSheetName.contains(DBConstant.POS_MODULE)) {
			locale = DBConstant.POS_MODULE + CommonConstant.UNDER_SCORE + locale;
			if (ConvertorConstant.POS_FR_FR_LOCALE_KEY.contains(locale)) {
				double decimalAmount = cellvalue.getNumericCellValue();
				BigDecimal bigdecimalValue = new BigDecimal(String.valueOf(decimalAmount));
				int scale = getScaleValue(bigdecimalValue);
				String dataformate = getAmountConversionFormat(scale, locale);
				DecimalFormat decimalFormat = new DecimalFormat(dataformate);
				decimalFormat.setGroupingSize(3);
				DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.FRENCH);
				symbols.setDecimalSeparator(',');
				symbols.setGroupingSeparator(' ');
				decimalFormat.setDecimalFormatSymbols(symbols);
				calculatedValue = decimalFormat.format(decimalAmount);
				return calculatedValue;
			}
			double decimalAmount = cellvalue.getNumericCellValue();
			BigDecimal bigdecimalValue = new BigDecimal(String.valueOf(decimalAmount));
			calculatedValue = bigdecimalValue.toString();
			// calculatedValue = getFormattedNumericDataenUSAndenFRLocale(cellvalue,
			// locale);
		} else {
			if (ConvertorConstant.FR_FR_LOCALE_KEY.equals(locale)
					|| ConvertorConstant.EN_FR_LOCALE_KEY.equals(locale)) {
				return getFormattedNumericDataFranceLocale(cellvalue, locale);
			}
			calculatedValue = getFormattedNumericDataUSLocale(cellvalue, locale);
		}
		return calculatedValue;
	}

	/**
	 * This method converts the data from cell which having numeric cell type, to
	 * french value [French number format ]
	 * 
	 * @param cellvalue
	 * @param locale
	 * @return String
	 * @throws NullPointerException if the formatting pattern is empty
	 */
	public static String getFormattedNumericDataFranceLocale(final Cell cellvalue, final String locale) {
		String calculatedValue = null;
		double decimalAmount = cellvalue.getNumericCellValue();
		BigDecimal bigdecimalValue = new BigDecimal(String.valueOf(decimalAmount));
		int scale = getScaleValue(bigdecimalValue);
		calculatedValue = formatAmountToFranceLocale(bigdecimalValue, locale, scale);
		return calculatedValue;
	}

	/**
	 * This method format amount in decimal format as per France locale
	 * 
	 * @param cellvalue
	 * @param locale
	 * @param scale
	 * @return locale specific formatted amount
	 */
	public static String formatAmountToFranceLocale(final BigDecimal decimalAmount, final String locale, int scale) {
		String calculatedValue = null;
		String dataformate = getAmountConversionFormat(scale, locale);
		DecimalFormat decimalFormat = new DecimalFormat(dataformate);
		decimalFormat.setGroupingSize(3);
		DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.FRENCH);
		symbols.setDecimalSeparator(',');
		symbols.setGroupingSeparator(' ');
		decimalFormat.setDecimalFormatSymbols(symbols);
		calculatedValue = decimalFormat.format(decimalAmount);
		return calculatedValue;
	}

	/**
	 * This method converts the data from cell which having numeric cell type, to US
	 * value [United States number format ]
	 * 
	 * @param cellvalue
	 * @param locale
	 * @return String
	 * @throws NullPointerException if the formatting pattern is empty
	 */
	public static String getFormattedNumericDataUSLocale(final Cell cellvalue, final String locale) {
		String calculatedValue = null;
		double decimalAmount = cellvalue.getNumericCellValue();
		BigDecimal bigdecimalValue = new BigDecimal(String.valueOf(decimalAmount));
		int scale = getScaleValue(bigdecimalValue);
		calculatedValue = formateAmountToUSLocale(bigdecimalValue, locale, scale);
		return calculatedValue;
	}

	/**
	 * This method converts the data from cell which having numeric cell type, to
	 * EN_ US / EN_FR value [United States / France number format for POS
	 * application]
	 * 
	 * @param cellvalue
	 * @param locale
	 * @return String
	 * @throws NullPointerException if the formatting pattern is empty
	 */
	public static String getFormattedNumericDataenUSAndenFRLocale(final Cell cellvalue, final String locale) {
		String calculatedValue = null;
		double decimalAmount = cellvalue.getNumericCellValue();
		BigDecimal bigdecimalValue = new BigDecimal(String.valueOf(decimalAmount));
		int scale = getScaleValue(bigdecimalValue);
		calculatedValue = formateAmountToUSLocale(bigdecimalValue, locale, scale);
		return calculatedValue;
	}

	/**
	 * This method format amount in decimal format as per US local
	 * 
	 * @param cellvalue
	 * @param locale
	 * @param scale
	 * @return locale specific formatted amount
	 */
	public static String formateAmountToUSLocale(final BigDecimal decimalAmount, final String locale, int scale) {
		String calculatedValue = null;
		String dataformatPattern = getAmountConversionFormat(scale, locale);
		DecimalFormat decimalFormat = new DecimalFormat(dataformatPattern);
		decimalFormat.setGroupingSize(3);
		DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
		decimalFormat.setDecimalFormatSymbols(symbols);
		calculatedValue = decimalFormat.format(decimalAmount);
		return calculatedValue;
	}

	/**
	 * This method returns the count of decimal values present in BigDecimal number
	 * 
	 * @param bigDecimal
	 * @return int
	 */
	public static int getScaleValue(BigDecimal bigDecimal) {
		int scale = bigDecimal.stripTrailingZeros().scale();
		return scale > 0 ? scale : 0;
	}

	/**
	 * This method is used to prepare pattern for coversion.
	 * 
	 * @param scale
	 * @param locale
	 * @return String
	 */
	public static String getAmountConversionFormat(int scale, String locale) {
		String patternFormat = AbstractDataConvertor.getLocaleMap().get(locale).get(ConvertorConstant.DATA_FORMATE_KEY);
		if (patternFormat == null) {
			logger.error("Data format pattern is not configured to convert amount for the locale : " + locale);
			logger.warn("Selecting default conversion pattern - " + ConvertorConstant.FR_DATA_FORMATE_VALUE);
			patternFormat = ConvertorConstant.FR_DATA_FORMATE_VALUE;
		}
		if (scale > 2) {
			patternFormat = CommonUtility.splitStringUsingPattern(patternFormat, CommonConstant.DOT_OPERATOR)[0];
			patternFormat = patternFormat + CommonConstant.DOT_OPERATOR;
			StringBuilder pattern = new StringBuilder(patternFormat);
			for (int k = 0; k < scale; k++) {
				pattern.append(CommonConstant.ZERO_VALUE);
			}
			return pattern.toString();
		}
		return patternFormat;

	}

	/**
	 * This method splits the string as per given regular expression
	 * 
	 * @param inputString
	 * @param regex
	 * @return String[] Array of splitted String values
	 */
	public static String[] splitString(final String inputString, final String regex) {
		if (null != inputString && null != regex) {
			return inputString.split(regex);
		}
		return null;
	}

	/**
	 * 
	 * @param inputString
	 * @param regex
	 * @return
	 */
	public static String[] splitStringUsingPattern(final String inputString, final String regex) {
		if (null != inputString && null != regex) {
			return inputString.split(Pattern.quote(regex));
		}
		return null;
	}
	
	/**
	 * 
	 * @param inputString
	 * @param regex
	 * @return
	 */
	public static String[] splitStringUsingPatternWithLastAvailable(final String inputString, final String regex) {
		if (null != inputString && null != regex) {
			int abc = inputString.lastIndexOf(CommonConstant.PIPE_SEPARATOR);
			String data1 = StringUtils.substring(inputString, 0, abc);
			String data2 = StringUtils.substring(inputString, abc+1, inputString.length());
			return new String[] {data1,data2};
		}
		return null;
	}

	public static String getApplicationNameFromWorksheetName(final String workSheetName) {
		if (workSheetName.contains(DBConstant.BO_APP_SHEET_NAME) || workSheetName.contains(DBConstant.API_APP_SHEET_NAME)) {
			return DBConstant.BO_MODULE;
		} else {
			return DBConstant.MO_MODULE;
		}
	}

	/**
	 * This method check for decimal point value.
	 * 
	 * @param calculatedValue
	 * @return
	 */
	public static boolean checkForDecimal(String calculatedValue) {
		boolean returnValue = false;
		Pattern pattern = Pattern.compile(FrameworkConstant.REGEX_EXP_FOR_DECIMAL);

		Matcher matcher = pattern.matcher(calculatedValue);
		if (matcher.find()) {
			returnValue = true;
		}
		return returnValue;
	}

	/**
	 * This method check for floating point value.
	 * 
	 * @param calculatedValue
	 * @return
	 */
	public static boolean checkForFloating(String calculatedValue) {
		boolean returnValue = false;
		if (calculatedValue != null) {
			Pattern pattern = Pattern.compile(FrameworkConstant.REGEX_EXP_FOR_FLOATING);
			Matcher matcher = pattern.matcher(calculatedValue);
			if (matcher.find()) {
				returnValue = true;
			}
		}
		return returnValue;
	}

	public static List<String> getStringValue(String[] summaryReporToken, String prefix, String suffix) {

		String resultValue = null;
		List<String> entries = new ArrayList<>();
		for (String summaryReportLine : summaryReporToken) {
			summaryReportLine = summaryReportLine.replace('\u00A0', ' ').trim();
			if (summaryReportLine.contains(prefix)) {
				if (suffix == null || suffix.trim().length() == 0) {
					resultValue = summaryReportLine.substring(summaryReportLine.indexOf(prefix) + prefix.length(),
							summaryReportLine.length());
					entries.add(resultValue.trim());
				} else {
					if (summaryReportLine.indexOf(suffix) != -1) {
						resultValue = summaryReportLine.substring(summaryReportLine.indexOf(prefix) + prefix.length(),
								summaryReportLine.indexOf(suffix));
						entries.add(resultValue.trim());
					}
				}
			}
		}
		return entries;
	}

	public static List<String> getDateValue(String[] summaryReporToken, String prefix) {
		String resultValue = null;
		List<String> entries = new ArrayList<>();
		for (String summaryReportLine : summaryReporToken) {
			summaryReportLine = summaryReportLine.replace('\u00A0', ' ').trim();
			if (summaryReportLine.contains(prefix)) {
				int startIndex = summaryReportLine.indexOf(prefix) + prefix.length();
				resultValue = summaryReportLine.substring(startIndex, startIndex + 10);
				entries.add(resultValue);
			}
		}
		return entries;
	}

	public static boolean isListNotNullAndNotEmpty(List list) {
		boolean returnValue = false;
		if (list != null && !list.isEmpty()) {
			returnValue = true;
		}
		return returnValue;
	}

	/**
	 * This method will validate the entries found and update the variable map.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 * @param occurenceNo           int
	 * @param foundEntriesList      List<String>
	 */
	public static void validateAndUpdateVariableMap(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO, int occurenceNo, List<String> foundEntriesList) {
		int foundEntriesSize;
		if (CommonUtility.isListNotNullAndNotEmpty(foundEntriesList)) {
			foundEntriesSize = foundEntriesList.size();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.OCCURENCE_MSG + foundEntriesSize);
			if (occurenceNo <= foundEntriesSize) {
				testCaseDetailTO.getReportingLogger()
						.info(ReportLoggerConstant.RETRIEVED_MSG + foundEntriesList.get(occurenceNo - 1));
				if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
					String[] storedValueKeys = excelTestCaseFieldsTO.getStoreValuesInVariable().trim()
							.split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
					if (storedValueKeys.length == 2) {
						String referenceKey = storedValueKeys[0].trim();
						String totalOccurencesKey = storedValueKeys[1].trim();
						testCaseDetailTO.getVariableHolder().put(referenceKey, foundEntriesList.get(occurenceNo - 1));
						testCaseDetailTO.getVariableHolder().put(totalOccurencesKey, String.valueOf(foundEntriesSize));
					} else if (storedValueKeys.length == 1) {
						String referenceKey = storedValueKeys[0].trim();
						testCaseDetailTO.getVariableHolder().put(referenceKey, foundEntriesList.get(occurenceNo - 1));
					}
				}
			} else {
				updateLogger(testCaseDetailTO, "Total number of occurences of '" + foundEntriesList.get(occurenceNo - 1)
						+ "' are less than expected in summary");
			}
		} else {
			updateLogger(testCaseDetailTO, ReportLoggerConstant.VALUE_NOT_FOUND_IN_SUMMARY);

		}
	}

	/**
	 * @param testCaseDetailTO
	 */
	private static void updateLogger(TestCaseDetail testCaseDetailTO, String message) {
		testCaseDetailTO.getReportingLogger().info(message);
		throw new CATTException(ReportLoggerConstant.VALUE_NOT_FOUND_IN_SUMMARY);
	}

	/**
	 * This method is used to get count of entities from UI with pagination.
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @param totalEntryInOnePage
	 * @param pageLabel
	 * @return totalEntityEntries
	 */
	private static int getCountOfEntriesWithPagination(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO, int totalEntryInOnePage, String pageLabel) {
		int totalEntityEntries;
		String countOfEntryInlastPage;
		if (pageLabel.equals(CommonConstant.PAGE_LABEL_COUNT_ENGLISH)) {
			totalEntityEntries = totalEntryInOnePage;
		} else {
			String labelCount = pageLabel.split(CommonConstant.PAGE_LABEL_COUNT_TRIM_STRING)[1].trim();
			labelCount = StringUtils.deleteWhitespace(labelCount);
			int totalPageCountFromlabel = Integer.parseInt(labelCount);
			int entityCount = totalEntryInOnePage * (totalPageCountFromlabel - 1);
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.CLICK_ON_LAST_PAGINATION_ICON);
			testCaseDetailTO.getDriver().findElement(By.xpath(FunctionLocatorConstant.LAST_ICON_OF_PAGINATION)).click();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.GET_COUNT_OF_ENTRIES_LAST_PAGE);
			countOfEntryInlastPage = SelectPanelTableEntryUtility.getCountOfEntries(testCaseDetailTO,
					testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0));

			int entriesInLastPage = Integer.parseInt(countOfEntryInlastPage);
			totalEntityEntries = entityCount + entriesInLastPage;
		}
		return totalEntityEntries;
	}

	/**
	 * This method is used to get the count of entity reference from UI
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @return totalEntityEntries
	 */
	public static int getCountOfTotalEntityFromUI(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		Map<String, List<String>> panelLocator = ObjectRepoInitialization.masterLocatorMap
				.get(ObjectRepoInitialization.PANEL_LOCATOR);
		int totalEntryInOnePage;
		int totalEntityEntries;
		String pageLabel = null;

		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.COUNT_OF_ENTRIES_IN_ONE_PAGE);

		totalEntryInOnePage = Integer.parseInt(SelectPanelTableEntryUtility.getCountOfEntries(testCaseDetailTO,
				testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0)));

		pageLabel = testCaseDetailTO.getDriver()
				.findElement(By.xpath((panelLocator.get(FunctionLocatorConstant.CURRENT_PAGE_LABEL_XPATH)).get(0)))
				.getText();
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.PAGINATION_LABEL_IS + pageLabel);

		totalEntityEntries = getCountOfEntriesWithPagination(excelTestCaseFieldsTO, testCaseDetailTO,
				totalEntryInOnePage, pageLabel);
		return totalEntityEntries;
	}

	public static int getTotalEntriesPresetInTableForPOS(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		String locatorKey = excelTestCaseFieldsTO.getLocatorKey();
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		Map<String, List<String>> locatorMap = testCaseDetailTO.getLocatorHashMap();
		WebDriver driver = testCaseDetailTO.getDriver();
		Logger repoLogger = testCaseDetailTO.getReportingLogger();
		
		// ------------- new implementation -----------------
		boolean lastPageDisplay = false;
		int totalEntries;
		try {
			driver.findElement(By.xpath("//button[contains(@data-testid,'griddleGoToPage.last')]"))
					.isDisplayed();
			lastPageDisplay = true;
		} catch (Exception exp) {
		}
		
		if (lastPageDisplay) {
			WebElement element = driver
					.findElement(By.xpath("//button[contains(@data-testid,'griddleGoToPage.last')]"));
			String maxPage = element.getText();
			repoLogger.info("Total number of pages are: " + maxPage);
			int maxPageInt = Integer.parseInt(maxPage);
			int maxRowDisplayForSearchResultPOS = Integer.parseInt(driver
						.findElement(GenericAction.locator(locatorKey, locatorMap)).getAttribute(CommonConstant.GET_ATTRIBUTE_DATA_ROW_COUNT));
			totalEntries = (maxPageInt - 1) * maxRowDisplayForSearchResultPOS ;
			repoLogger.info("Click on Last page to get entries");
			element.click();
			String totalEntriesOnLastPage = driver
					.findElement(GenericAction.locator(locatorKey, locatorMap)).getAttribute(CommonConstant.GET_ATTRIBUTE_DATA_ROW_COUNT);
			int totalEntriesOnLastPageInt = Integer.parseInt(totalEntriesOnLastPage);
			totalEntries = totalEntries + totalEntriesOnLastPageInt;
			repoLogger.info("Total entries are: " + totalEntries);
			
		} else {
			List<WebElement> list = driver.findElements(By.xpath(
					"//div[contains(@data-testid,'griddlePaging')]//div[contains(@data-rxrole,'pages-center')]//button"));
			int totalPages = list.size();
			repoLogger.info("Total number of pages are: " + list.size());
			int maxRowDisplayForSearchResultPOS = Integer.parseInt(driver
					.findElement(GenericAction.locator(locatorKey, locatorMap)).getAttribute(CommonConstant.GET_ATTRIBUTE_DATA_ROW_COUNT));
			totalEntries = (totalPages - 1) * maxRowDisplayForSearchResultPOS;
			repoLogger.info("Click on Last page to get entries");
			driver.findElement(By.xpath(
					"(//div[contains(@data-testid,'griddlePaging')]//div[contains(@data-rxrole,'pages-center')]//button)["
							+ list.size() + "]")).click();
			String totalEntriesOnLastPage = driver
					.findElement(GenericAction.locator(locatorKey, locatorMap)).getAttribute(CommonConstant.GET_ATTRIBUTE_DATA_ROW_COUNT);
			int totalEntriesOnLastPageInt = Integer.parseInt(totalEntriesOnLastPage);
			totalEntries = totalEntries + totalEntriesOnLastPageInt;
			repoLogger.info("Total entries are: " + totalEntries);
		}
		
		return totalEntries;
	}

	/**
	 * This method validate the inputValue is Null or empty or with Space.
	 * 
	 * @param inputValue String
	 * @return boolean
	 */
	public static boolean isNullOREmpty(String inputValue) {

		if (StringUtils.isEmpty(inputValue) || inputValue.trim().length() == 0) {
			return true;
		}

		return false;
	}

	public static void logTransactions(WebDriver webDriver, String transactionName) {
		if (webDriver instanceof NLWebDriver) {
			NLWebDriver nldriver = (NLWebDriver) webDriver;
			nldriver.startTransaction(transactionName);
			// reportingLogger.info(transactionName);
		} else {
			// reportingLogger.info(transactionName);
		}
	}

	public static Map<String, String> readProperties(final String propertyRead) {
		Map<String, String> columnsData = new HashMap<>();
		try (FileReader reader = new FileReader(propertyRead)) {
			Properties properties = new Properties();
			properties.load(reader);
			Set set = properties.entrySet();
			Iterator itr = set.iterator();

			while (itr.hasNext()) {
				Map.Entry entry = (Map.Entry) itr.next();
				columnsData.put(entry.getKey().toString(), entry.getValue().toString());
			}
			return columnsData;
		} catch (IOException l_ex) {
			l_ex.printStackTrace();
		}
		return columnsData;
	}

	/**
	 * This method is used to get the download path for current domain/project
	 * 
	 * @param domain
	 * @return Download Path for respective domain
	 */
	public static String getDownloadPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.downloadFolderName + InitializeConstants.fileSeparator + FrameworkConstant.TODAY;
	}

	/**
	 * This method is used to get the test data document path for current
	 * domain/project
	 * 
	 * @param domain
	 * @return Test Data Document Path for respective domain
	 */
	public static String getPaymentScheduleDocumentPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testCaseDocuments + InitializeConstants.fileSeparator
				+ InitializeConstants.paymentScheduleDocumentsFolderName + InitializeConstants.fileSeparator;
	}

	/**
	 * This method is used to get the console logs path for given domain
	 * 
	 * @param domain
	 * @return Console logs Path for respective domain
	 */
	public static String getConsoleLogFolderPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.consoleLogsFolderName + InitializeConstants.fileSeparator;
	}

	/**
	 * This method is used to get the pre -requisites SQL's path for domain/project
	 * 
	 * @param domain
	 * @return Pre-requisite SQL Path for respective product
	 */
	public static String getPreRequisiteSQLPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		if (productInfo[1].equalsIgnoreCase(FrameworkConstant.CBI_ENV_NMAE)) {
			return CommonUtility.getPrerequisitePathForCBIDump(domainName, ApplicationContext.productVersion);
		} else if (productInfo[1].equalsIgnoreCase(FrameworkConstant.COMMON_ENV_NMAE)
				|| productInfo[1].equalsIgnoreCase(FrameworkConstant.MOTOR_ENV_NMAE)) {
			return CommonUtility.getPrerequisitePathForCommonDump(domainName, ApplicationContext.productVersion);
		} else {
			throw new CATTException("Invalid product name - " + domainName);
		}
	}

	/**
	 * This method is used to get the pre -requisites folder path for domain/project
	 * 
	 * @param domain
	 * @return Pre-requisite Folder Path for respective product
	 */
	public static String getPreRequisiteFolderPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisites_folder_name;
	}

	/**
	 * This method is used to get the test case dashboard excel path for current
	 * domain/project
	 * 
	 * @param domain
	 * @return Dashboard Path for respective domain
	 */
	public static String getDashboardExcelPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testCaseSummaryFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.dashboard_excel_name;
	}

	/**
	 * This method is used to get the test case environment details excel path for
	 * current domain/project
	 * 
	 * @param domain
	 * @return environment details excel Path for respective domain
	 */
	public static String getEnvDetailExcelPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testEnvironmentDetailFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.test_environment_details_excel_name;
	}

	/**
	 * This method returns the test cases path for respective domain
	 * 
	 * @param domainName
	 * @return test cases folder path [excel based test case]
	 */
	public static String getTestCaseFolderPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testCaseDocuments + InitializeConstants.fileSeparator
				+ InitializeConstants.testCasesFolderName + InitializeConstants.fileSeparator;
	}

	public static String getRestAPIRequestsFolderPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testCaseDocuments + InitializeConstants.fileSeparator
				+ InitializeConstants.apiRequestsFolderName + InitializeConstants.fileSeparator;
	}

	/**
	 * This method returns the path of the documents folder where we have kept
	 * documents to be uploaded
	 * 
	 * @param domainName
	 * @return test cases folder path [excel based test case]
	 */
	public static String getUploadDocumentPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.testCaseDocuments + InitializeConstants.fileSeparator
				+ InitializeConstants.upload_documents_folder_name + InitializeConstants.fileSeparator;
	}

	/**
	 * This method returns the path of the documents folder where we have kept dump
	 * validation excel file
	 * 
	 * @param domainName
	 * @return path to where dump summary excel is present
	 */
	public static String getDumpValidationPath(String domainName) {

		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		if (productInfo[1].equalsIgnoreCase(FrameworkConstant.CBI_ENV_NMAE)) {
			return CommonUtility.getPrerequisitePathForCBIDumpValidation(domainName, ApplicationContext.productVersion);
		} else if (productInfo[1].equalsIgnoreCase(FrameworkConstant.COMMON_ENV_NMAE)
				|| productInfo[1].equalsIgnoreCase(FrameworkConstant.MOTOR_ENV_NMAE)) {
			return CommonUtility.getPrerequisitePathForCommonDumpValidation(domainName,
					ApplicationContext.productVersion);
		} else {
			throw new CATTException("Invalid product name - " + domainName);
		}
	}

	/**
	 * This method returns the path of the folder where execution evidences will be
	 * stored respect to product
	 * 
	 * @param domainName
	 * @return Execution evidences folder path
	 */
	public static String getExecutionEvidencePath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator;
	}

	/**
	 * This method is used to get Neoload projects path as per respective domain
	 * 
	 * @param domainName
	 * @return Path where neoload projects will get created.
	 */
	public static String getNeoLoadProjectFolderPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.neoload_projects_directory_name + InitializeConstants.fileSeparator;
	}

	public static String getSourcePackageFolderPathForClient(String domainName, String testCaseType) {

		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.cattProjectName + InitializeConstants.fileSeparator + "src"
				+ InitializeConstants.fileSeparator + "main" + InitializeConstants.fileSeparator + "java"
				+ InitializeConstants.fileSeparator + "com" + InitializeConstants.fileSeparator + "tests"
				+ InitializeConstants.fileSeparator + "client" + InitializeConstants.fileSeparator
				+ domainName.trim().toLowerCase() + InitializeConstants.fileSeparator
				+ testCaseType.trim().toLowerCase();
	}

	public static String getAbsolutePathForErrorFile() {

		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.cattProjectName + InitializeConstants.fileSeparator + "log"
				+ InitializeConstants.fileSeparator + "Error_File.txt";

	}

	public static String getClassifiedNameOfPackageForClient(String domainName, String testcaseType) {
		return "com.tests.client." + domainName.trim().toLowerCase() + CommonConstant.DOT_OPERATOR
				+ testcaseType.trim().toLowerCase();
	}

	public static int convertStringToInteger(String stringValue, String fileName) {
		if (StringUtils.isNumeric(stringValue.trim())) {
			return Integer.parseInt(stringValue.trim());
		} else {
			logger.info("Please check the input data in property file " + fileName + " - given value is not numeric : "
					+ stringValue);
			logger.error("Please check the input data in property file - given value is not numeric : " + stringValue);
			throw new CATTException(
					"Please check the input data in property file - given value is not numeric : " + stringValue);
		}
	}

	public static String[] getDomainName() {
		Map<String, String> configMap = CommonUtility.readProperties(InitializeConstants.domainDetailsFileName);
		String domainDetails = configMap.get("DOMAIN");
		return CommonUtility.splitString(domainDetails, CommonConstant.COMMA_SEPERATOR);
	}

	public static String[] getProductEnvNames() {
		return new String[] { "Common", "CBI" };
	}

	public static String[] getProductExecutionEnvNames() {
		Map<String, String> configMap = CommonUtility
				.readProperties(InitializeConstants.ProductTestingEnvironmentInfoFileName);
		String domainDetails = configMap.get("ProductTestingEnvironment");
		return CommonUtility.splitString(domainDetails, CommonConstant.COMMA_SEPERATOR);
	}

	public static boolean checkForNumericValue(String value) {
		try {
			Integer.parseInt(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static int getGeneratedReferenceColumn(int referenceColumnNumber) {
		int excelColumnNumber = InitializeConstants.Generated_Reference_Column1;
		if (referenceColumnNumber == 1) {
			excelColumnNumber = InitializeConstants.Generated_Reference_Column1;
		} else if (referenceColumnNumber == 2) {
			excelColumnNumber = InitializeConstants.Generated_Reference_Column2;
		} else if (referenceColumnNumber == 3) {
			excelColumnNumber = InitializeConstants.Generated_Reference_Column3;
		} else {
			throw new CATTException(
					"Invalid input - There are only 3 generated reference column in Test_Case_Summary file");
		}
		return excelColumnNumber;
	}

	public static boolean checkForNumericFloatValue(String value) {
		try {
			Double.parseDouble(value);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	public static String getJenkinsEnvDetailsFilePath() {
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.jenkins_build_parameter_file_name;
	}

	public static boolean checkForProductsEnv(String envName) {
		if (envName.equalsIgnoreCase(FrameworkConstant.COMMON_TC_FOLDER_NAME)
				|| envName.equalsIgnoreCase(FrameworkConstant.CBI_TC_FOLDER_NAME)) {
			return true;
		} else {
			return false;
		}

	}

	public static String getPrerequisitePathForCBIDump(String domainName, String baseVersionForExecution) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		VersionComparator testExecutionVersion = new VersionComparator();
		VersionComparator defaultBaseVersionforQAdump = new VersionComparator();
		if (baseVersionForExecution.contains(CommonConstant.UNDER_SCORE)) {
			baseVersionForExecution = CommonUtility.splitStringUsingPattern(baseVersionForExecution,
					CommonConstant.UNDER_SCORE)[1];
		} else if (!baseVersionForExecution.contains(CommonConstant.DOT_OPERATOR)) {
			throw new CATTException(
					"Product version is not specified in correct format, It should be like for e.g., 4.7.1");
		}
		defaultBaseVersionforQAdump.setVersionValue(FrameworkConstant.VERSION_471);
		testExecutionVersion
				.setVersionValue(TestNGSuiteCreationUtility.getAccurateVersionValue(baseVersionForExecution));

		if (baseVersionForExecution.equals(FrameworkConstant.VERSION_470)) {
			logger.info(ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL + FrameworkConstant.QA_CBI470_SQL_FOLDER_NAME
					+ ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL_END);
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("CBI_470") + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_sql_folder_name + InitializeConstants.fileSeparator;
		} else if (baseVersionForExecution.equals(FrameworkConstant.VERSION_471)) {
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("CBI_471") + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_sql_folder_name + InitializeConstants.fileSeparator;
		} else {
			if (testExecutionVersion.compareTo(defaultBaseVersionforQAdump) >= 1) {
				return getCurrentPathOfDump(domainName, productInfo, testExecutionVersion);
			} else {
				throw new CATTException(
						"Product version cannot be less than 4.7.0 AND should have only one underscore in value");
			}
		}
	}

	/*
	 * Get the path for CBI dump rom version 472 and above
	 */
	private static String getCurrentPathOfDump(String domainName, String[] productInfo,
			VersionComparator testExecutionVersion) {
		String[] productNameInfo = CommonUtility.splitStringUsingPattern(domainName, CommonConstant.UNDER_SCORE);
		String productName = productNameInfo[1];
		String envName = productNameInfo[2];
		String currentDumpName = productName + CommonConstant.UNDER_SCORE + envName + CommonConstant.UNDER_SCORE
				+ StringUtils.replaceChars(testExecutionVersion.get(), CommonConstant.DOT_OPERATOR,
						CommonConstant.EMPTY_STRING);
		String finalDumpName;
		if (null != InitializeConstants.dumpInformation.get(currentDumpName)) {
			finalDumpName = InitializeConstants.dumpInformation.get(currentDumpName);
		} else {
			currentDumpName = "ACTIVE_" + productName + CommonConstant.UNDER_SCORE + envName;
			finalDumpName = InitializeConstants.dumpInformation.get(currentDumpName);
		}
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator + finalDumpName
				+ InitializeConstants.fileSeparator + InitializeConstants.pre_requisites_sql_folder_name
				+ InitializeConstants.fileSeparator;
	}

	/*
	 * Get the path for CBI dump from version 472 and above
	 */
	private static String getCurrentPathOfDumpValidation(String domainName, String[] productInfo,
			VersionComparator testExecutionVersion) {
		String[] productNameInfo = CommonUtility.splitStringUsingPattern(domainName, CommonConstant.UNDER_SCORE);
		String productName = productNameInfo[1];
		String envName = productNameInfo[2];
		String currentDumpName = productName + CommonConstant.UNDER_SCORE + envName + CommonConstant.UNDER_SCORE
				+ StringUtils.replace(testExecutionVersion.get(), CommonConstant.DOT_OPERATOR,
						CommonConstant.EMPTY_STRING);
		String finalDumpName;
		if (null != InitializeConstants.dumpInformation.get(currentDumpName)) {
			finalDumpName = InitializeConstants.dumpInformation.get(currentDumpName);
		} else {
			currentDumpName = "ACTIVE_" + productName + CommonConstant.UNDER_SCORE + envName;
			finalDumpName = InitializeConstants.dumpInformation.get(currentDumpName);
		}
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator + finalDumpName
				+ InitializeConstants.fileSeparator + InitializeConstants.dump_validation_sql_folder_name
				+ InitializeConstants.fileSeparator;
	}

	public static String getPrerequisitePathForCBIDumpValidation(String domainName, String baseVersionForExecution) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		VersionComparator testExecutionVersion = new VersionComparator();
		VersionComparator defaultBaseVersionforQAdump = new VersionComparator();
		if (baseVersionForExecution.contains(CommonConstant.UNDER_SCORE)) {
			baseVersionForExecution = CommonUtility.splitStringUsingPattern(baseVersionForExecution,
					CommonConstant.UNDER_SCORE)[1];
		} else if (!baseVersionForExecution.contains(CommonConstant.DOT_OPERATOR)) {
			throw new CATTException(
					"Product version is not specified in correct format, It should be like for e.g., 4.7.1");
		}

		defaultBaseVersionforQAdump.setVersionValue(FrameworkConstant.VERSION_471);
		testExecutionVersion
				.setVersionValue(TestNGSuiteCreationUtility.getAccurateVersionValue(baseVersionForExecution));

		if (baseVersionForExecution.equals(FrameworkConstant.VERSION_470)) {
			logger.info(ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL + FrameworkConstant.QA_CBI470_SQL_FOLDER_NAME
					+ ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL_END);
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("CBI_470") + InitializeConstants.fileSeparator
					+ InitializeConstants.dump_validation_sql_folder_name + InitializeConstants.fileSeparator;
		} else if (baseVersionForExecution.equals(FrameworkConstant.VERSION_471)) {
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("CBI_471") + InitializeConstants.fileSeparator
					+ InitializeConstants.dump_validation_sql_folder_name + InitializeConstants.fileSeparator;
		} else {
			if (testExecutionVersion.compareTo(defaultBaseVersionforQAdump) >= 1) {
				return getCurrentPathOfDumpValidation(domainName, productInfo, testExecutionVersion);
			} else {
				throw new CATTException("Product version cannot be less than 4.7.0");
			}
		}
	}

	public static String getPrerequisitePathForCommonDump(String domainName, String baseVersionForExecution) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		VersionComparator testExecutionVersion = new VersionComparator();
		VersionComparator defaultBaseVersionforQAdump = new VersionComparator();
		if (baseVersionForExecution.contains(CommonConstant.UNDER_SCORE)) {
			baseVersionForExecution = CommonUtility.splitStringUsingPattern(baseVersionForExecution,
					CommonConstant.UNDER_SCORE)[1];
		} else if (!baseVersionForExecution.contains(CommonConstant.DOT_OPERATOR)) {
			throw new CATTException("Product version is not specified in correct format, it should be like - '4.7.1'");
		}

		defaultBaseVersionforQAdump.setVersionValue(FrameworkConstant.VERSION_471);
		testExecutionVersion
				.setVersionValue(TestNGSuiteCreationUtility.getAccurateVersionValue(baseVersionForExecution));

		if (baseVersionForExecution.equals(FrameworkConstant.VERSION_470)) {
			logger.info(ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL + FrameworkConstant.QA_COMMON470_SQL_FOLDER_NAME
					+ ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL_END);
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("COMMON_470") + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_sql_folder_name + InitializeConstants.fileSeparator;
		} else if (baseVersionForExecution.equals(FrameworkConstant.VERSION_471)) {
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("COMMON_471") + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_sql_folder_name + InitializeConstants.fileSeparator;
		} else {
			if (testExecutionVersion.compareTo(defaultBaseVersionforQAdump) >= 1) {
				return getCurrentPathOfDump(domainName, productInfo, testExecutionVersion);
			} else {
				throw new CATTException(
						"Product version cannot be less than 4.7.0 OR should not be in any other format");
			}
		}
	}

	public static String getPrerequisitePathForCommonDumpValidation(String domainName, String baseVersionForExecution) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		VersionComparator testExecutionVersion = new VersionComparator();
		VersionComparator defaultBaseVersionforQAdump = new VersionComparator();
		if (baseVersionForExecution.contains(CommonConstant.UNDER_SCORE)) {
			baseVersionForExecution = CommonUtility.splitStringUsingPattern(baseVersionForExecution,
					CommonConstant.UNDER_SCORE)[1];
		}
		defaultBaseVersionforQAdump.setVersionValue(FrameworkConstant.VERSION_471);
		testExecutionVersion
				.setVersionValue(TestNGSuiteCreationUtility.getAccurateVersionValue(baseVersionForExecution));

		if (baseVersionForExecution.equals(FrameworkConstant.VERSION_470)) {
			logger.info(ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL + FrameworkConstant.QA_CBI470_SQL_FOLDER_NAME
					+ ReportLoggerConstant.FORMATING_PATTERN_FOR_SQL_END);
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("COMMON_470") + InitializeConstants.fileSeparator
					+ InitializeConstants.dump_validation_sql_folder_name + InitializeConstants.fileSeparator;
		} else if (baseVersionForExecution.equals(FrameworkConstant.VERSION_471)) {
			return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
					+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
					+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
					+ InitializeConstants.pre_requisites_folder_name + InitializeConstants.fileSeparator
					+ InitializeConstants.dumpInformation.get("COMMON_471") + InitializeConstants.fileSeparator
					+ InitializeConstants.dump_validation_sql_folder_name + InitializeConstants.fileSeparator;
		} else {
			if (testExecutionVersion.compareTo(defaultBaseVersionforQAdump) >= 1) {
				return getCurrentPathOfDumpValidation(domainName, productInfo, testExecutionVersion);
			} else {
				throw new CATTException("Product version cannot be less than 4.7.0");
			}
		}
	}

	public static String getTempFolderPathForLogger(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.consoleLogsFolderName + InitializeConstants.fileSeparator + "Temp_Prop_Files";
	}

	public static String getScrenshotFolderPath(String domainName, String workBookName, String workSheetName) {

		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.screenshotsFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator + workBookName
				+ InitializeConstants.fileSeparator + workSheetName;
	}

	/**
	 * This method return the properties file path.
	 * 
	 * @param workSheetName String
	 * @param domainName    String
	 * @return String
	 */
	public static String getPropertiesFilePath(final String workSheetName, final String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.consoleLogsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.tempPropertyFilesFolderName + InitializeConstants.fileSeparator + workSheetName
				+ ".properties";
	}

	public static String geBrowserInstanceLocation(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.browserInstanceFolderName + InitializeConstants.fileSeparator;
	}

	public static String getPathOfTestCaseLogs(String domainName, String workbookName, String worksheetName,
			String browserName) {

		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.consoleLogsFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator + workbookName
				+ InitializeConstants.fileSeparator + worksheetName + InitializeConstants.fileSeparator + worksheetName
				+ CommonConstant.UNDER_SCORE + browserName + CommonConstant.UNDER_SCORE + DateDefination.Time + ".html";
	}
	
	public static String getPathOfUAIDLogFile(String domainName, String workbookName, String worksheetName,
			String browserName) {

		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.consoleLogsFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator + workbookName
				+ InitializeConstants.fileSeparator + worksheetName + InitializeConstants.fileSeparator;
	}

	/**
	 * @param domainName
	 * @param workBookName
	 * @param workSheetName
	 * @return
	 */
	public static String getScreenShotFilePath(final String domainName, final String workBookName,
			final String workSheetName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.screenshotsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.fileSeparator + DateDefination.execution_evidences_date_format
				+ InitializeConstants.fileSeparator + workBookName + InitializeConstants.fileSeparator + workSheetName
				+ InitializeConstants.fileSeparator + workSheetName + CommonConstant.UNDER_SCORE
				+ System.currentTimeMillis() + ".jpg";
	}

	public static String getStringValueFromText(String[] summaryReporToken, String prefix, String suffix,
			int[] occurenceslist) {
		String summaryReport = null;
		String resultValue = null;

		for (String summaryReportLine : summaryReporToken) {
			if (summaryReportLine.matches(".*\\w.*")) {
				summaryReport = summaryReport + summaryReportLine.replace('\u00A0', ' ').trim() + "\n";
			}
		}

		if (StringUtils.ordinalIndexOf(summaryReport, prefix, occurenceslist[0]) == -1
				|| StringUtils.ordinalIndexOf(summaryReport, suffix, occurenceslist[1]) == -1) {
			throw new CATTException(ReportLoggerConstant.PRIFIX_SUFFIX_OCCURENCE_ISSUE);
		}

		if (summaryReport.contains(prefix)) {
			if (suffix == null || suffix.trim().length() == 0) {
				resultValue = summaryReport.substring(
						StringUtils.ordinalIndexOf(summaryReport, prefix, occurenceslist[0]) + prefix.length(),
						summaryReport.length()).trim();

			} else {
				if (summaryReport.indexOf(suffix) != -1) {
					resultValue = summaryReport.substring(
							StringUtils.ordinalIndexOf(summaryReport, prefix, occurenceslist[0]) + prefix.length(),
							StringUtils.ordinalIndexOf(summaryReport, suffix, occurenceslist[1])).trim();

				}
			}
		}

		return resultValue;
	}

	public static String[] getProductInfoFromName(String domainName) {
		String[] productInfo = CommonUtility.splitStringUsingPattern(domainName, CommonConstant.UNDER_SCORE);
		if (productInfo.length == 3) {
			String productName = productInfo[0] + CommonConstant.UNDER_SCORE + productInfo[1];
			String envName = productInfo[2];
			return new String[] { productName, envName };
		} else {
			throw new CATTException("Product name is not entered correctly : " + domainName);
		}

	}

	/**
	 * This method is used to get Neoload projects path as per respective domain
	 * 
	 * @param domainName
	 * @return Path where neoload projects will get created.
	 */
	public static String getObjectRepositoryPath(String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + InitializeConstants.objectRepositoryFolderName
				+ InitializeConstants.fileSeparator + InitializeConstants.object_repository_excel_name;
	}

	public static String checkFileIsEmptyORNot(String downlodedPath, Logger reportinglogger, String fileparameters[]) {
		File file = new File(downlodedPath);
		File[] filesList = file.listFiles();
		String filestatus = CommonConstant.FALSE_VALUE;
		reportinglogger.info(ReportLoggerConstant.TOTAL_FILES_LOCATION + downlodedPath + ReportLoggerConstant.ARE_MSG
				+ filesList.length);
		String filestatus1 = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, reportinglogger,
				fileparameters[0]);
		String filePath = downlodedPath + InitializeConstants.fileSeparator + fileparameters[0];
		if (filestatus1.equals(CommonConstant.TRUE_VALUE)) {
			try {
				if (fileparameters[0].contains(CommonConstant.XLS_FILE_EXTENSION)
						|| fileparameters[0].contains(CommonConstant.XLSX_FILE_EXTENSION)) {
					filestatus = ExcelReader.isExcelFilesEmpty(filePath, fileparameters[1], reportinglogger);
				} else if (fileparameters[0].contains(CommonConstant.LOG_FILE_EXTENSION)
						|| fileparameters[0].contains(CommonConstant.TXT_FILE_EXTENSION)) {
					filestatus = isLogFileEmpty(filePath);
				} else if (fileparameters[0].contains(CommonConstant.PDF_FILE_EXTENSION)
						|| fileparameters[0].contains(CommonConstant.PDF_FILE_EXTENSION1)) {
					filestatus = isPDFFileEmpty(filePath);
				} else if (fileparameters[0].contains(CommonConstant.CSV_FILE_EXTENSION)) {

				}
			} catch (ArrayIndexOutOfBoundsException e) {
				reportinglogger.info(ErrorMessageConstant.PLEASE_CHECK_INPUT_PARAMETERS);
			} catch (NullPointerException e) {
				reportinglogger.info(ErrorMessageConstant.PLEASE_CHECK_INPUTPARAMETERS);
			}
		} else {
			Assert.fail(ErrorMessageConstant.REQURIED_FILE_IS_NOT_MSG);
		}
		return filestatus;
	}

	public static String isPDFFileEmpty(String filePath) {
		String fileStatus = CommonConstant.FALSE_VALUE;
		try {
			PDDocument document = PDDocument.load(new File(filePath));
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition(true);
			PDFTextStripper Tstripper = new PDFTextStripper();
			String parsedText = Tstripper.getText(document);
			if (!parsedText.equals(null) && parsedText.trim().length() != 0) {
				fileStatus = CommonConstant.TRUE_VALUE;
			}
		} catch (IOException e) {
			logger.info(ErrorMessageConstant.ISSUE_OCCURED_WHILE_READ_MSG);
			e.printStackTrace();
		}
		return fileStatus;
	}

	public static String isLogFileEmpty(String filePath) {
		String fileStatus = CommonConstant.FALSE_VALUE;
		try (FileReader content = new FileReader(filePath)) {
			if (content.read() == -1) {
				logger.info(ErrorMessageConstant.DOWNLOD_FILE_EMPTY_MSG);
			} else {
				fileStatus = CommonConstant.TRUE_VALUE;
			}
		} catch (IOException e) {
			logger.info(ErrorMessageConstant.ISSUE_OCCURED_WHILE_READ_MSG);
			e.printStackTrace();
		}
		return fileStatus;
	}

	public static String getBrowserDriverLocationPath() {
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
				+ InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator
				+ "GoogleChromePortable\\App\\Chrome-bin\\chrome.exe";
	}

	public static String getEdgeBrowserDriverLocationPath() {
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
				+ InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.msEdgePortable + InitializeConstants.fileSeparator + "Edge_bin\\msedge.exe";
	}

	/**
	 * @return This method will return EdgeProfileLoationPath
	 */
	public static String getEdgeProfileLocationPath() {
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
				+ InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
				+ InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.msEdgePortable + InitializeConstants.fileSeparator
				+ InitializeConstants.msEdgeProfile + InitializeConstants.fileSeparator
				+ InitializeConstants.msUserData;
	}

	public static String getApiResponsePath(final String domainName) {
		String[] productInfo = CommonUtility.getProductInfoFromName(domainName);
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.apiResponsesFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator;
	}

}
