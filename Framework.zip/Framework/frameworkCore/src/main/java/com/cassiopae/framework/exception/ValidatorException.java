/**
 *
 */
package com.cassiopae.framework.exception;

/**
 * @author nbhil
 *
 */
public class ValidatorException extends CATTException {

	private static final long serialVersionUID = -4598873066371924477L;

	public ValidatorException(final String message) {
		super(message);
	}

	public ValidatorException() {
		super();
	}

}
