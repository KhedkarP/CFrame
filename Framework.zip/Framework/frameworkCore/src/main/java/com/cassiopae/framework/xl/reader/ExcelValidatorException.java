/**
 *
 */
package com.cassiopae.framework.xl.reader;

import com.cassiopae.framework.exception.ValidatorException;

/**
 * @author nbhil
 */

public class ExcelValidatorException extends ValidatorException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8149009274354566684L;

	public ExcelValidatorException( final String message ) {
		super( message );
	}

	public ExcelValidatorException() {
		super();
	}
}
