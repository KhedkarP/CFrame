package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class ReceivablesFunctions {
	/*
	 * Receivables Functions
	 */

	private static Map<String, List<String>> receivablesLocatorMap = ObjectRepoInitialization.masterLocatorMap
			.get(ObjectRepoInitialization.RECEIVABLE_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger logger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.RECEIVABLE_MOUSE_HOVER,
				FunctionLocatorConstant.RECEIVABLES_MENU, receivablesLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.RECEIVABLESUB_MENU,
				FunctionLocatorConstant.RECEIVABLES_SUB_MENU, receivablesLocatorMap, driver, logger);
	}

	public static void open(String reference, ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_RECEIVABLE_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.RECEIVABLES_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(receivablesLocatorMap);
		GenericAction.enterValueIn(reference, excelTestCaseFields, testCaseDetail);

		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_RECEIVABLE_REFERENCE_ICON,
				FunctionLocatorConstant.RECEIVABLES_SEARCH_ICON, receivablesLocatorMap, testCaseDetail.getDriver(),
				testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_RECEIVABLE_REFERENCE_HYPERLINK + reference,
				FunctionLocatorConstant.RECEIVABLES_REFERNCE_HYPERLINK, receivablesLocatorMap,
				testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
