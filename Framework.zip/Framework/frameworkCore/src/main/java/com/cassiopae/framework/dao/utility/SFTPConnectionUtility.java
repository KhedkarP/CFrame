package com.cassiopae.framework.dao.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.testng.Assert;

import com.cassiopae.custom.action.constant.ServerConnectionConstants;
import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.TestNGSuiteCreationUtility;
import com.cassiopae.selenium.utils.excel.ExcelOperation;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SFTPConnectionUtility {

	static long finalCount = 0;
	static long start = -1;

	public static String linuxPathSeparator = "/";

	private static Logger logger = LogManager.getLogger(SFTPConnectionUtility.class);
	private static Logger sqlLogger = LogManager.getLogger("SQLLogger");

	public void init(int op, String src, String dest, long max) {
		start = System.currentTimeMillis();
	}

	public boolean count(long count) {
		finalCount += count;
		/*
		 * long took = (System.currentTimeMillis() - start) / 1000; if (took > 0) {
		 * Log.w("SFTP", "Transferred so far " + finalCount + " at speed bytes/sec " +
		 * (finalCount / took)); }
		 */
		return true;
	}

	public static void downloadFileFromAppServer(String remotePath, String destinationPath) {
		logger.info(ServerConnectionConstants.CONNECTING_TO + ApplicationContext.applicationServerHostname);
		Session session = null;
		ChannelExec execChannel = null;
		ChannelSftp sftpChannel = null;
		try {
			session = SFTPConnectionUtility.createSessionObject();
			SFTPConnectionUtility.configureSessionObject(session);
			execChannel = SFTPConnectionUtility.execChannelCreation(session);
			sftpChannel = SFTPConnectionUtility.sftpChannelCreation(session);
			SFTPConnectionUtility.configureChannel(sftpChannel);
			String navigateCommand = "cd " + remotePath;
			logger.info("Batch command for navigation is: " + navigateCommand);
			execChannel.setCommand(navigateCommand);
			execChannel.setInputStream(null);
			execChannel.setErrStream(System.err);
			try {
				execChannel.connect();
			} catch (JSchException e2) {
				logger.error(e2);
				throw new CATTException(e2.getMessage());
			}
			// printTerminalOutput(execChannel);
			try {
				recursiveFolderDownload(remotePath, destinationPath, sftpChannel);
			} catch (SftpException e) {
				logger.info("Error occured while copying files: ", e);
			}
			closeJSchConnections(session, execChannel, sftpChannel);
		} catch (Exception exp) {
			closeJSchConnections(session, execChannel, sftpChannel);
		}

	}

	private static void printTerminalOutput(ChannelExec execChannel) {
		try {
			InputStream monitorLogs = execChannel.getInputStream();
			BufferedReader logReader = new BufferedReader(new InputStreamReader(monitorLogs));
			String logLine;

			while (logReader.readLine() != null) {
				sqlLogger.info(logReader.readLine());
			}

		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	private static void closeJSchConnections(Session session, ChannelExec execChannel, ChannelSftp sftpChannel) {
		// Close the connections
		logger.info("disconnecting execChannel...");
		if (null != execChannel) {
			execChannel.disconnect();
		}
		logger.info("disconnecting sftpChannel...");
		if (null != sftpChannel) {
			sftpChannel.disconnect();
		}
		logger.info("disconnecting session...");
		if (null != session) {
			session.disconnect();
		}
	}

	public static List<String> createListOfSQLFileNameForDBServer(Map<String, LinkedList<String>> proceduDetails) {
		List<String> sqls = new ArrayList<>();
		for (Map.Entry<String, LinkedList<String>> entry : proceduDetails.entrySet()) {
			if (entry.getValue().get(4).equalsIgnoreCase(FrameworkConstant.EXECUTED_ON_DB_SERVER)) {
				sqls.add(entry.getValue().get(1));
			}
		}
		sqls.add("EnvironmentDetails.sh");
		sqls.add("Run.sh");
		sqls.add("Execute_Sql_Scripts.sh");
		return sqls;
	}

	/**
	 * This method is called recursively to download the folder content from SFTP
	 * server
	 * 
	 * @param sourcePath
	 * @param destinationPath
	 * @throws SftpException
	 */
	@SuppressWarnings("unchecked")
	private static void recursiveFolderDownload(String sourcePath, String destinationPath, ChannelSftp sftpChannel)
			throws SftpException {
		Vector<ChannelSftp.LsEntry> fileAndFolderList = sftpChannel.ls(sourcePath); // Let list of folder content

		// Iterate through list of folder content
		for (ChannelSftp.LsEntry item : fileAndFolderList) {
			String fileName = item.getFilename();
			if (!item.getAttrs().isDir()) { // Check if it is a file (not a directory).
				if (!(new File(destinationPath + InitializeConstants.fileSeparator + fileName)).exists() || (item
						.getAttrs()
						.getMTime() > Long.valueOf(
								new File(destinationPath + InitializeConstants.fileSeparator + fileName).lastModified()
										/ (long) 1000)
								.intValue())) { // Download only if changed later.

					new File(destinationPath + InitializeConstants.fileSeparator + item.getFilename());
					logger.info("Copying file: " + sourcePath + linuxPathSeparator + item.getFilename());
					sftpChannel.get(sourcePath + linuxPathSeparator + item.getFilename(),
							destinationPath + InitializeConstants.fileSeparator + item.getFilename());
				}
			} else if (!(".".equals(item.getFilename()) || "..".equals(item.getFilename()))) {
				logger.info("Creating new directory on local system : " + destinationPath
						+ InitializeConstants.fileSeparator + item.getFilename());
				new File(destinationPath + InitializeConstants.fileSeparator + item.getFilename()).mkdirs();
				recursiveFolderDownload(sourcePath + linuxPathSeparator + item.getFilename(),
						destinationPath + InitializeConstants.fileSeparator + item.getFilename(), sftpChannel);
			}
		}

	}

	/**
	 * This method is called recursively to download the folder content from SFTP
	 * server
	 * 
	 * @param sourcePath
	 * @param destinationPath
	 * @throws SftpException
	 */
	@SuppressWarnings("unchecked")
	public static void downloadLogFiles(String sourcePath, String destinationPath) throws SftpException {
		logger.info(ServerConnectionConstants.CONNECTING_TO + ApplicationContext.applicationServerHostname);
		Session session = SFTPConnectionUtility.createSessionObject();
		SFTPConnectionUtility.configureSessionObject(session);
		ChannelSftp sftpChannel = SFTPConnectionUtility.sftpChannelCreation(session);
		SFTPConnectionUtility.configureChannel(sftpChannel);
		Vector<ChannelSftp.LsEntry> fileAndFolderList = sftpChannel.ls(sourcePath); // Let list of folder content
		try {
			// Iterate through list of folder content
			for (ChannelSftp.LsEntry item : fileAndFolderList) {
				String fileName = item.getFilename();
				if (!item.getAttrs().isDir()) {
					if (fileName.endsWith(".log")) {
						new File(destinationPath + InitializeConstants.fileSeparator + fileName);
						logger.info("Copying file: " + sourcePath + linuxPathSeparator + fileName);
						sftpChannel.get(sourcePath + linuxPathSeparator + fileName,
								destinationPath + InitializeConstants.fileSeparator + fileName);
					}
				} else if (!(".".equals(fileName) || "..".equals(fileName))) {
					logger.info("Creating new directory on local system : " + destinationPath
							+ InitializeConstants.fileSeparator + fileName);
					new File(destinationPath + InitializeConstants.fileSeparator + fileName).mkdirs();
					recursiveFolderDownload(sourcePath + linuxPathSeparator + fileName,
							destinationPath + InitializeConstants.fileSeparator + fileName, sftpChannel);
				}
			}
			sftpChannel.disconnect();
			session.disconnect();
		} catch (Exception exp) {
			sftpChannel.disconnect();
			session.disconnect();
			throw new CATTException(exp.getMessage());
		}
	}

	public static void executeSQLusingJDBC(String[] domains) {
		sqlLogger.debug(ReportLoggerConstant.FORMAT_MESSAGE + ErrorMessageConstant.EXECUTION_STARTED_FOR_PRE_REQUISITES
				+ domains.length + CommonConstant.LINE_SEPERATER);
		Connection moConnection = null;
		Connection boConnection = null;
		Map<String, String> appDetail = new HashMap<>();
		Map<String, LinkedList<String>> procedureDetails = null;
		for (int i = 0; i < domains.length; i++) {
			sqlLogger.info(ReportLoggerConstant.FORMAT_MESSAGE_2 + ReportLoggerConstant.PROCEDURE_START_EXECUTION
					+ domains[i] + ReportLoggerConstant.FORMAT_MESSAGE_2);
			ApplicationConstant.initializeEnvspecificTestDataPath = DomainInitialization
					.initializeDomainTestDataExcelPath(domains[i]);
			ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
					.initializeDomainTestEnvDetailExcelPath(domains[i]);

			String sqlFilesPath = DomainInitialization.initializeDomainWisePreRequisiteSQLPath(domains[i]);
			FileUtility.createBatchSQLFile(sqlFilesPath + "BATCHES_PATH.SQL",
					ApplicationContext.collectionBatchPathQuery, sqlLogger);

			String sqlExcelDetailFilePath = sqlFilesPath
					+ InitializeConstants.dashboardExcelDetails.get("SQLExcelFileName");
			sqlLogger.info(ErrorMessageConstant.SQL_PRE_REQUISITE_LOCATION + sqlFilesPath);
			try {
				procedureDetails = ExcelOperation.getProcedureNames(
						InitializeConstants.dashboardExcelDetails.get("SQLExcelSheetName"), sqlExcelDetailFilePath,
						appDetail);
			} catch (Exception e) {
				sqlLogger.error(ErrorMessageConstant.ERROR_WHILE_READING_EXCEL_FILE, e);
				Assert.fail(ErrorMessageConstant.ERROR_WHILE_READING_EXCEL_FILE + e.getMessage());
			}
			try {
				if (!procedureDetails.isEmpty() && appDetail.containsKey(DBConstant.MO_MODULE)) {
					moConnection = DatabaseUtility.getConnection(DBConstant.MO_MODULE);
				}
				if (!procedureDetails.isEmpty() && appDetail.containsKey(DBConstant.BO_MODULE)) {
					boConnection = DatabaseUtility.getConnection(DBConstant.BO_MODULE);
				}
			} catch (SQLException e) {
				sqlLogger.error(e.getMessage(), e);
				Assert.fail(ErrorMessageConstant.DATABASE_CONNECTION_ERROR_MESSAGE + e.getMessage());
			}
			SQLLauncherUtility.executeSQLFiles(moConnection, boConnection, procedureDetails, sqlFilesPath);
		}
		if (!appDetail.isEmpty()) {
			SQLLauncherUtility.closeConnections(moConnection, boConnection, appDetail);
		}
	}

	public static void executeSQLOnDBServer(String[] domains) {
		sqlLogger.debug(ReportLoggerConstant.FORMAT_MESSAGE + ErrorMessageConstant.EXECUTION_STARTED_FOR_PRE_REQUISITES
				+ domains.length + CommonConstant.LINE_SEPERATER);
		Map<String, String> appDetail = new HashMap<>();
		Map<String, LinkedList<String>> procedureDetails = null;
		for (int i = 0; i < domains.length; i++) {
			String productName = domains[i];
			sqlLogger.info(
					ReportLoggerConstant.FORMAT_MESSAGE_2 + ReportLoggerConstant.PROCEDURE_START_EXECUTION_DB_SERVER
							+ domains[i] + ReportLoggerConstant.FORMAT_MESSAGE_2);
			ApplicationConstant.initializeEnvspecificTestDataPath = DomainInitialization
					.initializeDomainTestDataExcelPath(productName);
			ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
					.initializeDomainTestEnvDetailExcelPath(productName);

			String sqlFilesPath = DomainInitialization.initializeDomainWisePreRequisiteSQLPath(productName);
			FileUtility.createBatchSQLFile(sqlFilesPath + "BATCHES_PATH.SQL",
					ApplicationContext.collectionBatchPathQuery, sqlLogger);
			String sqlExcelDetailFilePath = sqlFilesPath
					+ InitializeConstants.dashboardExcelDetails.get("SQLExcelFileName");
			sqlLogger.info(ErrorMessageConstant.SQL_PRE_REQUISITE_LOCATION + sqlFilesPath);

			try {
				procedureDetails = ExcelOperation.getProcedureNames(
						InitializeConstants.dashboardExcelDetails.get("SQLExcelSheetName"), sqlExcelDetailFilePath,
						appDetail);
			} catch (Exception e) {
				sqlLogger.error(ErrorMessageConstant.ERROR_WHILE_READING_EXCEL_FILE, e);
				Assert.fail(ErrorMessageConstant.ERROR_WHILE_READING_EXCEL_FILE + e.getMessage());
			}
			// executeUsingJsch(domains, procedureDetails, i, sqlFilesPath);
			executeSQLviaSQLPLUS(procedureDetails, productName);

		}
	}

	public static void executeSQLviaSQLPLUS(Map<String, LinkedList<String>> procedureDetails, String productName) {
		String sqlPlusBatchFileName = "SQLPlusScripts.bat";
		String sqlPlusBatFilePath = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ sqlPlusBatchFileName;
		String sqlPlusBatFileLocalPath = CommonUtility.getPreRequisiteFolderPath(productName)
				+ InitializeConstants.fileSeparator + sqlPlusBatchFileName;

		if (FileUtility.createSQLplusBatFile(sqlPlusBatFilePath, procedureDetails, productName)
				&& FileUtility.createSQLplusBatFile(sqlPlusBatFileLocalPath, procedureDetails, productName)) {
			sqlLogger.info("SQLPlusScripts.bat file created successfully at location : " + sqlPlusBatFilePath);
			sqlLogger.info("SQLPlusScripts.bat file created successfully at location : " + sqlPlusBatFileLocalPath);
			/*
			 * Process p; try { sqlLogger.info("Executing sqlplus batch file located at : "
			 * + sqlPlusBatFilePath); p = Runtime.getRuntime().exec(sqlPlusBatFilePath);
			 * p.waitFor(); printBatchLogOnConsole(p); sqlLogger.info("Executed " +
			 * sqlPlusBatchFileName + " file successfully"); } catch (IOException |
			 * InterruptedException e) {
			 * sqlLogger.info("!!!!! Error occured while executing sqlplus batch file : " +
			 * sqlPlusBatFilePath); }
			 */
		} else {
			sqlLogger.info("!!!!!!!! Error occured while creating SQLplus .bat file  !!!!!!");
		}
	}

	private static void printBatchLogOnConsole(Process p) throws IOException {
		String line;
		try (BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
			while ((line = input.readLine()) != null) {
				sqlLogger.info(line);
			}
		}
		try (BufferedReader input = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
			while ((line = input.readLine()) != null) {
				sqlLogger.info(line);
			}
		}
	}

	public static String[] configureEnvironmentValues(String[] envNames) {
		String[] domains;
		if (envNames.length == 0) {
			domains = TestNGSuiteCreationUtility.setProductExecutionEnv(envNames);
		} else {
			domains = envNames;
		}
		return domains;
	}

	/**
	 * This method is used to configure session to increase buffer size during copy
	 * operation
	 * 
	 * @param sftpChannel
	 */
	public static void configureChannel(ChannelSftp sftpChannel) {
		try {
			sftpChannel.getSession().setConfig("max_input_buffer_size", "increased_size");
		} catch (JSchException e1) {
			logger.error(ServerConnectionConstants.SESSION_CONFIGURATION_ERROR_MESSAGE + e1.getMessage(), e1);
		}
	}

	/**
	 * This method closes sftpChannel connection and Session associated with it
	 * 
	 * @param sftpChannel
	 */
	public static void closeConnection(ChannelSftp sftpChannel) {
		try {
			sftpChannel.getSession().disconnect();
			sftpChannel.disconnect();
		} catch (JSchException jexp) {
			logger.error(ServerConnectionConstants.CLOSE_CONNECTION_ERROR_MESSAGE + jexp.getMessage(), jexp);
		}
	}

	/**
	 * This method copy file from local system to application server
	 * 
	 * @param filePathOnLocal directory location on local system
	 * @param remoteDirPath   directory location on app server
	 * @param sftpChannel     sftp channel object
	 * @param log             logger to log test case step
	 */
	public static void uploadFileOnServer(String filePathOnLocal, String remoteDirPath, ChannelSftp sftpChannel,
			Logger log) {
		try {
			sftpChannel.cd(remoteDirPath);
			File fileName = new File(filePathOnLocal);
			try (FileInputStream inputStream = new FileInputStream(fileName);) {
				sftpChannel.put(inputStream, fileName.getName(), ChannelSftp.OVERWRITE);
				sftpChannel.chmod(Integer.parseInt(ServerConnectionConstants.FILE_PERMISSION_VALUE, 8),
						remoteDirPath + CommonConstant.FORWARD_SLASH + fileName.getName());
			}
			logger.info(ServerConnectionConstants.FILE_UPLOAD_SUCCESS_MESSAGE_ALONG_WITH_LOCATION
					+ fileName.getAbsolutePath());
			log.info(ServerConnectionConstants.FILE_COPY_MESSAGE + fileName.getName()
					+ ServerConnectionConstants.AT_LOCATION + remoteDirPath);

		} catch (Exception e) {
			logger.error(e);
		}
	}

	/**
	 * This method will create directory on linux app server
	 * 
	 * @param remoteDirPath   path to where directory needs to be created
	 * @param dirCreationFlag if set to True, then directory will be created
	 *                        otherwise no
	 * @param sftpChannel     channel object to perform operation on server
	 */
	public static void createDirectoryIfnotPresentOnServer(String remoteDirPath, boolean dirCreationFlag,
			ChannelSftp sftpChannel) {

		try {
			sftpChannel.lstat(remoteDirPath);
		} catch (Exception e) {
			dirCreationFlag = true;
			logger.info(ServerConnectionConstants.DIREXTORY_CREATION_MESSAGE + remoteDirPath);
		}
		if (dirCreationFlag) {
			try {
				sftpChannel.mkdir(remoteDirPath);
				sftpChannel.chmod(Integer.parseInt(ServerConnectionConstants.FILE_PERMISSION_VALUE, 8), remoteDirPath);
			} catch (SftpException e1) {
				logger.error(ServerConnectionConstants.DIREXTORY_CREATION_ERROR_MESSAGE + remoteDirPath, e1);
			}
		}
	}

	public static void configureSessionObject(Session session) {
		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword(ApplicationContext.applicationServerPassword);
	}

	/**
	 * 
	 * @param session
	 * @return
	 */
	public static ChannelSftp sftpChannelCreation(Session session) {
		Channel channel;
		ChannelSftp sftpChannel;
		try {
			if(! session.isConnected() ) {
				session.connect();
			}
			channel = session.openChannel(ServerConnectionConstants.SFTP);
			channel.connect();
			sftpChannel = (ChannelSftp) channel;
			logger.info(ServerConnectionConstants.SERVER_CONNECTION_CREATION_MESSAGE
					+ ApplicationContext.applicationServerHostname);
		} catch (JSchException e) {
			logger.error(ServerConnectionConstants.SERVER_CONNECTION_ERROR_MESSAGE + e.getMessage());
			throw new CATTException(ServerConnectionConstants.SERVER_CONNECTION_ERROR_MESSAGE + e.getMessage());
		}
		return sftpChannel;
	}

	/**
	 * 
	 * @param session
	 * @return
	 */
	public static ChannelExec execChannelCreation(Session session) {
		Channel channel;
		ChannelExec execChannel;
		try {
			session.connect();
			channel = session.openChannel(ServerConnectionConstants.EXEC);
			channel.connect();
			execChannel = (ChannelExec) channel;
			logger.info(ServerConnectionConstants.SERVER_CONNECTION_CREATION_MESSAGE
					+ ApplicationContext.applicationServerHostname);
		} catch (JSchException e) {
			logger.error(ServerConnectionConstants.SERVER_CONNECTION_ERROR_MESSAGE + e.getMessage());
			throw new CATTException(ServerConnectionConstants.SERVER_CONNECTION_ERROR_MESSAGE + e.getMessage());
		}
		return execChannel;
	}

	/**
	 * This method is used to create session with linux server
	 * 
	 * @return Session object used for further processing
	 */
	public static Session createSessionObject() {
		JSch jsch = new JSch();
		try {
			Session session = jsch.getSession(ApplicationContext.applicationServerUsername,
					ApplicationContext.applicationServerHostname,
					Integer.parseInt(ApplicationContext.applicationServerPort.trim()));
			return session;
		} catch (JSchException e) {
			logger.error("Error occured while initiating the Session object with given username: "
					+ ApplicationContext.applicationServerUsername + " , host: "
					+ ApplicationContext.applicationServerHostname + " and port: "
					+ ApplicationContext.applicationServerPort.trim() + e.getMessage());
			throw new CATTException("Error occured while initiating the Session object with given username -"
					+ ApplicationContext.applicationServerUsername + " , host : "
					+ ApplicationContext.applicationServerHostname + " and port: "
					+ ApplicationContext.applicationServerPort.trim() + e.getMessage());
		}
	}

	/**
	 * This method is used to download logs from app server
	 * 
	 * @param products
	 */
	public static String downloadLogsFromLinuxServer(String productName) {
		ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
				.initializeDomainTestEnvDetailExcelPath(productName);
		ApplicationConstant.objectRepositoryPath = DomainInitialization.initializeProductWiseORFilePath(productName);
		String appInstallationDirectorty = StringUtils.upperCase(ApplicationContext.applicationServerUsername);
		String destinationPath = CommonUtility.getExecutionEvidencePath(productName) + "ApplicationServerLogs"
				+ InitializeConstants.fileSeparator + appInstallationDirectorty;
		FileUtility.createNewDirectory(destinationPath);
		Map<String, String> map = new HashMap<>();

		// structure is different for above 480 versions and below 480 version
		// populate below list accordingly
		String linuxInstallationDirectory = "/opt/cassiopae/";
		String logsFolderName = "/logs";
		if (!productName.contains("REAL")) {
			String posContextName = "POS" + appInstallationDirectorty;
			String sourcePathPOSLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
					+ SFTPConnectionUtility.linuxPathSeparator + posContextName + logsFolderName;
			map.put(sourcePathPOSLogs, destinationPath + InitializeConstants.fileSeparator + posContextName);
			String configConsoleContextName = "CCNF" + appInstallationDirectorty;
			String sourcePathCCNFLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
					+ SFTPConnectionUtility.linuxPathSeparator + posContextName + logsFolderName;
			map.put(sourcePathCCNFLogs, destinationPath + InitializeConstants.fileSeparator + configConsoleContextName);
		}
		
		String sourcePathBOLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
				+ SFTPConnectionUtility.linuxPathSeparator + ApplicationContext.username_DB_BO + logsFolderName;
		String sourcePathMOLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
				+ SFTPConnectionUtility.linuxPathSeparator + ApplicationContext.username_DB_MO + logsFolderName;
		String finEngineFolderName = "FE" + appInstallationDirectorty;
		String sourcePathFinEngineLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
				+ SFTPConnectionUtility.linuxPathSeparator + finEngineFolderName + logsFolderName;
		
		String webServiceLogsFolderName = "WS" + appInstallationDirectorty;
		String sourcePathwebServiceLogs = linuxInstallationDirectory + ApplicationContext.applicationServerUsername
				+ SFTPConnectionUtility.linuxPathSeparator + webServiceLogsFolderName + logsFolderName;
		map.put(sourcePathBOLogs,
				destinationPath + InitializeConstants.fileSeparator + ApplicationContext.username_DB_BO);
		map.put(sourcePathMOLogs,
				destinationPath + InitializeConstants.fileSeparator + ApplicationContext.username_DB_MO);
		map.put(sourcePathFinEngineLogs, destinationPath + InitializeConstants.fileSeparator + finEngineFolderName);
		//map.put(sourcePathwebServiceLogs, destinationPath + InitializeConstants.fileSeparator + webServiceLogsFolderName);

		for (Map.Entry<String, String> entry : map.entrySet()) {
			String componentName = entry.getKey();
			logger.info("Copying logs of component: " + componentName);
			try {
				FileUtility.createNewDirectory(entry.getValue());
				SFTPConnectionUtility.downloadLogFiles(componentName, entry.getValue());
			} catch (SftpException exp) {
				logger.info("************ Error occured while copying logs of component: " + exp.getMessage());
				logger.error(exp);
			}
		}
		return destinationPath;
	}
}
