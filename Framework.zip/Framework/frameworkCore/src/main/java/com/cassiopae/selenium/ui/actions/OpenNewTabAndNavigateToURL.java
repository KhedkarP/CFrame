/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;

/**
 * @author meenakshi
 *
 */
public class OpenNewTabAndNavigateToURL implements PerformAction {
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String appURL = null;
		appURL = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData().trim());
		try {
			testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps()
					+ ReportLoggerConstant.COLON_SYMBOL + excelTestCaseFieldsTO.getInputTestData());
			JavascriptExecutor js = (JavascriptExecutor) testCaseDetailTO.getDriver();
			js.executeScript("window.open('" + appURL + "');");
			String newWindowHandler = null;
			Set<String> handles = testCaseDetailTO.getDriver().getWindowHandles();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + handles.size());
			Iterator<String> iterator = handles.iterator();
			while (iterator.hasNext()) {
				newWindowHandler = iterator.next();
			}
			testCaseDetailTO.getDriver().switchTo().window(newWindowHandler);
			testCaseDetailTO.getDriver().findElement(By.xpath(FunctionLocatorConstant.WINDOW_LOCATOR));
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.NAVIGATE_NEWLY_OPENED_WINDOW);

		} catch (Exception e) {
			testCaseDetailTO.getReportingLogger().error(ReportLoggerConstant.WINDOW_NOT_PRESENT_UNABLETO_SWITCH);
			Assert.fail(ReportLoggerConstant.WINDOW_NOT_PRESENT_UNABLETO_SWITCH);

		}
	}

}
