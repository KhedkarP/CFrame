/**
 * 
 */
package com.cassiopae.excel.dataconvertor;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;

/**
 * @author nbhil
 *
 */
public class StringDataConvertor implements DataConvertor {

	/**
	 * This method convert the Cell data to numeric/String format.
	 * 
	 * @param cellvalue     Cell
	 * @param dataFormatter DataFormatter
	 * @param locale        String
	 * @return String
	 */
	@Override
	public String convertData(Cell cellvalue, DataFormatter dataFormatter, String locale, String worksSheetName) {

		String calculatedValue = null;
		calculatedValue = dataFormatter.formatCellValue((cellvalue));
		/*
		boolean result = CommonUtility.checkForDecimal(calculatedValue);
		if (result) {
			calculatedValue = CommonUtility.getNumericDataFormatted(cellvalue, dataFormatter, locale);
		}*/
		return calculatedValue;
	}

}
