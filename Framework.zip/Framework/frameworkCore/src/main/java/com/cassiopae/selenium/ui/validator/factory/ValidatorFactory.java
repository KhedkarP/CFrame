/**
 * 
 */

package com.cassiopae.selenium.ui.validator.factory;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.selenium.ui.validator.AssertEqualContains;
import com.cassiopae.selenium.ui.validator.AssertEqualsIgnoreCase;
import com.cassiopae.selenium.ui.validator.AssertEqualsValidator;
import com.cassiopae.selenium.ui.validator.AssertNotEqualsValidation;
import com.cassiopae.selenium.ui.validator.AssertStartsWithIgnoreCase;
import com.cassiopae.selenium.ui.validator.CheckComboBoxValue;
import com.cassiopae.selenium.ui.validator.CheckDropDownValueInSortedOrder;
import com.cassiopae.selenium.ui.validator.CheckboxValidation;
import com.cassiopae.selenium.ui.validator.CompareDates;
import com.cassiopae.selenium.ui.validator.DisplayValidation;
import com.cassiopae.selenium.ui.validator.DynamicCheckBoxValidation;
import com.cassiopae.selenium.ui.validator.ExcelCompareValidator;
import com.cassiopae.selenium.ui.validator.FieldEnabledValidation;
import com.cassiopae.selenium.ui.validator.PerformValidation;
import com.cassiopae.selenium.ui.validator.TableColumnDataValidation;
import com.cassiopae.selenium.ui.validator.ValidatePaymentScheduleExcel;
import com.cassiopae.ui.validation.constant.ValidationConstant;

/**
 * @author jraut
 *
 */
public class ValidatorFactory {
	public static PerformValidation getValidatorInstance(String action) {
		PerformValidation performValidation = null;
		if (StringUtils.isEmpty(action)) {
			return performValidation;
		}
		if (ValidationConstant.DISPLAY_VALIDATION.equals(action)) {
			performValidation = new DisplayValidation();
		} else if (ValidationConstant.ASSERT_NOT_EQUALS_VALIDATION.equals(action)) {
			performValidation = new AssertNotEqualsValidation();
		} else if (ValidationConstant.ASSERT_EQUALS_VALIDATION.equals(action)) {
			performValidation = new AssertEqualsValidator();
		} else if (ValidationConstant.EXCEL_VALIDATE_DATA.equals(action)) {
			performValidation = new ExcelCompareValidator();
		} else if (ValidationConstant.CHECKBOX_VALIDATION.equals(action)) {
			performValidation = new CheckboxValidation();
		} else if (ValidationConstant.FIELD_ENABLED_VALIDATION.equals(action)) {
			performValidation = new FieldEnabledValidation();
		} else if (ValidationConstant.ASSERT_EQUAL_IGNORE_CASE.equals(action)) {
			performValidation = new AssertEqualsIgnoreCase();
		} else if (ValidationConstant.ASSERT_EQUAL_CONTAINS.equals(action)) {
			performValidation = new AssertEqualContains();
		} else if (ValidationConstant.ASSERT_STARTS_WITH_IGNORECASE.equals(action)) {
			performValidation = new AssertStartsWithIgnoreCase();
		} else if (ValidationConstant.VALIDATE_PAYMENT_SCHEDULE_EXCEL.equals(action)) {
			performValidation = new ValidatePaymentScheduleExcel();
		} else if (ValidationConstant.TABLE_COLUMN_DATA_VALIDATION.equals(action)) {
			performValidation = new TableColumnDataValidation();
		} else if (ValidationConstant.CHECK_DROPDOWN_VALUE_IS_PRESENT.equals(action)) {
			performValidation = new CheckComboBoxValue();
		} else if (ValidationConstant.DATE_COMPARE.equals(action)) {
			performValidation = new CompareDates();
		} else if (ValidationConstant.DYNAMIC_CHECKBOX_VALIDAITON.equals(action)) {
			performValidation = new DynamicCheckBoxValidation();
		} else if (ValidationConstant.CHECK_DROPDOWN_VALUE_IS_SORTED.equals(action)) {
			performValidation = new CheckDropDownValueInSortedOrder();
		}
		return performValidation;
	}
}
