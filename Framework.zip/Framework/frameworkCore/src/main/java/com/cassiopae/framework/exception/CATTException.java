/**
 * 
 */
package com.cassiopae.framework.exception;

/**
 * @author nbhil
 *
 */
public class CATTException extends RuntimeException {

	private static final long serialVersionUID = 3349389849548776374L;

	public CATTException(final String message) {
		super(message);
	}

	public CATTException() {
		super();
	}

}
