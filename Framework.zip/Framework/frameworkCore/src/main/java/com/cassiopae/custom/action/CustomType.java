/**
 *
 */
package com.cassiopae.custom.action;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Nilesh Bhil
 *
 */
public enum CustomType {
	CSMZ_UserMethodCall, StartStatement, StopStatement,

	CSMZ_GenerateXpath_PerformClickAction, CSMZ_GenerateXpath_SelectDropdownAction,
	CSMZ_GenerateXpath_EnterTextBoxValueAction, CSMZ_GenerateXpath_SelectCheckboxAction,
	CSMZ_GenerateXpath_UnSelectCheckboxAction, CSMZ_GenerateXpath_CheckFieldIsEnabled,
	CSMZ_GenerateXpath_CheckFieldIsSelected, CSMZ_IsFileDownloaded, CSMZ_CalculateDate, CSMZ_RenameUploadFile,
	CSMZ_DownloadFile, CSMZ_ChangeDateFormat, CSMZ_GetValueFromText, CSMZ_GenerateXpath_ClearTextBoxValueAction,
	CSMZ_IsDownloadedFileEmpty, CSMZ_ReadDataFromJasperPDFAndConvertToExcel, CSMZ_ReplaceValueFromString,
	CSMZ_ReadDataFromJasperExcel, CSMZ_ExecuteBatch, CSMZ_FileUploadOnServer, CSMZ_UpdateXMLFile,
	CSMZ_GetTextValueFromFile, CSMZ_DownloadFileFromServer, CSMZ_CheckFileIsPresentOnServer,
	CSMZ_CheckTableEntryWithPagination, CSMZ_GetComparedValue, CSMZ_ValidatePDF,
	CSMZ_UpdateLocatorPerformClickAction, CSMZ_GetDropDownIndexNumber;

	private static HashSet<String> customActionTypeSet = null;

	public static Set<String> getActionType() {
		if (customActionTypeSet == null) {
			customActionTypeSet = new HashSet<>();
			for (CustomType customAction : CustomType.values()) {
				customActionTypeSet.add(customAction.name());
			}
		}
		return customActionTypeSet;
	}

}
