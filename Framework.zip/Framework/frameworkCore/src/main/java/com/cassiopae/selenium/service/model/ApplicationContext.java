
package com.cassiopae.selenium.service.model;

import java.util.Map;

import org.apache.logging.log4j.*;
import org.testng.Assert;

import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

public class ApplicationContext {
	private static Logger log = LogManager.getLogger(ApplicationContext.class);
	public static boolean headlessModeOfExecution = false;
	public static boolean ENABLE_JENKINS_UI_MODE_OF_EXECUTION = false;
	public static boolean localModeOfExecution = false;
	public static boolean neoLoadScriptCreation = false;
	// ************************** Class Handling Variables Details
	// *****************************************//
	// ************************** ENV Variables Details
	// ***************************************//
	public static String baseUrlBO = null;
	public static String baseUrlMO = null;
	public static String posURL = null;
	public static String configConsoleURL = null;
	public static String IP_ADDRESS_BO = null;
	public static String username_DB_BO = null;
	public static String password_DB_BO = null;
	public static String PortBO = null;
	public static String iphostBO = null;
	public static String dbsidBO = null;
	public static String IP_ADDRESS_MO = null;
	public static String username_DB_MO = null;
	public static String password_DB_MO = null;
	public static String PortMO = null;
	public static String iphostMO = null;
	public static String dbsidMO = null;
	public static String applicationServerHostname = null;
	public static String applicationServerUsername = null;
	public static String applicationServerPassword = null;
	public static String applicationServerPort = null;
	public static String collectionBatchPathQuery = null;
	public static String executionBrowserName = null;
	
	public static String DB_Validation = "Yes";
	public static String executionVideos = null;
	public static String executionScreenShots = null;
	public static String NeoLoadScriptGeneration = null;
	public static String productVersion = null;
	public static String headLessModeValue = null;
	public static String testExecutionAtZoomLevel75 = null;
	
	public static String batchLocationOnserver = null;
	public static String javaHome = null;
	public static String tnsAdmin = null;
	public static String batchTempPath = null;
	public static String ldLibraryPath = null;
	public static String nlsLANG = null;
	
	public static String engageoneConnectorPort = null;
	public static String ariadnextdigisignConnectorPort = null;
	public static String externalratingprotectelConnectorPort = null;
	

	static {
		Map<String, String> environmentDetailsMap = null;
		try {
			if (FileUtility.checkFileExists(CommonUtility.getJenkinsEnvDetailsFilePath())) {
				log.info("******* Fetching env details from property files ********");
				environmentDetailsMap = CommonUtility.readProperties(CommonUtility.getJenkinsEnvDetailsFilePath());
			} else {
				environmentDetailsMap = ExcelOperation.getEnvDetails(ApplicationConstant.initializeTestEnvExcelPath,
						InitializeConstants.test_environment_details_sheet_name);
			}
			baseUrlBO = environmentDetailsMap.get("BO_Url");
			baseUrlMO = environmentDetailsMap.get("MO_Url");
			posURL = environmentDetailsMap.get("POS_Url");
			configConsoleURL = environmentDetailsMap.get("ConfigConsole_Url");
			IP_ADDRESS_BO = environmentDetailsMap.get("BO_Application_IP");
			IP_ADDRESS_MO = environmentDetailsMap.get("MO_Application_IP");
			username_DB_BO = environmentDetailsMap.get("BO_DB_Username");
			password_DB_BO = environmentDetailsMap.get("BO_DB_Password");
			iphostBO = environmentDetailsMap.get("BO_DB_IP_Host");
			PortBO = environmentDetailsMap.get("BO_DB_Port");
			dbsidBO = environmentDetailsMap.get("BO_DB_SID");
			username_DB_MO = environmentDetailsMap.get("MO_DB_Username");
			password_DB_MO = environmentDetailsMap.get("MO_DB_Password");
			iphostMO = environmentDetailsMap.get("MO_DB_IP_Host");
			PortMO = environmentDetailsMap.get("MO_DB_Port");
			dbsidMO = environmentDetailsMap.get("MO_DB_SID");
			applicationServerHostname = environmentDetailsMap.get("Application_Server_Hostname");
			applicationServerUsername = environmentDetailsMap.get("Application_Server_Username");
			applicationServerPassword = environmentDetailsMap.get("Application_Server_Password");
			applicationServerPort = environmentDetailsMap.get("Application_Server_Port");
			collectionBatchPathQuery = environmentDetailsMap.get("Collection_Batch_Path_Query");
			executionBrowserName = environmentDetailsMap.get("Execution_Browser_Name");
			executionScreenShots = environmentDetailsMap.get("Execution_Screenshot_Required");
			executionVideos = environmentDetailsMap.get("Execution_Videos_Required");
			headLessModeValue = environmentDetailsMap.get("Headless_Execution_Required");
			testExecutionAtZoomLevel75 = environmentDetailsMap.get("Browser_Resolution_75_Percentage");
			NeoLoadScriptGeneration = environmentDetailsMap.get("Neoload_Script_Generation");
			productVersion = environmentDetailsMap.get("Product_Version");
			
			batchLocationOnserver = environmentDetailsMap.get("Batch_Location_On_Server");
			javaHome = environmentDetailsMap.get("JAVA_HOME");
			tnsAdmin = environmentDetailsMap.get("TNS_ADMIN");
			batchTempPath = environmentDetailsMap.get("TEMP_PATH");
			ldLibraryPath = environmentDetailsMap.get("LD_LIBRARY_PATH");
			nlsLANG = environmentDetailsMap.get("NLS_LANG");
			
			engageoneConnectorPort = environmentDetailsMap.get("EngageoneConnectorPort");
			ariadnextdigisignConnectorPort = environmentDetailsMap.get("AriadnextdigisignConnectorPort");
			externalratingprotectelConnectorPort = environmentDetailsMap.get("ExternalratingprotectelConnectorPort");
			
			
			if (headLessModeValue.equalsIgnoreCase(CommonConstant.YES)) {
				headlessModeOfExecution = true;
			} else {
				headlessModeOfExecution = false;
			}
			if (testExecutionAtZoomLevel75.equalsIgnoreCase(CommonConstant.YES)) {
				ENABLE_JENKINS_UI_MODE_OF_EXECUTION = true;
			} else {
				ENABLE_JENKINS_UI_MODE_OF_EXECUTION = false;
			}
			if (NeoLoadScriptGeneration.equalsIgnoreCase(CommonConstant.YES)) {
				neoLoadScriptCreation = true;
			}

		} catch (Throwable e) {
			log.info(ReportLoggerConstant.ENVIRONMENT_DETAILS_EXCEL_INITIALIZATION_ERROR_MESSAGE + e.getMessage());
			Assert.fail(ReportLoggerConstant.ENVIRONMENT_DETAILS_EXCEL_INITIALIZATION_ERROR_MESSAGE + e.getMessage());
		}

	}

}
