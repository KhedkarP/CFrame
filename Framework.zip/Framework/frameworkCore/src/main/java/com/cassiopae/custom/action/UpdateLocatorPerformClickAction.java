/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class UpdateLocatorPerformClickAction implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		GenericAction.locator(locatorKeys[0], locatorMap);
		String[] inputDataColumnValues = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDataRowNumbers= inputDataColumnValues[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String xpath=CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap);
		String clickXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetail.getVariableHolder(), inputTestDataRowNumbers);
		WebElement element = GenericAction.getWebElement(testCaseDetail.getDriver(), By.xpath(clickXpath), testCaseDetail.getReportingLogger());
		GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element,
			testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		element.click();
	}
}
