/**
 *
 */

package com.cassiopae.selenium.services;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.FileStructureConstants;
import com.xuggle.mediatool.IMediaReader;
import com.xuggle.mediatool.IMediaTool;
import com.xuggle.mediatool.IMediaWriter;
import com.xuggle.mediatool.MediaToolAdapter;
import com.xuggle.mediatool.ToolFactory;
import com.xuggle.mediatool.event.IAudioSamplesEvent;
import com.xuggle.mediatool.event.IVideoPictureEvent;
import com.xuggle.xuggler.ICodec;

/**
 * @author jraut
 *
 */
public class VideoCreationUtility {

	private VideoCreationUtility() {

	}

	private static Logger logger = LogManager.getLogger(VideoCreationUtility.class);

	public static String videoCreation(final String newVideoLocation, final String sceenshotFolderPath,
			final String workSheetName,String browserNme ) {
		Dimension screenBounds;
		List<String> list = null;
		File screenShot = new File(newVideoLocation);
		if (!screenShot.exists()) {
			screenShot.mkdirs();
		}
		String videoLocation = newVideoLocation + workSheetName + CommonConstant.UNDER_SCORE+browserNme+"_Video" + ".mp4";
		IMediaWriter writer = ToolFactory.makeWriter(videoLocation);
		screenBounds = Toolkit.getDefaultToolkit().getScreenSize();
		writer.addVideoStream(0, 0, ICodec.ID.CODEC_ID_MPEG4, screenBounds.width, screenBounds.height);
		File folder = new File(sceenshotFolderPath);
		File[] listOfFiles = folder.listFiles();
		list = new ArrayList<>();
		if (listOfFiles != null && listOfFiles.length > 0) {
			for (File file : listOfFiles) {
				if (file.isFile() && file.getName().contains(".jpg")) {
					list.add(file.getPath());
				}
			}
			Collections.sort(list);
			int getHeight = 0;
			int getWidth = 0;
			for (int index = 0; index <= list.size() - 1; index++) {
				BufferedImage screen = getImage(index, list);
				if (index == 0) {
					getWidth = screen.getWidth();
					getHeight = screen.getHeight();
				}
				BufferedImage bgrScreen = convertToType(screen, BufferedImage.TYPE_3BYTE_BGR, getWidth, getHeight);
				writer.encodeVideo(0, bgrScreen, 800 * index, TimeUnit.MILLISECONDS);
			}
			writer.close();
		}
		return videoLocation;
	}

	private static BufferedImage convertToType(final BufferedImage sourceImage, final int targetType,
			final int getWidth, final int getHeight) {
		BufferedImage image;
		if (sourceImage.getType() == targetType) {
			image = sourceImage;
		} else {
			image = new BufferedImage(getWidth, getHeight, targetType);
			image.getGraphics().drawImage(sourceImage, 0, 0, null);
		}
		return image;
	}

	private static BufferedImage getImage(final int index, final List<String> list) {

		String img = list.get(index);
		File file = new File(img);
		try {
			return ImageIO.read(file);
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTException(exception.getMessage());
		}
	}

	private static String videoCompression(final String filePath) {
		File file = new File(filePath);
		String inputFilename = file.getPath();
		String[] parts = inputFilename.split(".mp4"); // [Dossier < dharam > Reference: < LCC00188 >]
		String index = parts[0]; // 004
		final String outputFilename = index + "_1" + ".mp4";
		convertVideo(inputFilename, outputFilename, FileStructureConstants.imageFilename);
		return outputFilename;
	}

	private static void convertVideo(final String inputFilename, final String outputFilename,
			final String imageFilename) {
		IMediaReader mediaReader = ToolFactory.makeReader(inputFilename);
		mediaReader.setBufferedImageTypeToGenerate(BufferedImage.TYPE_3BYTE_BGR);
		IMediaWriter mediaWriter = ToolFactory.makeWriter(outputFilename, mediaReader);
		IMediaTool imageMediaTool = new StaticImageMediaTool(imageFilename);
		IMediaTool audioVolumeMediaTool = new VolumeAdjustMediaTool(0.1);
		mediaReader.addListener(imageMediaTool);
		imageMediaTool.addListener(audioVolumeMediaTool);
		audioVolumeMediaTool.addListener(mediaWriter);
		while (mediaReader.readPacket() == null)
			;

	}

	private static class StaticImageMediaTool extends MediaToolAdapter {
		private BufferedImage logoImage;

		public StaticImageMediaTool(final String imageFile) {
			try {
				logoImage = ImageIO.read(new File(imageFile));
			} catch (IOException exception) {
				logger.error(exception.getMessage(), exception);
				throw new CATTException(ReportLoggerConstant.FILE_NOT_OPEN);
			}
		}

		@Override
		public void onVideoPicture(final IVideoPictureEvent event) {
			BufferedImage image = event.getImage();
			Graphics2D g = image.createGraphics();
			Rectangle2D bounds = new Rectangle2D.Float(0, 0, logoImage.getWidth(), logoImage.getHeight());
			double inset = bounds.getHeight();
			g.translate(inset, event.getImage().getHeight() - inset);
			g.setColor(Color.WHITE);
			g.fill(bounds);
			g.setColor(Color.BLACK);
			g.drawImage(logoImage, 0, 0, null);
			super.onVideoPicture(event);
		}
	}

	private static class VolumeAdjustMediaTool extends MediaToolAdapter {
		private double mVolume;

		public VolumeAdjustMediaTool(final double volume) {
			mVolume = volume;
		}

		@Override
		public void onAudioSamples(final IAudioSamplesEvent event) {
			ShortBuffer buffer = event.getAudioSamples().getByteBuffer().asShortBuffer();
			for (int i = 0; i <= buffer.limit(); ++i) {
				buffer.put(i, (short) (buffer.get(i) * mVolume));
			}
			super.onAudioSamples(event);
		}
	}

}
