/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.JasperUtility;

/**
 * @author rkumar
 *
 */
public class GetValuesFromJasperReport implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String pdfFileName = null;
		int receivableCount = 0;
		int expenseCount = 0;
		String[] inputDataRequiredValues = null;
		String[] inputDataRequiredValues1 = null;
		String[] storeRetrievedValues = null;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			storeRetrievedValues = CommonUtility.splitStringUsingPattern(
					excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.COMMA_SEPERATOR);
		}
		if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR)) {
			getValuesFromJaserReport(excelTestCaseFieldsTO, testCaseDetailTO, pdfFileName, receivableCount,
					expenseCount, inputDataRequiredValues, inputDataRequiredValues1, storeRetrievedValues);
		} else {
			testCaseDetailTO.getReportingLogger()
					.error(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE
							+ excelTestCaseFieldsTO.getAction());
			throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
		}
	}

	public static void getValuesFromJaserReport(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO, String pdfFileName, int receivableCount, int expenseCount,
			String[] inputDataRequiredValues, String[] inputDataRequiredValues1, String[] storeRetrievedValues) {
		Logger replogger = testCaseDetailTO.getReportingLogger();
		inputDataRequiredValues = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		inputDataRequiredValues1 = CommonUtility.splitStringUsingPattern(inputDataRequiredValues[0],
				CommonConstant.COMMA_SEPERATOR);
		String excelName=VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputDataRequiredValues[1]);
		String ExcelFileName = excelName.trim() + CommonConstant.XLSX_FILE_EXTENSION;
		int count=0;
		if (inputDataRequiredValues1.length==storeRetrievedValues.length) {
			for (String element : inputDataRequiredValues1) {
				if (element.trim().equals(CommonConstant.JASPER_EXCEL_HEADER_RECEIVABLES)) {
					replogger.info(ReportLoggerConstant.EXPECTED_DATA_MSG + element);
					pdfFileName = CommonConstant.RECEVIABLE_PDF_FILE_NAME + CommonConstant.PDF_FILE_EXTENSION;
					receivableCount = JasperUtility.getDataFromJasperReport(pdfFileName, ExcelFileName, testCaseDetailTO,
							replogger);
					testCaseDetailTO.getVariableHolder().put(storeRetrievedValues[count], String.valueOf(receivableCount));
					replogger.info(ReportLoggerConstant.COUT_OF_RECEIVABLES_MSG + receivableCount);
				}else if(element.trim().equals(CommonConstant.JASPER_EXCEL_HEADER_EXPENSE)){
					replogger.info(ReportLoggerConstant.EXPECTED_DATA_MSG + element);
					pdfFileName = CommonConstant.EXPENSE_PDF_FILE_NAME + CommonConstant.PDF_FILE_EXTENSION;
					expenseCount = JasperUtility.getDataFromJasperReport(pdfFileName, ExcelFileName, testCaseDetailTO,
							replogger);
					testCaseDetailTO.getVariableHolder().put(storeRetrievedValues[count], String.valueOf(expenseCount));
					replogger.info(ReportLoggerConstant.COUT_OF_EXPENSE_MSG + expenseCount);
				}
				count++;
			}
			
		}else {
			replogger.error(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
			throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
		}
	}

}
