package com.cassiopae.framework.xl.reader;

public enum DataType {

	IntegerNumber, DecimalNumber, String
}
