/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author nbhil
 *
 */
public class GetAttributeClassAction implements PerformAction {

	/**
	 * This method execute action for get attribute title action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		String attributeSrc = GenericAction.getAttributeClass(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());

		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + attributeSrc);

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), attributeSrc);
		}

	}

}
