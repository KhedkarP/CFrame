package com.cassiopae.selenium.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.*;

public class JrxmlFileUpdateUtility {

	private static Logger logger = LogManager.getLogger(JrxmlFileUpdateUtility.class);

	public static List<File> searchAndReplaceContentInJrxmlFiles(String directoryName) {
		File directory = new File(directoryName);
		List<File> resultList = new ArrayList<File>();
		String search = "isBlankWhenNull=\"true\""; // <- changed to work with String.replaceAll()
		String replacement = "isBlankWhenNull=\"false\"";
		// get all the files from a directory
		File[] fList = directory.listFiles();
		logger.info("Total files present at location :" + directoryName + " are : " + fList.length);
		resultList.addAll(Arrays.asList(fList));
		for (File file : fList) {
			if (file.isFile() && FilenameUtils.getExtension(file.getAbsolutePath()).equalsIgnoreCase("jrxml")) {
				logger.info("Updation started for file : " + file.getName());
				try {
					FileReader fr = new FileReader(file);
					String s;
					String totalStr = "";
					try (BufferedReader br = new BufferedReader(fr)) {
						while ((s = br.readLine()) != null) {
							totalStr += s + System.lineSeparator();
						}
						totalStr = totalStr.replaceAll(search, replacement);
						FileWriter fw = new FileWriter(file);
						fw.write(totalStr);
						fw.close();
					}
				} catch (Exception e) {
					logger.error("Error occured while updating file :" + file.getName() + " => " + e.getMessage());
				}
				// steps for files
			} else if (file.isDirectory()) {
				logger.info("============= Updation started for files present in directory : " + file.getName());
				resultList.addAll(searchAndReplaceContentInJrxmlFiles(file.getAbsolutePath()));
			}
		}
		return resultList;
	}

}
