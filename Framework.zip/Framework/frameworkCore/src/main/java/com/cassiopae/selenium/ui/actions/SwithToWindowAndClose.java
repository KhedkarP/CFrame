/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;

/**
 * @author skumar
 *
 */
public class SwithToWindowAndClose implements PerformAction {

	/**
	 * This method execute action for get attribute title action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputTestDatas = excelTestCaseFieldsTO.getInputTestData().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		
		String childwinodwFlowid = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[0]);
		String parentwinodwFlowid = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[1]);
		
		WebDriver driver = SeleniumUtility.switchToWindowAndClose(childwinodwFlowid,parentwinodwFlowid,testCaseDetailTO);
		testCaseDetailTO.setDriver(driver);
	}

}
