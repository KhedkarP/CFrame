package com.cassiopae.custom.action;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.JasperUtility;

public class ConvertJasperPdfToExcel implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger replogger = testCaseDetailTO.getReportingLogger();
		String inputData=	VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		String[] storeRetrievedValues = null;
		String excelFilename = null;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			storeRetrievedValues = CommonUtility.splitStringUsingPattern(
					excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.COMMA_SEPERATOR);
			excelFilename = JasperUtility.convertPdfToExcel(testCaseDetailTO, replogger, inputData);
			testCaseDetailTO.getVariableHolder().put(storeRetrievedValues[0], String.valueOf(excelFilename));
			replogger.info(ReportLoggerConstant.EXCEL_FILE_NAME + excelFilename);
		} else {
			testCaseDetailTO.getReportingLogger()
					.error(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
							+ excelTestCaseFieldsTO.getAction());
			throw new CATTException(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
		}
	}

}
