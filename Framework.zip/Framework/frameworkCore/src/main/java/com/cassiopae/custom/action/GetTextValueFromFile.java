package com.cassiopae.custom.action;

import java.io.BufferedReader;
import java.io.FileReader;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

public class GetTextValueFromFile implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String expectedStringValue = getValueFromFile(excelTestCaseFieldsTO, testCaseDetailTO);

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					expectedStringValue);
		}
	}

	/**
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @return
	 */
	private String getValueFromFile(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String filepath = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[1]);
		String[] lineDetails = CommonUtility.splitStringUsingPattern(inputData[0], CommonConstant.COMMA_SEPERATOR);
		String startsWith = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				lineDetails[0]);
		String endsWith = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				lineDetails[1]);
		String occurenceNumber = VariableHolder
				.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), lineDetails[2]).trim();
		Boolean isOccurenceNumberLAST = false;
		int occurenceNo = 0;
		boolean isMatchFound = false;

		try {
			occurenceNo = Integer.parseInt(occurenceNumber);
		} catch (NumberFormatException nfe) {
			isOccurenceNumberLAST = Boolean.TRUE;
		}

		int count = 0;
		String expectedStringValue = null;
		try (FileReader file = new FileReader(filepath); BufferedReader bufferedReader = new BufferedReader(file)) {
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				if (line.contains(startsWith)) {
					isMatchFound = Boolean.TRUE;
					count++;
					if (StringUtils.isEmpty(endsWith)) {
						expectedStringValue = StringUtils.substring(line,
								StringUtils.indexOf(line, startsWith) + startsWith.length(), line.length()).trim();
					} else {
						expectedStringValue = StringUtils
								.substring(line, StringUtils.indexOf(line, startsWith) + startsWith.length(),
										StringUtils.lastIndexOf(line, endsWith))
								.trim();
					}
				}
				if (!Boolean.TRUE.equals(isOccurenceNumberLAST) && count == occurenceNo) {
					break;
				}
			}
			if (!isMatchFound) {
				testCaseDetailTO.getReportingLogger().warn("**** No match found ********");
			} else {
				testCaseDetailTO.getReportingLogger().info("Retrieved value is: " + expectedStringValue);
			}
		} catch (Exception e) {
			throw new CATTException("Error occured while fetching value from file: " + e.getMessage());
		}
		return expectedStringValue;
	}
}
