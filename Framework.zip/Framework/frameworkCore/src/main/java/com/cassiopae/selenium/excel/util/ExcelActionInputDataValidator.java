/**
 *
 */
package com.cassiopae.selenium.excel.util;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.CustomConstant;
import com.cassiopae.framework.to.ErrorValidation;
import com.cassiopae.framework.to.ExcelMasterData;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.operator.constant.OperatorConstant;
import com.cassiopae.selenium.ui.actions.constant.ActionConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.ui.validation.constant.ValidationConstant;
import com.cassiopae.webservices.action.constant.WSConstant;

/**
 * This java Utility class will validate the excel fields for given test data
 * file.
 *
 * @author nbhil
 */
public class ExcelActionInputDataValidator {
	private static Logger logger = LogManager.getLogger(ExcelActionInputDataValidator.class);

	private ExcelActionInputDataValidator() {

	}

	/**
	 * This method validate input test data in test data file.
	 *
	 * @param excelMasterData       ExcelMasterData
	 * @param errorValidatorList    List<ErrorValidation>
	 * @param excelTestCaseFieldsTO ExcelTestCaseFieldsTO
	 */
	public static void validateInputTestData(final ExcelMasterData excelMasterData,
											 final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if ((ActionConstant.CONCATENATE_STRING_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.EXECUTE_QUERY_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.NAVIGATE_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.SWITCH_TO_WINDOW_BY_FLOWID_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.GENERATE_DYNAMIC_DATA.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.ENTER_INPUT_VALUE_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.SELECT_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.CHECK_PANEL_ENTRY.equals(excelTestCaseFieldsTO.getAction())
				|| OperatorConstant.RELATIONAL_OPERATION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.METHOD_CALL.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.EXTERNAL_WAIT.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.CHECK_BLANK_VALUE_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.SLAC_ENTER_DATE.equals(excelTestCaseFieldsTO.getAction())
				|| ValidationConstant.TABLE_COLUMN_DATA_VALIDATION.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.CONVERT_DB_AMOUNT_TO_UI_FORMAT.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.FILE_UPLOAD_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_UPDATE_XML_FILE.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.REST_API_LOGIN_REQUEST.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.REST_API_POST_REQUEST.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.REST_API_GET_RESPONSE_DATA.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.REST_API_PATCH_REQUEST.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.REST_API_GET_REQUEST.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.SOAP_API_POST_REQUEST.equals(excelTestCaseFieldsTO.getAction())
				|| WSConstant.SOAP_API_GET_RESPONSE_DATA.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_DYNAMIC_DATE.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_XPATH_PERFORM_CLICK_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_XPATH_ENTER_TEXTBOX_VALUE_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_XPATH_SELECT_DROPDOWN_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_XPATH_SELECT_CHECKBOX.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.GENERATE_XPATH_UNSELECT_CHECKBOX.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.XLS_GET_DATA_FROM_EXCEL.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.XLS_PUT_DATA_IN_EXCEL.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_FILE_UPLOAD_ON_SERVER.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_GET_TEXT_VALUE_FROM_FILE.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_DOWNLOAD_FILE_FROM_SERVER.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_GET_COMPARED_VALUE.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_UPDATE_LOCATOR_PERFORM_CLICK_ACTION.equals(excelTestCaseFieldsTO.getAction())
				|| CustomConstant.CSMZ_CHECK_FILE_IS_PRESENT_ON_SERVER.equals(excelTestCaseFieldsTO.getAction())
				|| ActionConstant.SELECT_PANEL_ENTRY.equals(excelTestCaseFieldsTO.getAction()))
				&& StringUtils.isEmpty(excelTestCaseFieldsTO.getInputTestData())) {
			StringBuilder errorMessage = new StringBuilder();
			errorMessage.append(ErrorMessageConstant.INPUT_TEST_DATA_IS_MANDATORY)
					.append(excelTestCaseFieldsTO.getAction()).append(".");
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
		validateSelectPanelEntryInputData(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateCreateExecuteDynamicXpathData(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateFunctionValidateEntries(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateCSMZGenerateXpathSelectDropdownAction(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateCSMZCheckTableEntry(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateRESTLoginRequest(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateRESTPOSTRequest(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateXLSDataActions(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		validateCSMZGetTextValueFromFileAction(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);

		if (excelTestCaseFieldsTO.getAction().equals(ActionConstant.EXTERNAL_WAIT)) {
			validateExternalWaitInputData(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		}
		else if (excelTestCaseFieldsTO.getAction().equals(ValidationConstant.ASSERT_STARTS_WITH_IGNORECASE)) {
			validateAssertStartsWithIgnoreCase(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		}
		else if (excelTestCaseFieldsTO.getAction().equals(ValidationConstant.VALIDATE_PAYMENT_SCHEDULE_EXCEL)) {
			validatePaymentScheduleExcelInputData(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		} else if(excelTestCaseFieldsTO.getAction().equals(ValidationConstant.TABLE_COLUMN_DATA_VALIDATION)) {
			validateTableColumnDataValidationAction(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		} else if (excelTestCaseFieldsTO.getAction().equals(CustomConstant.GENERATE_DYNAMIC_DATE)) {
			validateCSMZ_CalculateDate(excelMasterData, errorValidatorList, excelTestCaseFieldsTO);
		}

	}

	/**
	 * This method validate the Input Test Data Column for CSMZ_CalculateDate Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateCSMZ_CalculateDate(final ExcelMasterData excelMasterData,
												   final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		String[] inputTestDatas = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		StringBuilder errorMessage = new StringBuilder();
		if (reqValues.length != 3 && inputTestDatas.length==2) {
			errorMessage.append("Please Check Input Test Data Column data For Action - ").append(excelTestCaseFields.getAction())
					.append(".");
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
	}



	/**
	 * This method validate the Input Test Data Column for CSMZ_GenerateXpath_SelectDropdownAction Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateTableColumnDataValidationAction(final ExcelMasterData excelMasterData,
																final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		String[] storeValueColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),CommonConstant.PIPE_SEPARATOR);
		StringBuilder errorMessage = new StringBuilder();
		if (storeValueColumnData.length != 3) {
			errorMessage.append("Please Check Input Test Data Column data For Action - ").append(excelTestCaseFields.getAction())
					.append(".");
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
	}

	/**
	 * This method validate the Input Test Data Column for CSMZ_GenerateXpath_SelectDropdownAction Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateCSMZCheckTableEntry(final ExcelMasterData excelMasterData,
													final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (ActionConstant.CHECK_PANEL_ENTRY.equals(excelTestCaseFields.getAction())) {
			String[] storeValueColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(),CommonConstant.PIPE_SEPARATOR);
			StringBuilder errorMessage = new StringBuilder();
			if (storeValueColumnData.length < 2) {
				errorMessage.append("Please Check Store Value in Variable Column data For Action - ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	/**
	 * This method validate the Store value in variable Column for RESTAPILoginRequest Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateRESTLoginRequest(final ExcelMasterData excelMasterData,
												 final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (WSConstant.REST_API_LOGIN_REQUEST.equals(excelTestCaseFields.getAction())) {
			String[] storeValueColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(),CommonConstant.PIPE_SEPARATOR);
			StringBuilder errorMessage = new StringBuilder();
			if (storeValueColumnData.length < 4) {
				errorMessage.append("Please Check 'Store Value in Variable' column data(count of pipe separated values) for action: ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	/**
	 * This method validate the input data for RESTAPIPOSTRequest Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateRESTPOSTRequest(final ExcelMasterData excelMasterData,
												final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (WSConstant.REST_API_POST_REQUEST.equals(excelTestCaseFields.getAction())) {
			String[] inputValueColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),CommonConstant.PIPE_SEPARATOR);
			StringBuilder errorMessage = new StringBuilder();
			if (inputValueColumnData.length < 2) {
				errorMessage.append("Please Check 'Input Test Data' column data(count of pipe separated values) for action: ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
			String[] storeValueColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(),CommonConstant.PIPE_SEPARATOR);
			if (storeValueColumnData.length < 2) {
				errorMessage.append("Please Check 'Store Value in Variable' column data(count of pipe separated values) for action: ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}

		}
	}

	private static void validateCSMZGetTextValueFromFileAction(final ExcelMasterData excelMasterData,
															   final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (CustomConstant.CSMZ_GET_TEXT_VALUE_FROM_FILE.equals(excelTestCaseFields.getAction())) {
			String[] inputValue = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),
					CommonConstant.PIPE_SEPARATOR);
			StringBuilder errorMessage = new StringBuilder();

			if(inputValue.length < 2) {
				errorMessage.append("Please check Input Test Data, there should be 2 PIPE separated input values for action: ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
			String[] subInputData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),
					CommonConstant.COMMA_SEPERATOR);
			if(subInputData.length < 3) {
				errorMessage.append("Please check Input Test Data, there should be 3 comma separated input values in first set of i/p values for action: ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	private static void validateXLSDataActions(final ExcelMasterData excelMasterData,
											   final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (ActionConstant.XLS_PUT_DATA_IN_EXCEL.equals(excelTestCaseFields.getAction()) || ActionConstant.XLS_GET_DATA_FROM_EXCEL.equals(excelTestCaseFields.getAction())) {
			String[] inputValue = CommonUtility.splitString(excelTestCaseFields.getInputTestData(),
					CommonConstant.COMMA_SEPERATOR);
			StringBuilder errorMessage = new StringBuilder();
			String columnNumber = inputValue[0].trim();
			if(inputValue.length < 2) {
				errorMessage.append("Please check Input test data, there should be 2 comma separated input values for action : ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
			boolean isNumbericValue = CommonUtility.checkForNumericValue(columnNumber);
			if(!isNumbericValue) {
				errorMessage.append("Please check Input test data column values, generated reference column value should be numeric for action : ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	/**
	 * This method validate the Input Test Data Column for CSMZ_GenerateXpath_SelectDropdownAction Action
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateCSMZGenerateXpathSelectDropdownAction(final ExcelMasterData excelMasterData,
																	  final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		if (CustomConstant.GENERATE_XPATH_SELECT_DROPDOWN_ACTION.equals(excelTestCaseFields.getAction()) || CustomConstant.GENERATE_XPATH_ENTER_TEXTBOX_VALUE_ACTION.equals(excelTestCaseFields.getAction())) {
			String[] inputDataColumnValues = excelTestCaseFields.getInputTestData()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
			StringBuilder errorMessage = new StringBuilder();
			if (inputDataColumnValues.length < 2) {
				errorMessage.append("Please Check Input Test Data Column values For Action - ").append(excelTestCaseFields.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	private static void validatePaymentScheduleExcelInputData(final ExcelMasterData excelMasterData,
															  final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		String[] countOftotalStdXLSCompare=excelTestCaseFieldsTO.getInputTestData().split(CommonConstant.TILDE_SEPARATOR);
		StringBuilder errorMessage = new StringBuilder();

		for (int k = 0; k < countOftotalStdXLSCompare.length; k++) {

			String inputData[] = CommonUtility.splitStringUsingPattern(countOftotalStdXLSCompare[k],
					CommonConstant.PIPE_SEPARATOR);
			String[] stdExlDataInfo=inputData[0].split(CommonConstant.COMMA_SEPERATOR);

			if (inputData == null || inputData.length == 0) {
				errorMessage.append("Input Test Data for Action should not Empty - ")
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			} else if (inputData.length < 2) {
				errorMessage.append("Please Check Syntax For Action - ").append(excelTestCaseFieldsTO.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			} else if (stdExlDataInfo.length < 2) {
				errorMessage.append("Please check standard excel name and sheet name for Action - ").append(excelTestCaseFieldsTO.getAction())
						.append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
			else {
				validatePaymentScheduleColumnInputData(excelMasterData, errorValidatorList, excelTestCaseFieldsTO, inputData,
						errorMessage);
			}
		}

	}

	/**
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFieldsTO
	 * @param inputData
	 * @param errorMessage
	 */
	private static void validatePaymentScheduleColumnInputData(final ExcelMasterData excelMasterData,
															   final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO,
															   String[] inputData, StringBuilder errorMessage) {
		for (int i = 1; i < inputData.length; i++) {
			String[] data=CommonUtility.splitStringUsingPattern(inputData[i], CommonConstant.COMMA_SEPERATOR);
			if (data.length != 4) {
				errorMessage.append("Input Test Data for Action should not Empty -")
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			} else {
				String[] inputArray = CommonUtility.splitString(inputData[i], CommonConstant.COMMA_SEPERATOR);
				if (CommonUtility.isNullOREmpty(inputArray[0]) || CommonUtility.isNullOREmpty(inputArray[1])
						|| (CommonUtility.isNullOREmpty(inputArray[2]) || !StringUtils.isNumeric(inputArray[2].trim()))
						|| (CommonUtility.isNullOREmpty(inputArray[3]) || !StringUtils.isNumeric(inputArray[3].trim()))) {
					errorMessage
							.append("Please check the input data - Column Names to be compared, Start Row , End Row For Action -")
							.append(excelTestCaseFieldsTO.getAction()).append(".");
					ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
							errorMessage.toString(), excelMasterData.getWorkSheetName(),
							excelMasterData.getWorkBookName());
					errorValidatorList.add(errorValidation);

				}
			}

		}
	}

	/**
	 *
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFieldsTO
	 */
	private static void validateAssertStartsWithIgnoreCase(final ExcelMasterData excelMasterData,
														   final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (ActionConstant.CREATE_EXECUTE_DYNAMIC_XPATH.equals(excelTestCaseFieldsTO.getAction())) {

			String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
					CommonConstant.PIPE_SEPARATOR);

			if (inputData.length != 2) {
				StringBuilder errorMessage = new StringBuilder();
				errorMessage.append("Please provide correct input data for Action - ")
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	private static void validateExternalWaitInputData(final ExcelMasterData excelMasterData,
													  final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		String sleepTime = excelTestCaseFieldsTO.getInputTestData();
		if (!StringUtils.isNumeric(sleepTime)) {
			StringBuilder errorMessage = new StringBuilder();
			errorMessage.append(ErrorMessageConstant.EXTERNAL_WAIT_INPUT_ERROR_MSG)
					.append(excelTestCaseFieldsTO.getAction()).append(".");
			ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
					errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
			errorValidatorList.add(errorValidation);
		}
	}

	/**
	 *
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFieldsTO
	 */
	private static void validateCreateExecuteDynamicXpathData(final ExcelMasterData excelMasterData,
															  final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (ActionConstant.CREATE_EXECUTE_DYNAMIC_XPATH.equals(excelTestCaseFieldsTO.getAction())) {

			String[] locatorKeys = excelTestCaseFieldsTO.getLocatorKey()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
			String[] inputTestDatas = excelTestCaseFieldsTO.getInputTestData()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
			String[] seleniumActions = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
			String[] storeValuesInVariable = excelTestCaseFieldsTO.getStoreValuesInVariable()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));

			if (!(locatorKeys.length == seleniumActions.length && locatorKeys.length == storeValuesInVariable.length )) {
				StringBuilder errorMessage = new StringBuilder();
				errorMessage.append(ActionConstant.CREATE_EXECUTE_DYNAMIC_XPATH
								+ " action is not defined correctly, please check Locator keys,Input Test Data.")
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}
	}

	/**
	 *
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFieldsTO
	 */
	private static void validateSelectPanelEntryInputData(final ExcelMasterData excelMasterData,
														  final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFieldsTO) {
		if (ActionConstant.SELECT_PANEL_ENTRY.equals(excelTestCaseFieldsTO.getAction())) {
			String[] locatorKeys = excelTestCaseFieldsTO.getLocatorKey()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
			String[] inputTestDatas = excelTestCaseFieldsTO.getInputTestData()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
			String[] seleniumActions = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
			String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

			StringBuilder errorMessage = new StringBuilder();

			int lenght = locatorKeys.length;
			if (lenght != seleniumActions.length) {
				errorMessage
						.append("Selenium Actions are not defined correctly to perform operation - "
								+ ActionConstant.SELECT_PANEL_ENTRY)
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);

			}
			if (lenght != reqValues.length) {
				errorMessage
						.append("Required Values are not defined correctly to perform operation - "
								+ ActionConstant.SELECT_PANEL_ENTRY)
						.append(excelTestCaseFieldsTO.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFieldsTO.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);

			}
		}
	}

	/**
	 *
	 * @param excelMasterData
	 * @param errorValidatorList
	 * @param excelTestCaseFields
	 */
	private static void validateFunctionValidateEntries(final ExcelMasterData excelMasterData,
														final List<ErrorValidation> errorValidatorList, final ExcelTestCaseFields excelTestCaseFields) {
		String validateEntries = "Function_Table_" + FunctionConstant.VALIDATE_ENTRIES;
		if (validateEntries.equals(excelTestCaseFields.getAction())) {
			String[] locatorKeys = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getLocatorKey(),
					CommonConstant.HASH_SEPERATOR);
			String[] inputTestDatas = excelTestCaseFields.getInputTestData()
					.split(Pattern.quote(CommonConstant.HASH_SEPERATOR));
			String[] conditionInputData = CommonUtility.splitStringUsingPattern(inputTestDatas[0],
					CommonConstant.PIPE_SEPARATOR);

			String[] conditionLocators = CommonUtility.splitStringUsingPattern(locatorKeys[0],
					CommonConstant.PIPE_SEPARATOR);

			if (conditionInputData.length != conditionLocators.length) {
				StringBuilder errorMessage = new StringBuilder();
				errorMessage.append("Please provide correct input test data and locatory keys value for action - ")
						.append(excelTestCaseFields.getAction()).append(".");
				ErrorValidation errorValidation = getErrorValidation(excelTestCaseFields.getSrNo(),
						errorMessage.toString(), excelMasterData.getWorkSheetName(), excelMasterData.getWorkBookName());
				errorValidatorList.add(errorValidation);
			}
		}

	}

	/**
	 * This method will return the ErrorValidation instance.
	 *
	 * @param rowNumber     String
	 * @param errorMessage  String
	 * @param workSheetName String
	 * @param workBookName  String
	 * @return ErrorValidation
	 */
	private static ErrorValidation getErrorValidation(String rowNumber, String errorMessage, String workSheetName,
													  String workBookName) {

		ErrorValidation errorValidation = new ErrorValidation();
		errorValidation.setRowNumber(rowNumber);
		errorValidation.setErrorMassage(errorMessage);
		errorValidation.setWorkSheetName(workSheetName);
		errorValidation.setWorkBookName(workBookName);
		return errorValidation;
	}
}
