/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;

/**
 * @author jraut
 *
 */
public class CheckBlankValueAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		String valueTobeChecked = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + valueTobeChecked);

		boolean status = checkStringIsEmpty(testCaseDetailTO.getReportingLogger(), valueTobeChecked);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			if (status) {
				testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
						CommonConstant.TRUE_VALUE);
			} else {
				testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
						CommonConstant.FALSE_VALUE);
			}
		}

	}

	/** This method is used to check whether given string is blank OR not
	 * @param excelTestCaseFieldsTO
	 * @param reportingLogger
	 * @param valueTobeChecked
	 * @return return True when String is blank, else False
	 */
	private boolean checkStringIsEmpty(Logger reportingLogger,
			String valueTobeChecked) {
		boolean isBlank=StringUtils.isBlank(valueTobeChecked);
		if(isBlank) {
			reportingLogger.info("Value is blank");
		} else {
			reportingLogger.info("Value is not blank");
		}
		return isBlank;
	}
}
