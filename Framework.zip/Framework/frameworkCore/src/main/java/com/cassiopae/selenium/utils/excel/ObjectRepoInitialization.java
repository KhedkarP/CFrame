/**
 * 
 */
package com.cassiopae.selenium.utils.excel;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.service.model.ApplicationConstant;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 * @author jraut
 *
 */
public class ObjectRepoInitialization {
	/*private ObjectRepoInitialization() {

	}*/

	private static Logger applicationLogger = LogManager.getLogger(ObjectRepoInitialization.class);

	public static Map<String, Map<String, List<String>>> masterLocatorMap = null;
	// ********************************************* Object Repository
	// ***********************************************************//
	public static final String DEAL_LOCATOR = "Deal";
	public static final String ACTOR_LOCATOR = "Actor";
	public static final String CONTRACT_LOCATOR = "Contract";
	public static final String EXPENSE_LOCATOR = "Expenses";
	public static final String EVENT_LOCATOR = "Events";
	public static final String PANEL_LOCATOR = "Panels";
	public static final String RECEIVABLE_LOCATOR = "Receivables";
	public static final String CONFIGURATION_LOCATOR = "Configuration";
	public static final String GENERAL_LOCATOR = "General";
	public static final String ASSET_LOCATOR = "Asset";
	public static final String CASHFLOW_LOCATOR = "CashFlow";
	public static final String CONSTRUCTION_LOCATOR = "Construction";
	public static final String PROPERTIES_LOCATOR = "Properties";
	public static final String DAMAGES_LOCATOR = "Damages";
	public static final String INSURANCE_LOCATOR = "Insurances";
	public static final String CLEARSUSPENSEACC_LOCATOR = "ClearSusAccount";
	public static final String APPLY_UNAPPLY_LOCATOR = "AplyUnaply";
	public static final String MISC_ENTRY_LOCATOR = "MisEntries";
	public static final String SERVICING_LOCATOR = "Servicing";
	public static final String LATECHARGE_LOCATOR = "Latecharges";
	public static final String COMPANIES_LOCATOR = "Companies";
	public static final String CARDS_LOCATOR = "Cards";
	public static final String BATCHPROCESS_LOCATOR = "BatchProcess";
	public static final String COLLECTION_LOCATOR = "Collection";
	public static final String TASK_LOCATOR = "Task";
	public static final String REFUNDOVERSUSPENSE_LOCATOR = "RundOverPayment";
	public static final String POS_PANEL = "POS_Panels";
	public static final String COLLATERAL_LOCATROR = "Collateral";
	public static final String WHOLESALE_LOCATOR = "Wholesale";
	
	public static final String POS_MY_DEALS = "POS_MyDeals";
	public static final String POS_NEW_DEAL = "POS_NewDeal";
	public static final String POS_MY_CONTRACTS = "POS_MyContracts";
	public static final String POS_MY_ASSET = "POS_MyAsset";
	public static final String POS_MY_DOCUMENTS = "POS_MyDocuments";
	public static final String POS_MY_CREDIT_LINES = "POS_MyCreditLines";
	public static final String POS_MY_USER = "POS_MyUser";
	public static final String POS_TIMELINE = "POS_Timeline";
	public static final String POS_LANDING_PAGE = "POS_LandingPage";
	
	public static final String CC_PRODUCT = "CC_Product";
	public static final String CC_SCALE = "CC_Scale";
	public static final String CC_RULE = "CC_Rule";
	public static final String CC_WORKFLOW = "CC_Workflow";
	public static final String CC_PRICINGELEMENT = "CC_PricingElement";
	public static final String CC_MATRIX = "CC_Matrix";
	
	protected static Map<String, List<String>> Configuration, MisEntries, BatchProcess, AplyUnaply, ClearSusAccount,
			RundOverPayment, Task, Latecharges, Servicing, Expenses, Deal, Events, Panels, Actor, POS_Panels, General,
			Contract, Receivables, Asset, CashFlow, Construction, Damages, Companies, Cards, Collateral, Properties,
			Insurances, Collection,POS_Timeline,POS_MyDeals,POS_NewDeal, POS_MyContracts,POS_MyAsset,POS_MyDocuments,
			POS_MyCreditLines,POS_MyUser ,Wholesale,CC_Product ,CC_Scale,CC_Rule,CC_Workflow,CC_PricingElement,CC_Matrix,POS_LandingPage = null;
	static {
		try {
			objectRepositoryInitialization();
		} catch (Exception exception) {
			applicationLogger.error(ErrorMessageConstant.OBJECT_REPO_INI_FAILED + exception.getMessage(), exception);
			throw new CATTException(ErrorMessageConstant.OBJECT_REPO_INI_FAILED + exception.getMessage());
		}
	}
	static {
		masterLocatorMap = new HashMap<>();
		masterLocatorMap.put(ACTOR_LOCATOR, Actor);
		masterLocatorMap.put(DEAL_LOCATOR, Deal);
		masterLocatorMap.put(CONTRACT_LOCATOR, Contract);
		masterLocatorMap.put(EXPENSE_LOCATOR, Expenses);
		masterLocatorMap.put(EVENT_LOCATOR, Events);
		masterLocatorMap.put(PANEL_LOCATOR, Panels);
		masterLocatorMap.put(RECEIVABLE_LOCATOR, Receivables);
		masterLocatorMap.put(CONFIGURATION_LOCATOR, Configuration);
		masterLocatorMap.put(GENERAL_LOCATOR, General);
		masterLocatorMap.put(ASSET_LOCATOR, Asset);
		masterLocatorMap.put(CASHFLOW_LOCATOR, CashFlow);
		masterLocatorMap.put(CONSTRUCTION_LOCATOR, Construction);
		masterLocatorMap.put(PROPERTIES_LOCATOR, Properties);
		masterLocatorMap.put(DAMAGES_LOCATOR, Damages);
		masterLocatorMap.put(INSURANCE_LOCATOR, Insurances);
		masterLocatorMap.put(CLEARSUSPENSEACC_LOCATOR, ClearSusAccount);
		masterLocatorMap.put(APPLY_UNAPPLY_LOCATOR, AplyUnaply);
		masterLocatorMap.put(MISC_ENTRY_LOCATOR, MisEntries);
		masterLocatorMap.put(SERVICING_LOCATOR, Servicing);
		masterLocatorMap.put(LATECHARGE_LOCATOR, Latecharges);
		masterLocatorMap.put(COMPANIES_LOCATOR, Companies);
		masterLocatorMap.put(CARDS_LOCATOR, Cards);
		masterLocatorMap.put(WHOLESALE_LOCATOR, Wholesale);
		masterLocatorMap.put(BATCHPROCESS_LOCATOR, BatchProcess);
		masterLocatorMap.put(COLLECTION_LOCATOR, Collection);
		masterLocatorMap.put(TASK_LOCATOR, Task);
		masterLocatorMap.put(REFUNDOVERSUSPENSE_LOCATOR, RundOverPayment);
		masterLocatorMap.put(POS_PANEL, POS_Panels);
		masterLocatorMap.put(COLLATERAL_LOCATROR, Collateral);
		masterLocatorMap.put(POS_MY_DEALS, POS_MyDeals);
		masterLocatorMap.put(POS_NEW_DEAL, POS_NewDeal);
		masterLocatorMap.put(POS_MY_CONTRACTS, POS_MyContracts);
		masterLocatorMap.put(POS_MY_ASSET, POS_MyAsset);
		masterLocatorMap.put(POS_MY_DOCUMENTS, POS_MyDocuments);
		masterLocatorMap.put(POS_MY_CREDIT_LINES, POS_MyCreditLines);
		masterLocatorMap.put(POS_MY_USER, POS_MyUser);
		masterLocatorMap.put(POS_TIMELINE, POS_Timeline);
		masterLocatorMap.put(CC_PRODUCT, CC_Product);
		masterLocatorMap.put(CC_SCALE, CC_Scale);
		masterLocatorMap.put(CC_RULE, CC_Rule);
		masterLocatorMap.put(CC_MATRIX, CC_Matrix);
		masterLocatorMap.put(CC_PRICINGELEMENT, CC_PricingElement);
		masterLocatorMap.put(CC_WORKFLOW, CC_Workflow);
		masterLocatorMap.put(POS_LANDING_PAGE, POS_LandingPage);
	}

	public static void objectRepositoryInitialization() {
		
		Workbook workBook = null;
		Path backupFile = Paths.get(ApplicationConstant.objectRepositoryPath.replace(".xls", "") + "_Last_Backup.xls");
		File inputWorkbook = new File(ApplicationConstant.objectRepositoryPath);
		applicationLogger.info("Fetching web element properties from object repository present at location  : "+ApplicationConstant.objectRepositoryPath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
			try {
				Files.copy(Paths.get(ApplicationConstant.objectRepositoryPath), backupFile,StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException exception) {
				applicationLogger.error(ErrorMessageConstant.BACK_UP_CREATION_FAILED + exception.getMessage(),
						exception);
				throw new CATTException(ErrorMessageConstant.BACK_UP_CREATION_FAILED + exception.getMessage());
			}
			try {
				workBook = Workbook.getWorkbook(inputWorkbook);
			} catch (BiffException | IOException exception) {
				applicationLogger.error(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage(), exception);
				throw new CATTException(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
			}
			for (int i = 0; i < workBook.getNumberOfSheets(); i++) {
				String sheetName = workBook.getSheet(i).getName();
				if (sheetName.equals(DEAL_LOCATOR))
					Deal = createLocatorHashMap(workBook, DEAL_LOCATOR);
				else if (sheetName.equals(ACTOR_LOCATOR))
					Actor = createLocatorHashMap(workBook, ACTOR_LOCATOR);
				else if (sheetName.equals(CONTRACT_LOCATOR))
					Contract = createLocatorHashMap(workBook, CONTRACT_LOCATOR);
				else if (sheetName.equals(EXPENSE_LOCATOR))
					Expenses = createLocatorHashMap(workBook, EXPENSE_LOCATOR);
				else if (sheetName.equals(CONFIGURATION_LOCATOR))
					Configuration = createLocatorHashMap(workBook, CONFIGURATION_LOCATOR);
				else if (sheetName.equals(EVENT_LOCATOR))
					Events = createLocatorHashMap(workBook, EVENT_LOCATOR);
				else if (sheetName.equals(CASHFLOW_LOCATOR))
					CashFlow = createLocatorHashMap(workBook, CASHFLOW_LOCATOR);
				else if (sheetName.equals(ASSET_LOCATOR))
					Asset = createLocatorHashMap(workBook, ASSET_LOCATOR);
				else if (sheetName.equals(RECEIVABLE_LOCATOR))
					Receivables = createLocatorHashMap(workBook, RECEIVABLE_LOCATOR);
				else if (sheetName.equals(GENERAL_LOCATOR))
					General = createLocatorHashMap(workBook, GENERAL_LOCATOR);
				else if (sheetName.equals(PANEL_LOCATOR))
					Panels = createLocatorHashMap(workBook, PANEL_LOCATOR);
				else if (sheetName.equals(CONSTRUCTION_LOCATOR))
					Construction = createLocatorHashMap(workBook, CONSTRUCTION_LOCATOR);
				else if (sheetName.equals(PROPERTIES_LOCATOR))
					Properties = createLocatorHashMap(workBook, PROPERTIES_LOCATOR);
				else if (sheetName.equals(DAMAGES_LOCATOR))
					Damages = createLocatorHashMap(workBook, DAMAGES_LOCATOR);
				else if (workBook.getSheet(i).getName().equals(INSURANCE_LOCATOR))
					Insurances = createLocatorHashMap(workBook, INSURANCE_LOCATOR);
				else if (sheetName.equals(CLEARSUSPENSEACC_LOCATOR))
					ClearSusAccount = createLocatorHashMap(workBook, CLEARSUSPENSEACC_LOCATOR);
				else if (sheetName.equals(APPLY_UNAPPLY_LOCATOR))
					AplyUnaply = createLocatorHashMap(workBook, APPLY_UNAPPLY_LOCATOR);
				else if (sheetName.equals(MISC_ENTRY_LOCATOR))
					MisEntries = createLocatorHashMap(workBook, MISC_ENTRY_LOCATOR);
				else if (sheetName.equals(SERVICING_LOCATOR))
					Servicing = createLocatorHashMap(workBook, SERVICING_LOCATOR);
				else if (sheetName.equals(LATECHARGE_LOCATOR))
					Latecharges = createLocatorHashMap(workBook, LATECHARGE_LOCATOR);
				else if (sheetName.equals(COMPANIES_LOCATOR))
					Companies = createLocatorHashMap(workBook, COMPANIES_LOCATOR);
				else if (sheetName.equals(CARDS_LOCATOR))
					Cards = createLocatorHashMap(workBook, CARDS_LOCATOR);
				else if (sheetName.equals(BATCHPROCESS_LOCATOR))
					BatchProcess = createLocatorHashMap(workBook, BATCHPROCESS_LOCATOR);
				else if (sheetName.equals(COLLECTION_LOCATOR))
					Collection = createLocatorHashMap(workBook, COLLECTION_LOCATOR);
				else if (sheetName.equals(TASK_LOCATOR))
					Task = createLocatorHashMap(workBook, TASK_LOCATOR);
				else if (sheetName.equals(REFUNDOVERSUSPENSE_LOCATOR))
					RundOverPayment = createLocatorHashMap(workBook, REFUNDOVERSUSPENSE_LOCATOR);
				else if (sheetName.equals(COLLATERAL_LOCATROR))
					Collateral = createLocatorHashMap(workBook, COLLATERAL_LOCATROR);
				else if (sheetName.equals(WHOLESALE_LOCATOR)) {
					Wholesale = createLocatorHashMap(workBook, WHOLESALE_LOCATOR);}
			
				else if (sheetName.equals(POS_PANEL))
					POS_Panels = createLocatorHashMap(workBook, POS_PANEL);
				else if (sheetName.equals(POS_TIMELINE))
					POS_Timeline = createLocatorHashMap(workBook, POS_TIMELINE);
				else if (sheetName.equals(POS_MY_DEALS))
					POS_MyDeals = createLocatorHashMap(workBook, POS_MY_DEALS);
				else if (sheetName.equals(POS_NEW_DEAL))
					POS_NewDeal = createLocatorHashMap(workBook, POS_NEW_DEAL);
				else if (sheetName.equals(POS_MY_CONTRACTS))
					POS_MyContracts = createLocatorHashMap(workBook, POS_MY_CONTRACTS);
				else if (sheetName.equals(POS_MY_ASSET))
					POS_MyAsset = createLocatorHashMap(workBook, POS_MY_ASSET);
				else if (sheetName.equals(POS_MY_DOCUMENTS))
					POS_MyDocuments = createLocatorHashMap(workBook, POS_MY_DOCUMENTS);
				else if (sheetName.equals(POS_MY_CREDIT_LINES))
					POS_MyCreditLines = createLocatorHashMap(workBook, POS_MY_CREDIT_LINES);
				else if (sheetName.equals(POS_MY_USER))
					POS_MyUser = createLocatorHashMap(workBook, POS_MY_USER);
				else if (sheetName.equals(CC_PRODUCT))
					CC_Product = createLocatorHashMap(workBook, CC_PRODUCT);
				else if (sheetName.equals(CC_MATRIX))
					CC_Matrix = createLocatorHashMap(workBook, CC_MATRIX);
				else if (sheetName.equals(CC_PRICINGELEMENT))
					CC_PricingElement = createLocatorHashMap(workBook, CC_PRICINGELEMENT);
				else if (sheetName.equals(CC_RULE))
					CC_Rule = createLocatorHashMap(workBook, CC_RULE);
				else if (sheetName.equals(CC_SCALE))
					CC_Scale = createLocatorHashMap(workBook, CC_SCALE);
				else if (sheetName.equals(CC_WORKFLOW))
					CC_Workflow = createLocatorHashMap(workBook, CC_WORKFLOW);
				else if (sheetName.equals(POS_LANDING_PAGE))
					POS_LandingPage = createLocatorHashMap(workBook, POS_LANDING_PAGE);
			}
			if (inputWorkbook.length() > 0) {
				excelBackupDeletion(backupFile);
			} else {
				applicationLogger.error(ErrorMessageConstant.FILE_CORRUPTED);
				try {
					Files.delete(inputWorkbook.toPath());
				} catch (Exception exception) {
					applicationLogger.error(ErrorMessageConstant.EXCEL_FILE_DELETION_FAILED + exception.getMessage(),
							exception);
					throw new CATTException(ErrorMessageConstant.EXCEL_FILE_DELETION_FAILED + exception.getMessage());
				}
				try {
					Files.copy(backupFile, Paths.get(ApplicationConstant.objectRepositoryPath));
				} catch (Exception exception) {
					applicationLogger.error(ErrorMessageConstant.EXCEL_COPPING_FAILED + exception.getMessage(),
							exception);
					throw new CATTException(ErrorMessageConstant.EXCEL_COPPING_FAILED + exception.getMessage());
				}
			}
		} else {
			applicationLogger.error(ErrorMessageConstant.FILE_NOT_FOUND + ApplicationConstant.objectRepositoryPath );
			throw new CATTException(ErrorMessageConstant.FILE_NOT_FOUND + ApplicationConstant.objectRepositoryPath );
		}
	}

	private static Map<String, List<String>> createLocatorHashMap(Workbook w, String sheetName) {
		String value = null;
		String key = null;
		Map<String, List<String>> locatorKeyMap = new HashMap<>();
		Sheet sheet = w.getSheet(sheetName);// sheet.getRow(row).length
		int noOfRows = sheet.getRows();// 100
		for (int rowNumber = 1; rowNumber < noOfRows; rowNumber++) {
			Cell cell = sheet.getCell(1, rowNumber);// col,row
			key = cell.getContents();
			if (!locatorKeyMap.containsKey(key)) {
				List<String> valuesList = new ArrayList<>();
				for (int columnNumber = 2; columnNumber < 5; columnNumber++) {
					cell = sheet.getCell(columnNumber, rowNumber);
					value = cell.getContents();
					valuesList.add(value);
					locatorKeyMap.put(key, valuesList);
				}
			} else {
			    if(!StringUtils.isEmpty(key))
			    {
				//applicationLogger.error(key+ErrorMessageConstant.DUPLICATE_KEY_FOUND + sheetName);
			    }
			}
		}
		return locatorKeyMap;
	}

	public static void excelBackupDeletion(Path backupFilePath) {
		try {
			Files.delete(backupFilePath);
		} catch (Exception exception) {
			applicationLogger.error(ErrorMessageConstant.FILE_DELETION_FAILED + exception.getMessage(), exception);
			throw new CATTException(ErrorMessageConstant.FILE_DELETION_FAILED + exception.getMessage());
		}
	}

}
