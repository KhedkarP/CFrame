/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class DBUpdateQueryAction implements PerformAction {

	
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + excelTestCaseFieldsTO.getInputTestData());
		String dbValue = null;
		String application = CommonUtility.getApplicationNameFromWorksheetName( testCaseDetailTO.getWorkSheetName());
		String[] inputQuery = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		dbValue = CommonFunctions.executeUpdateDBQuery(inputQuery, testCaseDetailTO.getVariableHolder(),
				testCaseDetailTO.getReportingLogger(),application);
		
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), dbValue);
		}

	}

}
