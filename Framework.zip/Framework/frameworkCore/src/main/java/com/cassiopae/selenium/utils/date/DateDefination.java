
package com.cassiopae.selenium.utils.date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;

public class DateDefination
{
		// ************************** TimeStamp Variables Details ***************************************//
		public static Map<String, String> DateDayTime=reportDateTime();
		public static String Date=DateDayTime.get("Date");
		public static String Time=DateDayTime.get("Time");
		public static String Today=DateDayTime.get("Today");
		public static String NumVal=DateDayTime.get("NumVal");
		public static String TodayDate_DDMMYYYY=DateDayTime.get("TodayDate_DDMMYYYY");
		public static String TodayDate_YYYYMMDD=DateDayTime.get("TodayDate_YYYYMMDD");
		public static String execution_evidences_date_format=DateDayTime.get("execution_evidences_date_format");
		public static String Timestamp=RandomStringUtils.randomAlphanumeric(5);

		// ****************************** Date and Time definitions ***************//
		public static Map<String, String> reportDateTime()
		{
				DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-dd-HH-mm-ss"); // 11-05-2016
				Date date=new Date();
				String Date=dateFormat.format(date);
				DateFormat Today1=new SimpleDateFormat("dd_MM_YYYY"); // 11-05-2016
				Date Today2=new Date();
				String Today=Today1.format(Today2);
				DateFormat Time1=new SimpleDateFormat("HH_mm_ss"); // 11-05-2016
				Date Time2=new Date();
				String Time=Time1.format(Time2);
				DateFormat numVal=new SimpleDateFormat("mmss"); // 11-05-2016
				Date numVal2=new Date();
				String Num=numVal.format(numVal2);
				DateFormat DMY=new SimpleDateFormat("ddMMYYYY"); // 11-05-2016
				Date DDMMYYYY_1=new Date();
				String DDMMYYYY=DMY.format(DDMMYYYY_1);
				
				DateFormat YMD=new SimpleDateFormat("YYYYMMdd"); // 11-05-2016
				Date YYYYMMDD_1=new Date();
				String TodayDate_YYYYMMDD=YMD.format(YYYYMMDD_1);
				
				DateFormat YYYY_MM_DD=new SimpleDateFormat("YYYY_MM_dd");
				Date YYYYMMDD=new Date();
				String execution_evidences_date=YYYY_MM_DD.format(YYYYMMDD);
				
				HashMap<String, String> result=new HashMap<String, String>();
				result.put("Date",Date);
				result.put("Today",Today);
				result.put("Time",Time);
				result.put("NumVal",Num);
				result.put("TodayDate_DDMMYYYY",DDMMYYYY);
				result.put("TodayDate_YYYYMMDD",TodayDate_YYYYMMDD);
				result.put("execution_evidences_date_format",execution_evidences_date);
				return result;
		}

}
