
package com.cassiopae.selenium.service.model;

import java.util.HashSet;
import java.util.Set;

import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class ApplicationConstant {
	private ApplicationConstant() {

	}

	public static String platform = System.getProperty("os.name");


	// ************************************ Excel sheet / Status variables
	// ********************************//

	public static final String excelStatusSheetName = InitializeConstants.dashboard_excel_status_sheet_name;
	public static final String excelTestDataSheetName = InitializeConstants.test_data_sheet_name;
	public static final int excelUsernameColumn = InitializeConstants.username_column_Number;
	public static final int excelPasswordColumn = InitializeConstants.passowrd_column_Number;
	public static int excelStatusColumn = InitializeConstants.status_column_Number;
	public static int defectIDColumn = InitializeConstants.defect_id_column_Number;
	public static int excelErrorColumn = InitializeConstants.error_column_Number;
	public static int excelGeneratedRferenceColumn1 = InitializeConstants.Generated_Reference_Column1;
	public static int excelGeneratedRferenceColumn2 = InitializeConstants.Generated_Reference_Column2;
	public static int excelGeneratedRferenceColumn3 = InitializeConstants.Generated_Reference_Column3;
	public static int excelVideoColumn = InitializeConstants.video_path;
	public static int excelExecutionTimePassColumnNo = InitializeConstants.execution_duration_column;
	
	public static final Set<String> alertIssueKeyword = appAlertIssueKeyword();
	
	public static final Set<String> appAlertAcceptKeyword =appAlertAcceptKeyword();
	
	public static Set<String> appAlertIssueKeyword() {
		String[] appAlertIssueKeyword = CommonUtility.splitStringUsingPattern(
				InitializeConstants.alertHandling.get("FailTCWhenAlertMessageContains"), CommonConstant.COMMA_SEPERATOR);
		HashSet<String> appAlertKeywords = new HashSet<>();
			for (int i=0; i< appAlertIssueKeyword.length ; i++) {
				appAlertKeywords.add(appAlertIssueKeyword[i]);
			}
		return appAlertKeywords;
	}
	
	public static Set<String> appAlertAcceptKeyword() {
		String[] appAlertAcceptKeyword = CommonUtility.splitStringUsingPattern(
				InitializeConstants.alertHandling.get("AcceptAlertMessageContains"), CommonConstant.COMMA_SEPERATOR);
		HashSet<String> appAlertKeywords = new HashSet<>();
			for (int i=0; i< appAlertAcceptKeyword.length ; i++) {
				appAlertKeywords.add(appAlertAcceptKeyword[i]);
			}
		return appAlertKeywords;
	}
	
	public static String objectRepositoryPath ;
	// ******************************************
	// ***********************************************//
	public static String initializeEnvspecificTestDataPath = null;
	public static String initializeTestEnvExcelPath = null;
	public static String PAYMENT_SCHEDULE = "Payment_Schedule";
	public static String EXECUTION_MODE_TEST_DATA = "Yes";

}
