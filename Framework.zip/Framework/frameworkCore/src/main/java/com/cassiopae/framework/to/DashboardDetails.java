/**
 * 
 */
package com.cassiopae.framework.to;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author nbhil
 *
 */
public class DashboardDetails {

	private final Map<String, LinkedList<XlsFileRowDetails>> xlsFileRowDetailsMap = new LinkedHashMap<>();
	private final Map<String, Map<String, Integer>> mapOfClassWithMethodPriority = new LinkedHashMap<>();
	private final Map<String, ArrayList<String>> mapOfClassMethod = new HashMap<>();
	private final Map<String, LinkedList<String>> projectTestCase = new LinkedHashMap<>();
	private String domainName;

	public Map<String, LinkedList<XlsFileRowDetails>> getXlsFileRowDetailsMap() {
		return xlsFileRowDetailsMap;
	}

	public Map<String, Map<String, Integer>> getMapOfClassWithMethodPriority() {
		return mapOfClassWithMethodPriority;
	}

	public Map<String, ArrayList<String>> getMapOfClassMethod() {
		return mapOfClassMethod;
	}

	/*public Map<String, LinkedList<String>> getProductTestCase() {
		return productTestCase;
	}*/

	public Map<String, LinkedList<String>> getProjectTestCase() {
		return projectTestCase;
	}

	/**
	 * @return the domainName
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * @param domainName the domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

}
