/**
 * 
 */
package com.cassiopae.custom.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.operator.utils.OperatorUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class GetComparedValues implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String operation = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputData[0].trim());
		String valueArray = inputData[1];
		String[] values = CommonUtility.splitStringUsingPattern(valueArray, CommonConstant.COMMA_SEPERATOR);
		String[] decimalValueArray = new String[values.length];

		String returnValue = null;
		for (int k = 0; k < values.length; k++) {
			decimalValueArray[k] = OperatorUtility.getNumberAsdecimalFormat(
					VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), values[k]));
		}
		List<BigDecimal> tempArray = new ArrayList<>();
		for (String s : decimalValueArray) {
			tempArray.add(new BigDecimal(s));
		}
		Collections.sort(tempArray);
		if (operation.equalsIgnoreCase(CommonConstant.MAXIMUM)) {
			returnValue = tempArray.get(tempArray.size() - 1).toString();
			testCaseDetailTO.getReportingLogger().info("Maximum value is: " +returnValue);
		} else if (operation.equalsIgnoreCase(CommonConstant.MINIMUM)) {
			returnValue = tempArray.get(0).toString();
			testCaseDetailTO.getReportingLogger().info("Minimum value is: " +returnValue);
		} else {
			testCaseDetailTO.getReportingLogger().error(operation + " - This operation is not supported");
			throw new CATTException("Invalid argument for action: "+excelTestCaseFields.getAction());
		}
		if (StringUtils.isNotEmpty(excelTestCaseFields.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), returnValue);
		}
	}

}
