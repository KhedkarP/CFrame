
package com.cassiopae.selenium.utils.driver;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.services.listener.WebDriverListener;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.FileStructureConstants;
import com.neotys.selenium.proxies.NLWebDriver;
import com.neotys.selenium.proxies.NLWebDriverFactory;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.html5.LocalStorage;
import org.openqa.selenium.html5.WebStorage;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class DriverDefination {

	private static Logger logger = LogManager.getLogger(DriverDefination.class);

	private DriverDefination() {

	}

	/**
	 * This method return the driver instance for IE and Chrome browser.
	 * 
	 * @param browser      String
	 * @param workseetName String
	 * @param domainName   String
	 * @return Map<String, String>
	 */

	public static Map<String, String> getNewDriverInstanceMap(final String browser, final String workseetName,
			final String domainName) {
		Map<String, String> result = new HashMap<>();
		if (browser.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			result = createNewDriverInstance(browser, workseetName, domainName,
					FileStructureConstants.localDriverIEBrowser, InitializeConstants.ie_driver_executable_name);
		} else if (browser.equalsIgnoreCase(CommonConstant.CHROME_BROWSER)) {
			result = createNewDriverInstance(browser, workseetName, domainName,
					FileStructureConstants.localDriverForChromeBrowser,
					InitializeConstants.chrome_driver_executable_name);
		} else if (browser.equalsIgnoreCase(CommonConstant.MS_EDGE_BROWSER)) {
			result = createNewDriverInstance(browser, workseetName, domainName,
					FileStructureConstants.localDriverForMSEdgeBrowser,
					InitializeConstants.msedge_driver_executable_name);
		}

		return result;

	}

	/**
	 * This method will create Driver Instance and put into HashMap
	 * 
	 * @param browser      String
	 * @param worksheetName String
	 * @param domainName   String
	 * @param driverPath   String
	 * @param driverName   String
	 * @return HashMap<String, String>
	 * @throws Throwable
	 */
	private static Map<String, String> createNewDriverInstance(final String browser, final String worksheetName,
			final String domainName, String driverPath, String driverName) {
		File newfile = null;
		File source = null;
		File dest = null;
		File oldfile = null;
		File closeInstance = null;
		source = new File(driverPath);
		dest = new File(CommonUtility.geBrowserInstanceLocation(domainName) + worksheetName);
		String destPath = dest.toPath() + InitializeConstants.fileSeparator + worksheetName + ".exe";
		
		try {
			FileUtils.copyFileToDirectory(source, dest);
			if(FileUtility.checkFileExists(dest.getAbsolutePath()+File.separator+driverName)) {
				logger.info(driverName+ " browser executable copied successfully to browser instance folder");
			}
			oldfile = new File(dest.toPath() + InitializeConstants.fileSeparator + driverName);
			newfile = new File(destPath);
			Path path = Paths.get(destPath);
			if (newfile.exists()) {
				closeInstance = createNewFileInstance(worksheetName, newfile, dest);
				//boolean isdeleted = newfile.delete();
				try {
					java.nio.file.Files.delete(path);
				}catch (AccessDeniedException ade) {
					Process process = Runtime.getRuntime().exec("\"" + closeInstance.getAbsolutePath() + "\"");
					process.waitFor();
					try {
					java.nio.file.Files.delete(path);} catch(Exception exp) {logger.error(exp.getMessage(), exp);}
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
				}
				
				if (oldfile.renameTo(newfile)) {
					logger.info("Browser executable renamed sucessfully with test method name - " + worksheetName);
				} else {
					logger.error("Browser executable rename failed for browser '"+browser+"', Trying to close already open instance by executing batch file: "+closeInstance.getAbsolutePath() );
					Process process = Runtime.getRuntime().exec("\"" + closeInstance.getAbsolutePath() + "\"");
					process.waitFor();
					if (oldfile.renameTo(newfile)) {
						logger.info("Browser executable renamed sucessfully with test method name - " + worksheetName);
					} else {
						logger.error("Browser executable rename operation failed for '"+browser+"' browser");
					}
				}
			} else {
				closeInstance = createNewFileInstance(worksheetName, newfile, dest);
				if (oldfile.renameTo(newfile)) {
					logger.info("New executable file renamed successfully with method name as : " + worksheetName);
				} else {
					logger.error("Browser executable rename operation failed");
				}
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTFileOperationException(exception.getMessage());
		}
		return getResultMap(newfile.getAbsolutePath(), dest.getAbsolutePath(), closeInstance.getAbsolutePath());
	}

	/**
	 * This method populate the result Map.
	 * 
	 * @param newfilePath   String
	 * @param destFilePath  String
	 * @param closeFilePath String
	 * @return Map<String, String>
	 */
	private static Map<String, String> getResultMap(String newfilePath, String destFilePath, String closeFilePath) {
		Map<String, String> result = new HashMap<String, String>();
		result.put(InitializeConstants.NEW_DRIVER_INSTANCE, newfilePath);
		result.put(InitializeConstants.DRIVER_INSTANCE_CLOSE, closeFilePath);
		result.put(InitializeConstants.DRIVER_INSTANCE_DELETE, destFilePath);
		return result;
	}

	/**
	 * This method create new file instance if not exists.
	 * 
	 * @param workseetName String
	 * @param newfile      File
	 * @param dest         File
	 * @return File
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static File createNewFileInstance(final String workseetName, File newfile, File dest) {
		Process process;
		File fileInstance = null;
		try {
			fileInstance = new File(dest.getAbsolutePath() + InitializeConstants.fileSeparator + workseetName + ".bat");
			if (!fileInstance.exists()) {
				if (fileInstance.createNewFile()) {
					logger.info("New bat file created successfully for closing instances: " + fileInstance);
				}
			} else {
				logger.info("Close browser instance bat file is already exists");
			}
			deleteEdgeProfile(dest.getAbsolutePath());
			List<String> lines = Arrays.asList("taskkill /f /im " + newfile.getName());
			Path file = Paths.get(fileInstance.getAbsolutePath());
			Files.write(file, lines, StandardCharsets.UTF_8);
			process = Runtime.getRuntime().exec("\"" + fileInstance.getAbsolutePath() + "\"");
			process.waitFor();
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTException(exception.getMessage());
		}
		return fileInstance;
	}

	/**
	 * THis method initialize the web driver.
	 * 
	 * @param browser      String
	 * @param methodDriver String
	 * @param domainName   String
	 * @return WebDriver
	 */
	public static WebDriver webDriverInitializer(final String browser, final String methodDriver,
			final String domainName, String downloadPath, String workBookName, String workSheetName,TestCaseCommonData testCaseCommonData) {
		WebDriver driver = null;

		try {
			if (browser.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
				driver = createIEDriverForWindows(methodDriver, driver, downloadPath, workBookName, domainName,
						workSheetName);
			}
		} catch (WebDriverException exception) {
			logger.error(ErrorMessageConstant.IE_DRIVER_INI_FAILED + exception.getMessage());
			throw new CATTException(exception.getMessage());
		}
		try {
			if (browser.equalsIgnoreCase(CommonConstant.CHROME_BROWSER)) {
				if (ApplicationConstant.platform.contains(CommonConstant.WINDOWS)) {
					driver = createChromeDriverForWindows(methodDriver, downloadPath,testCaseCommonData);
				} else if (ApplicationConstant.platform.contains(CommonConstant.LINUX)) {
					driver = createChromeDriverForLinux(downloadPath);
				} else {
					addMessageToLogger();
				}
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.CHROM_DRIVER_INI_FAILED + exception.getMessage());
			logger.error(exception);
			exception.printStackTrace();
			throw new CATTException(exception.getMessage());
		}
		try {
			if (browser.equalsIgnoreCase(CommonConstant.MOZILLA_BROWSER)) {
				if (ApplicationConstant.platform.contains(CommonConstant.WINDOWS)) {
					driver = createMozillaDriverForWindows(methodDriver, downloadPath);
				} else if (ApplicationConstant.platform.contains(CommonConstant.LINUX)) {
					driver = createMozillaDriverForLinux(downloadPath);
				} else {
					addMessageToLogger();
				}
			}
		} catch (java.lang.Exception exception) {
			logger.error(ErrorMessageConstant.MOZILLA_DRIVER_INI_FAILED + exception.getMessage());
			throw new CATTException(exception.getMessage());
		}
		try {
			if (browser.equalsIgnoreCase(CommonConstant.MS_EDGE_BROWSER)) {
				if (ApplicationConstant.platform.contains(CommonConstant.WINDOWS)) {
					driver = createEdgeDriverForWindows(methodDriver, downloadPath, domainName, workSheetName,testCaseCommonData);
				} else {
					addMessageToLogger();
				}
			}
		} catch (java.lang.Exception exception) {
			logger.error(ErrorMessageConstant.EDGE_DRIVER_INI_FAILED + exception.getMessage());
			exception.printStackTrace();
			throw new CATTException(exception.getMessage());
		}
		if (workSheetName.contains(DBConstant.POS_MODULE)
				&& null != driver) {
			dataTestIDConfigurationForPOS(workSheetName, driver);
		} else if (workSheetName.contains(DBConstant.CC_APP_SHEET_NAME) && null != driver) {
			dataTestIDConfigurationForConfigConsole( driver);
		}
		return driver;
	}

	/**
	 * @param workSheetName
	 * @param driver
	 */
	private static void dataTestIDConfigurationForPOS(String workSheetName, WebDriver driver) {
		try {
				logger.info("Hit pos app URL to set testid configuration: \n \"testids\", \"{\\\"enabled\\\":true}\"");
				driver.get(ApplicationContext.posURL);
				LocalStorage local = ((WebStorage) driver).getLocalStorage();
				local.setItem("testids", "{\"enabled\":true}");
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}
	
	/**
	 * @param workSheetName
	 * @param driver
	 */
	private static void dataTestIDConfigurationForConfigConsole( WebDriver driver) {
		try {
				logger.info("Hit Config console app URL to set testid configuration: \n \"testids\", \"{\\\"enabled\\\":true}\"");
				driver.get(ApplicationContext.configConsoleURL);
				LocalStorage local = ((WebStorage) driver).getLocalStorage();
				local.setItem("testids", "{\"enabled\":true}");
				driver.navigate().refresh();
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
		}
	}

	/**
	 * This method logs the logger statement.
	 */
	private static void addMessageToLogger() {
		logger.error(" **** Please do Configuration for " + ApplicationConstant.platform + " platform********");
	}

	/**
	 * This method returns the Mozilla browser driver
	 * 
	 * @param downloadPath
	 * @return WebDriver
	 */
	private static WebDriver createMozillaDriverForLinux(String downloadPath) {
		WebDriver driver;
		System.setProperty("DISPLAY", ":0");
		FirefoxOptions op = new FirefoxOptions();
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("layout.css.devPixelsPerPx", "0.7");
		profile.setPreference("browser.download.dir", downloadPath);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/vnd.ms-excel;charset=utf-8");
		op.setProfile(profile);
		driver = new FirefoxDriver(op);
		return driver;
	}

	/**
	 * This method returns the Mozilla driver for windows.
	 * 
	 * @param methodDriver String
	 * @param downloadPath String
	 * @return WebDriver
	 */
	private static WebDriver createMozillaDriverForWindows(final String methodDriver, String downloadPath) {
		WebDriver driver;
		System.setProperty(CommonConstant.MOZILLA_BROWSER_PROPERTY, methodDriver);
		FirefoxProfile profile = new FirefoxProfile();
		FirefoxOptions op = new FirefoxOptions();
		profile.setPreference("layout.css.devPixelsPerPx", "0.9");
		op.addArguments("--disable-gpu");
		profile.setPreference("browser.download.dir", downloadPath);
		profile.setPreference("browser.download.manager.showWhenStarting", false);
		profile.setPreference("browser.download.folderList", 2);
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/vnd.ms-excel;charset=utf-8");
		System.setProperty(FirefoxDriver.SystemProperty.DRIVER_USE_MARIONETTE, "true");
		System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");
		op.setProfile(profile);
		driver = new FirefoxDriver(op);
		return driver;
	}

	/**
	 * This method return the Chrome driver for Linux.
	 * 
	 * @param downloadPath String
	 * @return WebDriver
	 */
	private static WebDriver createChromeDriverForLinux(String downloadPath) {
		WebDriver driver;
		System.setProperty("DISPLAY", ":0");
		ChromeOptions op = new ChromeOptions();
		op.addArguments("--disable-extensions");
		op.addArguments("incognito");
		if (!ApplicationContext.localModeOfExecution) {
			op.addArguments("--headless");
		}
		op.addArguments("--window-size=1920,1080");
		HashMap<String, Object> chromeAdditionalOptions = new HashMap<>();
		chromeAdditionalOptions.put("download.default_directory", downloadPath);
		chromeAdditionalOptions.put("download.prompt_for_download", false);
		chromeAdditionalOptions.put("profile.default_content_settings.popups", 0);
		chromeAdditionalOptions.put("download.directory_upgrade", true);
		op.setExperimentalOption("prefs", chromeAdditionalOptions);
		driver = new ChromeDriver(op);
		return driver;
	}

	/**
	 * This method return the Chrome driver for Windows.
	 * 
	 * @param methodDriver String
	 * @param downloadPath String
	 * @return WebDriver
	 */
	private static WebDriver createChromeDriverForWindows(final String methodDriver, String downloadPath,TestCaseCommonData testCaseCommonData) {
		ChromeDriver driver = null;
		System.setProperty(CommonConstant.CHROME_BROWSER_PROPERTY, methodDriver);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-extensions");
		options.addArguments("--start-maximized");
		options.addArguments("--disable-logging");//disable disable browser logging on terminal
		options.addArguments("--no-sandbox"); // Bypass OS security model // if not set then gives issue during parallel
												// exe
		options.setBinary(CommonUtility.getBrowserDriverLocationPath());
		options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		Map<String, Object> chromeAdditionalOptions = new HashMap<>();
		chromeAdditionalOptions.put("download.default_directory", downloadPath);
		chromeAdditionalOptions.put("download.prompt_for_download", false);
		chromeAdditionalOptions.put("useAutomationExtension", false);
		chromeAdditionalOptions.put("profile.default_content_settings.popups", 0);
		chromeAdditionalOptions.put("download.directory_upgrade", true);
		chromeAdditionalOptions.put("plugins.plugins_disabled", "Chrome PDF Viewer");
		chromeAdditionalOptions.put("pdfjs.disabled", true);
		chromeAdditionalOptions.put("plugins.always_open_pdf_externally", true);
		options.setExperimentalOption("prefs", chromeAdditionalOptions);
		if (ApplicationContext.headlessModeOfExecution) {
			logger.info(ReportLoggerConstant.HEADLESS_MODE_BROWSE_INFO);
			options.addArguments("--headless");
		} else if (ApplicationContext.ENABLE_JENKINS_UI_MODE_OF_EXECUTION
				&& !ApplicationContext.headlessModeOfExecution) {
			options.addArguments("--force-device-scale-factor=0.70");
		}
		if (ApplicationContext.neoLoadScriptCreation) {
			Properties systemProperties = System.getProperties();
			systemProperties.setProperty("nl.selenium.proxy.mode", "Design");
			systemProperties.setProperty("nl.design.api.url", "http://localhost:7400/Design/v1/Service.svc/");
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(NLWebDriverFactory.addProxyCapabilitiesIfNecessary(capabilities));

		} else {
			driver = new ChromeDriver(options);
			DevTools devToolConfig=driver.getDevTools();
			testCaseCommonData.setDevTools(devToolConfig);
		}
		return driver;
	}

	/**
	 * This method return the Edge driver for Windows.
	 * 
	 * @param methodDriver String
	 * @param downloadPath String
	 * @return WebDriver
	 */
	private static WebDriver createEdgeDriverForWindows(final String methodDriver, String downloadPath,
			String domainName, String worSheetName,TestCaseCommonData testCaseCommonData) {{
				EdgeDriver driver;
				String dirName = null;
				System.setProperty(CommonConstant.EDGE_BROWSER_PROPERTY, methodDriver);
				EdgeOptions options = new EdgeOptions();
				options.addArguments("--disable-extensions");
				options.addArguments("--start-maximized");
				options.setBinary(CommonUtility.getEdgeBrowserDriverLocationPath());
				options.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
				dirName = copyEdgeProfileAndMoveToBrowserInstance(domainName, worSheetName);
				options.addArguments("user-data-dir=" + dirName);
				options.addArguments("profile-directory=Default");
				Map<String, Object> edgeAdditionalOptions = new HashMap<>();
				edgeAdditionalOptions.put("download.default_directory", downloadPath);
				edgeAdditionalOptions.put("pdfjs.disabled", true);
				edgeAdditionalOptions.put("plugins.always_open_pdf_externally", true);
				options.setExperimentalOption("prefs", edgeAdditionalOptions);
				if (ApplicationContext.headlessModeOfExecution) {
					logger.info(ReportLoggerConstant.HEADLESS_MODE_BROWSE_INFO);
					options.addArguments("--headless");
				} else if (ApplicationContext.ENABLE_JENKINS_UI_MODE_OF_EXECUTION
						&& !ApplicationContext.headlessModeOfExecution) {
					options.addArguments("--force-device-scale-factor=0.70");
				}
				logger.info(ReportLoggerConstant.EDGEBROWSER_CAPABILITES);
				driver = new EdgeDriver(options);
				DevTools devToolConfig=driver.getDevTools();
				testCaseCommonData.setDevTools(devToolConfig);
				return driver;
			}
	}
	/**
	 * @param domainName
	 * @param workseetName
	 * @return dynamic Edge profile Path
	 */
	private static String copyEdgeProfileAndMoveToBrowserInstance(String domainName, String workseetName) {
		logger.info(ReportLoggerConstant.COPY_EDGE_PROFILE);
		File dynamicEdgeProfilePath = null;
		File browserInstDestinationPath = new File(CommonUtility.geBrowserInstanceLocation(domainName) + workseetName);
		// Create dynamic FolderName
		String dynamicFolderName = InitializeConstants.fileSeparator + CommonConstant.EDGEPROFILE
				+ CommonConstant.UNDER_SCORE;
		String data = CommonFunctions.generateDynamicData(CommonConstant.ALPHANUMERIC, CommonConstant.PROFILE_FOlDER_LENGTH);
		String edgeFolderName = browserInstDestinationPath + dynamicFolderName + data;
		dynamicEdgeProfilePath = new File(edgeFolderName);
		try {
			// check directory if doesn't exist create new directory
			if (!dynamicEdgeProfilePath.exists()) {
				dynamicEdgeProfilePath.mkdir();
			}
			// Get source directory location and copy and paste to dynamicEProfilePath
			File souceDir = new File(CommonUtility.getEdgeProfileLocationPath());
			FileUtils.copyDirectory(souceDir, dynamicEdgeProfilePath);
		} catch (IOException e) {
			logger.warn(ErrorMessageConstant.ERROR_OCCURED_MESSAGE+ e.getMessage());
		}
		return dynamicEdgeProfilePath.getAbsolutePath();
	}

	/**
	 * This method returns the IE driver for windows.
	 * 
	 * @param methodDriver String
	 * @param driver       String
	 * @param downloadPath String
	 * @return WebDriver
	 */
	private static synchronized WebDriver createIEDriverForWindows(final String methodDriver, WebDriver driver,
			String downloadPath, String workBookName, String domainName, String worSheetName) {
		if (ApplicationConstant.platform.contains(CommonConstant.WINDOWS)) {
			SeleniumUtility.ieBrowserSettings(downloadPath, workBookName);
			System.setProperty(CommonConstant.IE_BROWSER_PROPERTY, methodDriver);
			DesiredCapabilities capabilities = new DesiredCapabilities();
			logger.info(ReportLoggerConstant.SETTING_IE_CAPABILITY_MESSAGE);
			if (workBookName.contains(FrameworkConstant.POS)) {
				 POSCapabilitesForIEBrowser(capabilities, downloadPath);
			} else {
				 FoBOCapabilitesForIEDriver(capabilities, downloadPath);
			}
			InternetExplorerOptions op = new InternetExplorerOptions(capabilities);
			if (ApplicationContext.neoLoadScriptCreation) {
				Properties systemProperties = System.getProperties();
				systemProperties.setProperty("nl.selenium.proxy.mode", "Design");
				systemProperties.setProperty("nl.design.api.url", "http://localhost:7400/Design/v1/Service.svc/");
				/*DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability("se:ieOptions", desireCap);  // Code commented Need further Enhancements as part of selenium-4 Integration
				driver = new InternetExplorerDriver(NLWebDriverFactory.addProxyCapabilitiesIfNecessary(capabilities));*/
			} else {
				logger.info(ReportLoggerConstant.LAUNCHING_IE_BROWSER_CAPABILITY_MESSAGE);
				File ie_temp = new File(CommonUtility.geBrowserInstanceLocation(domainName) + worSheetName);
				InternetExplorerDriverService.Builder ies = new InternetExplorerDriverService.Builder();
				ies.withExtractPath(ie_temp);
				InternetExplorerDriverService service = ies.build();
				driver = new InternetExplorerDriver(service,op);
			}
			logger.info(ReportLoggerConstant.LAUNCHING_IE_BROWSER_WITH_CAPABILITY_SUCCESS_MESSAGE);
		} else if (ApplicationConstant.platform.contains(CommonConstant.LINUX)) {
			logger.error(ReportLoggerConstant.NO_SUPPORT_FOR_IE);
		} else {
			logger.error("**** Please do Configuration for running IE on " + ApplicationConstant.platform
					+ " platform********");
		}
		return driver;
	}

	public static WebDriver eventFiringWebDriver(final String browser, final String domainName,
			final String workBookName, final String workSheetName, String NewNeoloadProjectPath,
			final String methodDriver,TestCaseCommonData testCaseCommonData) {
		EventFiringWebDriver eventFiringWebdriver = null;
		NLWebDriver driver = null;
		String path = null;
		path = DomainInitialization.initializeDomainwiseDownloadPath(domainName) + workBookName + File.separator
				+ workSheetName + File.separator;
		FileUtility.createNewDirectory(path);
		try {
			WebDriverEventListener eventListener = null;
			eventFiringWebdriver = new EventFiringWebDriver(webDriverInitializer(browser, methodDriver, domainName,
					path, workBookName, workSheetName,testCaseCommonData));
			eventListener = new WebDriverListener();
			eventFiringWebdriver.register(eventListener);
			if (ApplicationContext.neoLoadScriptCreation) {
				if (!StringUtils.isEmpty(InitializeConstants.neoLoadConfig.get("GlobalNeoloadProjectPath"))) {
					NewNeoloadProjectPath = InitializeConstants.neoLoadConfig.get("GlobalNeoloadProjectPath");
				}
				driver = NLWebDriverFactory.newNLWebDriver(eventFiringWebdriver, workSheetName, NewNeoloadProjectPath);
				return driver;
			}
			if(! browser.equalsIgnoreCase(CommonConstant.MS_EDGE_BROWSER)) {
			maximizeWindow(eventFiringWebdriver);
			}
		} catch (java.lang.Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTException(exception.getMessage());
		}
		return eventFiringWebdriver;
	}

	public static void closeDriver(final TestCaseCommonData testCaseCommonDataTO) {
		WebDriver driver = testCaseCommonDataTO.getDriver();
		String closeInstance = testCaseCommonDataTO.getNewDriverInstance()
				.get(InitializeConstants.DRIVER_INSTANCE_CLOSE);
		String deleteInstance = testCaseCommonDataTO.getNewDriverInstance()
				.get(InitializeConstants.DRIVER_INSTANCE_DELETE);
		try {
			logger.info("Closing driver instance : "+closeInstance);
			if (driver != null) {
				driver.quit();
			}
		} catch (NullPointerException | NoSuchSessionException exception) {
			logger.error(exception.getMessage());
			//throw new CATTException("Driver instance/session is already closed : " + exception.getMessage());
		}

		if (testCaseCommonDataTO.getBrowserName().equals(CommonConstant.MS_EDGE_BROWSER)) {
			deleteEdgeProfile(deleteInstance);
		}
		Process process;
		try {
			process = Runtime.getRuntime().exec("\"" + closeInstance + "\"");
			try {
				process.waitFor();
				process = Runtime.getRuntime().exec("\"" + closeInstance + "\"");
				process.waitFor();
				File test = new File(deleteInstance);
				if (test.exists()) {
					String[] entries = test.list();
					for (String s : entries) {
						File currentFile = new File(test.getPath(), s);
						currentFile.delete();
					}
				}
				try {
					test.delete();
				} catch (Exception exception) {
					logger.error(exception.getMessage());
					throw new CATTException(exception.getMessage());
				}
			} catch (InterruptedException exception) {
				logger.error(exception.getMessage());
				throw new CATTException(exception.getMessage());
			}
		} catch (IOException exception) {
			logger.error(exception.getMessage());
			throw new CATTException(exception.getMessage());
		}
	}

	/**
	 * @param testCaseCommonData
	 * Post execution completes This methods will delete Edge profile directory available at BrowserInstance location
	 */
	public static void deleteEdgeProfile(String deleteInstance) {
		File proFolder = new File(deleteInstance);
		if (proFolder.exists()) {
			for (File subFile : proFolder.listFiles()) {
			try {
					if (subFile.isDirectory() && subFile.getName().contains(CommonConstant.EDGEPROFILE)) {
						FileUtils.deleteDirectory(subFile);
					}
			} catch (IOException e) {
				logger.info(ErrorMessageConstant.ERROR_MESSAGE_DELETEPROFILE + e.getMessage());
			}
			}
		} else {
			logger.info(ErrorMessageConstant.EDGE_PROFILE_NOTFOUND);
		}
	}

	/**
	 * This method is used to terminate browser session opened with application
	 * 
	 * @param testCaseCommonDataTO
	 * @param driver
	 */
	private static void terminateSession(final TestCaseCommonData testCaseCommonDataTO, WebDriver driver) {
		String terminationUrl = null;
		if (testCaseCommonDataTO.getWorkSheetName().contains(DBConstant.BO_MODULE)) {
			terminationUrl = ApplicationContext.baseUrlBO + "sessiontermination";
		} else if (testCaseCommonDataTO.getWorkSheetName().contains(DBConstant.MO_MODULE)) {
			terminationUrl = ApplicationContext.baseUrlMO + "sessiontermination";
		}
		if (null != terminationUrl) {
			logger.info("Terminating session : " + terminationUrl);
			driver.get(terminationUrl);
		}
	}

	private static DesiredCapabilities FoBOCapabilitesForIEDriver(DesiredCapabilities explorerOptions,
			String downloadPath) {
		explorerOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		explorerOptions.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
		explorerOptions.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		explorerOptions.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, true);
		explorerOptions.setCapability("ie.setProxyByServer", true);
		explorerOptions.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
		explorerOptions.setCapability("ignoreProtectedModeSettings", true);
		explorerOptions.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		explorerOptions.setCapability("elementScrollBehavior", 1);
		explorerOptions.setCapability("browser.download.dir", downloadPath);
		explorerOptions.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		return explorerOptions;
		/*
		 * desireCap.setCapability("applicationCacheEnabled", true);
		 * desireCap.setCapability("ie.ensureCleanSession", true);//
		 * desireCap.setCapability("handlesAlerts", true);
		 * desireCap.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION,
		 * true); desireCap.setCapability(InternetExplorerDriver.FORCE_CREATE_PROCESS,
		 * false); desireCap.setCapability(InternetExplorerDriver.IE_SWITCHES,
		 * "-private");
		 */

	}

	private static DesiredCapabilities POSCapabilitesForIEBrowser(DesiredCapabilities explorerOptions,
			String downloadPath) {
		explorerOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		explorerOptions.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, true);
		explorerOptions.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		explorerOptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		explorerOptions.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		explorerOptions.setCapability("ignoreProtectedModeSettings", true);
		explorerOptions.setCapability("nativeEvents", true);
		explorerOptions.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);
		explorerOptions.setCapability("javascriptEnabled", true);
		explorerOptions.setCapability("browser.download.dir", downloadPath);
		return explorerOptions;
	}

	/**
	 * @param driver
	 */
	public static void maximizeWindow(EventFiringWebDriver driver) {
		try {
			logger.info(ReportLoggerConstant.WINDOW_MAXIMIZE_LOGGER);
			driver.manage().window().maximize();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
