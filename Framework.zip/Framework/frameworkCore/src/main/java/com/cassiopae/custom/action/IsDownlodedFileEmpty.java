package com.cassiopae.custom.action;

import java.io.File;
import java.util.regex.Pattern;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;

public class IsDownlodedFileEmpty implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		String fileStatus = CommonConstant.FALSE_VALUE;
		Logger reportingLogger = testCaseDetail.getTestCaseCommonData().getReportingLogger();
		CommonFunctions.explicitWait(10000);
		String downloded_Path = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] textBoxInputData = excelTestCaseFields.getInputTestData().trim()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String inputvalue1[] = new String[2];
		if (textBoxInputData.length == 2) {
			inputvalue1[0] = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					textBoxInputData[0]);
			inputvalue1[1] = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					textBoxInputData[1]);
		} else {
			inputvalue1[0]=VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), textBoxInputData[0]);
		}

		fileStatus = CommonUtility.checkFileIsEmptyORNot(downloded_Path, reportingLogger, inputvalue1);
		if (excelTestCaseFields.getStoreValuesInVariable() != null)
			testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), fileStatus);
	}
}
