/**
 * 
 */
package com.cassiopae.excel.dataconvertor.constant;

import com.cassiopae.framework.util.constant.InitializeConstants;

/**
 * @author nbhil
 *
 */
public interface ConvertorConstant {

	public static final String STRING_DATA_CONVERTOR = "STRING";
	public static final String NUMERIC_DATA_CONVERTOR = "NUMERIC";
	public static final String FORMULA_DATA_CONVERTOR = "FORMULA";
	
	public static final String DATE_FORMATE_KEY = "Date";
	public static final String DATA_FORMATE_KEY = "Data";

	public static final String FR_DATE_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("FR_DATE_FORMAT_PATTERN");
	public static final String FR_DATA_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("FR_AMOUNT_FORMAT_PATTERN");
	public static final String EN_DATE_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("EN_DATE_FORMAT_PATTERN");
	public static final String EN_DATA_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("EN_AMOUNT_FORMAT_PATTERN");

	public static final String POS_FR_DATE_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("POS_FR_DATE_FORMAT_PATTERN");
	public static final String POS_FR_DATA_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("POS_FR_AMOUNT_FORMAT_PATTERN");
	public static final String POS_EN_DATE_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("POS_EN_DATE_FORMAT_PATTERN");
	public static final String POS_EN_DATA_FORMATE_VALUE = InitializeConstants.dateAndAmountPatterns.get("POS_EN_AMOUNT_FORMAT_PATTERN");

	public static final String FR_FR_LOCALE_KEY = "fr_FR";
	public static final String EN_FR_LOCALE_KEY = "en_FR";	
	public static final String EN_US_LOCALE_KEY = "en_US";
	public static final String EN_UK_LOCALE_KEY = "en_UK";
	public static final String EN_GB_LOCALE_KEY = "en_GB";
	
	public static final String POS_FR_FR_LOCALE_KEY = "POS_fr_FR";
	public static final String POS_EN_FR_LOCALE_KEY = "POS_en_FR";	
	public static final String POS_EN_US_LOCALE_KEY = "POS_en_US";
	public static final String POS_EN_UK_LOCALE_KEY = "POS_en_UK";

}
