package com.cassiopae.webservices.action;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import io.restassured.path.json.JsonPath;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;

import java.util.regex.Pattern;

public class SOAPAPIGetResponseData implements WSAction {

	private static Logger log = LogManager.getLogger(SOAPAPIGetResponseData.class);

	@Override
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		String[] inputTestData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String responseBody = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestData[0]);
		String[] requiredData = inputTestData[1].split(CommonConstant.COMMA_SEPERATOR);
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		JSONObject json = XML.toJSONObject(responseBody);
		String jsonString = json.toString(4);
		JsonPath jsonPath = new JsonPath(jsonString.replace("\n", "").replace("\r", ""));
		int count = 0;
		String[] variablesList = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getStoreValuesInVariable(),
				CommonConstant.COMMA_SEPERATOR);
		if (requiredData.length == variablesList.length) {
			for (String parameter : requiredData) {
				try {
					parameter=parameter.split(CommonConstant.EnvelopSoapBodyConstant)[1];
					String part3[]=parameter.split(CommonConstant.COLON_SEPERATOR);
					String part4[]=part3[1].split(Pattern.quote(CommonConstant.DOT_OPERATOR));
					String preFinalString1="\""+ part3[0]+CommonConstant.COLON_SEPERATOR+part4[0]+"\""+part3[1].split(part4[0])[0];
					String preFinalString2[]=part3[1].split(part4[0]);
					for (String str:preFinalString2) {
						preFinalString1=preFinalString1.concat(str);

					}
					parameter= CommonConstant.EnvelopSoapBodyConstant +preFinalString1;
					testCaseDetailTO.getReportingLogger().info(parameter);

					String parvalue = jsonPath.getString(parameter);
					if (parvalue == null) {
						reportingLogger.error(WSErrorMessageConstant.INPUT_PARAMETER + parameter+ WSErrorMessageConstant.NOT_AVAILABLE_MSG + responseBody);
						throw new CATTException(WSErrorMessageConstant.INPUT_PARAMETER + parameter+ WSErrorMessageConstant.NOT_AVAILABLE_MSG + responseBody);
					}
					reportingLogger.info(WSReportingLoggerConstant.RETRIVED_VALUE +WSReportingLoggerConstant.PARAMETER + "'"+variablesList[count] + "'" +CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR +CommonConstant.SPACE+ parvalue);
					testCaseDetailTO.getVariableHolder().put(variablesList[count], parvalue);
				} catch (ClassCastException e) {
					log.error(e);
				}
				count++;
			}
		} else {
			reportingLogger.error(WSErrorMessageConstant.PARAMETERS_IMPROPER_ERRORMSG);
			throw new CATTException(WSErrorMessageConstant.PARAMETERS_IMPROPER_ERRORMSG);
		}
	}
}