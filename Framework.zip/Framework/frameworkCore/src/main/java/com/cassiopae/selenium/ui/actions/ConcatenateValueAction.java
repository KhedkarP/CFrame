/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;

/**
 * @author nbhil
 *
 */
public class ConcatenateValueAction implements PerformAction {

	/**
	 * This method execute action for concatenate action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String finalString = CommonFunctions.concatenateString(excelTestCaseFieldsTO.getInputTestData(),
				testCaseDetailTO.getVariableHolder());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps()+CommonConstant.SPACE+finalString );
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), finalString);
		}
	}

}
