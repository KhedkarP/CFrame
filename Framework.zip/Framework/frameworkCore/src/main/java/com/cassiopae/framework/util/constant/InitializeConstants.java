package com.cassiopae.framework.util.constant;

import java.util.Map;

import com.cassiopae.selenium.util.common.CommonUtility;

public class InitializeConstants {

	private InitializeConstants() {
	}

	public static String cattProjectName = null;
	protected static java.util.Properties properties = null;
	public static String fileSeparator = null;
	protected static Map<String, String> pathDetails = null;
	public static Map<String, String> mailDetails = null;
	public static Map<String, String> dateAndAmountPatterns = null;
	public static Map<String, String> dashboardExcelDetails = null;
	protected static Map<String, String> fileFolderDetails = null;
	public static Map<String, String> localeDetails = null;
	public static Map<String, String> expectedPaymentCalculationFileNames = null;
	public static Map<String, String> testParallelDetails = null;
	protected static Map<String, String> locationPathDetails = null;
	public static Map<String, String> dumpInformation = null;
	public static Map<String, String> neoLoadConfig = null;
	public static Map<String, String> alertHandling = null;

	public static String autoITexecutableBatFileName = null;
	public static String autoITCloseInstancesFileName = null;
	public static String autoIT_File_Upload_ExecutableName = null;
	public static String autoIT_File_Upload_CloseInstancesFileName = null;
	public static String autoITExecutableName = null;
	public static String OracleClientFolderName = null;
	public static String currentPackageDirectoryPath = null;
	public static String browserInstanceFolderName = null;
	public static String browserDriversFolderName = null;
	public static String msEdgePortable = null;
	public static String msEdgeProfile = null;
	public static String msUserData = null;
	public static String screenshotsFolderName = null;
	public static String executionVideosFolderName = null;
	public static String apiResponsesFolderName = null;

	public static String tempPropertyFilesFolderName = null;
	public static String productFolderName = null;
	public static String executionResultsFolderName = null;
	public static String consoleLogsFolderName = null;
	public static String objectRepositoryFolderName = null;
	public static String paymentScheduleDocumentsFolderName = null;
	public static String testCaseDocuments = null;
	public static String testEnvironmentDetailFolderName = null;
	public static String testCaseSummaryFolderName = null;
	public static String preRequisiteSQLExecutionLogFolderName = null;

	public static String downloadFolderName = null;
	public static String externalFilesFolderName = null;
	public static String testCasesFolderName = null;
	public static String neoload_projects_directory_name = null;
	public static String test_ng_folder_name = null;
	public static String suite_file_folder_name = null;
	public static String suite_xml_file_name = null;
	public static String chrome_driver_executable_name = null;
	public static String msedge_driver_executable_name = null;
	public static String ie_driver_executable_name = null;
	public static String neoload_launcher_bat_file_name = null;
	public static String object_repository_excel_name = null;
	public static String dashboard_excel_name = null;
	public static String dashboard_excel_status_sheet_name = null;
	public static String test_data_sheet_name = null;
	public static int username_column_Number;
	public static int passowrd_column_Number;
	public static int status_column_Number;
	public static int defect_id_column_Number;
	public static int error_column_Number;
	public static int Generated_Reference_Column1;
	public static int Generated_Reference_Column2;
	public static int Generated_Reference_Column3;
	public static int video_path;
	public static int execution_duration_column;
	public static int test_case_worksheet_name_column;
	public static int test_case_workbook_name_column;
	public static int test_type_column;
	public static int test_case_priority_column;
	public static int test_case_dependancy_column;
	public static int serial_num;
	public static int module_column;
	public static int component_column;
	public static int execution_required;
	public static int browser_column;
	public static int suiteName_Column;
	public static int tcVersion_Column;
	public static int endCompatibilityVersion;
	public static int please_wait_icon_loading_time;
	public static int toastMessageWaitingTimeForPOS;

	public static int sanitySuiteThreadCount;
	public static int sanityVerbose;
	public static String sanityParallelLevel = null;

	public static int regressionSuiteThreadCount;
	public static int regressionVerbose;
	public static String regressionParallelLevel = null;

	public static int paymentScheduleSuiteThreadCount;
	public static int paymentScheduleVerbose;
	public static String paymentScheduleParallelLevel = null;

	public static String pre_requisite_softwares = null;
	public static String pre_requisites_folder_name = null;
	public static String pre_requisites_sql_folder_name = null;
	public static String dump_validation_sql_folder_name = null;
	public static String dump_validation_excel_file_name = null;
	public static String dump_validation_excel_file_sheet_name = null;

	public static String neoload_configuration_folder_name = null;
	public static String configuration_folder_name = null;

	public static String test_environment_details_sheet_name = null;
	public static String test_environment_details_excel_name = null;
	public static String jenkins_build_parameter_file_name = null;

	public static String upload_documents_folder_name = null;
	public static String apiRequestsFolderName = null;
	public static int maximumWaitTimeForExpectedAlertInSeconds;
	public static int pageLoadTimeForChromeBrowserInSeconds;
	public static int pageLoadTimeForIEBrowserInSeconds;
	public static int pageLoadTimeForEdgeBrowserInSeconds;
	public static int pageLoadTimeForPOSApplication;
	
	public static int maxRowDisplayForSearchResultPOS;

	public static String SFP_ACF_ApplicationTitleMiddleOffice = null;
	public static String SFP_ACF_ApplicationTitleBackOffice = null;
	public static String SFP_ACF_ApplicationTitlePOS = null;
	public static String SFP_ACF_ApplicationTitleConfigConsole = null;
	public static String SFP_REAL_ApplicationTitleMiddleOffice = null;
	public static String SFP_REAL_ApplicationTitleBackOffice = null;
	public static String SFP_REAL_ApplicationTitlePOS = null;
	public static String SFP_REAL_ApplicationTitleConfigConsole = null;
	public static String setLocaleThroughDBQueryForEachTestCase = null;
	public static String listofPaymentcalculationFileames = null;
	public static String sqlScriptPathOnAppServer = null;

	public static String excelPropertyFileName = "ExcelDetails";
	public static String domainDetailsFileName = "resources/DomainConfig.properties";
	public static String ProductTestingEnvironmentInfoFileName = "resources/ProductEnvConfig.properties";
	public static String catt_resources = "resources";
	public static String parallelTestExecutionFileName = "ParallelTestExecution";

	static {
		cattProjectName = "CAT_Project";
		properties = System.getProperties();
		fileSeparator = properties.get("file.separator").toString();
		pathDetails = CommonUtility.readProperties("resources/BaseDirectory.properties");
		mailDetails = CommonUtility.readProperties("resources/MailDetails.properties");
		dateAndAmountPatterns = CommonUtility.readProperties("resources/DateAndAmountPattern.properties");
		localeDetails = CommonUtility.readProperties("resources/localeDetails.properties");
		expectedPaymentCalculationFileNames = CommonUtility.readProperties("resources/ExpectedPaymentCalculationFileNames.properties");
		fileFolderDetails = CommonUtility.readProperties("resources/FolderDetails.properties");
		dashboardExcelDetails = CommonUtility.readProperties("resources/" + excelPropertyFileName + ".properties");
		testParallelDetails = CommonUtility.readProperties("resources/ParallelTestExecution.properties");
		locationPathDetails = CommonUtility.readProperties("resources/PathDetails.properties");
		sqlScriptPathOnAppServer = locationPathDetails.get("SQLScriptPathOnAppServer");
		dumpInformation = CommonUtility.readProperties("resources/DumpInformation.properties");
		neoLoadConfig = CommonUtility.readProperties("resources/NeoLoadConfig.properties");
		alertHandling = CommonUtility.readProperties("resources/AlertHandling.properties");
		

		SFP_ACF_ApplicationTitleMiddleOffice = localeDetails.get("SFP_ACF_ApplicationTitleMiddleOffice");
		SFP_ACF_ApplicationTitleBackOffice = localeDetails.get("SFP_ACF_ApplicationTitleBackOffice");
		SFP_ACF_ApplicationTitlePOS = localeDetails.get("SFP_ACF_ApplicationTitlePOS");
		SFP_ACF_ApplicationTitleConfigConsole = localeDetails.get("SFP_ACF_ApplicationTitleConfigConsole");
		SFP_REAL_ApplicationTitleMiddleOffice = localeDetails.get("SFP_REAL_ApplicationTitleMiddleOffice");
		SFP_REAL_ApplicationTitleBackOffice = localeDetails.get("SFP_REAL_ApplicationTitleBackOffice");
		SFP_REAL_ApplicationTitlePOS = localeDetails.get("SFP_REAL_ApplicationTitlePOS");
		SFP_REAL_ApplicationTitleConfigConsole = localeDetails.get("SFP_REAL_ApplicationTitleConfigConsole");
		setLocaleThroughDBQueryForEachTestCase = localeDetails.get("SetLocaleThroughDBQueryForEachTestCase");
		listofPaymentcalculationFileames = expectedPaymentCalculationFileNames.get("ExcelFileName");
		
		currentPackageDirectoryPath = pathDetails.get("BaseDirectory");
		serial_num = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardSrNoColumn"),
				excelPropertyFileName);
		module_column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardModuleColumn"),
				excelPropertyFileName);
		component_column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardComponentColumn"),
				excelPropertyFileName);
		test_type_column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardTestTypeColumn"),
				excelPropertyFileName);
		tcVersion_Column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardTCVersionColumn"),
				excelPropertyFileName);
		endCompatibilityVersion = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardEndCompatibilityVersionColumn"), excelPropertyFileName);

		test_case_priority_column = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardTestCasePriorityColumn"), excelPropertyFileName);
		test_case_dependancy_column = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardTestCaseDependancyColumn"), excelPropertyFileName);
		test_case_worksheet_name_column = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardTestCaseWorkSheetName"), excelPropertyFileName);
		test_case_workbook_name_column = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardTestCaseWorkBookName"), excelPropertyFileName);
		execution_required = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardExecutionRequiredColumn"), excelPropertyFileName);
		username_column_Number = CommonUtility
				.convertStringToInteger(dashboardExcelDetails.get("DashboardUserNameColumn"), excelPropertyFileName);
		passowrd_column_Number = CommonUtility
				.convertStringToInteger(dashboardExcelDetails.get("DashboardPasswordColumn"), excelPropertyFileName);
		browser_column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardBrowserColumn"),
				excelPropertyFileName);
		suiteName_Column = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardSuiteNameColumn"),
				excelPropertyFileName);
		status_column_Number = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardStatusColumn"),
				excelPropertyFileName);
		defect_id_column_Number = CommonUtility
				.convertStringToInteger(dashboardExcelDetails.get("DashboardDefectIDColumn"), excelPropertyFileName);
		error_column_Number = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardErrorColumn"),
				excelPropertyFileName);
		Generated_Reference_Column1 = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardGeneratedReferenceColumn1"), excelPropertyFileName);
		Generated_Reference_Column2 = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardGeneratedReferenceColumn2"), excelPropertyFileName);
		Generated_Reference_Column3 = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardGeneratedReferenceColumn3"), excelPropertyFileName);
		video_path = CommonUtility.convertStringToInteger(dashboardExcelDetails.get("DashboardVideoColumn"),
				excelPropertyFileName);
		execution_duration_column = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("DashboardExecutionDurationColumn"), excelPropertyFileName);
		please_wait_icon_loading_time = CommonUtility
				.convertStringToInteger(dashboardExcelDetails.get("GlobalWaitTimeInSeconds"), excelPropertyFileName);
		toastMessageWaitingTimeForPOS = CommonUtility
				.convertStringToInteger(dashboardExcelDetails.get("ToastMessageWaitingTimeForPOS"), excelPropertyFileName);
		pageLoadTimeForPOSApplication = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("PageLoadTimeForPOSApplication"), excelPropertyFileName);
		maxRowDisplayForSearchResultPOS = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("MaxRowDisplayForSearchResultPOS"), excelPropertyFileName);

		sanitySuiteThreadCount = CommonUtility.convertStringToInteger(testParallelDetails.get("SanityThreadCount"),
				parallelTestExecutionFileName);
		sanityVerbose = CommonUtility.convertStringToInteger(testParallelDetails.get("SanityVerbose"),
				parallelTestExecutionFileName);
		sanityParallelLevel = testParallelDetails.get("SanityParallelType");

		regressionSuiteThreadCount = CommonUtility.convertStringToInteger(
				testParallelDetails.get("RegressionThreadCount"), parallelTestExecutionFileName);
		regressionVerbose = CommonUtility.convertStringToInteger(testParallelDetails.get("RegressionVerbose"),
				parallelTestExecutionFileName);
		regressionParallelLevel = testParallelDetails.get("RegressionParallelType");

		paymentScheduleSuiteThreadCount = CommonUtility.convertStringToInteger(
				testParallelDetails.get("paymentScheduleSuiteThreadCount"), parallelTestExecutionFileName);
		paymentScheduleVerbose = CommonUtility.convertStringToInteger(testParallelDetails.get("paymentScheduleVerbose"),
				parallelTestExecutionFileName);
		paymentScheduleParallelLevel = testParallelDetails.get("paymentScheduleParallelType");

		maximumWaitTimeForExpectedAlertInSeconds = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("MaximumWaitTimeForExpectedAlertInSeconds"), excelPropertyFileName);
		pageLoadTimeForChromeBrowserInSeconds = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("PageLoadTimeForChromeBrowserInSeconds"), excelPropertyFileName);
		pageLoadTimeForIEBrowserInSeconds = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("PageLoadTimeForIEBrowserInSeconds"), excelPropertyFileName);
		pageLoadTimeForEdgeBrowserInSeconds = CommonUtility.convertStringToInteger(
				dashboardExcelDetails.get("PageLoadTimeForEdgeBrowserInSeconds"), excelPropertyFileName);
		autoITexecutableBatFileName = fileFolderDetails.get("AutoITExecutableBatFileName");
		autoITCloseInstancesFileName = fileFolderDetails.get("AutoITCloseInstancesFileName");
		autoITExecutableName = fileFolderDetails.get("AutoITExecutableName");
		OracleClientFolderName = fileFolderDetails.get("OracleClientFolderName");
		autoIT_File_Upload_ExecutableName = fileFolderDetails.get("AutoITFileUploadExecutableName");
		autoIT_File_Upload_CloseInstancesFileName = fileFolderDetails.get("AutoITFileUploaCloseInstancesFileName");

		browserInstanceFolderName = fileFolderDetails.get("BrowserInstanceFolderName");
		neoload_configuration_folder_name = fileFolderDetails.get("NeoloadConfigurationFolderName");
		browserDriversFolderName = fileFolderDetails.get("BrowserDriverFolderName");

		msEdgePortable = fileFolderDetails.get("MSEdgePortableFolderName");
		msEdgeProfile = fileFolderDetails.get("MSEdgeProfileFolderName");
		msUserData = fileFolderDetails.get("MSUserDataFolderName");

		screenshotsFolderName = fileFolderDetails.get("ScreenShotFolderName");
		pre_requisite_softwares = fileFolderDetails.get("PreRequisiteSoftwareFolderName");
		pre_requisites_folder_name = fileFolderDetails.get("PreRequisitesFolderName");
		pre_requisites_sql_folder_name = fileFolderDetails.get("PreRequisitesSQLFolderName");

		dump_validation_sql_folder_name = fileFolderDetails.get("DumpValidationFolderName");
		dump_validation_excel_file_name = fileFolderDetails.get("DumpValidationExcelFileName");
		dump_validation_excel_file_sheet_name = fileFolderDetails.get("DumpValidationExcelSheetName");
		configuration_folder_name = fileFolderDetails.get("ConfigurationFolderName");
		executionVideosFolderName = fileFolderDetails.get("ExecutionFolderName");
		apiResponsesFolderName = fileFolderDetails.get("APIResponsesFolderName");
		upload_documents_folder_name = fileFolderDetails.get("UploadDocumentsFolderName");
		apiRequestsFolderName = fileFolderDetails.get("APIRequestsFolderName");

		tempPropertyFilesFolderName = "Temp_Prop_Files";
		productFolderName = fileFolderDetails.get("ProductFolderName");
		executionResultsFolderName = fileFolderDetails.get("ExecutionResultsFolderName");
		consoleLogsFolderName = fileFolderDetails.get("ExecutionConsoleLogsFolderName");
		objectRepositoryFolderName = fileFolderDetails.get("ObjectRepositoryFolderName");
		paymentScheduleDocumentsFolderName = fileFolderDetails.get("TestDataDocumentsFolderName");
		testCaseDocuments = fileFolderDetails.get("TestCaseDocuments");
		testEnvironmentDetailFolderName = fileFolderDetails.get("TestEnvironmentDetailFolderName");
		testCaseSummaryFolderName = fileFolderDetails.get("TestCaseSummaryFolderName");
		preRequisiteSQLExecutionLogFolderName = fileFolderDetails.get("PreRequisiteSQLExecutionLogFolderName");

		downloadFolderName = fileFolderDetails.get("DownLoadedFilesFolderName");
		externalFilesFolderName = fileFolderDetails.get("ExternalFilesFolderName");
		testCasesFolderName = fileFolderDetails.get("TestCasesFolderName");
		neoload_projects_directory_name = fileFolderDetails.get("NeoLoadProjectsFolderName");
		test_ng_folder_name = fileFolderDetails.get("TestNGFolderName");
		suite_file_folder_name = fileFolderDetails.get("TestNGSuiteFileFolderName");
		suite_xml_file_name = fileFolderDetails.get("DynamicTestNGSuiteFileName");
		chrome_driver_executable_name = fileFolderDetails.get("ChromeDriverExecutableName");
		msedge_driver_executable_name = fileFolderDetails.get("MSEdgeDriverExecutableName");
		ie_driver_executable_name = fileFolderDetails.get("IEDriverExecutableName");
		neoload_launcher_bat_file_name = fileFolderDetails.get("NeoloadLauncherBatFileName");
		object_repository_excel_name = dashboardExcelDetails.get("ObjectRepositoryExcelName");
		dashboard_excel_name = dashboardExcelDetails.get("DashboardExcelName");
		dashboard_excel_status_sheet_name = dashboardExcelDetails.get("DashboardExcelSheetName");
		test_data_sheet_name = dashboardExcelDetails.get("DashboardTestDataSheetName");
		test_environment_details_sheet_name = dashboardExcelDetails.get("EnvironmentDetailsExcelSheetName");
		test_environment_details_excel_name = dashboardExcelDetails.get("EnvironmentDetailsExcelName");
		jenkins_build_parameter_file_name = dashboardExcelDetails.get("JenkinsBuildParameterDetailsFileName");

	}
	public static final String DRIVER_INSTANCE_CLOSE = "Driver_Instance_Close";
	public static final String DRIVER_INSTANCE_DELETE = "Driver_Instance_Delete";
	public static final String NEW_DRIVER_INSTANCE = "New_Driver_Instance";
	
	public static Map<String, String> getDashboardExcelDetails() {
		return dashboardExcelDetails;
	}

	public static void setDashboardExcelDetails(Map<String, String> dashboardExcelDetails) {
		InitializeConstants.dashboardExcelDetails = dashboardExcelDetails;
	}

}
