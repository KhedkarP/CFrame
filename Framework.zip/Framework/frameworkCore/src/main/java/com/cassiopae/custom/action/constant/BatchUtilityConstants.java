package com.cassiopae.custom.action.constant;

public interface BatchUtilityConstants {

	public String CLOSE_CONNECTION_ERROR_MESSAGE = "Error occured wile closing inputStream ";
	public String BATCH_LOG_NAME = "_logs_";
	public String BATCH_FILE_EXTENSION = ".txt";
	public String BATCH_LOGS_WRITING_ERROR="Error occured while writing batch logs to file";
	public String RETURN_CODE = " ReturnCode ";
	public String JAVA_BATCH_EXIT_CODE = "Exit with code :";
	public String RETURN_CODE_MESSAGE_IS = "Batch return code is: ";
	public String EXIT_CODE_MESSAGE_IS = "Batch exit code is: ";
	public String PERMISSION_KO_MESSAGE = "Permission non accordée";
	public String PERMISSION_ERROR_MEESAGE = "Permission not granted for batch execution: ";
	public String BATCH_KO_MESSAGE = "Error occured while executing batch, please refer logs for more details - ";
	public String BATCH_COMMAND_MESSAGE = "Batch command for execution is: \n";
	public String BATCH_COMMOND_WITH_PATH_MESSAGE = "Batch command for execution along with path setting is: \n";
	public String ERROR_WHILE_FETCHING_LOGS = "Error occured while fetching batch execution logs";
	public String BATCH_START_MESSAGE = "Batch Execution started....... ";
	public String CHANNEL_CONNECTION_ERROR_MESSAGE = "Error occured while connecting execution channel with server";
	public String CHANNEL_ERROR_OPEN_MESSAGE = "Facing issue while opening channel with server: ";
}
