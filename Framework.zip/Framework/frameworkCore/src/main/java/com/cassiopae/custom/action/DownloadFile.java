/**
 * 
 */
package com.cassiopae.custom.action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.FileStructureConstants;

/**
 * @author mshik
 *
 */
public class DownloadFile implements CustomAction {

	public static boolean DownloadFileActionPOS=false;
	public static boolean DownloadFileActionIE=false;

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		try {
			
			testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
			if (testCaseDetail.getWorkBookName().contains(DBConstant.POS_MODULE)) {
				DownloadFileActionPOS=true;
				WebDriver driver = testCaseDetail.getDriver();
				Actions act = new Actions(driver);
				act.moveToElement(testCaseDetail.getDriver().findElement(
						GenericAction.locator(excelTestCaseFields.getLocatorKey(), testCaseDetail.getLocatorHashMap())))
						.click().build().perform();
			} else {
				testCaseDetail.getDriver().findElement(
						GenericAction.locator(excelTestCaseFields.getLocatorKey(), testCaseDetail.getLocatorHashMap()))
						.click();
			}
			
		} catch (Exception e) {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.FACING_ISSUE_DOWNLOAD_MSG);
		}
		if (testCaseDetail.getTestCaseCommonData().getBrowserName().equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			DownloadFileActionIE=true;
			SeleniumUtility.downloadPaymentSchedule(FileStructureConstants.autoITExecutalePathForFileDownload,
					FileStructureConstants.closeAutoITInstancesBatFilePath,
					testCaseDetail.getTestCaseCommonData().getReportingLogger());
		}
		CommonFunctions.explicitWait(10000);
	}
	
	
}
