/**
 *
 */
package com.cassiopae.framework.util;

import java.util.HashMap;
import java.util.Map;

import com.cassiopae.framework.dao.constant.DBConstant;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.testng.ITestResult;

import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.VideoCreationUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

/**
 * @author nbhil
 */
public class PostTestCaseExecutorUtility {
	private static Logger logger = LogManager.getLogger(PostTestCaseExecutorUtility.class);
	private PostTestCaseExecutorUtility() {

	}

	public static String Error_Message = null;

	/**
	 * This method get called in afterMethodCall to produce the execution video and
	 * update the status in master sheet.
	 * 
	 * @param p_testCaseCommonData TestCaseCommonData
	 * @param p_executionTime      String
	 * @param p_testResult         ITestResult
	 * @param p_issue              String
	 * @param p_statusSheetName    String
	 * @param p_errorMessgae       String
	 */
	public static void postTestCaseExecutionActivity(final TestCaseCommonData p_testCaseCommonData,
			final String p_executionTime, final ITestResult p_testResult, final String p_issue,
			final String p_statusSheetName, String p_errorMessgae) {
		String newVideoLocation = null;
		String testCaseStatus = p_testResult.isSuccess() ? CommonConstant.TEST_CASE_PASSED
				: CommonConstant.TEST_CASE_FAILED;
		if (p_testCaseCommonData.getMultiDataSetResult() != null
				&& !p_testCaseCommonData.getMultiDataSetResult().isEmpty()) {
			newVideoLocation = p_testCaseCommonData.getMultiDataSetResult()
					.get(CommonConstant.VIDEO_LOCATION_FOR_MULTI_DATA_SET);
			try {
				updateReportingLogger(p_testCaseCommonData, p_executionTime, newVideoLocation, p_testCaseCommonData.getMultiDataSetResult()
						.get(CommonConstant.MULTI_DATA_SET_EXECUTION_STATUS));
			} catch (Exception e) {
				logger.info("Updation of test case execution status in reporting logger failed", e);
			}
			if (p_testCaseCommonData.getMultiDataSetResult().get(CommonConstant.MULTI_DATA_SET_EXECUTION_STATUS).contains(CommonConstant.TEST_CASE_PASSED)){
				p_errorMessgae = p_testCaseCommonData.getMultiDataSetResult().get(CommonConstant.MULTI_DATA_SET_EXECUTION_RESULT);
			}
			performExcelOperation(p_testCaseCommonData, p_executionTime, p_statusSheetName, newVideoLocation,
					 p_testCaseCommonData.getMultiDataSetResult().get(CommonConstant.MULTI_DATA_SET_EXECUTION_STATUS), p_errorMessgae);
		} else {

			try {
				newVideoLocation = createExecutionVideo(p_testCaseCommonData, newVideoLocation);
			} catch (Exception e) {
				logger.info("Video Creation Failed", e);
			}

			try {
				updateReportingLogger(p_testCaseCommonData, p_executionTime, newVideoLocation, testCaseStatus);
			} catch (Exception e) {
				logger.info("Updation of test case execution status in reporting logger failed", e);
			}

			performExcelOperation(p_testCaseCommonData, p_executionTime, p_statusSheetName, newVideoLocation,
					testCaseStatus, p_errorMessgae);
		}
	}

	/**
	 * This method execute to create the execution video.
	 * 
	 * @param p_testCaseCommonData TestCaseCommonData
	 * @param newVideoLocation     String
	 * @return String
	 */
	private static String createExecutionVideo(final TestCaseCommonData p_testCaseCommonData, String newVideoLocation)
	{
		if (!p_testCaseCommonData.getWorkSheetName().contains(DBConstant.API_APP_SHEET_NAME))
		{
			if (ApplicationContext.executionVideos.equalsIgnoreCase(CommonConstant.YES))
			{
				newVideoLocation = VideoCreationUtility.videoCreation(getFolderPathForExecutionVideo(p_testCaseCommonData),
						getFolderPathForScrrenShot(p_testCaseCommonData), p_testCaseCommonData.getBaseWorksheetName(), p_testCaseCommonData.getBrowserName());
			}
		}
		return newVideoLocation;
	}
	/**
	 * This method perform excel operation and update the status.
	 * 
	 * @param p_testCaseCommonData TestCaseCommonData
	 * @param p_executionTime      String
	 * @param p_statusSheetName    String
	 * @param newVideoLocation     String
	 * @param testCaseStatus       String
	 */
	private static void performExcelOperation(final TestCaseCommonData p_testCaseCommonData,
			final String p_executionTime, final String p_statusSheetName, String newVideoLocation,
			String testCaseStatus, String errorMessgae) {
		Map<String, String> results = new HashMap<>();
		results.put(CommonConstant.TEST_CASE_STATUS, testCaseStatus);
		results.put(CommonConstant.VIDEO_LOCATION, newVideoLocation);
		results.put(CommonConstant.EXECUTION_TIME, p_executionTime);
		results.put(CommonConstant.DEFECT_ID, null);
		
		if (errorMessgae != null && !StringUtils.isEmpty(errorMessgae)) {
			results.put(CommonConstant.ERROR_MESSAGE, errorMessgae);
		} else {
			results.put(CommonConstant.ERROR_MESSAGE, CommonConstant.EMPTY_STRING);
		}
		ExcelOperation.putResultInSummaryFile(p_testCaseCommonData.getExcelRowNo(),
				p_testCaseCommonData.getDomainName(), results);

	}

	/**
	 * This method update the reporting logger.
	 * 
	 * @param p_testCaseCommonData TestCaseCommonData
	 * @param p_executionTime      String
	 * @param newVideoLocation     String
	 * @param testCaseStatus       String
	 */
	private static void updateReportingLogger(final TestCaseCommonData p_testCaseCommonData,
			final String p_executionTime, String newVideoLocation, String testCaseStatus) {
		if(!CommonUtility.isNullOREmpty(newVideoLocation))
		{
			p_testCaseCommonData.getReportingLogger().info(ReportLoggerConstant.VIDEO_LOCATION_MSG + newVideoLocation);
		}
		else
		{
			p_testCaseCommonData.getReportingLogger().info(ReportLoggerConstant.VIDEO_LOCATION_MSG_API_TEST_CASE);
		}
		StringBuilder messageuilder = new StringBuilder();
		messageuilder.append(p_testCaseCommonData.getWorkSheetName()).append(CommonConstant.IS)
				.append(testCaseStatus).append(CommonConstant.COLON_SEPERATOR).append(ReportLoggerConstant.EXECUTION_TIME_MSG)
				.append(p_executionTime);
		p_testCaseCommonData.getReportingLogger().info(messageuilder);
	}

	/**
	 * This method return the folder path for screenshot.
	 * 
	 * @param testCaseCommonData TestCaseCommonData
	 * @return String
	 */
	public static String getFolderPathForScrrenShot(final TestCaseCommonData testCaseCommonData) {
		
		String[] productInfo = CommonUtility.getProductInfoFromName(testCaseCommonData.getDomainName());
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.screenshotsFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator + testCaseCommonData.getWorkBookName()
				+ InitializeConstants.fileSeparator + testCaseCommonData.getBaseWorksheetName();
	}

	/**
	 * This method returns the folder path for execution video.
	 * 
	 * @param testCaseCommonData TestCaseCommonData
	 * @return String
	 */
	public static String getFolderPathForExecutionVideo(final TestCaseCommonData testCaseCommonData) {

		String[] productInfo = CommonUtility.getProductInfoFromName(testCaseCommonData.getDomainName());
		return InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
				+ InitializeConstants.productFolderName + InitializeConstants.fileSeparator + productInfo[0]
				+ InitializeConstants.fileSeparator + productInfo[1] + InitializeConstants.fileSeparator
				+ InitializeConstants.executionResultsFolderName + InitializeConstants.fileSeparator
				+ InitializeConstants.executionVideosFolderName + InitializeConstants.fileSeparator
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator
				+ testCaseCommonData.getWorkBookName() + InitializeConstants.fileSeparator;
	}
}
