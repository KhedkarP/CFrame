package com.cassiopae.webservices.action;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.webservices.action.util.RestWSUtility;

import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;

public class RESTAPIPATCHRequest implements WSAction {

	@Override
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		/*
		 * Reading input data parameters
		 */
		String productName = testCaseDetailTO.getTestCaseCommonData().getDomainName();
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData().trim(),
				CommonConstant.PIPE_SEPARATOR);
		String fileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]);
		String headerParameters[] = CommonUtility.splitStringUsingPattern(inputData[1], CommonConstant.COMMA_SEPERATOR);
		String endPointURL = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				headerParameters[0]);
		String sessionToken = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				headerParameters[1]);
		String cookiesID = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				headerParameters[2]);

		String apiInputParameters[] = null;
		if (inputData.length > 2) {
			apiInputParameters = CommonUtility.splitStringUsingPattern(inputData[2], CommonConstant.COMMA_SEPERATOR);
		}
		String[] storedVariables = CommonUtility.splitStringUsingPattern(
				excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);

		/** InitializeDomainWiseRestAPIRequest folder path */
		String requestPath = DomainInitialization.initializeDomainWiseRestAPIRequestsPath(productName);
		/** Create API response folder */
		String responseFolderPath = RestWSUtility.createAPIResponseFolder(productName,
				testCaseDetailTO.getWorkBookName(), testCaseDetailTO.getWorkSheetName());
		/** Checking API request folder is available or not */
		String fileStatus = SeleniumUtility.checkFileIsAvailableAtLocationOrNOT(requestPath, reportingLogger, fileName);
		if (fileStatus.equals(CommonConstant.TRUE_VALUE)) {
			/** ReadJSon file from location and parse to JSON Object */
			String jsonObj = RestWSUtility.readJsonFile(reportingLogger, requestPath, fileName);
			/** Update JSON based on User Input */
			String updatedRequest = RestWSUtility.updateRestAPIRequest(apiInputParameters, jsonObj, testCaseDetailTO);
			reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_REQUEST_Body + updatedRequest);
			/** Save Updated Json file at API responses folder */
			RestWSUtility.saveRestAPIFiles(fileName, WSReportingLoggerConstant.REQUEST_NAME, responseFolderPath,
					updatedRequest);
			/** Get RestURI end point */
			ExtractableResponse<Response> extractResponse = RestWSUtility.executeRESTAPIPATCHRequestService(
					sessionToken, updatedRequest, cookiesID, endPointURL, testCaseDetailTO);
			String statusCode = RestWSUtility.getResponseData(extractResponse,
					WSReportingLoggerConstant.STATUSCODE_MSG);
			String responseBody = RestWSUtility.getResponseData(extractResponse,
					WSReportingLoggerConstant.RESPONSEBODY_MSG);
			reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Code + statusCode);
			reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + responseBody);
			if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
				testCaseDetailTO.getVariableHolder().put(storedVariables[0], statusCode);
				testCaseDetailTO.getVariableHolder().put(storedVariables[1], responseBody);
			}
			RestWSUtility.saveRestAPIFiles(fileName, WSReportingLoggerConstant.RESPONSE_NAME, responseFolderPath,
					responseBody);
		}
	}
}
