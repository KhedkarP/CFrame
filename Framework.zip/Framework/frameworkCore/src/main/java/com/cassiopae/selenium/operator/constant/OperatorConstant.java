/**
 * 
 */
package com.cassiopae.selenium.operator.constant;

/**
 * @author jraut
 *
 */
public interface OperatorConstant {
    
    public static final String RELATIONAL_OPERATION="CSMZ_CompareNumericValues";
    public static final String ARTHMATIC_OPERATION="CSMZ_ArithmaticOperations";
    
    public static final String EQUAL_TO  ="EQT";
	public static final String NOT_EQUALT_TO  ="NEQT";
	public static final String GREATER_THAN  ="GT";
	public static final String LESS_THAN  ="LT";
	public static final String GREATER_THAN_EQUAL_TO  ="GTE";
	public static final String LESS_THAN_EQUAL_TO  ="LTE";
	
	public static final String ADD="ADD";
	public static final String SUB="SUB";
	public static final String MUL="MUL";
	public static final String DIV="DIV";
	public static final String MOD="MOD";
}
