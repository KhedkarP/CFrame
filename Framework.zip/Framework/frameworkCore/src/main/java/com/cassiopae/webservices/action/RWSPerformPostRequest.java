package com.cassiopae.webservices.action;

import org.apache.poi.ss.usermodel.DataFormatter;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.to.restWebServiceData;
import com.cassiopae.webservices.action.util.RestWSUtility;

public class RWSPerformPostRequest implements WSAction {

	@Override
	@Deprecated //This action is deprecated now please refer RESTAPIPOSTRequest
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		DataFormatter dataFormatter = new DataFormatter();
		restWebServiceData webServiceData = RestWSUtility.populateRestWSDataTO(excelTestCaseFieldsTO, testCaseDetailTO);
		if (webServiceData.getInputTestData().length > 2) {
			RestWSUtility.createExecuteDynamicRESTRequest(excelTestCaseFieldsTO, testCaseDetailTO, dataFormatter,
					webServiceData);
		} else {
			RestWSUtility.createExecuteStaticRESTRequest(excelTestCaseFieldsTO, testCaseDetailTO, dataFormatter,
					webServiceData);
		}
	}
}