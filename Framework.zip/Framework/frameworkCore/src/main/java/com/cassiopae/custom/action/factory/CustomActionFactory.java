/**
 *
 */
package com.cassiopae.custom.action.factory;

import com.cassiopae.custom.action.BatchProcessAutomation;
import com.cassiopae.custom.action.ChangeDateFomatAction;
import com.cassiopae.custom.action.CheckFileIsPresentOnServer;
import com.cassiopae.custom.action.CheckPaginationTableEntry;
import com.cassiopae.custom.action.Check_Downloaded_File;
import com.cassiopae.custom.action.ConvertJasperPdfToExcel;
import com.cassiopae.custom.action.CustomAction;
import com.cassiopae.custom.action.DownloadFile;
import com.cassiopae.custom.action.DownloadFileFromServer;
import com.cassiopae.custom.action.DynamicClearTextValueAction;
import com.cassiopae.custom.action.DynamicClickAction;
import com.cassiopae.custom.action.DynamicSelectAction;
import com.cassiopae.custom.action.DynamicSelectCheckboxAction;
import com.cassiopae.custom.action.DynamicTextBoxValueAction;
import com.cassiopae.custom.action.DynamicUnSelectCheckboxAction;
import com.cassiopae.custom.action.ExecuteMethodCallAction;
import com.cassiopae.custom.action.ExtractPDFDataAndValidate;
import com.cassiopae.custom.action.FileUploadOnServer;
import com.cassiopae.custom.action.GenerateDynamicDateAction;
import com.cassiopae.custom.action.GetComparedValues;
import com.cassiopae.custom.action.GetDataFromJasperExcel;
import com.cassiopae.custom.action.GetDropDownIndexNumber;
import com.cassiopae.custom.action.GetTextValueFromFile;
import com.cassiopae.custom.action.GetValueFromText;
import com.cassiopae.custom.action.IsDownlodedFileEmpty;
import com.cassiopae.custom.action.RenameFileToBeUploaded;
import com.cassiopae.custom.action.ReplaceValueFromString;
import com.cassiopae.custom.action.StartStatement;
import com.cassiopae.custom.action.StopStatement;
import com.cassiopae.custom.action.UpdateLocatorPerformClickAction;
import com.cassiopae.custom.action.UpdateXMLaction;
import com.cassiopae.custom.action.constant.CustomConstant;

/**
 * @author nbhil
 */
public class CustomActionFactory {

	private CustomActionFactory() {

	}

	public static CustomAction getCustomAction(final String type) {
		CustomAction customAction = null;
		if (CustomConstant.METHOD_CALL.equals(type)) {
			customAction = new ExecuteMethodCallAction();
		} else if (CustomConstant.START_STATEMENT.equals(type)) {
			customAction = new StartStatement();
		} else if (CustomConstant.STOP_STATEMENT.equals(type)) {
			customAction = new StopStatement();
		} else if (CustomConstant.GENERATE_XPATH_PERFORM_CLICK_ACTION.equals(type)) {
			customAction = new DynamicClickAction();
		} else if (CustomConstant.GENERATE_XPATH_SELECT_DROPDOWN_ACTION.equals(type)) {
			customAction = new DynamicSelectAction();
		} else if (CustomConstant.GENERATE_XPATH_ENTER_TEXTBOX_VALUE_ACTION.equals(type)) {
			customAction = new DynamicTextBoxValueAction();
		} else if (CustomConstant.GENERATE_XPATH_SELECT_CHECKBOX.equals(type)) {
			customAction = new DynamicSelectCheckboxAction();
		} else if (CustomConstant.GENERATE_XPATH_UNSELECT_CHECKBOX.equals(type)) {
			customAction = new DynamicUnSelectCheckboxAction();
		} else if (CustomConstant.CSMZ_CHECK_FILE_AVAILABLE_OR_NOT.equals(type)) {
			customAction = new Check_Downloaded_File();
		} else if (CustomConstant.GENERATE_DYNAMIC_DATE.equals(type)) {
			customAction = new GenerateDynamicDateAction();
		} else if (CustomConstant.RENAME_FILE.equals(type)) {
			customAction = new RenameFileToBeUploaded();
		} else if (CustomConstant.DOWNLOAD_FILE.equals(type)) {
			customAction = new DownloadFile();
		} else if (CustomConstant.CHANGE_DATE_FORMAT.equals(type)) {
			customAction = new ChangeDateFomatAction();
		} else if (CustomConstant.Get_STRING_VALUE_FROM_TEXT.equals(type)) {
			customAction = new GetValueFromText();
		} else if (CustomConstant.CLEAR_TEXTBOX_VALUE_ACTION.equals(type)) {
			customAction = new DynamicClearTextValueAction();
		} else if (CustomConstant.CSMZ_ISDOWNLOADED_FILE_EMPTY.equals(type)) {
			customAction = new IsDownlodedFileEmpty();
		} else if (CustomConstant.READ_DATA_FROM_JASPEREXCEL.equals(type)) {
			customAction = new GetDataFromJasperExcel();
		} else if (CustomConstant.CSMZ_READ_DATA_FROM_JASPERPDF_CONVERT_EXCEL.equals(type)) {
			customAction = new ConvertJasperPdfToExcel();
		} else if (CustomConstant.CSMZ_REPLACE_VALUE_FROMS_STRING.equals(type)) {
			customAction = new ReplaceValueFromString();
		} else if (CustomConstant.CSMZ_EXECUTE_BATCH.equals(type)) {
			customAction = new BatchProcessAutomation();
		} else if (CustomConstant.CSMZ_FILE_UPLOAD_ON_SERVER.equals(type)) {
			customAction = new FileUploadOnServer();
		} else if (CustomConstant.CSMZ_UPDATE_XML_FILE.equals(type)) {
			customAction = new UpdateXMLaction();
		} else if (CustomConstant.CSMZ_GET_TEXT_VALUE_FROM_FILE.equals(type)) {
			customAction = new GetTextValueFromFile();
		} else if (CustomConstant.CSMZ_DOWNLOAD_FILE_FROM_SERVER.equals(type)) {
			customAction = new DownloadFileFromServer();
		} else if (CustomConstant.CSMZ_CHECK_FILE_IS_PRESENT_ON_SERVER.equals(type)) {
			customAction = new CheckFileIsPresentOnServer();
		} else if (CustomConstant.CSMZ_CHECK_PAGINATE_TABLE_ENTERY.equals(type)) {
			customAction = new CheckPaginationTableEntry();
		} else if (CustomConstant.CSMZ_GET_COMPARED_VALUE.equals(type)) {
			customAction = new GetComparedValues();
		} else if (CustomConstant.CSMZ_EXTRACT_PDF_DATA_AND_COMPARE.equals(type)) {
			customAction =  new ExtractPDFDataAndValidate();
		} else if (CustomConstant.CSMZ_UPDATE_LOCATOR_PERFORM_CLICK_ACTION.equals(type)) {
			customAction =  new UpdateLocatorPerformClickAction();
		} else if (CustomConstant.CSMZ_GET_DROPDOWN_INDEX_NUMBER.equals(type)) {
			customAction =  new GetDropDownIndexNumber();
		} 
		return customAction;
	}

}
