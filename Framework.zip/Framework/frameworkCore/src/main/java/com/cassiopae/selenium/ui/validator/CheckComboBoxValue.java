/**
 * 
 */

package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;

/**
 * @author meenskshi
 *
 */
public class CheckComboBoxValue implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		boolean flag ;
		String dropDownValueIsPresentStatus = null;
		if(testCaseDetailTO.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.POS_MODULE)) {
			 flag = GenericAction.checkDropDownValueforPOS(excelTestCaseFieldsTO, testCaseDetailTO);
		}else {
		 flag = GenericAction.checkDropDownValue(excelTestCaseFieldsTO, testCaseDetailTO);
		}
		if (flag)
			dropDownValueIsPresentStatus = CommonConstant.TRUE_VALUE;
		else
			dropDownValueIsPresentStatus = CommonConstant.FALSE_VALUE;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					dropDownValueIsPresentStatus);
	}
}
