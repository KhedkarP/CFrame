/**
 * 
 */

package com.cassiopae.selenium.ui.functions.factory;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.ui.functions.executor.ActorFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.AssetFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.CommonFunctionsExecutor;
import com.cassiopae.selenium.ui.functions.executor.ContractFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.ContructionFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.DealFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.CashflowCollectionDisbursementFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.CollateralFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.ExpenseFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.FunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.PanelTableFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.PropertyFunctionExecutor;
import com.cassiopae.selenium.ui.functions.executor.ReceivableFunctionExecutor;

/**
 * @author nbhil
 *
 */
public class FunctionFactory
{

		private FunctionFactory()
		{
		}

		public static FunctionExecutor getFunctionInstance(String entityName)
		{

				FunctionExecutor performFunction=null;

				if (StringUtils.isEmpty(entityName))
				{
						return performFunction;
				}
				if (FunctionConstant.ACTOR.equals(entityName))
				{
						performFunction=new ActorFunctionExecutor();
				}
				else if (FunctionConstant.ASSET.equals(entityName))
				{
						performFunction=new AssetFunctionExecutor();
				}
				else if (FunctionConstant.CONSTRUCTION.equals(entityName))
				{
						performFunction=new ContructionFunctionExecutor();
				}
				else if (FunctionConstant.CONTRACT.equals(entityName))
				{
						performFunction=new ContractFunctionExecutor();
				}
				else if (FunctionConstant.DEAL.equals(entityName))
				{
						performFunction=new DealFunctionExecutor();
				}
				else if (FunctionConstant.COLLECTION_DISBURSEMENT.equals(entityName))
				{
						performFunction=new CashflowCollectionDisbursementFunctionExecutor();
				}
				else if (FunctionConstant.EXPENSE.equals(entityName))
				{
						performFunction=new ExpenseFunctionExecutor();
				}
				else if (FunctionConstant.RECEIVABLE.equals(entityName))
				{
						performFunction=new ReceivableFunctionExecutor();
				}
				else if (FunctionConstant.COMMON.equals(entityName))
				{
						performFunction=new CommonFunctionsExecutor();
				}
				else if (FunctionConstant.PROPERTY.equals(entityName))
				{
						performFunction=new PropertyFunctionExecutor();
				}
				else if (FunctionConstant.TABLE.equals(entityName))
				{
						performFunction=new PanelTableFunctionExecutor();
				}
				else if (FunctionConstant.COLLATERALS.equals(entityName))
				{
						performFunction=new CollateralFunctionExecutor();
				}

				return performFunction;
		}
}
