/**
 * 
 */
package com.cassiopae.selenium.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.zeroturnaround.zip.ZipException;
import org.zeroturnaround.zip.ZipUtil;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.dao.utility.DatabaseUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.FileStructureConstants;
import com.cassiopae.selenium.utils.date.DateDefination;

/**
 * @author jraut
 */
public class FileUtility {

	private static Logger logger = LogManager.getLogger(FileUtility.class);

	public static File validateDownloads(final String fileNameToValidate, final String downloadPath,
			final Logger reportingLogger) {
		File newFile = null;
		List<String> filteredList = new ArrayList<>();
		String filename = null;
		File[] listOfFiles = null;
		try {
			if (null != downloadPath) {
				newFile = new File(downloadPath);
			}
			if (null != newFile) {
				try {
					listOfFiles = newFile.listFiles();
				} catch (SecurityException e) {
					logger.error(e.getMessage(), e);
					throw new CATTFileOperationException(e.getMessage());
				}
			}
			for (File file : listOfFiles) {
				if (file.isFile()) {
					reportingLogger.info("Name of File - " + file.getName());
					if (file.getName().contains(fileNameToValidate)) {
						try {
							filteredList.add(file.getName());
						} catch (NullPointerException e) {
							logger.error(e.getMessage(), e);
							throw new CATTFileOperationException(e.getMessage());
						}

						catch (IllegalArgumentException e) {
							logger.error(e.getMessage(), e);
							throw new CATTFileOperationException(e.getMessage());
						}
					}
				}
			}
			if (null != filteredList) {
				try {
					filename = filteredList.get(filteredList.size() - 1);
				} catch (IndexOutOfBoundsException e) {
					logger.error(e.getMessage(), e);
					throw new CATTFileOperationException(e.getMessage());
				}
			}
			if (null != filename) {
				return new File(newFile + InitializeConstants.fileSeparator + filename);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		}
		return null;
	}

	public static void deleteDownloadsFile(final String downloadPath, final Logger reportingLogger) {
		File dir = null;
		File[] dirContents = null;
		if (null != downloadPath) {
			dir = new File(downloadPath);
		}
		if (null != dir) {
			try {
				dirContents = dir.listFiles();
			} catch (SecurityException e) {
				logger.error(e.getMessage(), e);
				throw new CATTFileOperationException(e.getMessage());
			}
		}
		if (null != dirContents) {
			for (File file : dirContents) {
				try {
					if (file.isFile()) {
						if (file.delete()) {
							reportingLogger.info("File deleted successfully");
						} else {
							reportingLogger.info("Failed to delete the file");
						}
					}
				} catch (SecurityException e) {
					logger.error(e.getMessage(), e);
					throw new CATTFileOperationException(e.getMessage());
				}
			}
		}
	}

	public static boolean isFileDownloaded(final String downloadPath, final String fileName,
			final Logger reportingLogger) {
		File dir = null;
		File[] dirContents = null;
		if (null != downloadPath) {
			dir = new File(downloadPath);
		}
		if (null != dir) {
			try {
				dirContents = dir.listFiles();
			} catch (SecurityException e) {
				logger.error(e.getMessage(), e);
				throw new CATTFileOperationException(e.getMessage());
			}
		}

		if (null != dirContents) {
			for (File file : dirContents) {
				if (file.getName().equals(fileName)) {
					return true;
				}
			}
		}
		return false;
	}

	public static void csvToExcel(final Logger reportingLogger, final String domainName, final String path) {
		/*
		 * String downloadPath = DomainInitialization.initializeDomainwiseDownloadPath(
		 * domainName ); for ( File file : new File( downloadPath ).listFiles() ) { if (
		 * file != null ) { if ( file.isFile() && file.getName().contains( ".csv" ) ) {
		 * try { String absPath = file.getAbsolutePath(); Process process =
		 * Runtime.getRuntime() .exec( "WScript" + " " +
		 * FileStructureConstants.CSVToExcel + " " + absPath + " " + path );
		 * process.waitFor(); File fileToDelete = new File( absPath );
		 * fileToDelete.delete(); } catch ( SecurityException e ) { logger.error(
		 * e.getMessage(), e ); throw new CATTFileOperationException( e.getMessage() );
		 * } catch ( IOException e ) { logger.error( e.getMessage(), e ); throw new
		 * CATTFileOperationException( e.getMessage() ); } catch ( InterruptedException
		 * e ) { logger.error( e.getMessage(), e ); throw new
		 * CATTFileOperationException( e.getMessage() ); } catch (
		 * IllegalArgumentException e ) { logger.error( e.getMessage(), e ); throw new
		 * CATTFileOperationException( e.getMessage() ); } } } }
		 */}

	public static void deleteExistingScreenshotFolder(final String path) {
		File file = null;
		if (null != path) {
			file = new File(path);
		}
		try {
			if (null != file) {
				if (file.exists()) {
					String[] entries = file.list();
					for (String entry : entries) {
						File currentFile = new File(file.getPath(), entry);
						currentFile.delete();
					}
				}
			}
			if (null != file) {
				file.delete();
			}
		} catch (SecurityException e) {
			logger.error(e.getMessage(), e);
			throw new CATTFileOperationException(e.getMessage());
		}

	}

	public static String getNeoLoadProjectPath(String directoryPath, String className) {
		String projectLocation = directoryPath + DateDefination.execution_evidences_date_format
				+ InitializeConstants.fileSeparator + className + InitializeConstants.fileSeparator;
		String nlpFilePath = projectLocation + className + CommonConstant.NEOLOAD_FILE_EXTENSION;
		try {
			File file = new File(projectLocation);
			if (!file.exists()) {
				file.mkdirs();
			} else {
				logger.info("Directory for neoload project is already created with class name");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		try {

			File file = new File(nlpFilePath);
			if (!file.exists()) {
				boolean isFileCreated = file.createNewFile();
				if (isFileCreated) {
					logger.info(".nlp file created successfully : " + nlpFilePath);
				}
			} else {
				logger.info("File is already created, deleting existing file : " + nlpFilePath);
				boolean status = file.delete();
				if (status) {
					logger.info("File Deleted successfully" + nlpFilePath);
				}
				boolean creationStatus = file.createNewFile();
				if (creationStatus) {
					logger.info(".nlp file created successfully : " + file.getAbsolutePath());
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		Path file = createNlpFile(nlpFilePath, className);
		launchNeoLoadWithNoGUIMode();
		return file.toString();
	}

	/**
	 * 
	 */
	private static void launchNeoLoadWithNoGUIMode() {
		try {
			Process p = Runtime.getRuntime()
					.exec(InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator
							+ InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
							+ InitializeConstants.neoload_configuration_folder_name + InitializeConstants.fileSeparator
							+ InitializeConstants.neoload_launcher_bat_file_name);
			logger.info("Launching NeoLoad with -NoGUI mode ");
			Thread.sleep(40000);
		} catch (IOException | InterruptedException e) {
			logger.error(e.getStackTrace(), e);
		}
	}

	/**
	 * @param directoryPath
	 * @param className
	 * @return
	 */
	private static Path createNlpFile(String nlpFilePath, String className) {

		List<String> lines = Arrays.asList("# Project description file", "project.name=" + className,
				"project.version=" + InitializeConstants.neoLoadConfig.get("project.version"),
				"project.original.version=" + InitializeConstants.neoLoadConfig.get("project.original.version"),
				"product.name=" + InitializeConstants.neoLoadConfig.get("product.name"),
				"product.original.name=" + InitializeConstants.neoLoadConfig.get("product.original.name"),
				"product.version=" + InitializeConstants.neoLoadConfig.get("product.version"),
				"product.original.version=" + InitializeConstants.neoLoadConfig.get("product.original.version"),
				"project.id=" + className,
				"project.config.path=" + InitializeConstants.neoLoadConfig.get("project.config.path"),
				"project.config.storage=" + InitializeConstants.neoLoadConfig.get("project.config.storage"),
				"team.server.enabled=" + InitializeConstants.neoLoadConfig.get("team.server.enabled"));
		Path file = Paths.get(nlpFilePath);
		try {
			Files.write(file, lines, StandardCharsets.UTF_8);
		} catch (IOException e1) {
			logger.info(e1.getStackTrace());
			throw new CATTException(".nlp file creation failed. " + e1.getMessage());
		}
		return file;
	}

	public static boolean createNewDirectory(String filePath) {
		logger.info("Creating directory : " + filePath);
		File file = new File(filePath);
		boolean isDirectoryCreated = file.mkdirs();
		if (!isDirectoryCreated) {
			logger.warn("Directory already created : " + filePath);
		} else {
			logger.info("New directory created successfully");
		}
		return isDirectoryCreated;
	}

	public static boolean createNewFile(String filePath) {
		boolean result = false;
		try {
			File file = new File(filePath);
			result = file.createNewFile();
			if (result) {
				logger.info("File created - " + file.getCanonicalPath());
				result = true;
			} else {
				logger.info("File already exist at location: " + file.getCanonicalPath());
				result = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new CATTException("Issue occured while creating File: " + e.getMessage());
		}
		return result;
	}

	public static boolean deleteExistingFileAndCreateNewFile(String filePath) {
		boolean result = false;
		try {
			File file = new File(filePath);
			if (file.exists()) {
				logger.info("Deleting file: " + file.getCanonicalPath());
				file.delete();
			}
			result = file.createNewFile();
			if (result) {
				logger.info("File created - " + file.getCanonicalPath());
				result = true;
			} else {
				logger.info("File already exist at location: " + file.getCanonicalPath());
				result = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new CATTException("Issue occured while creating file: " + e.getMessage());
		}
		return result;
	}

	public static void appendLogMessageToFile(String filepath, String message) {
		File file = new File(filepath);
		try (FileWriter fileWriter = new FileWriter(file, true)) {
			try (BufferedWriter br = new BufferedWriter(fileWriter)) {
				br.write(message);
				br.write('\n');
			}
		} catch (Exception e) {
			logger.info("Error occured while writing data to file : " + filepath, e);
			throw new CATTException(e.getMessage());
		}
	}

	public static void appendLogMessageToFileWithoutNewLine(String filepath, String message) {
		File file = new File(filepath);
		try (FileWriter fileWriter = new FileWriter(file, true)) {
			try (BufferedWriter br = new BufferedWriter(fileWriter)) {
				br.write(message);
			}
		} catch (Exception e) {
			logger.info("Error occured while writing data to file : " + filepath, e);
			throw new CATTException(e.getMessage());
		}
	}

	// Re-name File
	public static boolean renameFile(String oldFile, String newFile, String uploadPth, Logger reportingLogger,
			String logMSG) {
		boolean fileStatus = false;
		deleteFile(uploadPth, newFile, reportingLogger);
		try {
			File oldfile = new File(oldFile);
			File newfile = new File(newFile);
			if (oldfile.renameTo(newfile)) {
				reportingLogger.info(logMSG + newfile.getAbsolutePath());
				fileStatus = true;
			} else {
				reportingLogger.info(ReportLoggerConstant.FILE_RENAME_FAILUR);
				fileStatus = false;
			}
		} catch (Exception e) {
			reportingLogger.info(ReportLoggerConstant.FILE_RENAME_FAILUR);
			throw new CATTException(e.getMessage());
		}
		return fileStatus;
	}

	public static void deleteFile(String folder, String delfile, Logger reportingLogger) {
		File dir = null;
		File[] dirContents = null;
		dir = new File(folder);
		try {
			dirContents = dir.listFiles();
			for (File file : dirContents) {
				try {
					if (file.getAbsoluteFile().equals(new File(delfile))) {
						if (file.delete()) {
							reportingLogger.info(" Existing File " + file.getName() + " Deleted successfully");
						} else {
							reportingLogger.info(file.getName() + " File is not present at location ");
						}
					}
				} catch (SecurityException e) {
					logger.error(e.getMessage(), e);
					throw new CATTFileOperationException(e.getMessage());
				}
			}
		} catch (SecurityException e) {
			logger.error(e.getMessage(), e);
			throw new CATTFileOperationException(e.getMessage());
		}
	}

	public static void deleteFileRecursivelyFromDirectory(String directoryPath, Logger logger) {
		try {
			if (new File(directoryPath).exists()) {
				Files.walk(Paths.get(directoryPath)).map(Path::toFile).sorted((o1, o2) -> -o1.compareTo(o2))
						.forEach(File::delete);
			}
		} catch (IOException nsfe) {
			logger.info("Directory not found: " + directoryPath);
			throw new CATTException("Directory not found " + nsfe.getMessage());
		}
	}

	public static void deleteFileContains(String folder, String fileNameContains, Logger reportingLogger) {
		File dir = null;
		File[] dirContents = null;
		dir = new File(folder);
		try {
			dirContents = dir.listFiles();

			for (File file : dirContents) {
				try {
					if (file.getName().contains(fileNameContains)) {
						if (file.delete()) {
							reportingLogger.info(" Existing File " + file.getName() + " Deleted successfully");
						} else {
							reportingLogger
									.info(file.getName() + " File is not present at location/ Unable to delete ");
						}
					}
				} catch (SecurityException e) {
					logger.error(e.getMessage(), e);
					throw new CATTFileOperationException(e.getMessage());
				}
			}
		} catch (SecurityException e) {
			logger.error(e.getMessage(), e);
			throw new CATTFileOperationException(e.getMessage());
		}
	}

	public static boolean copyFileFromSourceToDestination(String sourceFile, String destFile, Logger reportingLogger) {
		boolean status = false;
		try {
			FileUtils.copyFile(new File(sourceFile), new File(destFile));
			logger.info(ReportLoggerConstant.SAVE_OLD_FILE_SUCESS_MSG + destFile);
			status = true;
		} catch (IOException e) {
			reportingLogger.info(ErrorMessageConstant.ERROR_OCCURED_FILE_MSG);
			throw new CATTException(ErrorMessageConstant.ERROR_OCCURED_FILE_MSG + e.getMessage());
		}
		return status;
	}

	public static String getFileExtension(String fileName) {
		String fileExension = null;
		if (fileName.endsWith(CommonConstant.XLSX_FILE_EXTENSION)) {
			fileExension = CommonConstant.XLSX_FILE_EXTENSION;
		} else if (fileName.endsWith(CommonConstant.CSV_FILE_EXTENSION)) {
			fileExension = CommonConstant.CSV_FILE_EXTENSION;
		}
		return fileExension;
	}

	public static String setFileExtension(String fileName, String newFileExtension) {
		String[] fileExension = new String[2];
		String newFileName = null;
		if (fileName.endsWith(CommonConstant.XLSX_FILE_EXTENSION)) {
			fileExension = fileName.split(CommonConstant.XLSX_FILE_EXTENSION);
		} else if (fileName.endsWith(CommonConstant.CSV_FILE_EXTENSION)) {
			fileExension = fileName.split(CommonConstant.CSV_FILE_EXTENSION);
		} else {
			fileExension[0] = fileName;
		}
		// replace with newFileExtension
		newFileName = fileExension[0] + newFileExtension;
		return newFileName;
	}

	public static String generateFileName(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO,
			String[] reqValues, String filenameSeperator) {
		String generatedFileName = new String();
		for (int K = 0; K < reqValues.length; K++) {
			String reqValue = reqValues[K].trim();
			generatedFileName = generatedFileName
					+ VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), reqValue)
					+ filenameSeperator;
		}

		return generatedFileName.toString();
	}

	public static void ValidateFileNameSeprator(String filenameSeperator, Logger reportingLogger) {
		Pattern specialCharPattern = Pattern.compile("[*?:<>,'/',\\\\,\\[\\]]");
		Matcher hasSpecialChar = specialCharPattern.matcher(filenameSeperator);
		if (hasSpecialChar.find()) {
			reportingLogger.info(ReportLoggerConstant.INPUT_FILESEPERATOR_MSG + filenameSeperator
					+ ReportLoggerConstant.NOT_VALID_MSG);
			throw new CATTException(ErrorMessageConstant.GIVEN_FILE_NAMESEPRATOR_ISNOT_VALID);
		} else {
			reportingLogger.info(ReportLoggerConstant.INPUT_FILESEPERATOR_MSG + filenameSeperator
					+ ReportLoggerConstant.VALIDATED_MSG);
		}
	}

	public static boolean checkFileExists(String filepath) {
		File file = new File(filepath);
		return file.exists() ? true : false;

	}

	public static void createEnvironmentShellFile(String absolutePath) throws IOException {
		try (FileWriter aWriter = new FileWriter(absolutePath, false);) {
			aWriter.write("###########################################################");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Variables Section (DB Details)");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("###########################################################");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Oracle database SID INFO");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export DB_SID=" + ApplicationContext.dbsidBO + "");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Oracle username for Back Office");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export BO_DB_Username=" + ApplicationContext.username_DB_BO + "");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Oracle password for Back Office");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export BO_DB_Password=" + ApplicationContext.password_DB_BO + "");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Oracle username for Middle Office");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export MO_DB_Username=" + ApplicationContext.username_DB_MO + "");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Oracle password for Middle Office");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export MO_DB_Password=" + ApplicationContext.password_DB_MO + "");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("# Default database language");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("export NLS_LANG=.UTF8");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("DIR_SqlFiles=" + "\"" + InitializeConstants.sqlScriptPathOnAppServer + "\"" + "");
		}
	}

	public static boolean createSQLplusBatFile(String absolutePath, Map<String, LinkedList<String>> procedureDetails,
			String productName) {
		String logFileLocation = CommonUtility.getExecutionEvidencePath(productName)
				+ InitializeConstants.preRequisiteSQLExecutionLogFolderName + CommonConstant.UNDER_SCORE
				+ StringUtils.replace(ApplicationContext.productVersion, CommonConstant.DOT_OPERATOR,
						CommonConstant.EMPTY_STRING)
				+ InitializeConstants.fileSeparator;
		FileUtility.createNewDirectory(logFileLocation);
		String logFileExtension = ".log";
		logger.info("Pre-requisite SQL execution result location: " + logFileLocation);
		try (FileWriter aWriter = new FileWriter(absolutePath, false);) {
			aWriter.write("echo **** Setting oracle home path : " + FileStructureConstants.oracleClientFolderPath);
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("set ORACLE_HOME=" + FileStructureConstants.oracleClientFolderPath);
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("set PATH=%ORACLE_HOME%;%PATH%");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("set NLS_LANG=.AL32UTF8");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("cd " + DomainInitialization.initializeDomainWisePreRequisiteSQLPath(productName));
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write(CommonConstant.LINE_SEPERATER);
			String sqlPlusdbConnectionMO = DatabaseUtility.getSQLplusConnectionURLforMO();
			String sqlPlusdbConnectionBO = DatabaseUtility.getSQLplusConnectionURLforBO();

			for (Map.Entry<String, LinkedList<String>> sqlEntry : procedureDetails.entrySet()) {
				LinkedList<String> sqlInfo = sqlEntry.getValue();
				if (CommonConstant.YES.equalsIgnoreCase(sqlInfo.get(2))) {
					String sqlFileName = sqlInfo.get(1);
					aWriter.write(CommonConstant.LINE_SEPERATER);
					if (DBConstant.MO_MODULE.equalsIgnoreCase((sqlInfo.get(3)))) {
						aWriter.write("echo **** Executing " + sqlFileName + " script on "
								+ ApplicationContext.username_DB_MO + " ****");
						aWriter.write(CommonConstant.LINE_SEPERATER);
						aWriter.write("@echo quit | sqlplus " + sqlPlusdbConnectionMO + sqlFileName
								+ CommonConstant.SPACE + ApplicationContext.username_DB_MO + CommonConstant.SPACE
								+ CommonConstant.GREATER_THAN_SEPERATOR + CommonConstant.SPACE + logFileLocation
								+ removeExtensionFromFileName(sqlFileName) + logFileExtension);
					} else {
						aWriter.write("echo **** Executing " + sqlFileName + " script on "
								+ ApplicationContext.username_DB_BO + " ****");
						aWriter.write(CommonConstant.LINE_SEPERATER);
						aWriter.write("@echo quit | sqlplus " + sqlPlusdbConnectionBO + sqlInfo.get(1)
								+ CommonConstant.SPACE + ApplicationContext.username_DB_BO + CommonConstant.SPACE
								+ CommonConstant.GREATER_THAN_SEPERATOR + CommonConstant.SPACE + logFileLocation
								+ removeExtensionFromFileName(sqlFileName) + logFileExtension);
					}
					aWriter.write(CommonConstant.LINE_SEPERATER);
					aWriter.write(CommonConstant.LINE_SEPERATER);
				}
			}
			logger.info("bat file for executing SQl's via SQLPLUS is created successfullly");
			return true;
		} catch (Exception e) {
			logger.info(e.getMessage(), e);
			return false;
		}
	}

	/**
	 * @param sqlFileName
	 * @return
	 */
	private static String removeExtensionFromFileName(String sqlFileName) {
		try {
			return CommonUtility.splitStringUsingPattern(sqlFileName, CommonConstant.DOT_OPERATOR)[0];
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return sqlFileName;
		}
	}

	public static void createRunShellFile(String absolutePath, Map<String, LinkedList<String>> procedureDetails)
			throws IOException {
		try (FileWriter aWriter = new FileWriter(absolutePath, false);) {
			aWriter.write("#!/bin/bash");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write(". " + InitializeConstants.sqlScriptPathOnAppServer + "Execute_Sql_Scripts.sh");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("time_stamp=$(date +%Y_%m_%d)");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("mkdir -p -m 777 ./logs/$time_stamp/BO");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("mkdir -p -m 777 ./logs/$time_stamp/MO");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("Main()");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("{");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("db_statuscheck");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("if [[ \"$DB_STATUS\" == \"UP\" ]] ; ");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("	then");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("		echo \"`date` : Database Status: ${DB_STATUS}.\"");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("		echo \"`date` : Starting Sql auto run script.\"");
			aWriter.write(CommonConstant.LINE_SEPERATER);

			for (Map.Entry<String, LinkedList<String>> sqlEntry : procedureDetails.entrySet()) {
				LinkedList<String> sqlInfo = sqlEntry.getValue();
				if (FrameworkConstant.EXECUTED_ON_DB_SERVER.equalsIgnoreCase(sqlInfo.get(4))
						&& (CommonConstant.YES.equalsIgnoreCase(sqlInfo.get(2)))) {
					aWriter.write("		runsqls \"" + sqlInfo.get(1) + "\" \"" + sqlInfo.get(3) + "\"");
					aWriter.write(CommonConstant.LINE_SEPERATER);
				}
			}

			aWriter.write("		echo \"`date` : Sql auto run script execution completed.\"");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("elif [[ \"$DB_STATUS\" == \"DOWN\" ]] ;");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("	then");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("		echo \"'date' : DB status check failed...\"");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("		echo \"'date' : Skipping to run extra sqls and exiting...\"");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("fi");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("		exit");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("}");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("Main | tee autosql.log");
			aWriter.write(CommonConstant.LINE_SEPERATER);
		}

	}

	public static void createBatchSQLFile(String absolutePath, String batchQuery, Logger sqlLogger) {
		try (FileWriter aWriter = new FileWriter(absolutePath, false);) {
			aWriter.write("SET SERVEROUTPUT ON;");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("/");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("BEGIN");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			if (null != batchQuery) {
				aWriter.write(batchQuery);
			}
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("Commit;");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("END;");
			aWriter.write(CommonConstant.LINE_SEPERATER);
			aWriter.write("/");
		} catch (IOException e) {
			logger.info(e);
			sqlLogger.error("BATCHES_PATH SQL file creation failed " + e.getMessage(), e);
		}
	}

	/**
	 * @param zipFileName
	 */
	private static String getFolderName(String InputZipFileName) {
		String folderName = null;
		File inputFile = new File(InputZipFileName);
		if (inputFile.getName().endsWith(CommonConstant.ZIP_FILE_EXTENSION)) {
			folderName = InputZipFileName.replace(CommonConstant.ZIP_FILE_EXTENSION, CommonConstant.EMPTY_STRING);
		} else {
			logger.info(ErrorMessageConstant.INPUT_FILE_NOT_ZIP_MSG);
		}
		return folderName;
	}

	/**
	 * This method is used to unzip file
	 * 
	 * @param zipFileName name of zip file
	 */
	public static void unZipFolder(final String[] inputZipFile) {
		String folderLocation = getFolderName(inputZipFile[0]);
		File expetedFolder = new File(folderLocation);
		if ((!expetedFolder.exists() && !expetedFolder.isDirectory())) {
			String outputFolderLocation = null;
			try {
				outputFolderLocation = inputZipFile[0].replace(new File(inputZipFile[0]).getName(),
						CommonConstant.EMPTY_STRING);
				ZipUtil.unpack(new File(inputZipFile[0]), new File(outputFolderLocation));
			} catch (ZipException exp) {
				logger.error(ErrorMessageConstant.EXPECTED_FILE_NOT_MSG + outputFolderLocation + CommonConstant.SPACE
						+ exp.getMessage());
			} catch (Exception e) {
				logger.error(ErrorMessageConstant.EXPECTED_FILE_NOT_MSG + outputFolderLocation + CommonConstant.SPACE
						+ e.getMessage());
			}
		}
	}

}
