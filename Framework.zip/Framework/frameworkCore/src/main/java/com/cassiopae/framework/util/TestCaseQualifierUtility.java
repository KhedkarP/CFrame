/**
 * 
 */
package com.cassiopae.framework.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.to.XlsFileRowDetails;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.TestNGSuiteCreationUtility;
import com.cassiopae.selenium.util.common.VersionComparator;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

/**
 * @author jraut
 *
 */
public class TestCaseQualifierUtility {
	
	private TestCaseQualifierUtility() {
	}

	private static Logger tracelogger = LogManager.getLogger(TestCaseQualifierUtility	.class);

	public static void putExcludedStatusInSummaryFile(Map<String, String> unqualifiedTestCases, String domainName) {
		String testCaseSummaryExcelpath = DomainInitialization.initializeDomainTestDataExcelPath(domainName);
		Path backupFile = Paths
				.get(testCaseSummaryExcelpath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		Boolean flag = false;
		File inputWorkbook = null;
		inputWorkbook = new File(testCaseSummaryExcelpath);
		ExcelOperation.excelBackupCreate(testCaseSummaryExcelpath, backupFile);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook);) {
				flag = ExcelOperation.checkSheetPresent(ApplicationConstant.excelStatusSheetName, workbook);
			} catch (Exception exp) {
				tracelogger.error(exp.getMessage(), exp);
			}
			if (flag.booleanValue()) {
				try (FileInputStream fis = new FileInputStream(new File(testCaseSummaryExcelpath));
						HSSFWorkbook workbook1 = (HSSFWorkbook) WorkbookFactory.create(fis)) {
					Sheet sheet = workbook1.getSheet(ApplicationConstant.excelStatusSheetName);
					Cell cell = null;
					for (int noOfRows = 0; noOfRows <= sheet.getLastRowNum(); noOfRows++) {

						String methodName = sheet.getRow(noOfRows)
								.getCell(InitializeConstants.test_case_worksheet_name_column).getStringCellValue();
						if (null != methodName && unqualifiedTestCases.containsKey(methodName)) {
							cell = sheet.getRow(noOfRows).getCell(InitializeConstants.status_column_Number);
							if(null != cell) {
							cell.setCellValue(CommonConstant.TEST_CASES_EXCLUDED_STATUS);
							setCellFormat(workbook1, cell);
							}
						}
					}
					writeDataIntoExcelFile(testCaseSummaryExcelpath, workbook1);
				} catch (Exception exp) {
					tracelogger.error("Error occured while putting 'Excluded' status into test case summary file for unqualified test casess", exp);
				}
				if (inputWorkbook.length() > 0) {
					ExcelOperation.deleteExistingFile(backupFile);
				} else {
					tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
					try {
						Files.delete(inputWorkbook.toPath());
						Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
					} catch (Exception exp) {
						tracelogger.error(exp.getMessage(), exp);
					}
				}
			} else {
				tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK
						+ ApplicationConstant.excelStatusSheetName);
				if (inputWorkbook.length() > 0) {
					ExcelOperation.deleteExistingFile(backupFile);
				} else {
					tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
					try {
						Files.delete(inputWorkbook.toPath());
						Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
					} catch (Exception exp) {
						tracelogger.error(exp.getMessage(), exp);
					}
				}
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + testCaseSummaryExcelpath);
		}
	}

	private static void writeDataIntoExcelFile(String testCaseSummaryExcelpath, HSSFWorkbook workbook1) {
		try (FileOutputStream fileOut = new FileOutputStream(testCaseSummaryExcelpath)) {
			workbook1.write(fileOut);
		} catch (Exception exp) {
			tracelogger.error(exp.getMessage(), exp);
		}
	}

	private static void setCellFormat(HSSFWorkbook workbook1, Cell cell) {
		try {
			CellStyle style = workbook1.createCellStyle();
			// Setting Background color
			style.setFillForegroundColor(IndexedColors.LIGHT_ORANGE.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setBorderBottom(BorderStyle.THIN);
			style.setBorderLeft(BorderStyle.THIN);
			style.setBorderRight(BorderStyle.THIN);
			style.setBorderTop(BorderStyle.THIN);
			cell.setCellStyle(style);
		} catch (Exception e) {
			tracelogger.error(e);
		}
	}

	public static void createMapOfUnqualifiedTestCases(Map<String, String> unqualifiedTestCases, String domainName) {
		Map<String, List<XlsFileRowDetails>> dashboardHashMap = new LinkedHashMap<>();
		ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
				.initializeDomainTestEnvDetailExcelPath(domainName);
		DashboardDetails dashboardDetails = new DashboardDetails();
		dashboardDetails.setDomainName(domainName);
		DashboardExcelReadOperation.readDashboardExcel(dashboardDetails);
		dashboardHashMap.putAll(DashboardProcessingUtility.getXlsFileRowDetailsMapForClass(domainName,
				dashboardDetails.getProjectTestCase()));

		VersionComparator basetestExecutionVersion = new VersionComparator();
		VersionComparator fixVersion = new VersionComparator();
		VersionComparator endCompatibleVersion = new VersionComparator();
		VersionComparator defaultBaseVersion = new VersionComparator();
		defaultBaseVersion.setVersionValue(FrameworkConstant.VERSION_470);

		basetestExecutionVersion.setVersionValue(
				TestNGSuiteCreationUtility.getAccurateVersionValue(ApplicationContext.productVersion.trim()));
		for (Map.Entry<String, List<XlsFileRowDetails>> object : dashboardHashMap.entrySet()) { // class level map
			List<XlsFileRowDetails> xlsFileRowDetailsList = object.getValue();
			for (int method = 0; method < xlsFileRowDetailsList.size(); method++) { // for each method w.r.t.class
				XlsFileRowDetails xlsFileRowDetails = xlsFileRowDetailsList.get(method);
				fixVersion.setVersionValue(
						TestNGSuiteCreationUtility.getAccurateVersionValue(xlsFileRowDetails.getTCVersion().trim()));
				endCompatibleVersion.setVersionValue(TestNGSuiteCreationUtility
						.getAccurateVersionValue(xlsFileRowDetails.getEndCompatibiltyVersion().trim()));

				if (xlsFileRowDetails.getEndCompatibiltyVersion()
						.contains(FrameworkConstant.END_COMPATIBILITY_VERSION_NEXT_VALUE)
						|| endCompatibleVersion.compareTo(basetestExecutionVersion) >= 0
						|| fixVersion.equals(basetestExecutionVersion)) {

					String endcompatibiltyTCVersion = xlsFileRowDetails.getEndCompatibiltyVersion();
					VersionComparator basetestExecutionVersion1 = new VersionComparator();
					VersionComparator endCompatibilityVersion1 = new VersionComparator();
					VersionComparator fixVersion1 = new VersionComparator();
					basetestExecutionVersion1.setVersionValue(
							TestNGSuiteCreationUtility.getAccurateVersionValue(ApplicationContext.productVersion));
					endCompatibilityVersion1.setVersionValue(
							TestNGSuiteCreationUtility.getAccurateVersionValue(endcompatibiltyTCVersion.trim()));
					fixVersion1.setVersionValue(TestNGSuiteCreationUtility
							.getAccurateVersionValue(xlsFileRowDetails.getTCVersion().trim()));
					if (fixVersion1.equals(basetestExecutionVersion1)
							|| fixVersion1.compareTo(basetestExecutionVersion1) <= 0) {
						if (endcompatibiltyTCVersion.contains(FrameworkConstant.END_COMPATIBILITY_VERSION_NEXT_VALUE)
								|| endCompatibilityVersion1.compareTo(basetestExecutionVersion1) >= 0) {
						} else {
							unqualifiedTestCases.put(xlsFileRowDetails.getMethodName(),
									CommonConstant.TEST_CASES_EXCLUDED_STATUS);
						}
					} else {
						unqualifiedTestCases.put(xlsFileRowDetails.getMethodName(),
								CommonConstant.TEST_CASES_EXCLUDED_STATUS);
					}
				} else {
					unqualifiedTestCases.put(xlsFileRowDetails.getMethodName(),
							CommonConstant.TEST_CASES_EXCLUDED_STATUS);
				}

			}
		}
	}

}