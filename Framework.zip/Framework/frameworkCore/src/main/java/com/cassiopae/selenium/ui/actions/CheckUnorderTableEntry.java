/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author skumar
 *
 */
public class CheckUnorderTableEntry implements PerformAction {

	/**
	 * This method execute action for select drop down action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFieldsTO.getLocatorKey()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDatas = excelTestCaseFieldsTO.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		boolean recordStatus = false;
		String[] seleniumActions = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		int globtotalEntryCount = SelectPanelTableEntryUtility.getCountOfUnorderListEntries(testCaseDetailTO,
				locatorMap.get(locatorKeys[0].trim()).get(0));

		List<PanelTableDetails> panelTableDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap,
				locatorKeys, seleniumActions, reqValues, testCaseDetailTO);

		int rowNumber = SelectPanelTableEntryUtility.executeCheckEntryInTableforUnorderedList(panelTableDetailList,
				recordStatus, globtotalEntryCount, testCaseDetailTO);

		String[] variableHolderColumnData = CommonUtility.splitStringUsingPattern(
				excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
		if (rowNumber == -1 && !recordStatus) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.ENTRY_IS_NOT_LISTED_IN_TABLE);
			testCaseDetailTO.getVariableHolder().put(variableHolderColumnData[0].trim(), "null");
			testCaseDetailTO.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.FALSE_VALUE);
		} else {
			testCaseDetailTO.getVariableHolder().put(variableHolderColumnData[0].trim(), String.valueOf(rowNumber));
			testCaseDetailTO.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.TRUE_VALUE);
		}
	}
}
