/**
 * 
 */
package com.cassiopae.selenium.util.common;

import java.util.List;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.to.ErrorValidation;
import com.cassiopae.framework.util.DashboardProcessingUtility;
import com.cassiopae.framework.util.DashboardValidation;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.utils.date.DateUtils;

/**
 * @author jraut
 *
 */
public class TestClassCreationUtility {

	private static Logger logger = LogManager.getLogger(TestClassCreationUtility.class);
	public static void launchJavaTestClassCreation(final String[] envNames, Logger excellogger) {
		String[] domains;
		if (envNames.length == 0) {
			domains = TestNGSuiteCreationUtility.setProductExecutionEnv(envNames);
		} else {
			domains = envNames;
		}

		for (int i = 0; i < domains.length; i++) {
			String domainName = domains[i];
			excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
			excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
			excellogger
					.info(ReportLoggerConstant.TEST_CLASS_EXECUTION_STARTED + domainName);

			DashboardDetails dashboardDetails = new DashboardDetails();
			dashboardDetails.setDomainName(domainName);
			DashboardProcessingUtility.processDashboard(dashboardDetails);
			List<ErrorValidation> errorMessageList = DashboardValidation.validateDashboard(dashboardDetails);
			if (!errorMessageList.isEmpty()) {
				for (ErrorValidation errorValidation : errorMessageList) {
					StringBuilder errorMessage = DashboardProcessingUtility.getMessage(errorValidation);
					excellogger.error(errorMessage.toString());
					logger.info(errorMessage.toString());
				}
				DashboardProcessingUtility.generateErrorFile();
				excellogger.error(
						ReportLoggerConstant.EXECUTION_ENDED_WITH_ERROR + domainName + ReportLoggerConstant.DOMAIN);
				excellogger.error(ReportLoggerConstant.TEST_CLASS_EXECUTION_ENDED_WITH_ERROR_FILE);
				excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
				excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
				continue;
			}

			DashboardProcessingUtility.createClassNamAndJavaFile(dashboardDetails.getXlsFileRowDetailsMap());
			excellogger
					.info(ReportLoggerConstant.TEST_CLASS_EXECUTION_ENDED + domainName + ReportLoggerConstant.DOMAIN);
			excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
			excellogger.info(ReportLoggerConstant.FORMATING_PATTERN);
		}
	}
}
