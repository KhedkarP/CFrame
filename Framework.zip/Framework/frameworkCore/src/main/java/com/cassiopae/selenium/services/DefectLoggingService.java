/**
 * 
 */

package com.cassiopae.selenium.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.FileStructureConstants;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

import java.util.Base64;
/*import word.api.interfaces.IDocument;
import word.w2004.Document2004;
import word.w2004.elements.BreakLine;
import word.w2004.elements.Image;
import word.w2004.elements.Paragraph;*/

/**
 * @author jraut
 */

public class DefectLoggingService {

	private static Logger logger = LogManager.getLogger(DefectLoggingService.class);
	// ************************** JIRA Handling Variables Details
	// ***************************************//
	public static String username1 = "";
	public static String password1 = "";
	public static String Project = "NLSCUAT";
	public static String assignee = "DHARMARAJD";
	public static String issuetype = "Bug";
	public static String components = "SERVICING";
	public static String Module = "All";
	public static String Feature = "All";
	public static String description = "Please refer .html and .mp4 file to reproduce issues";
	public static String Jira_Creation_URL = "https://jira.cassiopae.com/jira/rest/api/2/issue"; // http://172.29.248.52:8080/jira/rest/api/2/issue

	// ************************** Issue Jira Creation and Attached Attachment
	// Methods ***********************//
	public static String newIssueCreation(final String project, final String summary, final String username,
			final String password, final String description, final String assignee, final String issuetype,
			final String components, final String module, final String feature) {
		String output = null;
		try {
			Client client = Client.create();
			client.addFilter(new HTTPBasicAuthFilter(username, password));
			WebResource webResource = client.resource(Jira_Creation_URL);
			String input = "{\"fields\":{" + "\"project\":{\"key\":\"" + project + "\"}," + "\"summary\":\"" + summary
					+ "\"," + "\"description\":\"" + description + "\", " + "\"assignee\": {\"name\": \"" + assignee
					+ "\"}," + "\"issuetype\":{\"name\":\"" + issuetype + "\"}," + "\"components\":[{\"name\":\""
					+ components + "\"}]," + "\"customfield_15200\": {\"value\": \"" + module
					+ "\", \"child\": {\"value\":\"" + feature + "\"} }" + "}}";
			ClientResponse response = webResource.type("application/json").post(ClientResponse.class, input);
			output = CommonUtility.splitString(response.getEntity(String.class), "\"key\":\"")[1];
			output = CommonUtility.splitString(output, "\"")[0];
			return output;
		}

		catch (UniformInterfaceException e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		} catch (ClientHandlerException e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		}
	}

/*	public static String exception( final String error, final Method method, final WebDriver driver ) {
		try {
			Map<String, String> DateDayTime = DateDefination.reportDateTime();
			String time = DateDayTime.get("Time");
			File driverScreenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File screenshot = new File(
					FileStructureConstants.evidenceFolderPath + "Error_Screenshot_" + method.getName() + time + ".jpg");
			FileUtils.copyFile(driverScreenShot, screenshot);
			IDocument doc = new Document2004();
			doc.addEle(Paragraph.with(" 1." + method.getName() + " :- ").create());
			doc.addEle(new BreakLine(2));
			doc.addEle(Image.from_FULL_LOCAL_PATHL(
					System.getProperty("user.dir") + "//Execution_Results//Screenshots//" + screenshot.getName())
					.setHeight("300").setWidth("500").create().getContent());
			doc.addEle(new BreakLine(2));
			doc.addEle(Paragraph.with("2. Exception logs : - ").create());
			doc.addEle(new BreakLine(1));
			doc.addEle(Paragraph.with(error).create());
			File fileObj = new File(System.getProperty("user.dir") + "//Execution_Results//Fail_Reports//"
					+ "Error_Document_" + method.getName() + time + ".doc");
			PrintWriter writer = new PrintWriter(fileObj);
			writer.println(doc.getContent());
			writer.close();
			driver.switchTo().defaultContent();
			return fileObj.getAbsolutePath();
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(), e);
			throw new CATTFileOperationException(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			throw new CATTFileOperationException(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		}
	}*/

	// *************************** JIRA File Attachment Definition Method
	// ***************************//
/*
	public static void attachedDocumetToJira(final String issue, final String issueReproducestepslogs,
			final String issueVideoPath, final String username1, final String password1)
			 {
		try {
			File fileUpload = new File(issueReproducestepslogs);
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost postRequest = new HttpPost(Jira_Creation_URL + "/" + issue + "/attachments");
			BASE64Encoder base = new BASE64Encoder();
			String credentials = username1 + ":" + password1;
			String encoding = base.encode(credentials.getBytes());
			postRequest.setHeader("Authorization", "Basic " + encoding);
			postRequest.setHeader("X-Atlassian-Token", "nocheck");
			MultipartEntityBuilder entity = MultipartEntityBuilder.create();
			entity.addPart("file", new FileBody(fileUpload));
			postRequest.setEntity(entity.build());
			File fileUpload2 = new File(issueVideoPath);
			httpClient = HttpClientBuilder.create().build();
			postRequest = new HttpPost(Jira_Creation_URL + "/" + issue + "/attachments");
			base = new BASE64Encoder();
			credentials = username1 + ":" + password1;
			encoding = base.encode(credentials.getBytes());
			postRequest.setHeader("Authorization", "Basic " + encoding);
			postRequest.setHeader("X-Atlassian-Token", "nocheck");
			entity = MultipartEntityBuilder.create();
			entity.addPart("file", new FileBody(fileUpload2));
			postRequest.setEntity(entity.build());
		} catch (NullPointerException e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new CATTException(e.getMessage());
		}
	}*/

}
