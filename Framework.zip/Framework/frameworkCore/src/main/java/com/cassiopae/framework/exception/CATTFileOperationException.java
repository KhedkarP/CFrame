/**
 * 
 */
package com.cassiopae.framework.exception;

/**
 * @author nbhil
 *
 */
public class CATTFileOperationException extends CATTException {

	private static final long serialVersionUID = 5936342230671213004L;

	public CATTFileOperationException(final String message) {
		super(message);
	}

	public CATTFileOperationException() {
		super();
	}

}
