/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.functions.PropertyFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class PropertyFunctionExecutor implements FunctionExecutor {

	/* (non-Javadoc)
	 * @see com.selenium.ui.functions.executor.FunctionExecutor#executeFunction(java.lang.String, com.selenium.service.model.ExcelTestCaseFields, com.cassiopae.framework.to.TestCaseDetail)
	 */
	@Override
	public void executeFunction(String methodName, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		String[] inputData = CommonUtility.getInputData(excelTestCaseFields, testCaseDetail);	

		if (FunctionConstant.NAVIGATE_TO.equals(methodName)) {
			PropertyFunctions.navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		} else if (FunctionConstant.OPEN.equals(methodName)) {
			PropertyFunctions.open(inputData[0],excelTestCaseFields, testCaseDetail);
		}

	}

}
