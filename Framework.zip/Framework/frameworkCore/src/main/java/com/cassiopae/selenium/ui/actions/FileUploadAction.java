package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.FileStructureConstants;

public class FileUploadAction implements PerformAction {

	private static Logger logger = LogManager.getLogger(FileUploadAction.class);

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String fileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps()
				+ CommonConstant.COLON_SEPERATOR + CommonConstant.SPACE + fileName);
		String fileUploadPath = DomainInitialization
				.initializeDomainWiseUploadFilePath(testCaseDetailTO.getDomainName()) + fileName;
		if (testCaseDetailTO.getTestCaseCommonData().getBrowserName().equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			if (testCaseDetailTO.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.POS_MODULE)) {
				testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.CLICK_ON_FILEUPLOAD);
				try {
					testCaseDetailTO.getDriver().findElement(GenericAction
							.locator(excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap()))
							.click();
				} catch (Exception e) {
					testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FACING_ISSUE_FILEUPLOAD);
				}
				testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FILE_UPLOAD_FOR_IE);
				SeleniumUtility.executeExeFile(FileStructureConstants.autoITExecutalePathForFileUpload,
						testCaseDetailTO.getReportingLogger(), fileUploadPath);
				logger.info(ReportLoggerConstant.CLOSE_FILE_UPLOAD_INSTANCE);
				SeleniumUtility.executeExeFile(FileStructureConstants.closeAutoIT_File_Upload_InstancesBatFilePath,
						testCaseDetailTO.getReportingLogger());
			} else {
				testCaseDetailTO.getDriver().findElement(GenericAction.locator(excelTestCaseFieldsTO.getLocatorKey(),
						testCaseDetailTO.getLocatorHashMap())).sendKeys(fileUploadPath);
				CommonFunctions.explicitWait(5000);
			}
		} else if (testCaseDetailTO.getTestCaseCommonData().getBrowserName()
				.equalsIgnoreCase(CommonConstant.CHROME_BROWSER)
				|| testCaseDetailTO.getTestCaseCommonData().getBrowserName()
						.equalsIgnoreCase(CommonConstant.MS_EDGE_BROWSER)) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FILE_UPLOAD_FOR_CHROME);
			if (testCaseDetailTO.getTestCaseCommonData().getWorkSheetName().contains(FrameworkConstant.POS)
					|| StringUtils.startsWith(testCaseDetailTO.getWorkSheetName(), DBConstant.CC_APP_SHEET_NAME)) {
				if (ApplicationContext.productVersion.equals("4.7.1")) {
					testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.CLICK_ON_FILEUPLOAD);
					try {
						testCaseDetailTO.getDriver().findElement(GenericAction
								.locator(excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap()))
								.click();
					} catch (Exception e) {
						testCaseDetailTO.getReportingLogger()
								.info(ReportLoggerConstant.FACING_ISSUE_FILEUPLOAD + e.getMessage());
					}
					testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FILE_UPLOAD_FOR_POS);
					SeleniumUtility.executeExeFile(FileStructureConstants.autoITExecutalePathForFileUpload,
							testCaseDetailTO.getReportingLogger(), fileUploadPath);
					logger.info(ReportLoggerConstant.CLOSE_FILE_UPLOAD_INSTANCE);
					SeleniumUtility.executeExeFile(FileStructureConstants.closeAutoIT_File_Upload_InstancesBatFilePath,
							testCaseDetailTO.getReportingLogger());
				} else {
					CommonFunctions.explicitWait(5000);
					try {
						WebElement element = testCaseDetailTO.getDriver().findElement(GenericAction
								.locator(excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap()));
						Actions actions = new Actions(testCaseDetailTO.getDriver());
						actions.moveToElement(element);
						actions.perform();
						CommonFunctions.explicitWait(2000);
					} catch (Exception e) {
					}
					testCaseDetailTO.getDriver()
							.findElement(By.xpath(testCaseDetailTO.getLocatorHashMap()
									.get(excelTestCaseFieldsTO.getLocatorKey()).get(0) + "//input"))
							.sendKeys(fileUploadPath);
				}
			} else {
				testCaseDetailTO.getDriver().findElement(GenericAction.locator(excelTestCaseFieldsTO.getLocatorKey(),
						testCaseDetailTO.getLocatorHashMap())).sendKeys(fileUploadPath);
			}
			CommonFunctions.explicitWait(15000);
		}
	}
}
