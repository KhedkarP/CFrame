/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class CheckPanelEntryAction implements PerformAction {

	int globtotalEntryCount = 24;
//	private static Logger logger = LogManager.getLogger(CheckPanelEntryAction.class);

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		if(testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS)) {
			checkPanelPOSEntryAction(excelTestCaseFields, testCaseDetail);
		} else {
			checkPanelEntryActionBO(excelTestCaseFields, testCaseDetail);
		}
	}
	
	public void checkPanelEntryActionBO(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		boolean recordStatus=false;
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDatas = excelTestCaseFields.getInputTestData().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] seleniumActions = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		globtotalEntryCount = Integer.parseInt(SelectPanelTableEntryUtility.getCountOfEntries(testCaseDetail,
				locatorMap.get(locatorKeys[0].trim()).get(0)));
		
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		
		List<PanelTableDetails> panelTableDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap, locatorKeys, seleniumActions,
				reqValues,testCaseDetail);
		int rowNumber =SelectPanelTableEntryUtility.executeCheckEntryInTable(panelTableDetailList, recordStatus,
				globtotalEntryCount, testCaseDetail);
		
		String[] variableHolderColumnData = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
		
		if (rowNumber == -1 && !recordStatus ) {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.ENTRY_IS_NOT_LISTED_IN_TABLE);
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(),"null");
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(),CommonConstant.FALSE_VALUE);
		} else {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(),
					String.valueOf(rowNumber));
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(),
					CommonConstant.TRUE_VALUE);
		}
	
		
	}

	
	public void checkPanelPOSEntryAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		boolean recordStatus = false;
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDatas = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] seleniumActions = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		globtotalEntryCount = SelectPanelTableEntryUtility.getCountOfPOSEntries(testCaseDetail,
				locatorMap.get(locatorKeys[0].trim()).get(0));
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		List<PanelTableDetails> panelTableDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap,
				locatorKeys, seleniumActions, reqValues, testCaseDetail);
		int rowNumber = SelectPanelTableEntryUtility.executeCheckEntryInPOSTable(panelTableDetailList, recordStatus,
				globtotalEntryCount, testCaseDetail);
		String[] variableHolderColumnData = CommonUtility
				.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
		if (rowNumber == -1 && !recordStatus) {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.ENTRY_IS_NOT_LISTED_IN_TABLE);
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(), "null");
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.FALSE_VALUE);
		} else {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(), String.valueOf(rowNumber));
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.TRUE_VALUE);
		}
	}
	
	
	
}
