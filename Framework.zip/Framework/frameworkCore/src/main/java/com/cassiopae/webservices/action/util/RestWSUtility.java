package com.cassiopae.webservices.action.util;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.logging.log4j.*;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.to.restWebServiceData;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.cassiopae.webservices.action.WSCommonConstants;
import com.cassiopae.webservices.action.WSErrorMessageConstant;
import com.cassiopae.webservices.action.WSReportingLoggerConstant;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;

import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.http.ContentType;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestWSUtility {

	private RestWSUtility() {
		throw new IllegalStateException();
	}

	private static Logger logger = LogManager.getLogger(RestWSUtility.class);

	/**
	 * This method is used to convert JSON object from Map
	 * 
	 * @param excelDataMap
	 * @return JSONObject
	 */
	public static JSONObject convertMapDataInJsonObject(Map<String, String> excelDataMap) {
		JSONObject jsonObject = new JSONObject();
		JSONObject storeMapObject = null;
		Set<String> keys = excelDataMap.keySet();
		Iterator<String> keysit = keys.iterator();
		excelDataMap.size();
		while (keysit.hasNext()) {
			String actkey = keysit.next();
			JSONArray array = new JSONArray();
			if (actkey.contains("Array")) {
				array.put(excelDataMap.get(actkey));
				jsonObject.put(actkey.split("_")[0], array);
			}
			if (!actkey.contains("Array")) {
				storeMapObject = jsonObject.put(actkey, excelDataMap.get(actkey));

			}
		}

		return storeMapObject;
	}

	/**
	 * This method is used to execute POST request
	 * 
	 * @param sessionToken
	 * @param requestBody
	 * @param cookie
	 * @param postRequestURL
	 * @param testCaseDetailTO
	 * @return Response object which contains response data
	 */
	@Deprecated
	public static Response executePOSTRequest(String sessionToken, String requestBody, String cookie,
			String postRequestURL, TestCaseDetail testCaseDetailTO) {
		// Logger reportingLogger =
		// testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = ApplicationContext.baseUrlBO + WSCommonConstants.RestAPIBody;
		logger.info(WSReportingLoggerConstant.REQUEST_END_POINT + ApplicationContext.baseUrlBO
				+ WSCommonConstants.RestAPIBody);
		return RestAssured.given().log().all().contentType(ContentType.JSON)
				.headers(WSCommonConstants.COKIE_TOKEN, cookie)
				.headers(WSCommonConstants.KSIOPE_SESION_TOKEN, sessionToken).body(requestBody).post(postRequestURL)
				.then().extract().response();
	}

	public static ExtractableResponse<Response> executeRESTAPIPOSTRequestService(String sessionToken,
			String requestBody, String cookie, String postRequestURL, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = postRequestURL;
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_END_POINT + postRequestURL);
		return RestAssured.given().log().all().contentType(ContentType.JSON)
				.headers(WSCommonConstants.COKIE_TOKEN, cookie)
				.headers(WSCommonConstants.KSIOPE_SESION_TOKEN, sessionToken).body(requestBody).post(postRequestURL)
				.then().extract();
	}
	
	public static ExtractableResponse<Response> executeRESTAPIPUTRequestService(String sessionToken,
			String requestBody, String cookie, String postRequestURL, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = postRequestURL;
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_END_POINT + postRequestURL);
		return RestAssured.given().log().all().contentType(ContentType.JSON)
				.headers(WSCommonConstants.COKIE_TOKEN, cookie)
				.headers(WSCommonConstants.KSIOPE_SESION_TOKEN, sessionToken).body(requestBody).put(postRequestURL)
				.then().extract();
	}

	public static ExtractableResponse<Response> executeRESTRequest(String requestMethod, String requestBoday,
			String postRequestURL, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = postRequestURL;
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_END_POINT + postRequestURL);
		RequestSpecification requestSpecification = RestAssured.given().log().all().contentType(ContentType.JSON)
				.body(requestBoday);
		ExtractableResponse<Response> extractableResponse = null;
		switch (requestMethod) {
		case WSCommonConstants.POST_MSG:
			extractableResponse = requestSpecification.post(postRequestURL).then().extract();
			break;
		case WSCommonConstants.GET_MSG:
			extractableResponse = requestSpecification.get(postRequestURL).then().extract();
			break;
		case WSCommonConstants.PUT_MSG:
			extractableResponse = requestSpecification.put(postRequestURL).then().extract();
			break;
		case WSCommonConstants.PATCH_MSG:
			extractableResponse = requestSpecification.patch(postRequestURL).then().extract();
			break;
		default:
			logger.info(WSErrorMessageConstant.PLEASE_CHECK_INPUT_REQUEST_METHOD_MSG);
		}
		return extractableResponse;
	}

	public static ExtractableResponse<Response> executeRESTAPIPATCHRequestService(String sessionToken,
			String requestBody, String cookie, String requestURL, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = requestURL;
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_END_POINT + requestURL);
		return RestAssured.given().log().all().contentType(ContentType.JSON)
				.headers(WSCommonConstants.COKIE_TOKEN, cookie)
				.headers(WSCommonConstants.KSIOPE_SESION_TOKEN, sessionToken).body(requestBody).patch(requestURL).then()
				.extract();
	}

	public static ExtractableResponse<Response> executeRESTAPIGETRequestService(String sessionToken, String requestBody,
			String cookie, String requestURL, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		RestAssured.baseURI = requestURL;
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_END_POINT + requestURL);
		return RestAssured.given().log().all().contentType(ContentType.JSON)
				.headers(WSCommonConstants.COKIE_TOKEN, cookie)
				.headers(WSCommonConstants.KSIOPE_SESION_TOKEN, sessionToken).body(requestBody).get(requestURL).then()
				.extract();
	}

	/**
	 * This method is used to fetch cookies info from Response object
	 * 
	 * @param response object which contains REST web service response
	 * @return SCOUTER & Unitoken cookies in form of string separated by colon
	 */
	public static String generateCookie(Response response) {
		ArrayList<String> genertedCookies = new ArrayList<>();
		String cookie = "";
		Headers head = response.getHeaders();
		List<Header> litHead = head.asList();
		for (Header hd : litHead) {
			String cookieName = hd.getName();
			String val = hd.getValue();
			if (cookieName.equals(WSCommonConstants.SET_COOKIE)) {
				genertedCookies.add(val.split(" ")[0]);
			}
		}
		for (int i = 0; i < genertedCookies.size(); i++) {
			cookie = cookie + genertedCookies.get(i);
		}
		return cookie;
	}

	/**
	 * This method is used to create REST request and execute
	 * 
	 * @param excelTestCaseFieldsTO input data o
	 * @param testCaseDetailTO
	 * @param dataFormatter
	 * @param webServiceData
	 */
	@Deprecated
	public static void createExecuteStaticRESTRequest(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO, DataFormatter dataFormatter, restWebServiceData webServiceData) {
		JSONObject formjsonbody;
		Map<String, String> wsparlist2 = WSExcelReader.createTestDataMap(InitializeConstants.test_data_sheet_name,
				dataFormatter, testCaseDetailTO.getTestCaseCommonData().getLocale(), webServiceData.getPathOfTestCase(),
				webServiceData.getDataSetRowNumber());
		formjsonbody = RestWSUtility.convertMapDataInJsonObject(wsparlist2);
		testCaseDetailTO.getReportingLogger().info(WSReportingLoggerConstant.Check_THE_JSON_REQUEST_BODY_CREATED
				+ webServiceData.getDatasetName() + WSCommonConstants.FORWARD_ICON + formjsonbody.toString());
		Response generatedResponse = RestWSUtility.executePOSTRequest(webServiceData.getSessionToken(),
				formjsonbody.toString(), webServiceData.getCookies(), webServiceData.getResourceURL(),
				testCaseDetailTO);
		String[] storeHeaderValues = excelTestCaseFieldsTO.getStoreValuesInVariable()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		testCaseDetailTO.getReportingLogger()
				.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + generatedResponse.asString());
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(storeHeaderValues[0],
					String.valueOf(generatedResponse.getStatusCode()));
			testCaseDetailTO.getVariableHolder().put(storeHeaderValues[1], generatedResponse.asString());
		}
	}

	/**
	 * This method is used to create dynamic REST request and execute
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @param dataFormatter
	 * @param webServiceData
	 */
	@Deprecated
	public static void createExecuteDynamicRESTRequest(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO, DataFormatter dataFormatter, restWebServiceData webServiceData) {
		JSONObject formjsonbody;
		Map<String, String> wsparlist2;
		String[] dynamicParameters = CommonUtility.splitStringUsingPattern(webServiceData.getInputTestData()[2],
				CommonConstant.COMMA_SEPERATOR);
		wsparlist2 = WSExcelReader.createTestDataMap(InitializeConstants.test_data_sheet_name, dataFormatter,
				testCaseDetailTO.getTestCaseCommonData().getLocale(), webServiceData.getPathOfTestCase(),
				webServiceData.getDataSetRowNumber());
		formjsonbody = RestWSUtility.convertMapDataInJsonObject(wsparlist2);
		JSONObject dynamicJson = null;
		for (String part : dynamicParameters) {
			String empdata[] = part.split(":");
			String parkey = empdata[0].trim();
			String parval = empdata[1].trim();
			String dynamicVal = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), parval);
			dynamicJson = createDynamicJsonObject(formjsonbody, parkey, dynamicVal);
		}
		testCaseDetailTO.getReportingLogger().info(WSReportingLoggerConstant.Check_THE_JSON_REQUEST_BODY_CREATED
				+ webServiceData.getDatasetName() + WSCommonConstants.FORWARD_ICON + dynamicJson.toString());
		Response generatedResponse = RestWSUtility.executePOSTRequest(webServiceData.getSessionToken(),
				dynamicJson.toString(), webServiceData.getCookies(), webServiceData.getResourceURL(), testCaseDetailTO);
		testCaseDetailTO.getReportingLogger().info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body
				+ String.valueOf(generatedResponse.getBody().toString()));
		String[] headerout = excelTestCaseFieldsTO.getStoreValuesInVariable()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(headerout[0], String.valueOf(generatedResponse.getStatusCode()));
			testCaseDetailTO.getVariableHolder().put(headerout[1], generatedResponse.asString());
		}
	}

	/**
	 * This method is used to populate JSON object
	 * 
	 * @param obj
	 * @param keyMain
	 * @param newValue
	 * @return JSONObject which will be used for executing request
	 */
	public static JSONObject createDynamicJsonObject(JSONObject obj, String keyMain, String newValue) {
		Iterator<?> iterator = obj.keys();
		String key = null;
		while (iterator.hasNext()) {
			key = (String) iterator.next();
			if ((obj.optJSONArray(key) == null) && (obj.optJSONObject(key) == null)) {
				if ((key.equals(keyMain))) {
					// put new value
					obj.put(key, newValue);
					return obj;
				}
			}
			if (obj.optJSONObject(key) != null) {
				createDynamicJsonObject(obj.getJSONObject(key), keyMain, newValue);
			}
			if (obj.optJSONArray(key) != null) {
				JSONArray jArray = obj.getJSONArray(key);
				for (int i = 0; i < jArray.length(); i++) {
					createDynamicJsonObject(jArray.getJSONObject(i), keyMain, newValue);
				}
			}
		}
		return obj;
	}

	/**
	 * This method is used populate data from Test case excel file to one
	 * restWebServiceData object
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @return restWebServiceData object which contains relevant information from
	 *         test case excel file :
	 *         inputParameters,cookies,sessionToken,resourceURL,PathOfTestCase
	 */
	@Deprecated
	public static restWebServiceData populateRestWSDataTO(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		restWebServiceData data = new restWebServiceData();
		String[] request = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		data.setInputTestData(request);
		data.setDatasetName(
				VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), request[0]));

		String[] inputParameters = request[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		data.setCookies(
				VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputParameters[1]));
		data.setSessionToken(
				VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputParameters[0]));
		data.setResourceURL(
				VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputParameters[2]));
		data.setDataSetRowNumber(ExcelReader.getTestDataRowNumber(data.getDatasetName(),
				testCaseDetailTO.getWorkBookName(), testCaseDetailTO.getDomainName()));
		data.setPathOfTestCase(DomainInitialization.initializeDomainWiseTestCasesPath(testCaseDetailTO.getDomainName())
				+ testCaseDetailTO.getWorkBookName() + CommonConstant.XLSX_FILE_EXTENSION);
		return data;
	}

	/**
	 * This method is used to login via Rest web service
	 * 
	 * @param userName
	 * @param password
	 * @return Response object which contains response data
	 */
	@Deprecated
	public static Response executeLoginRestService(String userName, String password) {
		try {
			return RestAssured.given()
					.config(RestAssured.config()
							.encoderConfig(EncoderConfig.encoderConfig()
									.encodeContentTypeAs(WSCommonConstants.CONTENTTYPE_URLENC, ContentType.URLENC)))
					.contentType(ContentType.URLENC.withCharset(WSCommonConstants.UFT_8))
					.formParam(WSCommonConstants.USER_NAME_KEY, userName)
					.formParam(WSCommonConstants.PASSWORD_KEY, password).when()
					.post(ApplicationContext.baseUrlBO + WSCommonConstants.LoginURL).then().extract().response();
		} catch (Exception exp) {
			throw new CATTException(WSReportingLoggerConstant.LOGIN_REQUEST_FAILED_ERROR_MESSAGE + exp.getMessage());
		}
	}

	public static String getLoginURI(TestCaseDetail testCaseDetailTO, String resouceID) {
		String finalURI = null;
		String resourceName = null;
		String sheetName = testCaseDetailTO.getTestCaseCommonData().getWorkSheetName();
		if (sheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
			finalURI = ApplicationContext.baseUrlBO;
		} else if (sheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
			finalURI = ApplicationContext.baseUrlMO;
		}
		resourceName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), resouceID);
		finalURI = finalURI + resourceName;
		return finalURI;
	}

	public static Response executeRestAPILoginService(String userName, String password, String url) {
		try {
			return RestAssured.given()
					.config(RestAssured.config()
							.encoderConfig(EncoderConfig.encoderConfig()
									.encodeContentTypeAs(WSCommonConstants.CONTENTTYPE_URLENC, ContentType.URLENC)))
					.contentType(ContentType.URLENC.withCharset(WSCommonConstants.UFT_8))
					.formParam(WSCommonConstants.USER_NAME_KEY, userName)
					.formParam(WSCommonConstants.PASSWORD_KEY, password).when().post(url).then().extract().response();
		} catch (Exception exp) {
			throw new CATTException(WSReportingLoggerConstant.LOGIN_REQUEST_FAILED_ERROR_MESSAGE + exp.getMessage());
		}
	}

	public static String getResponseData(ExtractableResponse<?> extractableResponse, String inputparameter) {
		String data = null;
		if (inputparameter.equals(WSReportingLoggerConstant.STATUSCODE_MSG)) {
			int code = extractableResponse.response().getStatusCode();
			data = String.valueOf(code);
		} else if (inputparameter.equals(WSReportingLoggerConstant.RESPONSEBODY_MSG)) {
			data = extractableResponse.asString();
		}
		return data;
	}

	public static String createAPIResponseFolder(String productName, String workbookName, String worksheetName) {
		String apiResponsePath = null;
		String responseFolderPath = DomainInitialization.initializeProductWiseWSResponseFilePath(productName);
		apiResponsePath = responseFolderPath + workbookName + InitializeConstants.fileSeparator + worksheetName
				+ InitializeConstants.fileSeparator;
		FileUtility.createNewDirectory(apiResponsePath);
		return apiResponsePath;
	}

	public static String readJsonFile(Logger reportingLogger, String requestPath, String fileName) {
		JSONParser parser = new JSONParser();
		org.json.simple.JSONObject jsonObject = null;
		FileReader reader = null;
		Object obj = null;
		try {
			reader = new FileReader(requestPath + fileName);
			obj = parser.parse(reader);
			jsonObject = (org.json.simple.JSONObject) obj;
		} catch (ClassCastException e) {
			org.json.simple.JSONArray jsonArray = (org.json.simple.JSONArray) obj;
			return jsonArray.toJSONString();
		} catch (Exception e) {
			reportingLogger.info(WSReportingLoggerConstant.FACING_ISSUE_READING_FILE_MSG + requestPath);
			throw new CATTException(WSReportingLoggerConstant.FILE_READING_ISSUE_MESSAGE + e.getMessage());
		}
		return jsonObject.toJSONString();
	}

	public static void saveRestAPIFiles(String fileName, String fileType, String apiResponsePath, String jsonObject) {
		String requestFilename = fileName.substring(0, fileName.lastIndexOf("."));
		try (FileWriter file = new FileWriter(
				apiResponsePath + requestFilename + fileType + DateDefination.Time + ".json")) {
			file.write(jsonObject.toString());
			file.close();
		} catch (IOException e) {
			logger.error(WSReportingLoggerConstant.JSON_FILE_WRITE_MESSAGE, e);
		}
	}

	public static String updateRestAPIRequest(String apiInputParameters[], String jsonbody,
			TestCaseDetail testCaseDetailTO) {
		if (null != apiInputParameters) {
			final Configuration configuration = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
					.mappingProvider(new JacksonMappingProvider()).build();
			DocumentContext documentContext = com.jayway.jsonpath.JsonPath.using(configuration).parse(jsonbody);
			for (int i = 0; i < apiInputParameters.length; i++) {
				String keypair[] = CommonUtility.splitStringUsingPattern(apiInputParameters[i],
						CommonConstant.COLON_SEPERATOR);
				String value = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
						keypair[1]);
				if (CommonUtility.checkForNumericValue(value)) {
					documentContext.set(keypair[0], Integer.parseInt(value));
				} else {
					documentContext.set(keypair[0], value);
				}
			}
			return documentContext.jsonString();
		} else {
			return jsonbody;
		}
	}
}
