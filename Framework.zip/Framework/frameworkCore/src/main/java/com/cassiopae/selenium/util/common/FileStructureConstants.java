package com.cassiopae.selenium.util.common;

import com.cassiopae.framework.util.constant.InitializeConstants;

public interface FileStructureConstants {

    public static String imageFilename = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.cattProjectName +InitializeConstants.fileSeparator+"lib" + InitializeConstants.fileSeparator
	     + "Untitled.png";
    // *********************************** Driver Variables Details
    // ***************************************//
    public static String localDriverIEBrowser = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator +InitializeConstants.configuration_folder_name +InitializeConstants.fileSeparator+InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
	    + InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator + InitializeConstants.ie_driver_executable_name;
    public static String localDriverForChromeBrowser = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator +InitializeConstants.configuration_folder_name +InitializeConstants.fileSeparator+ InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
	    + InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator + InitializeConstants.chrome_driver_executable_name;
    public static String localDriverForMSEdgeBrowser = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator +InitializeConstants.configuration_folder_name +InitializeConstants.fileSeparator+ InitializeConstants.pre_requisite_softwares + InitializeConstants.fileSeparator
    	    + InitializeConstants.browserDriversFolderName + InitializeConstants.fileSeparator + InitializeConstants.msedge_driver_executable_name;
    public static String autoITExecutalePathForFileDownload = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
    	    + InitializeConstants.pre_requisite_softwares +InitializeConstants.fileSeparator +InitializeConstants.autoITExecutableName;
    public static String closeAutoITInstancesBatFilePath = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
    	    + InitializeConstants.pre_requisite_softwares +InitializeConstants.fileSeparator +InitializeConstants.autoITCloseInstancesFileName;
    public static String autoITExecutalePathForFileUpload = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
    	    + InitializeConstants.pre_requisite_softwares +InitializeConstants.fileSeparator +InitializeConstants.autoIT_File_Upload_ExecutableName;
    public static String closeAutoIT_File_Upload_InstancesBatFilePath = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
    	    + InitializeConstants.pre_requisite_softwares +InitializeConstants.fileSeparator +InitializeConstants.autoIT_File_Upload_CloseInstancesFileName;
    public static String oracleClientFolderPath = InitializeConstants.currentPackageDirectoryPath + InitializeConstants.fileSeparator + InitializeConstants.configuration_folder_name + InitializeConstants.fileSeparator
    	    + InitializeConstants.pre_requisite_softwares +InitializeConstants.fileSeparator +InitializeConstants.OracleClientFolderName;
    
    
}
