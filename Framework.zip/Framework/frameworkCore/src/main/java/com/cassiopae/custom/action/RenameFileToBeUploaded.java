/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;

/**
 * @author gmenkshi
 * @author mshaik --Enhancement
 *
 */
public class RenameFileToBeUploaded implements CustomAction {
	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportlogger = testCaseDetailTO.getReportingLogger();
		reportlogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputTestData = excelTestCaseFieldsTO.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String existedFileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestData[0]);
		reportlogger.info(ReportLoggerConstant.EXISTING_FIlE_NAME + existedFileName);
		String[] reqValues = inputTestData[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String filenameSeperator = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestData[2].trim());
		FileUtility.ValidateFileNameSeprator(filenameSeperator, reportlogger);
		String newFileName = FileUtility.generateFileName(excelTestCaseFieldsTO, testCaseDetailTO, reqValues,
				filenameSeperator);
		newFileName = newFileName.substring(0, newFileName.length() - 1);
		if (newFileName.length() > 150) {
			throw new CATTException(ErrorMessageConstant.FILE_NAME_LENGTH_IS_NOT_VALID);
		}
		String copiedOriginalFileName = FileUtility.setFileExtension(
				existedFileName.split(Pattern.quote(CommonConstant.DOT_OPERATOR))[0] + ReportLoggerConstant.COPIED_MSG,
				FileUtility.getFileExtension(existedFileName));
		String expectedFileName = FileUtility.setFileExtension(newFileName,
				FileUtility.getFileExtension(existedFileName));
		String fileUploadPath = DomainInitialization
				.initializeDomainWiseUploadFilePath(testCaseDetailTO.getDomainName());
		// Copy original file at same location
		String OriginalFile = fileUploadPath + existedFileName;
		String copyofOriginalFile = fileUploadPath + copiedOriginalFileName;
		String expectedFilePath = fileUploadPath + expectedFileName;
		FileUtility.copyFileFromSourceToDestination(OriginalFile.toString(), copyofOriginalFile.toString(),
				reportlogger);
		CommonFunctions.explicitWait(5000);
		// Rename copied file
		FileUtility.renameFile(copyofOriginalFile, expectedFilePath, fileUploadPath, reportlogger,
				ReportLoggerConstant.RENAME_FILE_SUCESS_MSG);
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), expectedFileName);
		}
	}

}
