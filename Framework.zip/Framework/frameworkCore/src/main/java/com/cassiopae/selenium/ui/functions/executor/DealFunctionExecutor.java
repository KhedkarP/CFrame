/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.functions.DealFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class DealFunctionExecutor implements FunctionExecutor {

	@Override
	public void executeFunction(String methodName, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {

		String[] inputData = CommonUtility.getInputData(excelTestCaseFields, testCaseDetail);

		if (FunctionConstant.NAVIGATE_TO.equals(methodName)) {
			DealFunctions.navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		} else if (FunctionConstant.OPEN.equals(methodName)) {
			DealFunctions.open(inputData[0],excelTestCaseFields, testCaseDetail);
		} else if(FunctionConstant.CHECK_DEAL_IS_SAVED_SUCCESSFULY.equals(methodName)) {
			DealFunctions.checkDealIsSaved(excelTestCaseFields, testCaseDetail);
		}

	}

}
