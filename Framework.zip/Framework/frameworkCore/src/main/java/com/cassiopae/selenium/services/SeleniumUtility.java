package com.cassiopae.selenium.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;
import java.util.regex.Pattern;

import com.cassiopae.selenium.services.listener.CustomeHtmlLayout;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.*;
import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.ConsoleAppender;
import org.apache.logging.log4j.core.appender.FileAppender;
import org.apache.logging.log4j.core.config.AppenderRef;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.Configurator;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.apache.logging.log4j.core.config.builder.api.*;
import org.apache.logging.log4j.core.config.builder.impl.BuiltConfiguration;
import org.apache.logging.log4j.core.layout.HtmlLayout;
import org.apache.logging.log4j.core.layout.PatternLayout;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.listener.WebDriverListener;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.neotys.selenium.proxies.NLWebDriver;

public class SeleniumUtility {
	// ********************* Event Listener Methods ***********************//

	// ************************************* Page Loading Handling
	// Method**************************************//
	private static Logger logger = LogManager.getLogger(SeleniumUtility.class);

	public static void invisibilityOfLoadingIcon(final WebDriver webDriver, final Logger reportingLogger) {
		for (int i = 0; i <= 1; i++) {
			try {
				webDriver.switchTo().defaultContent();
				WebDriverListener.checkPleaseWaitLoadingStability(webDriver);
				WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(InitializeConstants.please_wait_icon_loading_time));
				/*
				 * Wait<WebDriver> wait = new FluentWait(webDriver)
				 * .withTimeout(InitializeConstants.please_wait_icon_loading_time,
				 * TimeUnit.SECONDS) .pollingEvery(100, TimeUnit.MILLISECONDS);
				 */
				wait.until(ExpectedConditions
						.invisibilityOfElementLocated((By.xpath(CommonConstant.PLEASE_WAIT_LOADING_GLASS_PANE_XPATH))));
				// wait.until(ExpectedConditions.invisibilityOfElementLocated((By.xpath(CommonConstant.PLEASE_WAIT_INVISIBILITY_WITH_STYLE_XPATH))));

				break;
			} catch (UnhandledAlertException uae) {
				unexpectAlert(webDriver, reportingLogger);
			} catch (TimeoutException toe) {
				break;
			} catch (NoSuchWindowException ele) {
				logger.info("Child Window is not available to perform operation");
				logger.info(ele.getMessage());
			} catch (Exception e) {
				reportingLogger.info(e.getMessage(), e);
			}
		}
	}

	/**
	 * This method is used to get 'style' attribute value of given Xpath
	 *
	 * @param webDriver
	 * @return
	 */
	public static String getAttributeValue(final WebDriver webDriver, String xpath, String attributeName) {
		String styleValue;
		try {
			styleValue = webDriver.findElement(By.xpath(xpath)).getAttribute(attributeName);
		} catch (Exception e) {
			styleValue = null;
		}
		return styleValue;
	}

	/**
	 * An expectation for checking that an element is either invisible or not
	 * present on the DOM.
	 *
	 * @param locator used to find the element
	 * @return true if the element is not displayed or the element doesn't exist or
	 *         stale element
	 */
	public static ExpectedCondition<Boolean> invisibilityOfElementLocatedby(final By locator) {
		return new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				try {
					boolean flag = (driver.findElement(locator).isDisplayed());
					System.out.println(flag);
					return flag;
				} catch (NoSuchElementException e) {
					System.out.println("nosuch element");
					// Returns true because the element is not present in DOM. The
					// try block checks if the element is present but is invisible.
					return true;
				} catch (StaleElementReferenceException e) {
					System.out.println(" StaleElementReferenceException");
					// Returns true because stale element reference implies that element
					// is no longer visible.
					return true;
				}
			}

			@Override
			public String toString() {
				return "element to no longer be visible: " + locator;
			}
		};
	}

	/**
	 * This method is used to synchronize web page with selenium for POS App
	 *
	 * @param webDriver
	 * @param logger
	 */
	public static void waitTillPageLoadingForPOS(final By by, final WebDriver webDriver, final Logger reportingLogger) {
		try {
			webDriver.switchTo().defaultContent();
			new WebDriverWait(webDriver, InitializeConstants.please_wait_icon_loading_time).until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'pace-activity')]")));
			new WebDriverWait(webDriver, InitializeConstants.please_wait_icon_loading_time).until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'redux-toastr top-center')]")));
			new WebDriverWait(webDriver, InitializeConstants.please_wait_icon_loading_time).until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//i[@class='fa fa-circle-o-notch fa-spin fa-2x fa-fw']")));
			new WebDriverWait(webDriver, InitializeConstants.please_wait_icon_loading_time).until(
					ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[@class='Select-loading-zone']")));

		} catch (TimeoutException e) {
			logger.info(e.getMessage());
			reportingLogger.error("Page is not loaded fully in given time : "
					+ InitializeConstants.please_wait_icon_loading_time + " seconds");
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
	}

	// ************************************* Application Alerts Handling
	// Method**************************************//
	public static String checkAlert(final WebDriver driver, final Logger reportingLogger, final String actionType) {
		String alertMessage = null;
		int maxAlertTime = InitializeConstants.maximumWaitTimeForExpectedAlertInSeconds;
		try {
			new WebDriverWait(driver, maxAlertTime).until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alertMessage = alert.getText();
			if (CommonConstant.CHECK_ALERT_ACCEPT.equals(actionType)) {
				alert.accept();
			} else if (CommonConstant.CHECK_ALERT_DISMISS.equals(actionType)) {
				alert.dismiss();
			}

			driver.switchTo().defaultContent();
			reportingLogger.info("Alert pop-up text : - " + alertMessage);
			WebDriverListener.checkPleaseWaitLoadingStability(driver);
		} catch (TimeoutException toe) {
			reportingLogger.error(" **** Alert pop-up not displayed in " + maxAlertTime + " seconds ****");
		} catch (Exception exception) {
			reportingLogger.info(" Alert Text Message : -" + alertMessage);
			logger.error(exception.getMessage(), exception);
			throw new CATTException(exception.getMessage());
		}
		return alertMessage;
	}

	public static void unexpectAlert(final WebDriver webDriver, final Logger reportingLogger) {
		boolean flag = false;
		try {
			new WebDriverWait(webDriver, 10).until(ExpectedConditions.alertIsPresent());
			flag = true;
		} catch (TimeoutException te) {
			logger.info(te.getMessage());
		}
		if (flag) {
			try {
				Alert unhandledAlert = webDriver.switchTo().alert();
				String unhandledAlertText = unhandledAlert.getText();
				reportingLogger.info("Alert pop-up message : " + unhandledAlertText);
				if (checkStringValuePresentInSet(ApplicationConstant.alertIssueKeyword, unhandledAlertText)) {
					throw new CATTException(unhandledAlertText);
				} else if (checkStringValuePresentInSet(ApplicationConstant.appAlertAcceptKeyword, unhandledAlertText)) {
					unhandledAlert.accept();
					reportingLogger.info("Alert Accepted");
				}
			} catch (Exception exception) {
				logger.error(exception.getMessage(), exception);
				throw new CATTException(exception.getMessage());
			}
		}
	}

	private static boolean checkStringValuePresentInSet(Set<String> set, String alertText) {
		for (String val : set) {
			if (alertText.contains(val)) {
				return true;
			}
		}
		return false;
	}

	// ************************************* Browser Driver Definition
	// ********************************************//

	public static void ieBrowserSettings(final String downloadPath, String workBookName) {
		logger.info(ReportLoggerConstant.IE_REGISTRY_SETTING_STARTED_MESSAGE);
		try {
			if (workBookName.contains(FrameworkConstant.POS)) {
				String cmd1 = "REG ADD \"HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Internet Explorer\\Zoom\" /v \"ZoomFactor\" /t REG_DWORD /d 100000 /f";
				Process t1 = Runtime.getRuntime().exec(cmd1);
				t1.waitFor();
			} else {
				String cmd2 = "REG ADD \"HKEY_CURRENT_USER\\SOFTWARE\\Microsoft\\Internet Explorer\\Zoom\" /v \"ZoomFactor\" /t REG_DWORD /d 75000 /f";
				Process t2 = Runtime.getRuntime().exec(cmd2);
				t2.waitFor();
			}
			String cmd3 = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\New Windows\\Allow\" /v \""
					+ ApplicationContext.IP_ADDRESS_BO + "\" /t REG_BINARY /d 0000 /f";
			String cmd4 = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\1\" /v 2500 /t REG_DWORD /d 0 /f";

			String cmd5 = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\2\" /v 2500 /t REG_DWORD /d 0 /f";

			String cmd6 = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\3\" /v 2500 /t REG_DWORD /d 0 /f";

			String cmd7 = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\4\" /v 2500 /t REG_DWORD /d 0 /f";

			String cmd8 = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Main\" /F /V \"Default Download Directory\" /T REG_SZ /D "
					+ downloadPath;
			String cmd9 = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\New Windows\\Allow\" /v \""
					+ ApplicationContext.IP_ADDRESS_MO + "\" /t REG_BINARY /d 0000 /f";
			Process t3 = Runtime.getRuntime().exec(cmd3);
			t3.waitFor();
			Process t4 = Runtime.getRuntime().exec(cmd4);
			t4.waitFor();
			Process t5 = Runtime.getRuntime().exec(cmd5);
			t5.waitFor();
			Process t6 = Runtime.getRuntime().exec(cmd6);
			t6.waitFor();
			Process t7 = Runtime.getRuntime().exec(cmd7);
			t7.waitFor();
			Process t8 = Runtime.getRuntime().exec(cmd8);
			t8.waitFor();
			Process t9 = Runtime.getRuntime().exec(cmd9);
			t9.waitFor();
			logger.info(ReportLoggerConstant.SETTING_IE_REGISTRY_SETTING_SUCCESS_MESSAGE);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new CATTException(exception.getMessage());
		}
	}

	public static WebDriver switchToWindow(final String screenTitle, TestCaseDetail testCaseDetail) {
		CommonFunctions.explicitWait(15000);
		boolean flag = false;
		EventFiringWebDriver webDriverInstance = null;
		WebDriver testDriver = testCaseDetail.getDriver();
		if (testCaseDetail.getDriver() instanceof NLWebDriver) {
			Set<String> windowIterator = testCaseDetail.getDriver().getWindowHandles();
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + windowIterator.size());
			for (String s : windowIterator) {
				String windowHandle = s;
				testDriver = testCaseDetail.getDriver().switchTo().window(windowHandle);
				if (testDriver.getTitle().equals(screenTitle)) {
					webDriverInstance = new EventFiringWebDriver(testDriver);
					WebDriverEventListener eventListener = new WebDriverListener();
					webDriverInstance.register(eventListener);
					setWindowSize(testCaseDetail, webDriverInstance);
					testCaseDetail.getReportingLogger()
							.info("Switched on " + testDriver.getTitle() + " windows successfully");
					return webDriverInstance;
				}
			}
			return testCaseDetail.getDriver();
		} else {
			Set<String> windowIterator = testCaseDetail.getDriver().getWindowHandles();
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + windowIterator.size());
			for (String windowHandle : windowIterator) {
				WebDriver newDriver = testCaseDetail.getDriver().switchTo().window(windowHandle);
				testCaseDetail.getDriver().findElement(By.xpath("//html"));
				newDriver.manage().window().maximize();
				testCaseDetail.getReportingLogger().info("window title  is : " + newDriver.getTitle());
				if (newDriver.getTitle().equals(screenTitle)) {
					webDriverInstance = new EventFiringWebDriver(newDriver);
					WebDriverEventListener eventListener = new WebDriverListener();
					webDriverInstance.register(eventListener);
					setWindowSize(testCaseDetail, webDriverInstance);
					testCaseDetail.getReportingLogger().info("Switched on " + screenTitle + " window successfully");
					testCaseDetail.getDriver().findElement(By.xpath("//html"));
					flag = true;
					break;
				} else {
					webDriverInstance = (EventFiringWebDriver) testCaseDetail.getDriver();
				}
			}
		}
		if (!flag) {
			testCaseDetail.getReportingLogger().error(
					"No window present having title as : " + screenTitle + " , hence unable to switch to new window");
			Assert.fail(
					"No window present having title as : " + screenTitle + " , hence unable to switch to new window");
		}
		return webDriverInstance;
	}

	/**
	 * @param testCaseDetail
	 * @param webDriverInstance
	 */
	private static void setWindowSize(TestCaseDetail testCaseDetail, EventFiringWebDriver webDriverInstance) {
		if ((ApplicationContext.headlessModeOfExecution && CommonConstant.CHROME_BROWSER
				.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName())) ||(ApplicationContext.headlessModeOfExecution && CommonConstant.MS_EDGE_BROWSER
				.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName()))) {
			webDriverInstance.manage().window().maximize();
			webDriverInstance.manage().window().setSize(new Dimension(1382, 744));
		}
	}

	public static String checkFileIsAvailableORNot(String downlodedPath, Logger reportinglogger,
												   String File_name) {

		File file = new File(downlodedPath);
		File[] filesList = file.listFiles();
		String filestatus = CommonConstant.FALSE_VALUE;
		reportinglogger.info(ReportLoggerConstant.TOTAL_FILES_LOCATION + downlodedPath + ReportLoggerConstant.ARE_MSG
				+ filesList.length);
		for (int i = 0; i < filesList.length; i++) {
			reportinglogger.info((i + 1) + ReportLoggerConstant.FULL_STOP + filesList[i].getName());
			if (filesList[i].getName().equals(File_name)) {
				reportinglogger.info(ReportLoggerConstant.FILE_NAME_MSG + filesList[i].getName());
				filestatus = CommonConstant.TRUE_VALUE;
				break;
			}
		}
		if (filestatus.equals(CommonConstant.FALSE_VALUE)) {
			reportinglogger.info(ReportLoggerConstant.EXPECTED_FILE_MSG + File_name
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
		}
		return filestatus;
	}


	public static String checkFileIsAvailableAtLocationOrNOT(String downlodedPath, Logger reportinglogger,
															 String File_name) {

		File file = new File(downlodedPath);
		File[] filesList = file.listFiles();
		String filestatus = CommonConstant.FALSE_VALUE;
		logger.info(ReportLoggerConstant.TOTAL_FILES_LOCATION + downlodedPath + ReportLoggerConstant.ARE_MSG
				+ filesList.length);
		for (int i = 0; i < filesList.length; i++) {
			logger.info((i + 1) + ReportLoggerConstant.FULL_STOP + filesList[i].getName());
			if (filesList[i].getName().equals(File_name)) {
				logger.info(ReportLoggerConstant.FILE_NAME_MSG + filesList[i].getName());
				filestatus = CommonConstant.TRUE_VALUE;
				break;
			}
		}
		if (filestatus.equals(CommonConstant.FALSE_VALUE)) {
			logger.info(ReportLoggerConstant.EXPECTED_FILE_MSG + File_name
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
		}
		return filestatus;
	}




	public static WebDriver switchToWindowByFlowid(final String screenFlowid, TestCaseDetail testCaseDetail) {
		CommonFunctions.explicitWait(15000);
		boolean flag = false;
		EventFiringWebDriver webDriverInstance = null;
		WebDriver testDriver = null;
		if (testCaseDetail.getDriver() instanceof WebDriver) {
			Set<String> windowIterator = testCaseDetail.getDriver().getWindowHandles();
			testCaseDetail.getReportingLogger()
					.info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + windowIterator.size());
			for (String s : windowIterator) {
				String windowHandle = s;
				testDriver = testCaseDetail.getDriver().switchTo().window(windowHandle);
				testDriver.manage().window().maximize();
				String appURL = testDriver.getCurrentUrl();
				String flowidExecutionkey = appURL.split(Pattern.quote(CommonConstant.FLOW_VALUE))[1];
				String flowIdValue = flowidExecutionkey.split(Pattern.quote(CommonConstant.FLOW_KEY))[0];
				if (flowIdValue.equals(screenFlowid)) {
					webDriverInstance = new EventFiringWebDriver(testDriver);
					WebDriverEventListener eventListener = new WebDriverListener();
					webDriverInstance.register(eventListener);
					setWindowSize(testCaseDetail, webDriverInstance);
					webDriverInstance.findElement(By.xpath(FunctionLocatorConstant.WINDOW_LOCATOR));
					testCaseDetail.getReportingLogger().info(
							ReportLoggerConstant.SWITCH_TO + flowIdValue + ReportLoggerConstant.WINDOW_SUCESSFULLY);
					flag = true;
					break;
				}
			}
		}
		if (!flag) {
			testCaseDetail.getReportingLogger().error(ReportLoggerConstant.NO_WINDOW_PRESENT_USING_FLOWID + screenFlowid
					+ ReportLoggerConstant.UNABLETO_SWITCH);
			Assert.fail(ReportLoggerConstant.NO_WINDOW_PRESENT_USING_FLOWID + screenFlowid
					+ ReportLoggerConstant.UNABLETO_SWITCH);
		}
		return webDriverInstance;
	}

	public static WebDriver switchToWindowAndClose(String childwinodfid,String pwindowfid, TestCaseDetail testCaseDetail) {
		CommonFunctions.explicitWait(15000);
		boolean flag = false;
		EventFiringWebDriver webDriverInstance = null;

		WebDriver testDriver = null;
		if (testCaseDetail.getDriver() instanceof WebDriver) {
			Set<String> windowIterator = testCaseDetail.getDriver().getWindowHandles();
			testCaseDetail.getReportingLogger()
					.info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + windowIterator.size());
			String parentID = null;
			for (String s : windowIterator) {
				String windowHandle = s;
				testDriver = testCaseDetail.getDriver().switchTo().window(windowHandle);
				testDriver.manage().window().maximize();
				String appURL = testDriver.getCurrentUrl();
				String flowidExecutionkey = appURL.split(Pattern.quote(CommonConstant.FLOW_VALUE))[1];
				String flowIdValue = flowidExecutionkey.split(Pattern.quote(CommonConstant.FLOW_KEY))[0];
				if (flowIdValue.equals(pwindowfid)) {
					parentID = s;
					break;
				}
			}
			for (String s : windowIterator) {
				String windowHandle = s;
				testDriver = testCaseDetail.getDriver().switchTo().window(windowHandle);
				testDriver.manage().window().maximize();
				String appURL = testDriver.getCurrentUrl();
				String flowidExecutionkey = appURL.split(Pattern.quote(CommonConstant.FLOW_VALUE))[1];
				String flowIdValue = flowidExecutionkey.split(Pattern.quote(CommonConstant.FLOW_KEY))[0];
				if (flowIdValue.equals(childwinodfid)) {
					testDriver.close();
					testDriver = testCaseDetail.getDriver().switchTo().window(parentID);
					webDriverInstance = new EventFiringWebDriver(testDriver);
					WebDriverEventListener eventListener = new WebDriverListener();
					webDriverInstance.register(eventListener);
					webDriverInstance.findElement(By.xpath(FunctionLocatorConstant.WINDOW_LOCATOR));
					testCaseDetail.getReportingLogger().info(
							ReportLoggerConstant.SWITCH_TO + childwinodfid + ReportLoggerConstant.WINDOW_SUCESSFULLY);
					flag = true;
					break;
				}
			}
		}
		if (!flag) {
			testCaseDetail.getReportingLogger().error(ReportLoggerConstant.NO_WINDOW_PRESENT_USING_FLOWID + childwinodfid
					+ ReportLoggerConstant.UNABLETO_SWITCH);
			Assert.fail(ReportLoggerConstant.NO_WINDOW_PRESENT_USING_FLOWID + childwinodfid
					+ ReportLoggerConstant.UNABLETO_SWITCH);
		}
		return webDriverInstance;
	}

	// ******************************
	// TakeScreenshot/Logger_file/Exception/Video_Creation/Delete_Existing_Screenshot_Folder
	// definitions ***************//
	public static void takeScreenshotAugmenter(final WebDriver driver, final String domainName,
											   final String workBookName, final String workSheetName, final Logger reportingLogger) {
		if (ApplicationContext.executionScreenShots.equalsIgnoreCase(CommonConstant.YES)) {
			File screenShot = null;
			try {
				if (driver instanceof NLWebDriver) {
					// screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				} else {
					screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				}
			} catch (Exception exception) {
				unexpectAlert(driver, reportingLogger);
				logger.error(exception.getMessage(), exception);
				throw new CATTException(exception.getMessage());
			}
			try {
				if (screenShot != null) {
					FileUtils.copyFile(screenShot,
							new File(CommonUtility.getScreenShotFilePath(domainName, workBookName, workSheetName)));
				}
			} catch (Exception exception) {
				logger.error(exception.getMessage(), exception);
				throw new CATTFileOperationException(exception.getMessage());
			}
		}
	}

	public static Logger loggerFile(final String workSheetName, final String workBookName,
									final String issueReproduceStepsLogs, final String domainName) {
		Logger reportingLogger = LogManager.getLogger(workSheetName);
		try {
			File file = new File(CommonUtility.getTempFolderPathForLogger(domainName));
			if (!file.exists()) {
				file.mkdir();
			} else {
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTFileOperationException(exception.getMessage());
		}
		String propertyFile = CommonUtility.getPropertiesFilePath(workSheetName, domainName);
		try {
			File file = new File(propertyFile);
			if (!file.exists()) {
				file.createNewFile();
			} else {
				file.delete();
				file.createNewFile();
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTFileOperationException(exception.getMessage());
		}
		try {
			final LoggerContext ctx = (LoggerContext) LogManager.getContext(false);
			final Configuration config = ctx.getConfiguration();
			Layout layout = CustomeHtmlLayout.createLayout(false,workSheetName,null,null,null,null);
			Appender appender = FileAppender.createAppender(issueReproduceStepsLogs, "false", "false", "File", "true",
					"false", "false", "4000", layout, null, "false", null, config);
			appender.start();
			ctx.getLogger(workSheetName).addAppender(appender);
			ctx.updateLoggers();
			reportingLogger=ctx.getLogger(workSheetName);
			FileUtility.deleteExistingScreenshotFolder(
					CommonUtility.getScrenshotFolderPath(domainName, workBookName, workSheetName));

		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
			throw new CATTFileOperationException(exception.getMessage());
		}
		return reportingLogger;
	}

	public static void downloadPaymentSchedule(String exepath, String batFile, Logger reportingLogger) {
		executeExeFile(exepath, reportingLogger);
		executeExeFile(batFile, reportingLogger);
	}

	public static void executeExeFile(String exefilePath, Logger reportingLogger, String... sarameters) {

		if (sarameters.length == 0) {
			CommonFunctions.explicitWait(5000);
			try {
				Process proc = Runtime.getRuntime().exec(exefilePath);
				proc.waitFor();
				CommonFunctions.explicitWait(15000);
				reportingLogger.info(ReportLoggerConstant.AUTO_IT_EXECUTED_SUCESSFULLY);
			} catch (IOException | InterruptedException e) {
				reportingLogger.info(ReportLoggerConstant.ERROR_OCCURED_WHILE_EXE_FILE_EXECUTION, e);
				logger.error(e);
			}
		} else {
			CommonFunctions.explicitWait(5000);
			try {
				String[] filePath = sarameters;
				Process proc = Runtime.getRuntime().exec(exefilePath + " " + filePath[0]);
				proc.waitFor();
				CommonFunctions.explicitWait(15000);
				reportingLogger.info(ReportLoggerConstant.AUTO_IT_EXECUTED_SUCESSFULLY);
			} catch (IOException | InterruptedException e) {
				reportingLogger.info(ReportLoggerConstant.ERROR_OCCURED_WHILE_EXE_FILE_EXECUTION, e);
				logger.error(e);
			}

		}

	}
}
