package com.cassiopae.framework.xl.reader;

import java.util.HashMap;
import java.util.Map;


public class GenericRow {

	private Map<Integer, String> map = new HashMap<>();

	public void setCellValue( final Integer ColNo, final String value ) {
		map.put( ColNo, value );
	}

	public String getCellValue( final Integer ColNo ) {
		return map.get( ColNo );

	}
}
