package com.cassiopae.selenium.ui.actions.constant;

public interface ReportLoggerConstant {

	// DAO Consistent
	public String PROCEDURE_POST_EXECUTION = "Procedure executed successfully ";
	public String PROCEDURE_START_EXECUTION = "Started executing the SQL's : ";
	public String PROCEDURE_START_EXECUTION_DB_SERVER = "Started executing the SQL's by connecting to DB server for : ";
	public String CONNECTION_SUCESS_MESSAGE = "Database Connection is done";
	public String PROCEDURE_PARAM_VALUE_IS = ". Parameter value is  : ";
	public String QUERY_PARAM_VALUE_IS = ". Parameter value is  : ";
	public String TOTAL_VALUE_IN_DROPDOWN = "Total values in drop-down are: ";
	public String ERROR_IN_PROCEDURE_EXECUTION = "Error occurred while executing SQL";
	public String TOAST_MESSAGE_POP_UP = "Alert pop-up message is: ";
	public String NOT_TOST_AVAILABLE = "No toast pop-up present on UI";

	// get drop-down value constants
	String DROP_VALUE_COUNT = " Number of Values available for given drop down is : ";

	// Compare date constants
	public final String LENGTH = "Length :";
	public final String EQUALSTO = "ET";
	public final String LESSTHANTO = "LT";
	public final String GRATERTHANTO = "GT";
	public final String IN_BETWEEN = "IN_BETWEEN";
	public final String ASC_ORDER = "ASC";
	public final String DESC_ORDER = "DESC";

	public final String DATES_VALIDATION_ERROR = "Please check input Date parameters As value should not contains any special charaters or Empty";
	public final String PLEASE_CHECK = "Please check Date  ";
	public final String VALUE_LOGGER_MESSGAE = " value >> ";

	// Date compare
	public final String BOTH_DATES_ARE_EQUAL = " both dates are equal";
	public final String AND_MSG = " And ";
	public final String BOTH_DATES_ARE_NOT_EQUAL = "Date1 and Date2 are not equal";
	public final String DATE1_BEFORE_DATE2 = " is less than ";
	public final String DATE1_NOT_BEFORE_DATE2 = "Date1 is not less than Date2";
	public final String DATE1_AFTER_DATE2 = " is greater than ";
	public final String INPUT_DATE1_MSG = "Input Date 1  ";
	public final String INPUT_DATE_MSG = "Date ";
	public final String INPUT_DATE2_MSG = "Input Date 2  ";
	public final String INPUT_DATE3_MSG = "Input Date 3  ";
	public final String DB_DATE_FORMAT = "dd-MMM-yyyy";
	public final String CONVERTING_MSG = " Converting ";
	public final String TO_MSG = "' to '";
	public final String FORMAT_MSG = "' format";
	public final String TO_APPLICATION_DATE_FORMAT = " to Application date format  : ";

	public final String INPUT_PARAMETERS_VALIDATED_MSG = "Input Parameters validated successfully";
	public final String PLEASE_CHECK_INPUTDATES_MSG = " Please check input Date format";
	public final String DATE1_NOT_AFTER_DATE2 = "Date1 is not greater than Date2";
	public final String DATE3_IN_BETWEEN_DATE1_AND_DATE2 = "  : is In Between :";
	public final String DATE3_NOT_IN_BETWEEN_DATE1_AND_DATE2 = " is Not In between ";
	public final String CHECK_DATES_OPERATION_IN_ACTION = "Please check operation mention in compare date action";
	public final String OPERATION = " Operation is: ";
	public String CLASS = "class";
	// event panel function constant
	String VERIFY_EVENT_PRESENT = "Verify Event is present or not";
	String ClICK_MORE_MESSAGE = "Click on More Icon >> ";
	String CLICK_DROPDOWN_MESSAGE = "Click on dropdown icon ";
	String EVENT_IS_NOT_PRESENT = "Event is not visible on UI";

	// Action constant
	public String UNABLE_TO_LOCATE_ELEMENT_MESSAGE = "Unable to locate web element [Field] on UI by using property[Xpath] - ";
	public String CHECKBOX_ALREADY_CHECKED = "Checkbox is already cheked";
	public String CHECKBOX_SELECTED_SUCESSFULLY = "Checkbox is selected successfully";
	public String ELEMENT_NOT_VISIBLE_MESSAGE = " Element was not Visible on Application -Please Refer logs for more derails ";

	public String ELEMENT_NOT_ENABLED_MESSAGE = " Element/Field/Button is not enabled to perform click operation ";
	public String ELEMENT_NOT_CLICKABLE = "Element is not enabled to perform click operation - Please see logs for more detail";
	public String CHECKBOX_UN_CHECKED = "Checkbox is unchecked";
	public String CHECKBOX_ALREADY_UN_CHECKED = "Checkbox is already unchecked";
	public String AS = " as : ";
	public String ELEMENT_NOT_AVAILABLE_MESSAGE = "Element is not available on UI";
	public String TESTDATA_VALUE_NULL = "Test Data value is empty for input field, please check the test case/input data";
	public String TESTSTEP_FAIL_DUE_TO_TEST_DATA_NULL = " Test Step Fail due to Test Data value passed as Null ";
	public String UNABLE_TO_LOCATE_ELEMENT_DETAILS = "Unable to locate element [Field] on UI - Please see scenario logs for more details";
	public String CHECK_PROPERTY_ERROR_MESSAGE = " - Please check the property of the web element [HTML tag]/[Xpath]";

	public String TESTDATA_WHITE_SPACE_ISSUE = " Please check the TESTDATA for this field [Case-sensitive] / White spaces - ";
	public String TEST_DATA_VALUE_AS = "Test Data value as  : ";
	public String ASSERTION_FAILED_VALUE = "Assertion failed - Actual value : ";
	public String DROP_DOWN_VALUE_VERIFIED = "Drop-down value verified successfully";
	public String EXPECTED_MESSAGE = ",  but Expected as : ";
	public String TITLE = "title";
	public String VALIDATION_SUCESS_MESSAGE = "Validation successfully passed";
	public String TOTAL_NUMBER_OF_ELEMENTS = " Total Number of Elements ";
	public String ACTUAL_VALUE_MESSAGE = ", Actual value is - ";
	String EXPECTED_VALUE_MESSAGE = " and Expected value is - ";
	public String ASSERTION_FAILED_MESSAGE = "Assertion Failed due to >> ";
	public String MISSMATCH_ERROR_MESSAGE = " Missmatch occurs between Actual value : ";
	public String EQUALS_SYMBOL = " = ";
	public String VALUE = "value";
	public String INNER_TEXT = "innerText";
	public String SRC = "src";
	public String NAME = "name";
	public String OPTION = "/option";
	public String COUNT_OF_VALUES = " Count of Values ";
	public String UNABLE_TO_GET_SIZE_OF_ELEMENT = "Unable to get size of Elements";
	public String TOTAL_NUMBER_OF_ROWS = " Total Number of Rows are ";
	public String ROWCOUNT = "_rowcount";
	public String POS_ROWCOUNT = "data-rows";
	public String GET_VALUE_OF = " Get Value of ";
	public String UNABLE_TO_SELECT_VALUE_FROM_DROP_DOWN = " Unable to get value from select DropDown Field  ";
	public String UNABLE_TO_GET_VALUE_FROM_INPUT = " Unable to get value from Input Field ";
	public String COLON_SYMBOL = " : ";
	public String RECEIVED_VALUE = "Retrieved value is : ";
	public String DROP_DOWN_FIELD_DISABLED_MESSAGE = "Drop-down field is not visible/disabled to perform operation";
	public String INCORRECT_PROPERTY_MESSAGE = "Incorrect property of the web element - Unable to perform operation, Please check object repository";
	String AVILABLE_DROP_DOWN_VALUE = "Available drop-down value is : ";
	public String DROP_DOWN_VALUE_NOT_IN_ASCENDING = " dropdown values are not in ascending order ";
	public String DROPDOWN_VALUE_ASCENDING_ORDER = " Ascending order ";
	public String DROPDOWN_VALUE_DESCENDING_ORDER = " Descending order ";
	public String SORTED_ERROR_MESSAGE = "Please provide the correct test data ";
	public String ELEMENT_NOT_ASORTED_MESSAGE = "Element is neither in Ascending or in Descending order";
	public String ASCENDING_SORTED_VALUES = "The dropddown values are in";
	public String DESCENDNG_SORTED_VALUES = "The dropddown values are in";
	public String EXCEPTION = "Exception : >> ";
	public String CANNOT_LOCATE_ELEMENT_WITH_TEXT = "Cannot locate option with text:";
	public String DROP_DOWN_VALUE_NOT_PRESENT = " is not present in combobox ";
	public String DROP_DOWN_VALUE_NO = " - drop down value is not present in combobox ";
	public String ELEMENT_INFO = "Element info:";
	public String CHECK_ELEMENT_PROPERTY_WEB_ELEMENT = " - Please check the property of the web element [HTML tag]/[Xpath]";
	public String EXCEPTION_OCCURS_WHILE_SELECTING = "------ Exception occurs while selecting value using Index -----------";
	public String EXCEPTION_WHILE_TAKING_SCREENSHOT = "Exception while taking  screenshot";
	public String HREF = "href";

	public String FORWARD_ICON_MESSAGE = "Tab is not visible on UI, click on forwardIcon >> icon to expand tabs";
	public String BACKWARD_ICON_MESSAGE = "Tab is not visible on UI, click on backwardIcon << icon to expand tabs";
	public String FORWARD_LOCATOR_KEY = "Div.ForwardIcon";
	public String BACKWARD_LOCATOR_KEY = "Div.BackwardIcon";
	public String TAB_NOT_PRESENT_MESG = "Tab is not present on ui for this module";

	public String VIDEO_LOCATION_MSG = "Video location for test case : -";
	public String VIDEO_LOCATION_MSG_API_TEST_CASE = "Video is not created where API mentioned in Sheet Name";
	public String EXECUTION_TIME_MSG = "Execution time in mins ";
	public String FILE_NOT_OPEN = "Could not open file.";
	public String RETRIEVED_MSG = "Retrieved value is : ";
	public String OCCURENCE_MSG = "Total number of occurences are  ";
	public String NO_SUPPORT_FOR_IE = "Linux OS is not supported for IE browser";

	public String UNEXPECTED_CELL_TYPE = "Unexpected cell type: ";
	public String WORKBOOK_MATCH_MESSAGE = "%s\nworkbook1 -> %s [%d] != workbook2 -> %s [%d]";
	public String COLUMN_DOESNOT_MATCH = "Number Of Columns does not Match ::";
	public String WORKBOOK_MATCH_MESSAGE_2 = "%s\nworkbook1 -> %s -> %s [%s] != workbook2 -> %s -> %s [%s]";
	public String CELL_ALIGNMENT_DOESNOT_MATCH = "Cell Alignment does not Match ::";
	public String CELL_BORDER_ATTRIBUTES_DOESNOT_MATCH = "Cell Border Attributes does not Match ::";
	public String NOT = "NOT ";
	public String EMPTY_STRING = "";
	public String BORDER = " BORDER";
	public String JAVA_COMPILE_MESSAGE = "java -cp <classpath> ";
	public String WORK_BOOK_EXCEL = " <workbook1.xls/x> <workbook2.xls/x";
	public String CELL_DATA_DOESNOT_MATCH = "Cell Data does not Match ::";
	public String CELL_FILL_COLOR_DOESNOT_MATCH = "Cell Fill Color does not Match ::";
	public String CELL_FILL_PATTERN_DOESNOT_MATCH = "Cell Fill pattern does not Match ::";
	public String CELL_FONT_FAMILY_DOESNOT_MATCH = "Cell Font Family does not Match ::";
	public String CELL_DATATYPE_DOESNOT_MATCH = "Cell Data-Type does not Match in :: ";
	public String CELL_PROTECTION_DOESNOT_MATCH = "Cell Protection does not Match ::";
	public String CORRUPTED_FILE_CELL_STYLE_REFERENCE = "Corrupted file, cell style references a font which is not defined";
	public String CELL_FONT_SIZE_DOESNOT_MATCH = "Cell Font Size does not Match ::";
	public String CELL_VISIBILITY_DOESNOT_MATCH = "Cell Visibility does not Match ::";
	public String HIDDEN = "HIDDEN";
	public String lOCKED = "LOCKED";

	public String SUCESSFULL_WRITE_MESSAGE = "Successfully written data to Excelsheet >> Sheetname : ";
	public String SUCESSFULL_TEST_RESULT_WRITE_MESSAGE = "Test case results are written successfully in test case summary file against row number: ";
	public String ROW_LABEL = ",Row : ";
	public String COLUMN_LABEL = ",Column : ";
	public String VALUE_LABEL = "Value:";
	public String DELETING_CORRUPTED_EXCEL_FILE_MESSAGE = "Excel file is corrupt > Deleting corrupted file and renaming backupfile";
	public String SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK = "Excel sheetName you have passed is not present in Excelsheet ::";
	public String EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT = "Excel file you are trying to access is either Corrupted or dosen't exist at location - ";
	public String ENVIRONMENT_DETAILS_EXCEL_INITIALIZATION_ERROR_MESSAGE = "Exception occured while initializing environmental variables : ";
	public String DATA_FROM_EXCEL_NULL = "Data from Excel is NULL, Please check Excel,row,cloumn,data";
	public String TOTAL_NO_KEYS = "Total no of keys in ";
	public String HASH_MAP_SHEET = " Hashmap(Xpath sheet): ";
	public String EXCEPTION_WHILE_COPYING_BACK_UP_FILE = "Exception while copying backup file to original";
	public String SHEET_IS_NOT_PRESENT_IN_WORKBOOK = "Sheet is not present in workbook";
	public String XLS = ".xls";
	public String XLSX = ".xlsx";
	public String LAST_BACKUP_FILE = "_Last_Backup.xls";
	public String WRITE_LABEL = "Write";
	public String READ_LABEL = "Read";
	public String KEY_LABEL = "Key:";
	public String NUll_LABEL = "null";
	public String ENV_CONFIGURATION_LABEL = "ENV configuration File Path :";
	public String TOP_LABEL = "TOP";
	public String BOTTOM_LABEL = "BOTTOM";
	public String LEFT_LABEL = "LEFT";
	public String RIGHT_LABEL = "RIGHT";
	public String NO_COLOR_LABEL = "NO COLOR";
	public String NOW_ROW_PROVIDED_FOR_TEST_SCENARIO = "No row provided for test scenario : '";
	public String IN = "' in '";
	public String SHEET_LABEL = "' sheet";
	public String PAYMENT_SCHEDULE_NOT_DOWNLOADED = "Payment Schedule file is not Downloaded";
	public String PAYMENT_SCHEDULE_DOWNLOADED_SUCESSFULLY = "Payment Schedule file is  Downloaded Successfully";
	public String PAYMENT_SCHEDULE_NOT_PRESENT_AT_LOCATION = "Payment Schedule TEST file is not present at location : ";
	public String DIFFERENCES_OF_EXCELSHEET_OF_PAYMENT_SCHEDULE = "Differences of Excel sheet of Payment Schedules : ";
	public String CELL_DATA = "Cell Data";

	/* Get Total Count constant */
	public String CLICK_ON_LAST_PAGINATION_ICON = "Click on Last Icon from pagination header";
	public String GET_COUNT_OF_ENTRIES_LAST_PAGE = "Get the count of entries present in last page";
	public String COUNT_OF_ENTRIES_IN_ONE_PAGE = "Get the count of entries present in one page";
	public String TOTAL_COUNT_OF_ENTRIES = "Total number of entries are : ";
	public String PAGINATION_LABEL_IS = "Current page is : ";
	public String ENTRY_IS_NOT_LISTED_IN_TABLE = "Entry is not present in table";

	/* Summary panel constant */
	public String VALUE_NOT_FOUND_IN_SUMMARY = "Value is not found in summary panel";
	public String DROP_DOWN_VALUE_PRESENT = " is present in drop-down";
	public String PRESENT_AT = " is present at ";
	public String TOTAL_VALUE_PRESENT = "Total values present in drop-down are : ";
	public String GIVEN_DATA = "Given value ";
	public String DROP_DOWN_VALUE = "Drop-down value ";

	/* Excel Payment Schedule Validation Constant */
	public String PAYMENT_SCHEDULE_VALIDATION_FAILED_MESSAGE = "Record validation Failed";
	public String PAYMENT_SCHEDULE_VALIDATION_PASSED_MESSAGE = "Records are validated successfully";
	public String WORKSHEET_EMPTY_MESSAGE = "Worksheet is empty - ";
	public String INCORRECT_COLUMN_COUNT = "Number of required columns are not same as in property file and csv file downloaded from application";
	public String COLUMN_NOT_PRESENT_IN_PAYMENT_APP_PAYMENT_SCHEDULE_FILE = " column name is not present in excel file downloaded from application";
	public String COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE = "Issue in Excel file please check created Excel workbook";
	public String VALIDATION_START_MESSAGE = "Validation started for Column : ";
	public String VALIDATION_FAILED_MESSAGE = "Validation Failed For Column : ";
	public String PAYMENT_SCHEDULE_FILE_DOWNLOAD_SUCCESS_MESSAGE = "File is Downloaded Successfully : ";
	public String PAYMENT_SCHEDULE_FILE_DOWNLOAD_FAILURE_MESSAGE = "File is not Downloaded : ";

	public String NUMBER_OF_WINDOW_PRESENT = "No of window present are :  ";
	public String NAVIGATE_NEWLY_OPENED_WINDOW = "Navigation to newly opened window done successfully";
	public String WINDOW_NOT_PRESENT_UNABLETO_SWITCH = "No window present, hence unable to switch to new  window";

	public String NO_WINDOW_PRESENT_USING_FLOWID = " No window present having flowid as : ";
	public String UNABLETO_SWITCH = " , hence unable to switch to new  window";
	public String SWITCH_TO = "Switched TO  window using Flow ID = ";
	public String WINDOW_SUCESSFULLY = " Done successfully";
	public String RECORDS_QUALIFIED_FOR_PROCESSING_CLIENT = "Total number of rows qualified for Client Team for : - ";
	public String WORKBOOK_QUALIFIED_FOR_PROCESSING = "Total number of workbook qualified for -: ";

	// Formatting Constants
	public String FORMAT_MESSAGE = " ***********";
	public String FORMAT_MESSAGE_2 = " ----------------------------";
	public String FORMATING_PATTERN = "**************************************************";
	public String FORMATING_PATTERN_FOR_SQL = "################# Executing Pre-requisites of ";
	public String FORMATING_PATTERN_FOR_SQL_END = " #################";

	// Test class creation message
	public String TEST_CLASS_EXECUTION_STARTED = "Test Class creation started for : ";
	public String TEST_CLASS_EXECUTION_ENDED = "Test Class creation ended for : ";
	public String TEST_CLASS_EXECUTION_ENDED_WITH_ERROR_FILE = "Test case entries in \"Test Case Summary\" is not appropriate,please refer \"DashBoardValidation.log\" file for more details ";
	public String DOMAIN = " domain";
	public String EXECUTION_ENDED_WITH_ERROR = "Execution ended with some error for : ";

	// isDisplayed validation action constant
	public static String CONTINUE = "Continue";
	public static String FIELD_ENABILITY = "Field on UI is enabled";
	public static String FIELD_DISABILITY = "Field on UI is disabled";

	//

	public String WINDOW_MAXIMIZE_LOGGER = "Maximizing browser window";
	public String SETTING_IE_CAPABILITY_MESSAGE = "Started setting capabilities for IE browser";
	public String LAUNCHING_IE_BROWSER_CAPABILITY_MESSAGE = "Launching IE browser with custom capabilities";
	public String LAUNCHING_IE_BROWSER_WITH_CAPABILITY_SUCCESS_MESSAGE = "IE browser launched with capabilities";
	public String IE_REGISTRY_SETTING_STARTED_MESSAGE = "Started doing registry settings for IE browser";
	public String SETTING_IE_REGISTRY_SETTING_SUCCESS_MESSAGE = "Registry settings applied successfully";

	// AutoIT
	public String AUTO_IT_EXECUTED_SUCESSFULLY = "File upload [AutoIT/Batch] executed sucessfully";
	public String ERROR_OCCURED_WHILE_EXE_FILE_EXECUTION = "Error occured while executing Executable program [AutoIT/Batch]";
	public String FILE_UPLOAD_FOR_IE = "Uploading file on IE browser";
	public String FILE_UPLOAD_FOR_CHROME = "Uploading file on Chrome browser";
	public String FILE_UPLOAD_FOR_POS = "Executing utility in background to get file uploaded for POS application";
	public String CLOSE_FILE_UPLOAD_INSTANCE = "Closing File Upload Program Instance";

	// POS login
	public String VERSION_TEXT = "/version.txt";
	public String CHECK_APPLICAITON_VERSION_MSG = "Check application version by launching URL : ";
	public String ISSUE_OCCURED_WHILE_GETTING_VERSION_MSG = "Issue occurs while getting Application version";
	public String NAVIGATE_TO_POS_MSG = "Navigate to POS application  - ";
	public String NAVIGATE_TO_CC_URL_MSG = "Navigate to Configuration console application  - ";
	public String TITLE_OF_WINDOW_MSG = "Title of window is : ";
	public String APP_NOT_ACCESSABLE = "Application homepage is not accessible : ";
	public String REDIRECT_MSG = "Redirecting again to URL : ";
	public String APPLICATION_NOT_LAUNCHED_SUCESSFULLY_MSG = "Application is not launched successfully/Unable to access, please refer logs for details";
	public String APPLICAITON_LAUNCHED_SUCESSFULLY_MSG = "Application launched Successfully";
	public String ENTER_USERNAME_MSG = "Enter Username as: ";
	public String ENTER_PASSWORD_MSG = "Enter Password as: ";
	public String CLICK_ON_LOGIN_MSG = "Click on login button";
	public String CHECK_PROFILE_DROPDOWN_MSG = "Check ProfileDropdown isDisplayed or not";
	public String ELEMENT_NOT_DISPLAYED_MSG = "Element is not Displayed on UI";
	public String LOGIN_TO_APP_SUCESSFULLY_MSG = "Logged into application successfully";
	public String LOGOUT_FROM_APPLICATION_MESSSAGE = "===== Logging out from application =====";
	public String WORKSHEET_NAME_KO_MESSAGE = "Worksheet name does not contains '_MO_' or '_BO_' or '_POS_' login details, please check naming conventions";

	// Check_Downloaded_File
	public String CHECK_INPUT_TESTDATA_MSG = " Please check input test Data as it should not be null / Give File --> ";
	public String FILE_NOT_AVAILABLE_MSG = " Is not available at Location";
	public String FILE_NAME_MSG = "File is available: ";
	public String TOTAL_FILES_LOCATION = "Total Files at location: ";
	public String ARE_MSG = "' are : ";
	public String EXPECTED_FILE_MSG = "Expected File:- ";
	public String IS_NOT_AVAILABLE_MSG = " is not available at location >> ";
	public String FULL_STOP = ". ";

	// generate dynamic date action constants
	public String APPLICATION_DATE_FORMAT = "Application date Format is : ";
	public String DATE_GENERATED_DYNAMICALLY = "Calculated date on the basis of given Day,Month and Year value is : ";

	// FileUpload
	public String CLICK_ON_FILEUPLOAD = "Click on File Upload Button ";
	public String FACING_ISSUE_FILEUPLOAD = "Facing issue while cliking on File upload Button: ";
	public String FACING_ISSUE_DOWNLOAD_MSG = " Facing issue while clicking File download Button ";

	// File rename constants
	public String EXISTING_FIlE_NAME = " Existing File Name is : ";
	public String RENAMED_FILE = " Expected  File Name is : ";
	public String INPUT_FILESEPERATOR_MSG = "Input FileSeprate Character  ";
	public String VALIDATED_MSG = " Is Validated successfully ";
	public String RENAME_FILE_SUCESS_MSG = " File Renamed successfully and placed at loation >> ";
	public String SAVE_OLD_FILE_SUCESS_MSG = " Existing File copid and saved at location >> ";
	public String NOT_VALID_MSG = " Not Valid Please check input";

	public String FILE_RENAME_FAILUR = "Failed to rename Given file";

	// CSMZ_ChangeDateFormat
	public String DATE_AFTER_CHAGE_FORMAT = "Date after processing is: ";
	public String EXPETED_DATE_FORMAT = "Expected Date Format is:";
	public String GIVEN_DATE_MSG = " Given Date before Formate is ";

	public String INVALID_INPUT_MSG = "No prefix suffix value is provided, Please provide the value ";
	public String OUTPUT_VARIABLE_NOT_MATCH = "Variables to store the value are not provided in stored variable column,Please provide variables with '|' seperator as per no of text line need to be retrived";
	public String VALUE_NOT_FOUND_IN_Text = "Value is not found in Given Text";

	// Jasper Report
	public String PDF_FILE_NAME = "dlgfacturation.pdf";
	public String PDF_TO_EXCEL_FILE_NAME = "dlgfacturation.xlsx";
	public String JASPER_EXCEL_SHEET_NAME = "Receivables";
	public String JASPER_EXCEL_HEADER1 = "Sr.No.";
	public String JASPER_EXCEL_HEADER2 = "Generated Receivables";
	public String GET_RECEIVABLES = "Get_Receivables";
	public String COUT_OF_RECEIVABLES_MSG = "Count of Generated Receivables from Jasper report are : ";
	public String INPUT_VALIDATION_MSG = "Input requried validation is not provided";
	public String COUT_OF_EXPENSE_MSG = "Count of Generated Expenses from Jasper report are : ";

	public String VALUE_EMPTY_GENERATED_MSG = " Value of Stored Variable :";
	public String JASPER_REPORT_VALIDATION = " is Empty Please check Generated Jasper report for more detials ";

	public String PRIFIX_SUFFIX = "Prifix/Suffix Occurence should be numeric please check input";
	public String PRIFIX_SUFFIX_OCCURENCE_ISSUE = "Prifix/Suffix Occurence is invalid please check inputdata of occurence value";
	public String FILE_RENAMED_MSG = " File Renamed sucessfully and available at location >> ";
	public String DATA_SET_MSG = "Expected Data Set Saved sucessfully into Excel >> ";
	public String VALUE_OF_STRED_VARIABLE_MSG = " Value of Stored Variable '";
	public String IS = "' is - ";
	public String EXPECTED_DATA_MSG = "Expected data entity to be retrived form JasperReport is :";
	public String INPUT_EXCEL_MSG = "Input Excel File Name is >> ";
	public String VALUE_OF_STORE_VARIABLE = " Value of Stored Variable '";
	public String UNABLETO_SELECT_DROPDOWN = " Unabel to select Dropdown value due to Error Message >> ";
	// GetDataFromJasperExcel
	public String COUNT_OF_ENTITY = "Count of Headers ";
	public String RETRIVED_HEADER = "Retrived header ";
	public String Value_MSG = " Value = ";
	public String EXCEL_FILE_NAME = " Converted Jasper report to ExcelName = ";
	public String INPUT_FIELD_MSG = "Input fileName is ";

	// driver constant
	public String HEADLESS_MODE_BROWSE_INFO = "*** Launching browser in headless mode ***";

	// Overflow Icon handling
	public String OVER_FLOW_ICON_MSG = "Menu is not visible, click on overflow icon to expand menu";

	// DynamicCheckBoxValidation
	public String CHECKBOX_IS_CHECKED = "Checkbox is checked";
	public String CHECKBOX_IS_UNCHECKED = "Checkbox is unchecked";

	// Replace all
	String REPLACED_VALUE = "Replaced value is > ";

	// Edgebrowser logger
	public String EDGEBROWSER_CAPABILITES = "Launching Edge browser with custom capabilities";
	public String COPY_EDGE_PROFILE = "************* Copying Edge Profile **********";
	public String XML_FILE_UPDATION_ERROR_MESSAGE = "Issue occured while updation XML file: ";

	public String VALUE_NOT_AVAILABLE_MESSAGE = "Value is not available on UI";
	public String VALUE_NOT_GETTING_FILTERED_MESSAGE = " The given text didnt searched any filter value ";
	public String CLICK_ON_PAGINATIONICON = " *** Click on Pagination Icon *** ";
	public String PAGINAION_LOG_RANGE_MESSAGE = "Expected Entry is not found in table after searching traversing 75 records";

	// ExtractPDFDataAndValidate
	public String GIVEN_FILE = " Given File : ";
	public String RENAMED_SUCESSFULL_MESSAGE = " : is Renamed sucessfully at location ";
	public String PDF_DATA_CONVERTED_SUCESS_MSG = " PDF Data convered into log file sucessfully, please refer file at : ";
	public String EXPECTED_VALUE = " Expected value  : ";
	public String PDF_OCCURENCE_MSG = " : is present in PDF and total occurence = ";
	public String PDF_DATA_NOT_PRESENT = ": is not present in PDF please check occurence | expected value";
	public String LINE_MSG = "Line ";
	public String COPIED_MSG = "_Copied";

	// EnterDateActionPOS
	public String SELECTED_MSG = " selected";
	public String YEAR_MSG = "Year: ";
	public String MONTH_MSG = "Month: ";
	public String DAY_MSG = "Day: ";

	// CompareDates
	public String INPUTDATES_ORDER_MSG = " Input dates order ";
	public String EXPECTED_ASCENDING_MSG = " Expected Ascending order ";
	public String EXPECTED_DESCENDING_MSG = " Expected descending order ";

}
