/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.functions.CasflowCollectionDisbursement;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class CashflowCollectionDisbursementFunctionExecutor implements FunctionExecutor {

	@Override
	public void executeFunction(String methodName, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {

		String[] inputData = CommonUtility.getInputData(excelTestCaseFields, testCaseDetail);

		if (FunctionConstant.NAVIGATE_TO.equals(methodName)) {
			CasflowCollectionDisbursement.navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		} else if (FunctionConstant.OPEN.equals(methodName)) {
			CasflowCollectionDisbursement.open(inputData[0],excelTestCaseFields, testCaseDetail);
		}

	}

}
