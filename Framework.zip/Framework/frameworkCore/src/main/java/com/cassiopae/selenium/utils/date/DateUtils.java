package com.cassiopae.selenium.utils.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.Range;
import org.apache.logging.log4j.*;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class DateUtils {

	private static Logger logger = LogManager.getLogger(DateUtils.class);

	/**
	 * @author mshaik
	 * @param excelTestCaseFields
	 * @param testCaseDetail
	 * @param reqValues
	 * @param date
	 * @param reqOperations
	 */
	public static void dateCompare(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail,
			String reqValues[], String date[], String reqOperations) {
		boolean comparisionStatus = false;
		String variableHolderColumnData = excelTestCaseFields.getStoreValuesInVariable();
		logger.info(ReportLoggerConstant.LENGTH + date.length);
		switch (reqOperations) {
		case ReportLoggerConstant.EQUALSTO:
			comparisionStatus = checkEqualsOperation(date, testCaseDetail);
			break;
		case ReportLoggerConstant.LESSTHANTO:
			comparisionStatus = checkLessthanToOperation(date, testCaseDetail);
			break;
		case ReportLoggerConstant.GRATERTHANTO:
			comparisionStatus = checkGreaterThanToOperation(date, testCaseDetail);
			break;
		case ReportLoggerConstant.IN_BETWEEN:
			comparisionStatus = checkInbetweenOperation(date, testCaseDetail);
			break;
		case ReportLoggerConstant.ASC_ORDER:
			comparisionStatus = checkAscendingOrder(date, testCaseDetail);
			break;
		case ReportLoggerConstant.DESC_ORDER:
			comparisionStatus = checkDescendingOrder(date, testCaseDetail);
			break;
		default:
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.CHECK_DATES_OPERATION_IN_ACTION);
			comparisionStatus = false;
		}
		if (comparisionStatus) {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData.trim(), CommonConstant.TRUE_VALUE);
		} else {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData.trim(), CommonConstant.FALSE_VALUE);
		}
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkEqualsOperation(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		Date inputDate1 = null;
		Date inputDate2 = null;
		try {
			inputDate1 = getformatedDate(date[0], testCaseDetail);
			inputDate2 = getformatedDate(date[1], testCaseDetail);
		} catch (IllegalArgumentException e) {
			logger.error(ReportLoggerConstant.PLEASE_CHECK_INPUTDATES_MSG, e);
		}
		String formatedDate1 = convertInputDateToApplicaitonFormat(inputDate1, testCaseDetail);
		String formatedDate2 = convertInputDateToApplicaitonFormat(inputDate2, testCaseDetail);
		logger.info(ReportLoggerConstant.INPUT_DATE1_MSG + formatedDate1);
		logger.info(ReportLoggerConstant.INPUT_DATE2_MSG + formatedDate2);
		if (inputDate1.compareTo(inputDate2) == 0) {
			testCaseDetail.getReportingLogger()
					.info(CommonConstant.SINGLE_QUOTE + formatedDate1 + CommonConstant.SINGLE_QUOTE
							+ ReportLoggerConstant.AND_MSG + CommonConstant.SINGLE_QUOTE + formatedDate2
							+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.BOTH_DATES_ARE_EQUAL);
			comparisionStatus = true;
		} else {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.BOTH_DATES_ARE_NOT_EQUAL);
			comparisionStatus = false;
		}
		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkLessthanToOperation(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		Date inputDate1 = null;
		Date inputDate2 = null;
		try {
			inputDate1 = getformatedDate(date[0], testCaseDetail);
			inputDate2 = getformatedDate(date[1], testCaseDetail);
		} catch (IllegalArgumentException e) {
			logger.error(ReportLoggerConstant.PLEASE_CHECK_INPUTDATES_MSG, e);
		}
		String formatedDate1 = convertInputDateToApplicaitonFormat(inputDate1, testCaseDetail);
		String formatedDate2 = convertInputDateToApplicaitonFormat(inputDate2, testCaseDetail);
		logger.info(ReportLoggerConstant.INPUT_DATE1_MSG + formatedDate1);
		logger.info(ReportLoggerConstant.INPUT_DATE2_MSG + formatedDate2);
		if (inputDate1.compareTo(inputDate2) < 0) {
			testCaseDetail.getReportingLogger()
					.info(CommonConstant.SINGLE_QUOTE + formatedDate1 + CommonConstant.SINGLE_QUOTE
							+ ReportLoggerConstant.DATE1_BEFORE_DATE2 + CommonConstant.SINGLE_QUOTE + formatedDate2
							+ CommonConstant.SINGLE_QUOTE);
			comparisionStatus = true;
		} else {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.DATE1_NOT_BEFORE_DATE2);
			comparisionStatus = false;
		}
		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkGreaterThanToOperation(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		Date inputDate1 = null;
		Date inputDate2 = null;
		try {
			inputDate1 = getformatedDate(date[0], testCaseDetail);
			inputDate2 = getformatedDate(date[1], testCaseDetail);
		} catch (IllegalArgumentException e) {
			logger.error(ReportLoggerConstant.PLEASE_CHECK_INPUTDATES_MSG, e);
		}
		String formatedDate1 = convertInputDateToApplicaitonFormat(inputDate1, testCaseDetail);
		String formatedDate2 = convertInputDateToApplicaitonFormat(inputDate2, testCaseDetail);
		logger.info(ReportLoggerConstant.INPUT_DATE1_MSG + formatedDate1);
		logger.info(ReportLoggerConstant.INPUT_DATE2_MSG + formatedDate2);
		if (inputDate1.compareTo(inputDate2) > 0) {
			testCaseDetail.getReportingLogger()
					.info(CommonConstant.SINGLE_QUOTE + formatedDate1 + CommonConstant.SINGLE_QUOTE
							+ ReportLoggerConstant.DATE1_AFTER_DATE2 + CommonConstant.SINGLE_QUOTE + formatedDate2
							+ CommonConstant.SINGLE_QUOTE);
			comparisionStatus = true;
		} else {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.DATE1_NOT_AFTER_DATE2);
			comparisionStatus = false;
		}
		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkInbetweenOperation(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		Date inputDate1 = null;
		Date inputDate2 = null;
		Date inputDate3 = null;
		try {
			inputDate1 = getformatedDate(date[0], testCaseDetail);
			inputDate2 = getformatedDate(date[1], testCaseDetail);
			inputDate3 = getformatedDate(date[2], testCaseDetail);
		} catch (IllegalArgumentException e) {
			logger.error(ReportLoggerConstant.PLEASE_CHECK_INPUTDATES_MSG, e);
		}

		String formatedDate1 = convertInputDateToApplicaitonFormat(inputDate1, testCaseDetail);
		String formatedDate2 = convertInputDateToApplicaitonFormat(inputDate2, testCaseDetail);
		String formatedDate3 = convertInputDateToApplicaitonFormat(inputDate3, testCaseDetail);
		logger.info(ReportLoggerConstant.INPUT_DATE1_MSG + formatedDate1);
		logger.info(ReportLoggerConstant.INPUT_DATE2_MSG + formatedDate2);
		logger.info(ReportLoggerConstant.INPUT_DATE3_MSG + formatedDate3);
		if (inputDate3.compareTo(inputDate1) > 0 && inputDate3.compareTo(inputDate2) < 0
				|| inputDate1.compareTo(inputDate3) == 0 || inputDate2.compareTo(inputDate3) == 0) {
			testCaseDetail.getReportingLogger()
					.info(formatedDate3 + ReportLoggerConstant.DATE3_IN_BETWEEN_DATE1_AND_DATE2 + formatedDate1
							+ ReportLoggerConstant.AND_MSG + formatedDate2);
			comparisionStatus = true;
		} else {
			testCaseDetail.getReportingLogger()
					.info(CommonConstant.SINGLE_QUOTE + formatedDate3 + CommonConstant.SINGLE_QUOTE
							+ ReportLoggerConstant.DATE3_NOT_IN_BETWEEN_DATE1_AND_DATE2 + CommonConstant.SINGLE_QUOTE
							+ formatedDate1 + CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.AND_MSG
							+ CommonConstant.SINGLE_QUOTE + formatedDate2 + CommonConstant.SINGLE_QUOTE);
			comparisionStatus = false;
		}
		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkAscendingOrder(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		ArrayList<Date> datelist = getInputDateList(date, testCaseDetail);
		ArrayList<Date> datscpy = new ArrayList<>(datelist);
		// Sort Dates in assending order
		Collections.sort(datscpy); // che
		// compare two Array List
		comparisionStatus = datelist.equals(datscpy);
		if (!comparisionStatus) {
			testCaseDetail.getReportingLogger().warn(ErrorMessageConstant.INPUT_DATES_ORDER_MISMATCHED);
		}

		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean checkDescendingOrder(String date[], TestCaseDetail testCaseDetail) {
		boolean comparisionStatus = false;
		ArrayList<Date> datelist = getInputDateList(date, testCaseDetail);
		ArrayList<Date> datscpy = new ArrayList<>(datelist);
		// Sort Dates in decending order
		Collections.sort(datscpy, Comparator.reverseOrder());
		// compare two Array List
		comparisionStatus = datelist.equals(datscpy);
		if (!comparisionStatus) {
			testCaseDetail.getReportingLogger().warn(ErrorMessageConstant.INPUT_DATES_DESCENDING_ORDER_MISMATCHED);
		}
		return comparisionStatus;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static ArrayList<Date> getInputDateList(String date[], TestCaseDetail testCaseDetail) {
		StringBuilder builder = new StringBuilder();
		ArrayList<Date> d1 = new ArrayList<Date>();
		int count = 0;
		String message;
		for (String dateArrayElement : date) {
			count++;
			message = ReportLoggerConstant.INPUT_DATE_MSG + count + CommonConstant.SPACE
					+ CommonConstant.COLON_SEPERATOR + dateArrayElement + CommonConstant.COMMA_SEPERATOR;
			//logger.info();
			builder.append(message);
			builder.append(CommonConstant.LINE_SEPERATER);
			d1.add(getformatedDate(dateArrayElement, testCaseDetail));
		}
		testCaseDetail.getReportingLogger().info(builder);
		return d1;
	}

	public static String convertInputDateToApplicaitonFormat(Date inputDate, TestCaseDetail testCaseDetail) {
		String appformatedDate = null;
		String applicationDateFormat = testCaseDetail.getVariableHolder().get(FrameworkConstant.APP_DATE_FORMAT);
		SimpleDateFormat sdf = new SimpleDateFormat(applicationDateFormat);
		appformatedDate = sdf.format(inputDate);
		return appformatedDate;
	}

	/**
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static Date getformatedDate(String date, TestCaseDetail testCaseDetail) {
		// Getting Application date format
		DateTimeFormatter dtf = null;
		Date jodatime = null;
		try {
			dtf = DateTimeFormat.forPattern(getInputDateFormat(date, testCaseDetail));
			jodatime = dtf.parseDateTime(date).toDate();
		} catch (UnsupportedOperationException e) {
			logger.error(ErrorMessageConstant.DATE_FORMATE_ERROR_MSG);
			logger.error(e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error(ErrorMessageConstant.DATE_FORMATE_ERROR_MSG);
			logger.error(e.getMessage());
		}
		return jodatime;
	}

	/**
	 * @param reqOperations
	 * @param date
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean validateParameter(String reqOperations, String[] date, TestCaseDetail testCaseDetail) {
		boolean parameterStatus = false;
		if (reqOperations.equals(ReportLoggerConstant.EQUALSTO)
				|| reqOperations.equals(ReportLoggerConstant.GRATERTHANTO)
				|| reqOperations.equals(ReportLoggerConstant.LESSTHANTO)) {
			if (date.length == 2) {
				logger.info(ReportLoggerConstant.INPUT_PARAMETERS_VALIDATED_MSG);
				parameterStatus = true;
			} else {
				logger.error(ErrorMessageConstant.COMPARE_DATE_ACTION_INPUTDATA_INCORRECT);
				throw new CATTException(ErrorMessageConstant.COMPARE_DATE_ACTION_INPUTDATA_INCORRECT);
			}
		} else if (date.length == 3) {
			parameterStatus = true;
			logger.info(ReportLoggerConstant.INPUT_PARAMETERS_VALIDATED_MSG);
		} else if (reqOperations.equals(ReportLoggerConstant.ASC_ORDER)
				|| reqOperations.equals(ReportLoggerConstant.DESC_ORDER)) {
			parameterStatus = true;
			logger.info(ReportLoggerConstant.INPUT_PARAMETERS_VALIDATED_MSG);
		} else {

			testCaseDetail.getReportingLogger()
					.error(ErrorMessageConstant.CHECK_INBETWEEN_DATE_ACTION_INPUTDATA_INCORRECT);
			throw new CATTException(ErrorMessageConstant.CHECK_INBETWEEN_DATE_ACTION_INPUTDATA_INCORRECT);
		}
		return parameterStatus;
	}

	/**
	 * @param value
	 * @return
	 */
	public static boolean validateSpecialCharacterInDate(String value) {
		Pattern specialCharPattern = Pattern.compile("[!@#$%&*()+=|<>?{}\\[\\]~]");
		Matcher hasSpecial = specialCharPattern.matcher(value);
		Pattern spacePattern = Pattern.compile("\\s");
		Matcher hasSpecial1 = spacePattern.matcher(value);
		return (hasSpecial.find() || hasSpecial1.find());
	}

	/**
	 * @param value
	 * @param testCaseDetail
	 * @return
	 */
	public static boolean validateInputDates(String value[], TestCaseDetail testCaseDetail) {
		Boolean dateStatus = null;
		String dateValue = null;
		for (int j = 0; j < value.length; j++) {
			try {
				dateValue = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), value[j])
						.trim();
				if (!dateValue.isEmpty() && !validateSpecialCharacterInDate(dateValue)) {
					dateStatus = true;
				} else {
					testCaseDetail.getReportingLogger()
							.info(ReportLoggerConstant.PLEASE_CHECK + (j + 1)
									+ ReportLoggerConstant.VALUE_LOGGER_MESSGAE + dateValue
									+ ReportLoggerConstant.DATES_VALIDATION_ERROR);
					dateStatus = false;
				}
			} catch (NullPointerException e) {
				testCaseDetail.getReportingLogger().info(ReportLoggerConstant.DATES_VALIDATION_ERROR);
			}
		}
		return dateStatus;
	}

	/**
	 * @return
	 */
	public static String getCurrentDateTime() {
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy:HH.mm.ss");
		return formatter.format(currentDate.getTime());
	}

	/**
	 * This method is used to calculate date(Future/Past) based on inputs
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @param dayMonYearVal         Day,Month,Year
	 * @param baseDate              the date from which calculations should begin
	 * @return Calculated date in application format
	 */
	public static String generateDynamicDate(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO,
			String[] dayMonYearVal, String baseDate) {
		String day = null;
		String month = null;
		String year = null;
		String ApplicationDateFormat = testCaseDetailTO.getVariableHolder().get(FrameworkConstant.APP_DATE_FORMAT);

		testCaseDetailTO.getReportingLogger()
				.info(ReportLoggerConstant.APPLICATION_DATE_FORMAT + ApplicationDateFormat);

		day = dayMonYearVal[0];
		month = dayMonYearVal[1];
		year = dayMonYearVal[2];

		// testCaseDetailTO.getReportingLogger().error(ErrorMessageConstant.REQUIRED_INPUT_TEST_DATA_IS_NOT_CORRECT);

		SimpleDateFormat sdf = new SimpleDateFormat(ApplicationDateFormat);
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(sdf.parse(baseDate));
		} catch (ParseException e) {
			logger.info(e.getMessage(), e);
		}
		if (day.startsWith(CommonConstant.ARITHMATIC_MINUS_OPERATOR)) {
			String localDay = day.split(CommonConstant.ARITHMATIC_MINUS_OPERATOR)[1];
			if (localDay.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				day = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), localDay);
			}
			else {
				day = localDay;
			}
			calendar.add(Calendar.DATE, -Integer.parseInt(day));
		} else {
			if (day.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				day = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), day);
			}
			calendar.add(Calendar.DATE, Integer.parseInt(day));
		}
		if (month.startsWith(CommonConstant.ARITHMATIC_MINUS_OPERATOR)) {
			String localMonth = month.split(CommonConstant.ARITHMATIC_MINUS_OPERATOR)[1];
			if (localMonth.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				month = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), localMonth);
			}
			else {
				month = localMonth;
			}
			calendar.add(Calendar.MONTH, -Integer.parseInt(month));
		} else {
			if (month.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				month = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), month);
			}
			calendar.add(Calendar.MONTH, Integer.parseInt(month));
		}
		if (year.startsWith(CommonConstant.ARITHMATIC_MINUS_OPERATOR)) {
			String localYear = year.split(CommonConstant.ARITHMATIC_MINUS_OPERATOR)[1];
			if (localYear.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				year = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), localYear);
			}
			else {
				year = localYear;
			}
			calendar.add(Calendar.YEAR, -Integer.parseInt(year));
		} else {
			if (year.startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				year = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), year);
			}
			calendar.add(Calendar.YEAR, Integer.parseInt(year));
		}
		String generatedDate = sdf.format(calendar.getTime());
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.DATE_GENERATED_DYNAMICALLY + generatedDate);
		return generatedDate;
	}

	/**
	 * @author mshaik
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 * @param baseDate
	 * @param expectedFormat
	 * @return
	 */
	public static String chageDateFormat(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO,
			String baseDate, String expectedFormat) {
		// Getting Application date format
		String applicationDateFormat = testCaseDetailTO.getVariableHolder().get(FrameworkConstant.APP_DATE_FORMAT);
		logger.info(ReportLoggerConstant.APPLICATION_DATE_FORMAT + applicationDateFormat);
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.CONVERTING_MSG + baseDate
				+ ReportLoggerConstant.TO_MSG + expectedFormat + ReportLoggerConstant.FORMAT_MSG);
		DateTimeFormatter dtf = null;
		Date jodatime = null;
		try {
			dtf = DateTimeFormat.forPattern(getInputDateFormat(baseDate, testCaseDetailTO));
			jodatime = dtf.parseDateTime(baseDate).toDate();
		} catch (UnsupportedOperationException e) {
			logger.error(ErrorMessageConstant.DATE_FORMATE_ERROR_MSG);
			logger.error(e.getMessage());
		}
		SimpleDateFormat sdf2;
		String formatedDate = null;
		try {
			sdf2 = new SimpleDateFormat(expectedFormat);
			formatedDate = sdf2.format(jodatime);
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.DATE_AFTER_CHAGE_FORMAT + formatedDate);
		} catch (IllegalArgumentException e) {
			testCaseDetailTO.getReportingLogger().info(ErrorMessageConstant.DATE_FORMATE_ERROR_MSG);
			throw new CATTException(ErrorMessageConstant.DATE_FORMATE_ERROR_MSG);
		}
		return formatedDate;
	}

	/**
	 * @param baseDate
	 * @param testCaseDetail
	 * @return
	 */
	public static String getInputDateFormat(String baseDate, TestCaseDetail testCaseDetail) {
		String inputDateformate = null;
		HashMap<String, String> map = new HashMap<String, String>();
		// ******** MM/dd/yyyy format **********
		map.put("^(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/([0-9]{4})", "MM/dd/yyyy");
		map.put("^([0-9]{1})/[0-9]{1}/([0-9]{4})", "M/d/yyyy");
		map.put("^(1[0-2]|0[1-9])/[0-9]{1}/([0-9]{4})", "MM/d/yyyy");
		map.put("[0-9]{1}/(3[01]|[12][0-9]|0[1-9])/([0-9]{4})", "M/dd/yyyy");
		// ******** dd/MM/yyyy format **********
		map.put("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/([0-9]{4})", "dd/MM/yyyy");
		map.put("^([0-9]{1})/(1[0-2]|0[1-9])/([0-9]{4})", "d/MM/yyyy");
		map.put("^([0-9]{1})/([0-9]{1})/([0-9]{4})", "d/M/yyyy");
		map.put("^(3[01]|[12][0-9]|0[1-9])/([1-9]{1})/([0-9]{4})", "dd/M/yyyy");
		// ********** dd-MMM-YYYY format **********
		map.put("\\d{2}-[A-z]{3}-\\d{4}", "dd-MMM-yyyy");
		map.put("\\d{1}-[A-z]{3}-\\d{4}", "d-MMM-yyyy");
		map.put("\\d{2}-[A-z]{3}-\\d{2}", "dd-MMM-yy");
		// ******** MM-dd-yyyy format **********
		map.put("^(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9])-([0-9]{4})", "MM-dd-yyyy");
		map.put("^([0-9]{1})-[0-9]{1}-([0-9]{4})", "M-d-yyyy");
		map.put("^(1[0-2]|0[1-9])-[0-9]{1}-([0-9]{4})", "MM-d-yyyy");
		map.put("^[0-9]{1}-(3[01]|[12][0-9]|0[1-9])-([0-9]{4})", "M-dd-yyyy");
		// ******** dd-MM-yyyy format **********
		map.put("^(3[01]|[12][0-9]|0[1-9])-(1[0-2]|0[1-9])-([0-9]{4})", "dd-MM-yyyy");
		map.put("^([0-9]{1})-([0-9]{1})-([0-9]{4})", "d-M-yyyy");
		map.put("^(3[01]|[12][0-9]|0[1-9])-([1-9]{1})-([0-9]{4})", "dd-M-yyyy");
		map.put("^([0-9]{1})-(1[0-2]|0[1-9])-([0-9]{4})", "d-MM-yyyy");
		int count = 0;
		for (Map.Entry<String, String> m : map.entrySet()) {
			if (baseDate.matches(m.getKey())) {
				inputDateformate = m.getValue();
				count++;
			}
		}
		if (count == 2 && baseDate.contains(CommonConstant.ARITHMATIC_MINUS_OPERATOR)
				&& (testCaseDetail.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.POS_MODULE)
						|| testCaseDetail.getTestCaseCommonData().getWorkSheetName()
								.contains(DBConstant.CC_APP_SHEET_NAME))) {
			inputDateformate = CommonConstant.POS_APP_FORMAT;
			logger.info(ReportLoggerConstant.CONVERTING_MSG + baseDate + ReportLoggerConstant.TO_APPLICATION_DATE_FORMAT
					+ inputDateformate);
		} else if (count == 2 && baseDate.contains(CommonConstant.ARITHMATIC_MINUS_OPERATOR)
				&& (testCaseDetail.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.BO_APP_SHEET_NAME)
						|| testCaseDetail.getTestCaseCommonData().getWorkSheetName()
								.contains(DBConstant.MO_APP_SHEET_NAME))) {
			inputDateformate = CommonConstant.BO_APP_FORMAT;
			logger.info(ReportLoggerConstant.CONVERTING_MSG + baseDate + ReportLoggerConstant.TO_APPLICATION_DATE_FORMAT
					+ inputDateformate);
		} else if (count == 2 && baseDate.contains(CommonConstant.FORWARD_SLASH)) {
			inputDateformate = testCaseDetail.getVariableHolder().get(FrameworkConstant.APP_DATE_FORMAT);
		}
		return inputDateformate;
	}

	private static Map<String, List<String>> posPannel = ObjectRepoInitialization.masterLocatorMap
			.get(ObjectRepoInitialization.POS_PANEL);

	/**
	 * @param testCaseDetail
	 * @return
	 * @author mshaik
	 */
	public static int[] getDatePickerGlobalYearRage(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		testCaseDetail.setLocatorHashMap(posPannel);
		Map<String, List<String>> poslocator = testCaseDetail.getLocatorHashMap();
		int glogYearRange[] = new int[2];
		String globYear = driver.findElement(GenericAction.locator("POS.Global.DatePickerRange", poslocator)).getText();
		String comp[] = globYear.split(CommonConstant.ARITHMATIC_MINUS_OPERATOR);
		glogYearRange[0] = Integer.parseInt(comp[0]);
		glogYearRange[1] = Integer.parseInt(comp[1]) + 2;
		return glogYearRange;
	}

	/**
	 * @param startYear
	 * @param endYear
	 * @param expectedYear
	 * @return
	 * @author mshaik
	 */
	public static int checkTheInputDateInGivenRange(int startYear, int endYear, int expectedYear) {
		Range<Integer> globalRage = Range.between(startYear, endYear);
		int rangeStatus = globalRage.elementCompareTo(expectedYear);
		return rangeStatus;
	}

	/**
	 * @param inputDate
	 * @author mshaik
	 * @return
	 */
	public static int processInputDateAndGetYear(String inputDate) {
		int expYearNumber = 0;
		String comp[] = inputDate.split(CommonConstant.FORWARD_SLASH);
		String expYear = comp[2];
		expYearNumber = Integer.parseInt(expYear);
		return expYearNumber;
	}

	/**
	 * @param inputDate
	 * @param testCaseDetail
	 * @author mshaik
	 * @return
	 */
	public static String processInputDateAndGetMonth(String inputDate, TestCaseDetail testCaseDetail) {
		DateTimeFormatter dtf = DateTimeFormat.forPattern(getInputDateFormat(inputDate, testCaseDetail));
		Date jodatime = dtf.parseDateTime(inputDate).toDate();
		SimpleDateFormat sdf2 = new SimpleDateFormat(CommonConstant.MMMDDYYYY,Locale.ENGLISH);
		String formatedDate = sdf2.format(jodatime);
		String out[] = formatedDate.split(CommonConstant.FORWARD_SLASH);
		return out[0];
	}

	/**
	 * @param inputDate
	 * @author mshaik
	 * @return
	 */
	public static String processInputDateAndGetDay(String inputDate) {
		String comp[] = inputDate.split(CommonConstant.FORWARD_SLASH);
		String day = null;
		if (comp[1].charAt(0) == '0') {
			day = comp[1].replace(CommonConstant.ZERO_VALUE, CommonConstant.EMPTY_STRING);
		} else {
			day = comp[1];
		}
		return day;
	}

	/**
	 * @param driver
	 * @param inputDate
	 * @param testCaseDetail
	 * @author mshaik
	 */
	public static void selectYear(int expYearNumber, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		testCaseDetail.setLocatorHashMap(posPannel);
		Map<String, List<String>> locatorHashmap = testCaseDetail.getLocatorHashMap();
		driver.findElement(GenericAction.locator("POS.Global.DatePickerRange", locatorHashmap)).click();
		driver.findElement(GenericAction.locator("POS.Global.DatePickerRange", locatorHashmap)).click();
		int rage[] = getDatePickerGlobalYearRage(excelTestCaseFields, testCaseDetail);
		int rangeStatus = checkTheInputDateInGivenRange(rage[0], rage[1], expYearNumber);
		String expyearxpath = "//*[@class='rdtPicker']//*[text()='" + expYearNumber + "' and @class ='rdtYear']";
		while (!(rangeStatus == 0)) {
			if (rangeStatus == 1) {
				driver.findElement(GenericAction.locator("POS.DatePicker.NextIcon", locatorHashmap)).click();
				int globRange[] = getDatePickerGlobalYearRage(excelTestCaseFields, testCaseDetail);
				rangeStatus = checkTheInputDateInGivenRange(globRange[0], globRange[1], expYearNumber);
			} else if (rangeStatus == -1) {
				driver.findElement(GenericAction.locator("POS.DatePicker.PreviousIcon", locatorHashmap)).click();
				int globRange[] = getDatePickerGlobalYearRage(excelTestCaseFields, testCaseDetail);
				rangeStatus = checkTheInputDateInGivenRange(globRange[0], globRange[1], expYearNumber);
			}
		}
		try {
			if (driver.findElement(By.xpath(expyearxpath)).isDisplayed()) {
				WebElement elem = driver.findElement(By.xpath(expyearxpath));
				((JavascriptExecutor) driver).executeScript(FrameworkConstant.JAVASCRIPT_SCROLL_TRUE, elem);
				elem.click();
				logger.info(ReportLoggerConstant.YEAR_MSG + expYearNumber + ReportLoggerConstant.SELECTED_MSG);
			}
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				logger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				logger.error(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
				throw new CATTException(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
			} else {
				logger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		}
	}

	/**
	 * @param driver
	 * @param dateUI
	 * @param testCaseDetail
	 * @param excelTestCaseFields
	 * @author mshaik
	 */
	public static void selectMonth(String month, TestCaseDetail testCaseDetail,
			ExcelTestCaseFields excelTestCaseFields) {
		WebDriver driver = testCaseDetail.getDriver();
		String expMonthxpath = "//*[@class='rdtPicker']//*[text()='" + month + "' and @class ='rdtMonth']";
		try {
			if (driver.findElement(By.xpath(expMonthxpath)).isDisplayed()) {
				WebElement elem = driver.findElement(By.xpath(expMonthxpath));
				((JavascriptExecutor) driver).executeScript(FrameworkConstant.JAVASCRIPT_SCROLL_TRUE, elem);
				elem.click();
				logger.info(ReportLoggerConstant.MONTH_MSG + month + ReportLoggerConstant.SELECTED_MSG);
			}
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				logger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				logger.error(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
				throw new CATTException(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
			} else {
				logger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		}
	}

	/**
	 * @param driver
	 * @param dateUI
	 * @param testCaseDetail
	 * @author mshaik
	 */
	public static void selectDay(String day, TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		String expDay = "//*[@class='rdtPicker']//*[text()='" + day + "' and @class ='rdtDay']";
		try {
			if (driver.findElement(By.xpath(expDay)).isDisplayed()) {
				WebElement elem = driver.findElement(By.xpath(expDay));
				((JavascriptExecutor) driver).executeScript(FrameworkConstant.JAVASCRIPT_SCROLL_TRUE, elem);
				elem.click();
				logger.info(ReportLoggerConstant.DAY_MSG + day + ReportLoggerConstant.SELECTED_MSG);
			}
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				logger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				logger.error(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
				throw new CATTException(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
			} else {
				logger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		}
	}
}
