package com.cassiopae.framework.to;

public class XlsFileRowDetails {


	String className;
	String methodName;
	String priority;
	String domain;
	String testType;
	String dependsOnScenerio;
	String browser;
	String rowNum;
	String suiteName;
	String tcVersion;
	String endCompatibiltyVersion;
	
	public String getTCVersion() {
		return tcVersion;
	}

	public void setTCVersion(String tcVersion) {
		this.tcVersion = tcVersion;
	}

	/**
	 * @return the browser
	 */
	public String getBrowser() {
		return browser;
	}

	/**
	 * @param p_browser
	 *                      the browser to set
	 */
	public void setBrowser( final String p_browser ) {
		browser = p_browser;
	}

	/**
	 * @return the className
	 */
	public String getClassName() {
		return className;
	}

	/**
	 * @param p_className
	 *                        the className to set
	 */
	public void setClassName( final String p_className ) {
		className = p_className;
	}

	/**
	 * @return the methodName
	 */
	public String getMethodName() {
		return methodName;
	}

	/**
	 * @param p_methodName
	 *                         the methodName to set
	 */
	public void setMethodName( final String p_methodName ) {
		methodName = p_methodName;
	}

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * @param p_priority
	 *                       the priority to set
	 */
	public void setPriority( final String p_priority ) {
		priority = p_priority;
	}

	/**
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * @param p_domain
	 *                     the domain to set
	 */
	public void setDomain( final String p_domain ) {
		domain = p_domain;
	}

	/**
	 * @return the testType
	 */
	public String getTestType() {
		return testType;
	}

	/**
	 * @param p_testType
	 *                       the testType to set
	 */
	public void setTestType( final String p_testType ) {
		testType = p_testType;
	}

	/**
	 * @return the dependsOnScenerio
	 */
	public String getDependsOnScenerio() {
		return dependsOnScenerio;
	}

	/**
	 * @param p_dependsOnScenerio
	 *                                the dependsOnScenerio to set
	 */
	public void setDependsOnScenerio( final String p_dependsOnScenerio ) {
		dependsOnScenerio = p_dependsOnScenerio;
	}

	
	public String getRowNum() {
		return rowNum;
	}

	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}

	public String getSuiteName() {
		return suiteName;
	}

	public void setSuiteName(String suiteName) {
		this.suiteName = suiteName;
	}

	/**
	 * @return the endCompatibiltyVersion
	 */
	public String getEndCompatibiltyVersion() {
		return endCompatibiltyVersion;
	}

	/**
	 * @param endCompatibiltyVersion the endCompatibiltyVersion to set
	 */
	public void setEndCompatibiltyVersion(String endCompatibiltyVersion) {
		this.endCompatibiltyVersion = endCompatibiltyVersion;
	}


}
