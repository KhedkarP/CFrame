/**
 * 
 */

package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;

/**
 * @author jraut
 *
 */
public class AssertNotEqualsValidation implements PerformValidation {

    @Override
    public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
	testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
	String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),excelTestCaseFieldsTO.getExpectedResult());
	String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),excelTestCaseFieldsTO.getActualValue());
	GenericAction.assertNotEquals(variableHolderActualValue, variableHolderExpectedValue,excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
    }

}
