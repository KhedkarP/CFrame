package com.cassiopae.framework.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.to.ErrorValidation;
import com.cassiopae.framework.to.XlsFileRowDetails;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

public class DashboardProcessingUtility {

	private DashboardProcessingUtility() {

	}

	private static Logger logger = LogManager.getLogger(DashboardProcessingUtility.class);

	public static void processDashboard(DashboardDetails dashboardDetails) {
		DashboardExcelReadOperation.readDashboardExcel(dashboardDetails);
		createXlsFileRowDetailsObject(dashboardDetails);
	}

	private static void createXlsFileRowDetailsObject(DashboardDetails dashboardDetails) {

		Map<String, LinkedList<String>> projectTestCase = dashboardDetails.getProjectTestCase();
		Map<String, LinkedList<XlsFileRowDetails>> xlsFileRowDetailsMap = dashboardDetails.getXlsFileRowDetailsMap();
		Map<String, Map<String, Integer>> mapOfClassWithMethodPriority = dashboardDetails
				.getMapOfClassWithMethodPriority();
		Map<String, ArrayList<String>> mapOfClassMethod = dashboardDetails.getMapOfClassMethod();

		LinkedList<XlsFileRowDetails> xlsFileRowDetailsList = null;
		List<String> methodList = null;
		if (null != projectTestCase) {
			for (String name : projectTestCase.keySet()) {
				List<String> value = projectTestCase.get(name);
				XlsFileRowDetails xlsFileRowDetails = new XlsFileRowDetails();
				xlsFileRowDetails.setClassName(value.get(InitializeConstants.test_case_workbook_name_column));
				xlsFileRowDetails.setDependsOnScenerio(value.get(InitializeConstants.test_case_dependancy_column));
				xlsFileRowDetails.setDomain(dashboardDetails.getDomainName());
				xlsFileRowDetails.setMethodName(value.get(InitializeConstants.test_case_worksheet_name_column));
				xlsFileRowDetails.setPriority(value.get(InitializeConstants.test_case_priority_column));
				xlsFileRowDetails.setTestType(value.get(InitializeConstants.test_type_column));
				xlsFileRowDetails.setBrowser(value.get(InitializeConstants.browser_column));
				xlsFileRowDetails.setRowNum(value.get(InitializeConstants.serial_num));
				if (xlsFileRowDetailsMap.containsKey(value.get(InitializeConstants.test_case_workbook_name_column))) {
					xlsFileRowDetailsList = xlsFileRowDetailsMap
							.get(value.get(InitializeConstants.test_case_workbook_name_column));
					xlsFileRowDetailsList.add(xlsFileRowDetails);
					methodList = mapOfClassMethod.get(value.get(InitializeConstants.test_case_workbook_name_column));
					methodList.add(xlsFileRowDetails.getMethodName());
				} else {
					xlsFileRowDetailsList = new LinkedList<>();
					xlsFileRowDetailsList.add(xlsFileRowDetails);
					xlsFileRowDetailsMap.put(xlsFileRowDetails.getClassName(), xlsFileRowDetailsList);
					methodList = new ArrayList<>();
					methodList.add(xlsFileRowDetails.getMethodName());
					mapOfClassMethod.put(xlsFileRowDetails.getClassName(), (ArrayList<String>) methodList);
				}
				try {
					if (mapOfClassWithMethodPriority.containsKey(xlsFileRowDetails.getClassName())) {
						Map<String, Integer> map = mapOfClassWithMethodPriority.get(xlsFileRowDetails.getClassName());
						map.put(xlsFileRowDetails.getMethodName(), Integer.valueOf(xlsFileRowDetails.getPriority()));
					} else {
						Map<String, Integer> methodPriorityMap = new HashMap<>();
						methodPriorityMap.put(xlsFileRowDetails.getMethodName(),
								Integer.valueOf(xlsFileRowDetails.getPriority()));
						mapOfClassWithMethodPriority.put(xlsFileRowDetails.getClassName(), methodPriorityMap);
					}
				} catch (Exception e) {
					logger.error("For test case: " + xlsFileRowDetails.getRowNum() + " || Test case workbook name:  "
							+ xlsFileRowDetails.getClassName() + " || Test case worksheet:  "
							+ xlsFileRowDetails.getMethodName()
							+ "|| ==> Priority cannot be blank/null/String. It should be a numeric starting from 1.");
					return;
				}
			}
			logger.info(ReportLoggerConstant.WORKBOOK_QUALIFIED_FOR_PROCESSING + dashboardDetails.getDomainName()
					+ " Domain is " + xlsFileRowDetailsMap.size());
		}
	}

	public static boolean isClassExist(final String className) {
		try {
			Class.forName(className);
			return true;
		} catch (ClassNotFoundException e) {
			return false;
		}
	}

	private static String getFullyQualifiedClassNameForClient(String domainName, String testType, String className) {
		String fullyQualifiedClass = "";
		if (testType.contains(FrameworkConstant.TEST_TYPE_SAN_QA)) {
			fullyQualifiedClass = CommonUtility.getClassifiedNameOfPackageForClient(domainName,
					CommonConstant.SANITY_PACKAGE_NAME) + CommonConstant.DOT_OPERATOR + className;
		} else {
			fullyQualifiedClass = CommonUtility.getClassifiedNameOfPackageForClient(domainName,
					CommonConstant.REGRESSION_PACKAGE_NAME) + CommonConstant.DOT_OPERATOR + className;
		}
		return fullyQualifiedClass;
	}

	public static String getPackageNameForCLient(String domainName, String testType) {
		String fullyQualifiedClass = "";
		if (testType.contains(FrameworkConstant.TEST_TYPE_SAN_QA)) {
			fullyQualifiedClass = CommonUtility.getClassifiedNameOfPackageForClient(domainName,
					CommonConstant.SANITY_PACKAGE_NAME);
		} else {
			fullyQualifiedClass = CommonUtility.getClassifiedNameOfPackageForClient(domainName,
					CommonConstant.REGRESSION_PACKAGE_NAME);
		}
		return fullyQualifiedClass;
	}

	public static String createClassNamAndJavaFile(Map<String, LinkedList<XlsFileRowDetails>> xlsFileRowDetailsMap) {
		String className = null;

		for (Map.Entry<String, LinkedList<XlsFileRowDetails>> entry : xlsFileRowDetailsMap.entrySet()) {
			className = getFullyQualifiedClassNameForClient(entry.getValue().get(0).getDomain(),
					entry.getValue().get(0).getTestType(), entry.getValue().get(0).getClassName());
			if (!isClassExist(className)) {
				createJavaFileFromDashboardTestCase(entry.getValue());
			} else {
				String filePath = getAbsoluteFilePathForClient(entry.getValue().get(0).getDomain(),
						entry.getValue().get(0).getTestType(), entry.getValue().get(0).getClassName());
				File classNameFile = new File(filePath);
				ExcelOperation.deleteExistingFile(classNameFile.toPath());
				createJavaFileFromDashboardTestCase(entry.getValue());
			}
		}
		return className;
	}

	private static String getAbsoluteFilePathForClient(String domainName, String testType, String className) {
		String absolutePath = null;
		if (testType.contains(FrameworkConstant.TEST_TYPE_SAN_QA)) {
			absolutePath = CommonUtility.getSourcePackageFolderPathForClient(domainName,
					CommonConstant.SANITY_PACKAGE_NAME) + File.separator + className
					+ CommonConstant.JAVA_FILE_EXTENSION;
		} else {
			absolutePath = CommonUtility.getSourcePackageFolderPathForClient(domainName,
					CommonConstant.REGRESSION_PACKAGE_NAME) + File.separator + className
					+ CommonConstant.JAVA_FILE_EXTENSION;
		}
		return absolutePath;

	}
	
	private static String getAbsolutePackagePathForClient(String domainName, String testType, String className) {
		String absolutePath = null;
		if (testType.contains(FrameworkConstant.TEST_TYPE_SAN_QA)) {
			absolutePath = CommonUtility.getSourcePackageFolderPathForClient(domainName,
					CommonConstant.SANITY_PACKAGE_NAME) ;
		} else {
			absolutePath = CommonUtility.getSourcePackageFolderPathForClient(domainName,
					CommonConstant.REGRESSION_PACKAGE_NAME);
		}
		return absolutePath;

	}

	public static void createJavaFileFromDashboardTestCase(final List<XlsFileRowDetails> dataList) {
		try {
			String absolutePath = null;
			String className = null;
			String packageName = null;
			String packageAbsolutePath = null;
			className = dataList.get(0).getClassName();
			packageName = getPackageNameForCLient(dataList.get(0).getDomain(), dataList.get(0).getTestType());
			absolutePath = getAbsoluteFilePathForClient(dataList.get(0).getDomain(), dataList.get(0).getTestType(),
					className);
			packageAbsolutePath = getAbsolutePackagePathForClient(dataList.get(0).getDomain(), dataList.get(0).getTestType(),
					className);
			FileUtility.createNewDirectory(packageAbsolutePath);
			CreateJavaFileUtility.generateJavaFile(dataList, absolutePath,packageAbsolutePath, className, packageName);
			logger.info("Test class created for execution : " + className);

		} catch (Exception e) {
			logger.info(e);
		}
	}

	public static StringBuilder getMessage(ErrorValidation errorValidation) {
		StringBuilder errorMessage = new StringBuilder();
		errorMessage.append("Please correct test case entry in 'Test_Case_Summary' excel file ");
		if (!StringUtils.isEmpty(errorValidation.getRowNumber())) {
			errorMessage.append(ErrorMessageConstant.FOR_TICKET)
					.append(errorValidation.getRowNumber() + CommonConstant.SPACE + CommonConstant.COMMA_SEPERATOR);
		}
		errorMessage.append(errorValidation.getErrorMassage());
		/*
		 * if (!StringUtils.isEmpty(Validation.getWorkBookName())) {
		 * errorMessage.append(ErrorMessageConstant.TEST_CASE_WORKBOOK_NAME).append(
		 * errorValidation.getWorkBookName()); } if
		 * (!StringUtils.isEmpty(errorValidation.getWorkSheetName())) {
		 * errorMessage.append(ErrorMessageConstant.TEST_CASE_WORKSHEET_NAME)
		 * .append(errorValidation.getWorkSheetName()); }
		 */

		return errorMessage;
	}

	public static void generateErrorFile() {
		String filePath = CommonUtility.getAbsolutePathForErrorFile();
		try {
			File erroeFile = new File(filePath);
			if (erroeFile.createNewFile()) {
				logger.info("Error file created successfully  with file name :- " + CommonConstant.ERROR_FILE_NAME);
			}
		} catch (Exception e) {
			logger.error(e);
		}

	}

	public static Map<String, List<XlsFileRowDetails>> getXlsFileRowDetailsMapForClass(String domainName,
			Map<String, LinkedList<String>> testCaseMap) {
		Map<String, List<XlsFileRowDetails>> xlsFileRowDetailsMap = new LinkedHashMap<>();
		List<XlsFileRowDetails> xlsFileRowDetailsList = null;
		if (null != testCaseMap && !testCaseMap.isEmpty()) {
			for (String name : testCaseMap.keySet()) {
				List<String> values = testCaseMap.get(name);
				XlsFileRowDetails xlsFileRowDetails = new XlsFileRowDetails();
				String className = getFullyQualifiedClassNameForClient(domainName,
						values.get(InitializeConstants.test_type_column),
						values.get(InitializeConstants.test_case_workbook_name_column));
				xlsFileRowDetails.setClassName(className);
				xlsFileRowDetails.setDependsOnScenerio(values.get(InitializeConstants.test_case_dependancy_column));
				xlsFileRowDetails.setDomain(domainName);
				xlsFileRowDetails.setMethodName(values.get(InitializeConstants.test_case_worksheet_name_column));
				xlsFileRowDetails.setPriority(values.get(InitializeConstants.test_case_priority_column));
				xlsFileRowDetails.setTestType(values.get(InitializeConstants.test_type_column));
				xlsFileRowDetails.setBrowser(values.get(InitializeConstants.browser_column));
				xlsFileRowDetails.setRowNum(values.get(InitializeConstants.serial_num));
				xlsFileRowDetails.setSuiteName(values.get(InitializeConstants.suiteName_Column));
				xlsFileRowDetails.setTCVersion(values.get(InitializeConstants.tcVersion_Column));
				xlsFileRowDetails.setEndCompatibiltyVersion(values.get(InitializeConstants.endCompatibilityVersion));

				if (xlsFileRowDetailsMap.containsKey(xlsFileRowDetails.getClassName())) {
					xlsFileRowDetailsList = xlsFileRowDetailsMap.get(xlsFileRowDetails.getClassName());
					xlsFileRowDetailsList.add(xlsFileRowDetails);
				} else {
					xlsFileRowDetailsList = new ArrayList<>();
					xlsFileRowDetailsList.add(xlsFileRowDetails);
					xlsFileRowDetailsMap.put(xlsFileRowDetails.getClassName(), xlsFileRowDetailsList);
				}
			}
		}
		return xlsFileRowDetailsMap;
	}

}
