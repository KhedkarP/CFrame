/**
 *
 */
package com.cassiopae.framework.to;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nbhil
 */
public class ExcelMasterData {

	private List<ExcelTestCaseFields> excelTestCaseFieldsList = new ArrayList<>();
	private String status;
	private List<ErrorValidation> erroValidationList = new ArrayList<>();
	private String workBookName;
	private String workSheetName;

	public List<ExcelTestCaseFields> getExcelTestCaseFieldsList() {
		return excelTestCaseFieldsList;
	}

	public void setExcelTestCaseFieldsList(List<ExcelTestCaseFields> excelTestCaseFieldsList) {
		this.excelTestCaseFieldsList = excelTestCaseFieldsList;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus( final String status ) {
		this.status = status;
	}

	public List<ErrorValidation> getErroValidationList() {
		return erroValidationList;
	}

	public void setErroValidationList( final List<ErrorValidation> erroValidationList ) {
		this.erroValidationList = erroValidationList;
	}

	public String getWorkBookName() {
		return workBookName;
	}

	public void setWorkBookName( final String workBookName ) {
		this.workBookName = workBookName;
	}

	public String getWorkSheetName() {
		return workSheetName;
	}

	public void setWorkSheetName( final String tabName ) {
		this.workSheetName = tabName;
	}
}
