package com.cassiopae.webservices.action;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.webservices.action.util.SoapWSUtility;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class SOAPAPIPOSTRequest implements WSAction {

    public final String  Utf8Encoding = "UTF-8";

    public final String SoapBodyText="soapenv:Body";

    public final String XmlOneLineCloseTageSlash="</";

    @Override
    public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
        /*
         * Reading input data parameters
         */
        String productName = testCaseDetailTO.getTestCaseCommonData().getDomainName();
        Logger reportingLogger = testCaseDetailTO.getReportingLogger();
        reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
        String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData().trim(),
                CommonConstant.PIPE_SEPARATOR);
        String[] fileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]).split(Pattern.quote(","));
        String[] headerParameters = CommonUtility.splitStringUsingPattern(inputData[1], CommonConstant.COMMA_SEPERATOR);
        String endPointURL = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
                headerParameters[0]);
        String[] apiInputParameters = null;
        if (inputData.length > 2) {
            apiInputParameters = CommonUtility.splitStringUsingPattern(inputData[2], CommonConstant.COMMA_SEPERATOR);
            for (int i = 0; i <apiInputParameters.length ; i++ ) {
                String eachApiInputParameters=apiInputParameters[i];
                eachApiInputParameters=eachApiInputParameters.replace(CommonConstant.EnvelopSoapRequestBodyConstant,"");
                String[] part3 =eachApiInputParameters.split(CommonConstant.COLON_SEPERATOR);
                String[] part4 =part3[1].split(Pattern.quote(CommonConstant.DOT_OPERATOR));
                eachApiInputParameters=eachApiInputParameters.replace(part3[0]+CommonConstant.COLON_SEPERATOR+part4[0]+CommonConstant.DOT_OPERATOR,"");
                apiInputParameters[i]=eachApiInputParameters;
            }
        }
        String[] storedVariables = CommonUtility.splitStringUsingPattern(
                excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);

        /*
         * InitializeDomainWiseRestAPIRequest folder path
         */
        String requestPath = DomainInitialization.initializeDomainWiseRestAPIRequestsPath(productName);
        /*
         * Create API response folder
         */
        String responseFolderPath = SoapWSUtility.createAPIResponseFolder(productName,
                testCaseDetailTO.getWorkBookName(), testCaseDetailTO.getWorkSheetName());
        /*
         * Checking API request folder is available or not
         */
        String parentFileStatus = SeleniumUtility.checkFileIsAvailableAtLocationOrNOT(requestPath, reportingLogger, fileName[0]);
        if (parentFileStatus.equals(CommonConstant.TRUE_VALUE)) {
            /* ReadJSon file from location and parse to JSON Object */
//			SoapWSUtility.readJsonFile(reportingLogger, requestPath, fileName);


            String parentXmlObject = null;
            try {
                parentXmlObject = IOUtils.toString(new FileInputStream(requestPath + File.separator + fileName[0]), Utf8Encoding);
                parentXmlObject.replace("\n", "").replace("\r", "");
            } catch (IOException e) {
                e.printStackTrace();
            }



            String headerPart=parentXmlObject.split(CommonConstant.LESS_THAN_OPERATOR+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR)[0];
            String bodyPart=parentXmlObject.split(CommonConstant.LESS_THAN_OPERATOR+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR)[1].split(XmlOneLineCloseTageSlash+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR)[0];
            String footerPart=parentXmlObject.split(CommonConstant.LESS_THAN_OPERATOR+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR)[1].split(XmlOneLineCloseTageSlash+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR)[1];
            String fistTageName=getStartOfTageNameFromString(bodyPart);
            String childXmlObject=bodyPart.replace(CommonConstant.LESS_THAN_OPERATOR+fistTageName+CommonConstant.GREATER_THAN_SEPERATOR,"").replace(XmlOneLineCloseTageSlash+fistTageName+CommonConstant.GREATER_THAN_SEPERATOR,"");


            /*
				Will read child XML File
			*/
            /*String childXmlObject = null;
            try {
                childXmlObject = IOUtils.toString(new FileInputStream(requestPath + File.separator + fileName[1]), Utf8Encoding);
            } catch (IOException e) {
                e.printStackTrace();
            }*/

			/*
				Update Child requests by converting XML to JSON
			*/

            JSONObject jsontest = XML.toJSONObject(childXmlObject);
            String childConvertedJsonString = jsontest.toString(4);
            /*
             * Will perform edit operation on Child Json i.e child XML
             * */

            String updatedChildConvertedJsonString = SoapWSUtility.updateSOAPAPIRequest(apiInputParameters, childConvertedJsonString, testCaseDetailTO);

            /*
             * will conver JSON to XML string
             * */

            JSONObject jsons = new JSONObject(updatedChildConvertedJsonString.replace("\n", "").replace("\r", ""));
            String updatedXMLString = XML.toString(jsons);

//            parentXmlObject= parentXmlObject.replace( fileName[1],updatedXMLString).replace("\n", "").replace("\r", "");


            String SOAPAPIRequestString=headerPart+CommonConstant.LESS_THAN_OPERATOR+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR+CommonConstant.LESS_THAN_OPERATOR+fistTageName+CommonConstant.GREATER_THAN_SEPERATOR+updatedXMLString+XmlOneLineCloseTageSlash+fistTageName+CommonConstant.GREATER_THAN_SEPERATOR+XmlOneLineCloseTageSlash+SoapBodyText+CommonConstant.GREATER_THAN_SEPERATOR+footerPart;

            /*
             * Save Updated Json file at API responses folder
             */
            SoapWSUtility.saveSOAPAPIFiles(fileName[0], WSReportingLoggerConstant.REQUEST_NAME, responseFolderPath, SOAPAPIRequestString);

            /* Get SOAP URI end point */
            reportingLogger.info(SOAPAPIRequestString);

            ExtractableResponse<Response> extractResponse = SoapWSUtility.executeSOAPAPIPOSTRequestService(SOAPAPIRequestString, endPointURL, testCaseDetailTO);
//			SOAPWSUtility.executeSOAPAPIPOSTRequestService(endPointURL,parentXmlObject);

            String statusCode = SoapWSUtility.getResponseData(extractResponse,WSReportingLoggerConstant.STATUSCODE_MSG);
            String responseBody = SoapWSUtility.getResponseData(extractResponse,WSReportingLoggerConstant.RESPONSEBODY_MSG);
            reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Code + statusCode);
            reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + responseBody);
            if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
                testCaseDetailTO.getVariableHolder().put(storedVariables[0], statusCode);
                testCaseDetailTO.getVariableHolder().put(storedVariables[1], responseBody.replace("\n", "").replace("\r", ""));
            }

            SoapWSUtility.saveSOAPAPIFiles(fileName[0], WSReportingLoggerConstant.RESPONSE_NAME, responseFolderPath,responseBody);


        }

    }
    private String getStartOfTageNameFromString(String xmlStringObject)
    {
        int indexOfStart= xmlStringObject.indexOf("<" );
        int indexOfEnd= xmlStringObject.indexOf(">");
        return xmlStringObject.substring(indexOfStart+1,indexOfEnd);
    }
}
