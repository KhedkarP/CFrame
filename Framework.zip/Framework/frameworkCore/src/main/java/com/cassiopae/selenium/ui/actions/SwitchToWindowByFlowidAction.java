/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.services.SeleniumUtility;

/**
 * @author Priti
 *
 */
public class SwitchToWindowByFlowidAction implements PerformAction {

	/**
	 * This method execute action for switch to window action by using flow id.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields'
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		WebDriver driver = SeleniumUtility.switchToWindowByFlowid(excelTestCaseFieldsTO.getInputTestData(),testCaseDetailTO);
		testCaseDetailTO.setDriver(driver);

	}

}

