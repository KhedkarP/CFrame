/**
 * 
 */
package com.cassiopae.selenium.ui.actions;


import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author jraut
 *
 */
public class ExternalWait implements PerformAction {

	private static Logger logger = LogManager.getLogger(ExternalWait.class);
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps() +" : "+ excelTestCaseFieldsTO.getInputTestData() +" milliseconds");
		try {
			Thread.sleep(Integer.parseInt(excelTestCaseFieldsTO.getInputTestData()));
		} catch (NumberFormatException | InterruptedException e) {
			logger.debug(e);
		}
		
	}

}
