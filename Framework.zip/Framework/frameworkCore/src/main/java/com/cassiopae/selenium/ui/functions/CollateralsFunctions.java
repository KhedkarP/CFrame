
package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class CollateralsFunctions {

	private static Map<String, List<String>> collateralLocatorMap = ObjectRepoInitialization.masterLocatorMap
			.get(ObjectRepoInitialization.COLLATERAL_LOCATROR);

	public static void navigateTo(WebDriver driver, Logger logger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.COLLATERAL_MOUSE_HOVER,
				FunctionLocatorConstant.COLLATERAL_MENU, collateralLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.COLLATERALSUB_MENU,
				FunctionLocatorConstant.COLLATERALS_SUB_MENU, collateralLocatorMap, driver, logger);
	}

	public static void open(String reference, ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_COLLATERAL_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.COLLATERALS_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(collateralLocatorMap);
		GenericAction.enterValueIn(reference, excelTestCaseFields, testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_COLLATERAL_REFERENCE_ICON,
				FunctionLocatorConstant.COLLATERALS_SEARCH_ICON, collateralLocatorMap, testCaseDetail.getDriver(),
				testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_COLLATERAL_REFERENCE_HYPERLINK + reference,
				FunctionLocatorConstant.COLLATERALS_REFERNCE_HYPERLINK, collateralLocatorMap,
				testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
