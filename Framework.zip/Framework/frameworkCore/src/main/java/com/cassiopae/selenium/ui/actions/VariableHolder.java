/**
 *
 */
package com.cassiopae.selenium.ui.actions;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.util.constant.CommonConstant;

/**
 * @author jraut
 */
public class VariableHolder {

	private VariableHolder() {

	}

	public static String getValueFromVariableHolder( final Map<String, String> variableHolder, final String variableHolderKey ) {
		String returnValue = null;
		if ( !StringUtils.isEmpty( variableHolderKey ) &&
			 variableHolderKey.trim().startsWith( CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR ) &&
			 variableHolderKey.trim().endsWith( CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR ) ) {
			String variableKey = variableHolderKey.trim();
			returnValue = variableHolder.get( variableKey.substring( 2, variableKey.length() - 1 ) );
		}
		else {
			returnValue = variableHolderKey;
		}
		return returnValue;

	}
}
