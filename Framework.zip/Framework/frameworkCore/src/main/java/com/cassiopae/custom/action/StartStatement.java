package com.cassiopae.custom.action;

import com.cassiopae.custom.action.constant.CustomConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 */

public class StartStatement implements CustomAction {

	@Override
	public void performCustomAction(final ExcelTestCaseFields p_excelTestCaseFieldsTO,
			final TestCaseDetail p_testCaseDetailTO) {
		p_testCaseDetailTO.getReportingLogger().info(p_excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputDataValues = CommonUtility.splitStringUsingPattern(p_excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		if (!VariableHolder.getValueFromVariableHolder(p_testCaseDetailTO.getVariableHolder(), inputDataValues[0])
				.equals(VariableHolder.getValueFromVariableHolder(p_testCaseDetailTO.getVariableHolder(),
						inputDataValues[1]))) {
			p_testCaseDetailTO.getVariableHolder().put(CustomConstant.START_STATEMENT, CommonConstant.YES);
		}
	}

}
