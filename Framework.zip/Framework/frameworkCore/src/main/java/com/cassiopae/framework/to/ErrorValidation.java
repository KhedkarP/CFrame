package com.cassiopae.framework.to;

public class ErrorValidation {

	private String rowNumber;
	private String errorMassage;
	private String workBookName;
	private String workSheetName;

	public String getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(final String rowNumber) {
		this.rowNumber = rowNumber;
	}

	public String getErrorMassage() {
		return errorMassage;
	}

	public void setErrorMassage(final String errorMassage) {
		this.errorMassage = errorMassage;
	}

	public String getWorkBookName() {
		return workBookName;
	}

	public void setWorkBookName(final String workBookName) {
		this.workBookName = workBookName;
	}

	public String getWorkSheetName() {
		return workSheetName;
	}

	public void setWorkSheetName(final String tabName) {
		this.workSheetName = tabName;
	}

}
