/**
 *
 */
package com.cassiopae.framework.util;

import java.util.Map;

import com.cassiopae.framework.dao.constant.DBConstant;
import org.apache.logging.log4j.*;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;
import org.testng.ITestResult;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.service.PostTestCaseExecutor;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelMasterData;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.CFrameManager;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.InstructionExecutor;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.utils.driver.DriverDefination;

/**
 * @author nbhil
 */
public class FrameworkUtil {

    private static Logger logger = LogManager.getLogger(FrameworkUtil.class);

    private FrameworkUtil() {}

    /**
     * This method populate the TestCaseCommonData. This method is called from
     * beforeMethod.
     * 
     * @param testCaseCommonData TestCaseCommonData
     * @param browserName        String
     * @param workSheetName      String
     * @param workBookName       String
     * @param domainName         String
     * @return testCaseCommonData
     */
    public static void populateTestCaseCommonData(TestCaseCommonData testCaseCommonData, final String browserName,
	    final String workSheetName, final String workBookName, final String domainName,
			Map<String, String> variableHolder) {
		testCaseCommonData.setVariableHolder(variableHolder);
		testCaseCommonData.setBrowserName(browserName);
		testCaseCommonData.setDomainName(domainName);
		testCaseCommonData.setWorkBookName(workBookName);
		testCaseCommonData.setWorkSheetName(workSheetName);

		try {
			ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization.initializeDomainTestEnvDetailExcelPath(testCaseCommonData.getDomainName());
			ApplicationConstant.initializeEnvspecificTestDataPath = DomainInitialization
					.initializeDomainTestDataExcelPath(testCaseCommonData.getDomainName());
			ApplicationConstant.objectRepositoryPath = DomainInitialization.initializeProductWiseORFilePath(domainName);
			Map<String, String> newDriverInstance;
			newDriverInstance = DriverDefination.getNewDriverInstanceMap(testCaseCommonData.getBrowserName(),
					testCaseCommonData.getWorkSheetName(), testCaseCommonData.getDomainName());
			testCaseCommonData.setNewDriverInstance(newDriverInstance);
			if (ApplicationContext.neoLoadScriptCreation) {
				String neoLoadProjectsDirectory = DomainInitialization
						.initializeDomainWiseNeoLoadProjectsPath(testCaseCommonData.getDomainName());
				String nlpLocation = FileUtility.getNeoLoadProjectPath(neoLoadProjectsDirectory,
						testCaseCommonData.getWorkBookName());
				testCaseCommonData.setNeoLoadProjectsPath(nlpLocation);
			}
			
			/*int testDataRowNo = ExcelReader.getTestDataRowNumber(testCaseCommonData.getWorkSheetName(),
					testCaseCommonData.getWorkBookName(), testCaseCommonData.getDomainName());
			testCaseCommonData.setTestDataRowNo(testDataRowNo);*/
			
			Map<String, Integer> testDataRowDetailMap = ExcelReader.getTestDataRowDetails(workSheetName, workBookName, domainName);
			testCaseCommonData.setMaxDataSetRowNum(testDataRowDetailMap.get(CommonConstant.MAX_DATA_SET_ROW_NUM));
			testCaseCommonData.setTestDataHeaderRowNum(testDataRowDetailMap.get(CommonConstant.DATA_SET_HEADER_ROW_NUM));
			
		} catch (CATTException exception) {
			logger.error(exception.getMessage(), exception);
			Assert.fail(exception.getMessage());
		}
	}

    /**
     * This method will be called from test method.
     * 
     * @param testCaseCommonData TestCaseCommonData
     * @param testCaseDetail     TestCaseDetail
     * @param worksheetName      String
     * @param variableHolder     Map<String, String>
     * @param testCaseRepoPath   String
     */
    public static void executeTest(TestCaseCommonData testCaseCommonData, final TestCaseDetail testCaseDetail,
			String worksheetName, String testCaseRepoPath) {
		try {
			FrameworkCommonUtility.updateTestCaseCommonData(testCaseCommonData, worksheetName, testCaseRepoPath);
			FrameworkCommonUtility.populateCurrentTestCase(testCaseCommonData);
			if (!testCaseCommonData.getWorkSheetName().contains(DBConstant.API_APP_SHEET_NAME))
			{
				FrameworkCommonUtility.launchBrowser(testCaseCommonData);
			}
			ApplicationConstant.objectRepositoryPath=DomainInitialization.initializeProductWiseORFilePath(testCaseCommonData.getDomainName());
			Map<String, ExcelMasterData> workSheetMap = ExcelReader.readTestCaseDataFile(testCaseCommonData);
			ExcelMasterData excelMasterData = workSheetMap.get(testCaseCommonData.getWorkSheetName());
			FrameworkCommonUtility.updateTestCaseDetails(testCaseCommonData, testCaseDetail);
			FrameworkCommonUtility.printLogger(testCaseCommonData);
			FrameworkCommonUtility.populateAppInfoOfEnv(testCaseDetail);
			if (!CommonConstant.FAILUARE_STATUS.equals(excelMasterData.getStatus())) {
				testCaseDetail.setExcelTestCaseFieldsList(excelMasterData.getExcelTestCaseFieldsList());
				InstructionExecutor.executeTestAction(testCaseDetail);
			} else {
				String message = FrameworkCommonUtility.logError(excelMasterData, testCaseDetail);
				Assert.fail(message);
			}

		} catch (CATTException | NoSuchElementException | StaleElementReferenceException | ElementClickInterceptedException | AssertionError exception) {
			logger.error(exception.getMessage());
			if (CurrentTestCase.getCurrentrownumber().get() != null) {
				testCaseCommonData.getReportingLogger().error(
						"Test Case is failed at step/row number is : " + CurrentTestCase.getCurrentrownumber().get());
			}
			Assert.fail(exception.getMessage(),exception);
		}

	}

    /**
     * This method will be called from afterTestMethod.
     * 
     * @param testResult         ITestResult
     * @param testCaseCommonData TestCaseCommonData
     */
	public static void postTestCaseExecution(final ITestResult testResult, TestCaseCommonData testCaseCommonData) {
		PostTestCaseExecutor postTestCaseExecutor = new PostTestCaseExecutor();
		if (!testResult.isSuccess()) {
			if (null != testCaseCommonData.getDriver()) {
				CFrameManager.copyUAIDtoFile(testCaseCommonData.getDriver(), testCaseCommonData.getDomainName(),
					testCaseCommonData.getWorkBookName(), testCaseCommonData.getWorkSheetName());
				testCaseCommonData.getReportingLogger().info(ReportLoggerConstant.LOGOUT_FROM_APPLICATION_MESSSAGE);
				CommonFunctions.logoutOperationForFailedTC(testCaseCommonData.getWorkSheetName(),
						testCaseCommonData.getReportingLogger(), testCaseCommonData.getDriver(),
						testCaseCommonData.getDomainName());
			}
		}
		if (!testCaseCommonData.getWorkSheetName().contains(DBConstant.API_APP_SHEET_NAME))
		{
			DriverDefination.closeDriver(testCaseCommonData);
		}
		String errorMessage = null;
		errorMessage = postTestCaseExecutor.getErrorMessageFromITestListener(testResult);
		postTestCaseExecutor.postTestCaseExecutionActivity(testCaseCommonData,
				Long.toString(((testResult.getEndMillis() - testResult.getStartMillis()) / 60000)), testResult,
				testCaseCommonData.getIssue(), ApplicationConstant.excelStatusSheetName, errorMessage);
	}
}
