
package com.cassiopae.selenium.utils.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.Assert;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.TestCaseDataRow;
import com.cassiopae.framework.util.DashboardExcelReadOperation;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;

public class ExcelOperation {

	private static Logger tracelogger = LogManager.getLogger(ExcelOperation.class);

	// ************************** Excel
	// Read-Write/Row-Number/GetTestData/ObjectLocatore/MethodName/ENV details
	// Methods ***********************//

	public static synchronized String excelAction(final String method, final int row, final int column,
			final String sheetName, final String domainName, final String value) {
		String testCaseSummaryExcelpath = DomainInitialization.initializeDomainTestDataExcelPath(domainName);
		Path backupFile = Paths
				.get(testCaseSummaryExcelpath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		Boolean flag = false;
		File inputWorkbook = null;
		boolean isfileFreetoProcess = true;// waitForFileAvailability(testDataExcelpath);
		if (isfileFreetoProcess) {
			inputWorkbook = new File(testCaseSummaryExcelpath);
			String data = null;
			flag = dashboardExcelWriteOperation(method, row, column, sheetName, value, testCaseSummaryExcelpath,
					backupFile, flag, inputWorkbook);
			if (method.equalsIgnoreCase(ReportLoggerConstant.READ_LABEL)) {
				excelBackupCreate(testCaseSummaryExcelpath, backupFile);
				if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
					try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
						FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
						for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
							if (workbook.getSheetName(i).equals(sheetName)) {
								flag = true;
								break;
							}
						}
						DataFormatter dataFormatter = new DataFormatter();
						if (flag) {
							try {
								Sheet sheet = workbook.getSheet(sheetName);
								Cell cell = sheet.getRow(row).getCell(column);
								data = dataFormatter.formatCellValue(cell);
							} catch (Exception exp) {
								tracelogger.error(exp.getMessage(), exp);
							}
							if (inputWorkbook.length() > 0) {
								deleteExistingFile(backupFile);
							} else {
								tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
								try {
									Files.delete(inputWorkbook.toPath());
									Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
									//
								} catch (IOException exp) {
									tracelogger.error(exp.getMessage(), exp);
								} catch (Exception exp) {
									tracelogger.error(exp.getMessage(), exp);
								}
							}
						} else {
							tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK);
							if (inputWorkbook.length() > 0) {
								deleteExistingFile(backupFile);
							} else {
								tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
								try {
									Files.delete(inputWorkbook.toPath());
									Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
								} catch (Exception exp) {
									tracelogger.error(exp.getMessage(), exp);
								}
							}
						}
					} catch (Exception exception) {
						tracelogger.error(exception.getMessage(), exception);
					}
				}
			}
			if (data != null) {
				return data;
			} else {
				if (method.equalsIgnoreCase(ReportLoggerConstant.READ_LABEL)) {
					tracelogger.info(ReportLoggerConstant.DATA_FROM_EXCEL_NULL);
				}
				return ReportLoggerConstant.NUll_LABEL;
			}
		} else {
			tracelogger.info("File is not present for processing : " + testCaseSummaryExcelpath);
			return ReportLoggerConstant.NUll_LABEL;
		}
	}

	/**
	 * @param testDataExcelpath
	 * @param inputWorkbook
	 * @return
	 */
	public static boolean waitForFileAvailability(String testDataExcelpath) {
		int cnt = 0;
		File inputWorkbook = null;
		do {
			inputWorkbook = new File(testDataExcelpath);
			if (inputWorkbook.exists() && inputWorkbook.length() > 0L) {
				cnt = -1;
				System.err.println("File is available: " + cnt + CommonConstant.COLON_SEPERATOR + testDataExcelpath);
			} else {
				CommonFunctions.explicitWait(3000);
				System.err.println("File is not available: waiting for 3 sec to release" + testDataExcelpath);
				cnt++;
			}

		} while (cnt != -1 && cnt != 3);

		return null != inputWorkbook ? true : false;
	}

	/**
	 * @param method
	 * @param row
	 * @param column
	 * @param sheetName
	 * @param value
	 * @param testDataExcelpath
	 * @param backupFile
	 * @param flag
	 * @param inputWorkbook
	 * @return
	 */
	private static synchronized Boolean dashboardExcelWriteOperation(final String method, final int row,
			final int column, final String sheetName, final String value, String testDataExcelpath, Path backupFile,
			Boolean flag, File inputWorkbook) {
		if (method.equalsIgnoreCase(ReportLoggerConstant.WRITE_LABEL) && value != null) {
			excelBackupCreate(testDataExcelpath, backupFile);
			if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
				try (Workbook workbook = WorkbookFactory.create(inputWorkbook);) {
					for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
						if (workbook.getSheetName(i).equals(sheetName)) {
							flag = true;
							break;
						}
					}
				} catch (Exception exp) {
					tracelogger.error(exp.getMessage(), exp);
				}
				if (Boolean.valueOf(flag)) {
					try (FileInputStream fis = new FileInputStream(new File(testDataExcelpath));
							HSSFWorkbook workbook1 = (HSSFWorkbook) WorkbookFactory.create(fis)) {
						Sheet sheet = workbook1.getSheet(sheetName);
						Cell cell = sheet.getRow(row).getCell(column);
						cell.setCellValue(value);

						try (FileOutputStream fileOut = new FileOutputStream(testDataExcelpath)) {
							workbook1.write(fileOut);
						} catch (Exception exp) {
							tracelogger.error(exp.getMessage(), exp);
						}
						tracelogger.info(ReportLoggerConstant.SUCESSFULL_WRITE_MESSAGE + sheetName
								+ ReportLoggerConstant.ROW_LABEL + row + ReportLoggerConstant.COLUMN_LABEL + column
								+ ReportLoggerConstant.VALUE_LABEL + value);
					} catch (Exception exp) {
						tracelogger.error(exp.getMessage(), exp);
					}
					if (inputWorkbook.length() > 0) {
						deleteExistingFile(backupFile);
					} else {
						tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
						try {
							Files.delete(inputWorkbook.toPath());
							Files.copy(backupFile, Paths.get(testDataExcelpath));
						} catch (Exception exp) {
							tracelogger.error(exp.getMessage(), exp);
						}
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
					if (inputWorkbook.length() > 0) {
						deleteExistingFile(backupFile);
					} else {
						tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
						try {
							Files.delete(inputWorkbook.toPath());
							Files.copy(backupFile, Paths.get(testDataExcelpath));
						} catch (Exception exp) {
							tracelogger.error(exp.getMessage(), exp);
						}
					}
				}
			} else {
				tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + testDataExcelpath);
			}
		}
		return flag;
	}

	// *************************** Retrieve Excel Row For Status/TestData
	// ***************************//

	/**
	 * Retrieves the test data row number from the excel sheet.
	 * 
	 * @param testCaseName      name of the test case. The testNG method name and
	 *                          method name in test data sheet should be same.
	 * @param testDataSheetName name of the sheet which contains test data
	 * @return integer value represents the row number which contains the test data
	 *         required to execute particular scenario. If testCaseName is not
	 *         present in test data sheet , then it returns 0
	 * @exception IOException
	 * @see #getTestData
	 */
	// *************************** HashMap Definition Method
	// ***************************//
	public static Map<String, TestCaseDataRow> getTestData(final String testDataExcelPath, final String domainName,
			String locale, final int headerRowNumber, final int maxDataSetRowNum,String testCaseWorksheetName) {
		Path backUpFilePath = Paths
				.get(testDataExcelPath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		Map<String, TestCaseDataRow> testDataMap = new HashMap<>();
		File inputWorkbook = new File(testDataExcelPath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0L) {
			excelBackupCreate(testDataExcelPath, backUpFilePath);
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
				testDataMap = populateTestDataMap(ApplicationConstant.excelTestDataSheetName, inputWorkbook, locale,
						headerRowNumber, maxDataSetRowNum,testCaseWorksheetName);
			} catch (Exception exception) {
				tracelogger.error(exception.getMessage(), exception);
				throw new CATTFileOperationException(exception.getMessage());
			}

			if (inputWorkbook.length() > 0) {
				deleteExistingFile(backUpFilePath);
			} else {
				try {
					Files.delete(inputWorkbook.toPath());
					Files.copy(backUpFilePath, Paths.get(testDataExcelPath));
				} catch (IOException e) {
					tracelogger.error(e);
				}
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		return testDataMap;
	}

	private static Map<String, TestCaseDataRow> populateTestDataMap(final String workSheetName, File inputWorkbook,
			String locale, final int headerRow, final int maxDataSetRowNum, String testCaseWorksheetName) {

		Map<String, TestCaseDataRow> testDataMap = new LinkedHashMap<>();
		Boolean flag = false;
		try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
			workbook.setForceFormulaRecalculation(true);
			HSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			DataFormatter dataFormatter = new DataFormatter();
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				if (workbook.getSheetName(i).equals(workSheetName)) {
					flag = true;
					break;
				}
			}
			if (flag) {
				// createTestDataMap(workSheetName, testDataMap, workbook, dataFormatter,
				// locale, row);
				createMultiTestDataMap(workSheetName, testDataMap, workbook, dataFormatter, locale, headerRow,
						maxDataSetRowNum,testCaseWorksheetName);
			} else {
				StringBuilder messsageBuilder = new StringBuilder();
				messsageBuilder.append(ErrorMessageConstant.WORK_SHEET_NOT_FOUND).append(CommonConstant.SPACE)
						.append(inputWorkbook.getAbsolutePath()).append(CommonConstant.SPACE).append(workSheetName);
				String message = messsageBuilder.toString();
				tracelogger.error(message);
				throw new CATTFileOperationException(message);
			}

		} catch (Exception exception) {
			tracelogger.error(exception.getMessage(), exception);
			throw new CATTFileOperationException(exception.getMessage());
		}

		return testDataMap;

	}

	/**
	 * @param workSheetName
	 * @param testDataMap
	 * @param workbook
	 * @param evaluator
	 * @param dataFormatter
	 * @param row
	 */
	private static void createTestDataMap(final String workSheetName, Map<String, String> testDataMap,
			Workbook workbook, DataFormatter dataFormatter, String locale,String testCaseWorksheetName, final int... row) {
		String value;
		String key;
		Sheet sheet = workbook.getSheet(workSheetName);
		for (int singlerow : row) {
			if (singlerow > 0) {
				for (int i = 0; i <= sheet.getRow(singlerow).getLastCellNum() - 1; i++) {
					Cell cell = sheet.getRow(singlerow).getCell(i);
					key = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,testCaseWorksheetName);
					cell = sheet.getRow(singlerow + 1).getCell(i);
					value = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,testCaseWorksheetName);
					if (null != key && null != value && !key.equals(ReportLoggerConstant.EMPTY_STRING)
							&& !value.equals(ReportLoggerConstant.EMPTY_STRING)) {
						testDataMap.put(key, value);
						tracelogger.info(
								i + ReportLoggerConstant.KEY_LABEL + key + ReportLoggerConstant.VALUE_LABEL + value);
						key = null;
						value = null;
					}
				}
			}
		}
	}

	/**
	 * @param workSheetName
	 * @param testDataMap
	 * @param workbook
	 * @param evaluator
	 * @param dataFormatter
	 * @param row
	 */
	private static void createMultiTestDataMap(final String workSheetName, Map<String, TestCaseDataRow> testDataMap,
			Workbook workbook, DataFormatter dataFormatter, String locale, final int testDataHeaderRowNumber,
			final int maxDataSetRowNum,String testCaseWorksheetName) {
		String headerKey;
		String dataValue;
		Map<String, Integer> headerMap = new HashMap<>();
		Sheet sheet = workbook.getSheet(workSheetName);
		int count = 0;
		for (int rowNum = testDataHeaderRowNumber; rowNum <= maxDataSetRowNum; rowNum++) {
			TestCaseDataRow testCaseDataRow = null;
			if (testDataHeaderRowNumber != rowNum) {
				testCaseDataRow = new TestCaseDataRow();
			}
			int maxRowCellNumber = sheet.getRow(rowNum).getLastCellNum() - 1;
			for (int colNum = 3; colNum <= maxRowCellNumber; colNum++) {
				if (testDataHeaderRowNumber == rowNum) {
					Cell cell = sheet.getRow(rowNum).getCell(colNum);
					if (cell != null) {
						headerKey = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,testCaseWorksheetName);
						int index = cell.getColumnIndex();
						if (null != headerKey && !ReportLoggerConstant.EMPTY_STRING.equals(headerKey)) {
							headerMap.put(headerKey, index);
						}
					}

				} else {
					Cell cell = sheet.getRow(rowNum).getCell(colNum);
					if (cell != null) {
						int index = cell.getColumnIndex();
						dataValue = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,testCaseWorksheetName);
						testCaseDataRow.setCellValue(index, dataValue);
					}
				}
			}
			if (testDataHeaderRowNumber != rowNum) {
				testCaseDataRow.getHeaderMap().putAll(headerMap);
				count++;
				StringBuilder builder = new StringBuilder();
				for(Entry <String, Integer> headerNum : testCaseDataRow.getHeaderMap().entrySet()) {
					String value = testCaseDataRow.getCellValue(headerNum.getValue());
					builder.append(CommonConstant.LINE_SEPERATER);
					builder.append(
							ReportLoggerConstant.KEY_LABEL + headerNum.getKey()+CommonConstant.COMMA_SEPERATOR+CommonConstant.TAB + ReportLoggerConstant.VALUE_LABEL + value);
				}
				tracelogger.info(builder.toString());
				testDataMap.put(CommonConstant.DATA_SET_NAME + count, testCaseDataRow);
				tracelogger.info("============ DATA SET END ============");
			}
		}
	}

	public static synchronized Map objectLocatorHashMap(final String sheetName) throws Exception, IOException {
		String locatorExcelPath = ApplicationConstant.objectRepositoryPath;
		String value = null;
		String key = null;
		Boolean flag = false;
		HashMap<String, List<?>> map = new HashMap<String, List<?>>();
		Path BackupFile = Paths
				.get(locatorExcelPath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		File inputWorkbook = new File(locatorExcelPath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
				FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
				DataFormatter dataFormatter = new DataFormatter();
				Files.copy(Paths.get(locatorExcelPath), BackupFile);
				for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
					if (workbook.getSheetName(i).equals(sheetName)) {
						flag = true;
						break;
					}
				}
				if (flag) {
					Sheet sheet = workbook.getSheet(sheetName);
					int noOfColumns = sheet.getRow(0).getLastCellNum();
					int noOfRows = sheet.getLastRowNum() + 1;
					for (int i = 1; i < noOfRows; i++) {
						Cell cell = sheet.getRow(i).getCell(1);
						key = dataFormatter.formatCellValue(cell);
						if (map.containsKey(key)) {
							List<String> values = (List<String>) map.get(key);
							for (int j = 2; j < noOfColumns; j++) {
								cell = sheet.getRow(i).getCell(j);
								value = cell != null ? cell.getStringCellValue() : null;
								values.add(value);
								map.put(key, values);
							}
						} else {
							List<String> values = new ArrayList<String>();
							for (int j = 2; j < noOfColumns; j++) {
								cell = sheet.getRow(i).getCell(j);
								value = dataFormatter.formatCellValue(cell);
								values.add(value);
								map.put(key, values);
							}
						}
					}
					if (inputWorkbook.length() > 0) {
						deleteExistingFile(BackupFile);
					} else {
						tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);

						Files.delete(inputWorkbook.toPath());

						Files.copy(BackupFile, Paths.get(locatorExcelPath));
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
					if (inputWorkbook.length() > 0) {
						deleteExistingFile(BackupFile);
					} else {
						tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);

						Files.delete(inputWorkbook.toPath());

						Files.copy(BackupFile, Paths.get(locatorExcelPath));
					}
				}
			} catch (EncryptedDocumentException | IOException exp) {
				tracelogger.error(exp.getMessage(), exp);
			} catch (Exception exp) {
				tracelogger.error(exp.getMessage(), exp);
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		return map;
	}

	/**
	 * This method is used to read the SQL's pre-requisite excel file
	 * 
	 * @return map of <String, LinkedList<String>>
	 */
	public static synchronized Map<String, LinkedList<String>> getProcedureNames(final String sheetName,
			final String testDataExcelpath, Map<String, String> appDetail) throws Exception {
		String value = null;
		String key = null;
		int executionRequired = 2;
		int appdetailsColumn = 3;
		Boolean flag = Boolean.valueOf(false);
		Map<String, LinkedList<String>> map = new LinkedHashMap<>();
		File inputWorkbook = new File(testDataExcelpath);
		if ((inputWorkbook.exists()) && (inputWorkbook.length() > 0L)) {
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
				DataFormatter dataFormatter = new DataFormatter();
				flag = DashboardExcelReadOperation.isWorksheetPresent(sheetName, workbook);
				if (flag.booleanValue()) {
					Sheet sheet = workbook.getSheet(sheetName);
					int noOfColumns = sheet.getRow(0).getLastCellNum();
					int noOfRows = sheet.getLastRowNum() + 1;
					for (int i = 1; i < noOfRows; i++) {
						Cell cell = sheet.getRow(i).getCell(0);
						key = String.valueOf(i);
						LinkedList<String> values = new LinkedList<>();
						String executionValue = dataFormatter
								.formatCellValue(sheet.getRow(i).getCell(executionRequired));
						String applicationValue = dataFormatter
								.formatCellValue(sheet.getRow(i).getCell(appdetailsColumn));

						if (!appDetail.containsKey(applicationValue)
								&& executionValue.equalsIgnoreCase(CommonConstant.YES)) {
							if (applicationValue.equalsIgnoreCase(DBConstant.BO_MODULE)) {
								appDetail.put(DBConstant.BO_MODULE, key);
							} else {
								appDetail.put(DBConstant.MO_MODULE, key);
							}
						}
						if (executionValue.equalsIgnoreCase(CommonConstant.YES)) {
							for (int j = 0; j < noOfColumns; j++) {
								cell = sheet.getRow(i).getCell(j);
								value = dataFormatter.formatCellValue(cell);
								values.add(value);
								map.put(key, values);
							}
						}
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
				}
			} catch (Exception exp) {
				tracelogger.error(exp.getMessage(), exp);
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		tracelogger.info("Total Entries in list are : " + map.size());
		return map;
	}

	/**
	 * This method is used to read the dump validation excel file
	 * 
	 * @return map of <String, LinkedList<String>>
	 */
	public static synchronized Map<String, LinkedList<String>> getDumpValdationData(final String sheetName,
			final String testDataExcelpath, Map<String, String> appDetail) {
		String value = null;
		String key = null;
		Boolean flag = Boolean.valueOf(false);
		Map<String, LinkedList<String>> map = new LinkedHashMap<>();

		File inputWorkbook = new File(testDataExcelpath);
		if ((inputWorkbook.exists()) && (inputWorkbook.length() > 0L)) {
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
				DataFormatter dataFormatter = new DataFormatter();
				flag = DashboardExcelReadOperation.isWorksheetPresent(sheetName, workbook);
				if (flag.booleanValue()) {
					Sheet sheet = workbook.getSheet(sheetName);
					int noOfColumns = sheet.getRow(0).getLastCellNum();
					int noOfRows = sheet.getLastRowNum() + 1;
					for (int i = 1; i < noOfRows; i++) {
						Cell cell = sheet.getRow(i).getCell(0);
						key = String.valueOf(i);
						String applicationValue = dataFormatter.formatCellValue(sheet.getRow(i).getCell(2));
						if (!appDetail.containsKey(applicationValue)) {
							if (applicationValue.equalsIgnoreCase(DBConstant.BO_MODULE)) {
								appDetail.put(DBConstant.BO_MODULE, key);
							} else {
								appDetail.put(DBConstant.MO_MODULE, key);
							}
						}
						LinkedList<String> values = new LinkedList<>();
						for (int j = 0; j <= 5; j++) {
							cell = sheet.getRow(i).getCell(j);
							if (cell.getCellType() != CellType.FORMULA) {
								value = dataFormatter.formatCellValue(cell);
								values.add(value);
								map.put(key, values);
							} else {
								String fomulacellVal = cell.getStringCellValue();
								values.add(fomulacellVal);
								map.put(key, values);
							}
						}
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
				}
			} catch (Exception exp) {
				tracelogger.error(exp.getMessage(), exp);
				Assert.fail(ErrorMessageConstant.ERROR_WHILE_READING_EXCEL_FILE + exp.getMessage());
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		tracelogger.info("Total SQL's in list are : " + map.size());
		return map;
	}

	public static Map<String, String> getEnvDetails(final String configExcelPath, final String sheetName)
			throws Throwable {

		tracelogger.info(ReportLoggerConstant.ENV_CONFIGURATION_LABEL + configExcelPath);
		String value = null;
		String key = null;
		Boolean flag = Boolean.valueOf(false);
		Map<String, String> map = new LinkedHashMap<>();
		File inputWorkbook = new File(configExcelPath);
		if ((inputWorkbook.exists()) && (inputWorkbook.length() > 0L)) {
			try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
				DataFormatter dataFormatter = new DataFormatter();
				flag = DashboardExcelReadOperation.isWorksheetPresent(sheetName, workbook);
				if (flag.booleanValue()) {
					Sheet sheet = workbook.getSheet(sheetName);
					int noOfColumns = sheet.getRow(0).getLastCellNum();
					int noOfRows = sheet.getLastRowNum() + 1;
					for (int i = 1; i < noOfRows; i++) {
						if (null != sheet.getRow(i)) {
							Cell cell = sheet.getRow(i).getCell(1);
							key = dataFormatter.formatCellValue(cell);
							if (!StringUtils.isEmpty(key)) {
								Set entrySet = map.entrySet();
								Iterator it = entrySet.iterator();
								while (it.hasNext()) {
									Map.Entry me = (Map.Entry) it.next();
									if (!me.getKey().equals(key)) {
									}
								}
								LinkedList<String> values = new LinkedList<String>();
								for (int j = 2; j < noOfColumns; j++) {
									cell = sheet.getRow(i).getCell(j);
									value = dataFormatter.formatCellValue(cell);
									if (!value.equals(ReportLoggerConstant.EMPTY_STRING)) {
										map.put(key, value);
									}
								}
							}
						}
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
				}
			} catch (Exception exp) {
				tracelogger.error(exp.getMessage(), exp);
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + configExcelPath);
			throw new CATTException(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + configExcelPath);
		}
		return map;
	}

	// ************************** Excel Create - Delete Backup Methods
	// ***********************//
	public static synchronized void excelBackupCreate(final String excelpath, final Path backupFile) {
		try {
			Files.copy(Paths.get(excelpath), backupFile, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException exp) {
			tracelogger
					.warn("Exception while creating backup file before reading data from Excel :" + exp.getMessage());
			tracelogger.error(exp.getMessage(), exp);
		}
	}

	public static synchronized void deleteExistingFile(final Path backupFile) {
		try {
			Files.delete(backupFile);
		} catch (Exception exp) {
			tracelogger.error(exp.getMessage(), exp);
		}
	}

	public static synchronized Map<String, String> getRowNumUsernamePassword(String testCaseSummarySheetName,
			String workSheetName, String domainName) {

		Map<String, String> map = new HashMap<>();
		String testCaseSummaryExcelpath = DomainInitialization.initializeDomainTestDataExcelPath(domainName);
		Path backupFile = Paths
				.get(testCaseSummaryExcelpath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		File inputWorkbook = null;
		// ExcelOperation.waitForFileAvailability(testCaseSummaryExcelpath);
		inputWorkbook = new File(testCaseSummaryExcelpath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0L) {
			ExcelOperation.excelBackupCreate(testCaseSummaryExcelpath, backupFile);
			try (Workbook workbook = WorkbookFactory.create(new File(testCaseSummaryExcelpath))) {
				boolean isSheetPresent = checkSheetPresent(testCaseSummarySheetName, workbook);
				if (isSheetPresent) {
					getTestCaseSummayRowNum(map, workSheetName, testCaseSummarySheetName,
							InitializeConstants.test_case_worksheet_name_column, workbook);
					getUserNamePassword(testCaseSummarySheetName, map, workbook);

					if (!map.get(CommonConstant.IS_WORKSHEET_PRESENT).equals("true")) {
						tracelogger.info(ReportLoggerConstant.NOW_ROW_PROVIDED_FOR_TEST_SCENARIO + workSheetName
								+ ReportLoggerConstant.IN + testCaseSummarySheetName
								+ ReportLoggerConstant.SHEET_LABEL);
					}
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK);
					ExcelOperation.deleteExistingFile(backupFile);
				}
			} catch (FileNotFoundException exception) {
				String errorMessage = "File is not present for processing : " + testCaseSummaryExcelpath
						+ exception.getMessage();
				tracelogger.error(errorMessage, exception);
				FileUtility.appendLogMessageToFile(InitializeConstants.currentPackageDirectoryPath + File.separator
						+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
						+ "DashBoardValidation.log", errorMessage);
				throw new CATTException(errorMessage);
			} catch (IOException exception) {
				FileUtility.appendLogMessageToFile(
						InitializeConstants.currentPackageDirectoryPath + File.separator
								+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
								+ "DashBoardValidation.log",
						ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
				throw new CATTException(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
			}
			if (inputWorkbook.length() > 0L) {
				ExcelOperation.deleteExistingFile(backupFile);
			} else {
				tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
				try {
					Files.delete(inputWorkbook.toPath());
					Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
				} catch (Exception exp) {
					tracelogger.error(exp.getMessage(), exp);
				}
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		return map;
	}

	/**
	 * @param workBookNameTestSummary
	 * @param map
	 * @param workbook
	 */
	private static void getUserNamePassword(String workBookNameTestSummary, Map<String, String> map,
			Workbook workbook) {
		int excelDashBoardRowNo;
		excelDashBoardRowNo = Integer.parseInt(map.get(CommonConstant.DASHBOARD_ROW_NUMBER));
		DataFormatter dataFormatter = new DataFormatter();
		Sheet sheet = workbook.getSheet(workBookNameTestSummary);
		Cell cell = sheet.getRow(excelDashBoardRowNo).getCell(ApplicationConstant.excelUsernameColumn);
		String userName = dataFormatter.formatCellValue(cell);
		cell = sheet.getRow(excelDashBoardRowNo).getCell(ApplicationConstant.excelPasswordColumn);
		String passWord = dataFormatter.formatCellValue(cell);
		map.put(CommonConstant.USERNAME, userName);
		map.put(CommonConstant.PASSWORD, passWord);
	}

	/**
	 * @param workBookName
	 * @param workbook
	 * @param isSheetPresent
	 * @return
	 */
	public static boolean checkSheetPresent(String workBookName, Workbook workbook) {
		boolean isSheetPresent = false;
		for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
			if (workbook.getSheetName(i).equals(workBookName)) {
				isSheetPresent = true;
				break;
			}
		}
		return isSheetPresent;
	}

	/**
	 * @param workSheetName
	 * @param workBookName
	 * @param cellNumber
	 * @param workbook
	 */
	private static void getTestCaseSummayRowNum(Map<String, String> map, String workSheetName, String workBookName,
			int cellNumber, Workbook workbook) {
		int count = 0;
		boolean flag = false;
		Sheet sheet = workbook.getSheet(workBookName);
		if (null != sheet) {
			Iterator<Row> rows = sheet.rowIterator();
			while (rows.hasNext()) {
				Row row = rows.next();
				Cell cell = row.getCell(cellNumber);
				if (cell != null) {
					if (!StringUtils.isEmpty(cell.getStringCellValue())
							&& workSheetName.equalsIgnoreCase(cell.getStringCellValue())) {
						count = row.getRowNum();
						flag = true;
						break;
					}
				}
			}
		}
		map.put(CommonConstant.IS_WORKSHEET_PRESENT, Boolean.toString(flag));
		map.put(CommonConstant.DASHBOARD_ROW_NUMBER, Integer.toString(count));
	}

	public static synchronized void putResultInSummaryFile(int rowNum, String domainName, Map<String, String> results) {

		String testCaseSummaryExcelpath = DomainInitialization.initializeDomainTestDataExcelPath(domainName);
		Path backupFile = Paths
				.get(testCaseSummaryExcelpath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		File inputWorkbook = null;
		ExcelOperation.waitForFileAvailability(testCaseSummaryExcelpath);
		inputWorkbook = new File(testCaseSummaryExcelpath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0L) {
			ExcelOperation.excelBackupCreate(testCaseSummaryExcelpath, backupFile);
			try (FileInputStream fis = new FileInputStream(new File(testCaseSummaryExcelpath));
					HSSFWorkbook workbook = (HSSFWorkbook) WorkbookFactory.create(fis)) {
				boolean isSheetPresent = checkSheetPresent(InitializeConstants.dashboard_excel_status_sheet_name,
						workbook);
				if (isSheetPresent) {

					Sheet sheet = workbook.getSheet(InitializeConstants.dashboard_excel_status_sheet_name);
					Cell cell = sheet.getRow(rowNum).getCell(ApplicationConstant.excelStatusColumn);
					cell.setCellValue(results.get(CommonConstant.TEST_CASE_STATUS));
					cell = sheet.getRow(rowNum).getCell(ApplicationConstant.excelVideoColumn);
					cell.setCellValue(results.get(CommonConstant.VIDEO_LOCATION));
					cell = sheet.getRow(rowNum).getCell(ApplicationConstant.excelExecutionTimePassColumnNo);
					cell.setCellValue(results.get(CommonConstant.EXECUTION_TIME));
					cell = sheet.getRow(rowNum).getCell(ApplicationConstant.excelErrorColumn);
					cell.setCellValue(results.get(CommonConstant.ERROR_MESSAGE));
					cell = sheet.getRow(rowNum).getCell(ApplicationConstant.defectIDColumn);
					cell.setCellValue(results.get(CommonConstant.DEFECT_ID));

					writeUpdatedWorkbook(testCaseSummaryExcelpath, workbook);
					tracelogger.info(ReportLoggerConstant.SUCESSFULL_TEST_RESULT_WRITE_MESSAGE + rowNum
							+ CommonConstant.LINE_SEPERATER + CommonConstant.TEST_CASE_STATUS + CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR + results.get(CommonConstant.TEST_CASE_STATUS)
							+ CommonConstant.LINE_SEPERATER + CommonConstant.EXECUTION_TIME + CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR + results.get(CommonConstant.EXECUTION_TIME)
							+ CommonConstant.LINE_SEPERATER + CommonConstant.ERROR_MESSAGE + CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR + results.get(CommonConstant.ERROR_MESSAGE)
							+ CommonConstant.LINE_SEPERATER + CommonConstant.VIDEO_LOCATION + CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR + results.get(CommonConstant.VIDEO_LOCATION)
							+ CommonConstant.LINE_SEPERATER + CommonConstant.DEFECT_ID + CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR + results.get(CommonConstant.DEFECT_ID));
				} else {
					tracelogger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK);
					ExcelOperation.deleteExistingFile(backupFile);
				}
			} catch (Exception exception) {
				String errorMessage = "Test Case Summary file is not free to perform write operation: "
						+ testCaseSummaryExcelpath + exception.getMessage();
				tracelogger.error(errorMessage, exception);
			}
			if (inputWorkbook.length() > 0L) {
				ExcelOperation.deleteExistingFile(backupFile);
			} else {
				tracelogger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);
				try {
					Files.delete(inputWorkbook.toPath());
					Files.copy(backupFile, Paths.get(testCaseSummaryExcelpath));
				} catch (Exception exp) {
					tracelogger.error(exp.getMessage(), exp);
				}
			}
		} else {
			tracelogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
	}

	/**
	 * @param testCaseSummaryExcelpath
	 * @param workbook
	 */
	private static void writeUpdatedWorkbook(String testCaseSummaryExcelpath, HSSFWorkbook workbook) {
		try (FileOutputStream fileOut = new FileOutputStream(testCaseSummaryExcelpath);) {
			workbook.write(fileOut);
		} catch (Exception exception) {
			tracelogger.error(exception.getMessage(), exception);
		}
	}
}
