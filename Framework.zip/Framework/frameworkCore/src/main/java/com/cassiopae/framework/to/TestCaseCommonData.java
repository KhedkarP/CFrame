/**
 *
 */
package com.cassiopae.framework.to;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.devtools.DevTools;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jraut
 *
 */

//To be incorporated for future sprints
public class TestCaseCommonData {

    private Map<String, String> variableHolder = null;
    private Map<String, String> multiDataSetResult = null;
    private WebDriver driver = null;
    private boolean isNeoLoadTestScenario = false;
    private int excelRowNo = 0;
    private Logger reportingLogger = null;
    private String browserName = null;
    private String appVersion = null;
    private String domainName = null;
    private String issueReproduceStepsLogs = null;
    private Map<String, String> newDriverInstance = null;
    private String screenshotFolderPath = null;
    private String newVideoLocation = null;
    private String summary = null;
    private String issue = null;
    private String userName = null;
    private String password = null;
    private String defaultUserName = null;
    private String defaultPassword = null;
    
    private String application = null;
    private int testDataRowNo = 0;
    private Map<String, TestCaseDataRow> testData = null;
    private String testCaseExcelPath;
    private String executionResultPath;
    private String consoleLogsPath;
    private String downloadedFilesPath;
    private String errorDocumentsPath;
    private String executionVideosPath;
    private String neoLoadProjectsPath;
    private String uploadFilesPath;
    private String testNGpath;
    private String screenshotsPath;
    private String executionResultLocation;
    private String workBookName;
    private String workSheetName;
    private String locale;
    private String baseWorksheetName;
	private int maxDataSetRowNum;
    private int testDataHeaderRowNum;

    public DevTools getDevTools() {
        return devTools;
    }

    public void setDevTools(DevTools devTools) {
        this.devTools = devTools;
    }

    private DevTools devTools;
    
    
    public String getBaseWorksheetName() {
		return baseWorksheetName;
	}

	public void setBaseWorksheetName(String baseWorksheetName) {
		this.baseWorksheetName = baseWorksheetName;
	}
	
    /**
	 * This variable set to TRUE only when there is scenario for payment schedule excel comparison/validation.
	 */

	public String getWorkBookName() {
	return workBookName;
    }

    public void setWorkBookName(String workBookName) {
	this.workBookName = workBookName;
    }

    public String getWorkSheetName() {
	return workSheetName;
    }

    public void setWorkSheetName(String workSheetName) {
	this.workSheetName = workSheetName;
    }

    public Map<String, String> getVariableHolder() {
	return variableHolder;
    }

    public void setVariableHolder(final Map<String, String> variableHolder) {
	this.variableHolder = variableHolder;
    }

    public WebDriver getDriver() {
	return driver;
    }

    public void setDriver(final WebDriver driver) {
	this.driver = driver;
    }

    public int getExcelRowNo() {
	return excelRowNo;
    }

    public void setExcelRowNo(final int excelRowNo) {
	this.excelRowNo = excelRowNo;
    }

    public Logger getReportingLogger() {
	return reportingLogger;
    }

    public void setReportingLogger(final Logger logger) {
	this.reportingLogger = logger;
    }

    public String getBrowserName() {
	return browserName;
    }

    public void setBrowserName(final String browserName) {
	this.browserName = browserName;
    }

    public String getAppVersion() {
	return appVersion;
    }

    public void setAppVersion(final String appVersion) {
	this.appVersion = appVersion;
    }

    public String getDomainName() {
	return domainName;
    }

    public void setDomainName(final String domainName) {
	this.domainName = domainName;
    }

    public String getIssueReproduceStepsLogs() {
	return issueReproduceStepsLogs;
    }

    public void setIssueReproduceStepsLogs(final String issueReproduceStepsLogs) {
	this.issueReproduceStepsLogs = issueReproduceStepsLogs;
    }

    public Map<String, String> getNewDriverInstance() {
	return newDriverInstance;
    }

    public void setNewDriverInstance(final HashMap<String, String> newDriverInstance) {
	this.newDriverInstance = newDriverInstance;
    }

    public String getScreenshotFolderPath() {
	return screenshotFolderPath;
    }

    public void setScreenshotFolderPath(final String screenshotFolderPath) {
	this.screenshotFolderPath = screenshotFolderPath;
    }

    public String getNewVideoLocation() {
	return newVideoLocation;
    }

    public void setNewVideoLocation(final String newVideoLocation) {
	this.newVideoLocation = newVideoLocation;
    }

    public String getSummary() {
	return summary;
    }

    public void setSummary(final String summary) {
	this.summary = summary;
    }

    public String getIssue() {
	return issue;
    }

    public void setIssue(final String issue) {
	this.issue = issue;
    }

    public String getUserName() {
	return userName;
    }

    public void setUserName(final String userName) {
	this.userName = userName;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(final String password) {
	this.password = password;
    }

    public String getApplication() {
	return application;
    }

    public void setApplication(final String application) {
	this.application = application;
    }

    public int getTestDataRowNo() {
	return testDataRowNo;
    }

    public void setTestDataRowNo(final int testDataRowNo) {
	this.testDataRowNo = testDataRowNo;
    }

	public Map<String, TestCaseDataRow> getTestData() {
	return testData;
    }
    public String getTestCaseExcelPath() {
	return testCaseExcelPath;
    }

    public String getExecutionResultPath() {
	return executionResultPath;
    }

    public void setExecutionResultPath(String executionResultPath) {
	this.executionResultPath = executionResultPath;
    }

    public String getConsoleLogsPath() {
	return consoleLogsPath;
    }

    public void setConsoleLogsPath(String consoleLogsPath) {
	this.consoleLogsPath = consoleLogsPath;
    }

    public String getDownloadedFilesPath() {
	return downloadedFilesPath;
    }

    public void setDownloadedFilesPath(String downloadedFilesPath) {
	this.downloadedFilesPath = downloadedFilesPath;
    }

    public String getErrorDocumentsPath() {
	return errorDocumentsPath;
    }

    public void setErrorDocumentsPath(String errorDocumentsPath) {
	this.errorDocumentsPath = errorDocumentsPath;
    }

    public String getExecutionVideosPath() {
	return executionVideosPath;
    }

    public void setExecutionVideosPath(String executionVideosPath) {
	this.executionVideosPath = executionVideosPath;
    }

    public String getNeoLoadProjectsPath() {
	return neoLoadProjectsPath;
    }

    public void setNeoLoadProjectsPath(String neoLoadProjectsPath) {
	this.neoLoadProjectsPath = neoLoadProjectsPath;
    }

    public String getUploadFilesPath() {
	return uploadFilesPath;
    }

    public void setUploadFilesPath(String uploadFilesPath) {
	this.uploadFilesPath = uploadFilesPath;
    }

    public String getTestNGpath() {
	return testNGpath;
    }

    public void setTestNGpath(String testNGpath) {
	this.testNGpath = testNGpath;
    }

    public String getScreenshotsPath() {
	return screenshotsPath;
    }

    public void setScreenshotsPath(String screenshotsPath) {
	this.screenshotsPath = screenshotsPath;
    }

    public String getExecutionResultLocation() {
	return executionResultLocation;
    }

    public void setExecutionResultLocation(String executionResultLocation) {
	this.executionResultLocation = executionResultLocation;
    }

    public void setNewDriverInstance(Map<String, String> newDriverInstance) {
	this.newDriverInstance = newDriverInstance;
    }

    public void setTestData(Map<String, TestCaseDataRow> testData) {
	this.testData = testData;
    }

    public void setTestCaseExcelPath(final String testCaseExcelPath) {
	this.testCaseExcelPath = testCaseExcelPath;
    }

    /**
     * @return the locale
     */
    public String getLocale() {
	return locale;
    }

    /**
     * @param locale the locale to set
     */
    public void setLocale(String locale) {
	this.locale = locale;
    }

	public boolean isNeoLoadTestScenario() {
		return isNeoLoadTestScenario;
	}

	public void setNeoLoadTestScenario(boolean isNeoLoadTestScenario) {
		this.isNeoLoadTestScenario = isNeoLoadTestScenario;
	}

	public int getTestDataHeaderRowNum() {
		return testDataHeaderRowNum;
	}

	public void setTestDataHeaderRowNum(int testDataHeaderRowNum) {
		this.testDataHeaderRowNum = testDataHeaderRowNum;
	}

	public int getMaxDataSetRowNum() {
		return maxDataSetRowNum;
	}

	public void setMaxDataSetRowNum(int maxDataSetRowNum) {
		this.maxDataSetRowNum = maxDataSetRowNum;
	}

	public Map<String, String> getMultiDataSetResult() {
		return multiDataSetResult;
	}

	public void setMultiDataSetResult(Map<String, String> multiDataSetResult) {
		this.multiDataSetResult = multiDataSetResult;
	}

	public String getDefaultUserName() {
		return defaultUserName;
	}

	public void setDefaultUserName(String defaultUserName) {
		this.defaultUserName = defaultUserName;
	}

	public String getDefaultPassword() {
		return defaultPassword;
	}

	public void setDefaultPassword(String defaultPassword) {
		this.defaultPassword = defaultPassword;
	}

}
