package com.cassiopae.framework.util.constant;

public interface MailConstants {

	public static final String MAIL_SMTP_HOST = InitializeConstants.mailDetails.get("SMTP_HOST");
	public static final String MAIL_PORT =  InitializeConstants.mailDetails.get("MAIL_PORT");
	public static final String MAIL_USERNAME =  InitializeConstants.mailDetails.get("MAIL_USERNAME");

	public static final String MAIL_PASSOWORD = InitializeConstants.mailDetails.get("MAIL_PASSOWORD");
	public static final String MAIL_FROM =  InitializeConstants.mailDetails.get("MAIL_FROM");

	public static final String MAIL_TO =  InitializeConstants.mailDetails.get("MAIL_TO");
	public static final String MAIL_CC =  InitializeConstants.mailDetails.get("MAIL_CC");

	public static final String MAIL_SUBJECT_BEFORE_EXECUTION =  InitializeConstants.mailDetails.get("MAIL_SUBJECT_BEFORE_EXECUTION");
	public static final String MAIL_BODY_BEFORE_EXECUTION =  InitializeConstants.mailDetails.get("MAIL_BODY_BEFORE_EXECUTION");
	public static final String MAIL_SUBJECT_AFTER_EXECUTION =  InitializeConstants.mailDetails.get("MAIL_SUBJECT_AFTER_EXECUTION");
	public static final String MAIL_BODY_AFTER_EXECUTION =  InitializeConstants.mailDetails.get("MAIL_BODY_AFTER_EXECUTION");

	public static final String MailCon_FileToAttach_1 = " ";
	public static final String MailCon_FileToAttach_2 = " ";

	public static final String EXCEL_Path = " ";
	public static final String TESTNG_PATH_EMAILABLE_REPORT = " ";

}
