package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class PropertyFunctions  {

	/*
	 * Asset Functions
	 */

	private static Map<String, List<String>> assetLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.ASSET_LOCATOR);
	private static Map<String, List<String>> propertyLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.PROPERTIES_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger logger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.ASSET_MOUSE_HOVER, FunctionLocatorConstant.ASSET_MENU, assetLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.PROPERTY_SITES_SUB_MENU, FunctionLocatorConstant.SITES_SUB_MENU, assetLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.PROPERTY_SUB_MENU_OF_SITES, FunctionLocatorConstant.IMMOBILIERS_SUB_MENU_OF_SITES, assetLocatorMap, driver, logger);
	}

	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_PROPERTY_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.PROPERTY_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(propertyLocatorMap);
		GenericAction.enterValueIn(reference,excelTestCaseFields, testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_PROPERTY_REFERENCE_ICON,FunctionLocatorConstant.PROPERTY_SEARCH_ICON, propertyLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_PROPERTY_REFERENCE_HYPERLINK + reference, FunctionLocatorConstant.PROPERTY_REFERNCE_HYPERLINK, propertyLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
