/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.FrameworkConstant;

/**
 * @author mshaik
 *
 */
public class SelectDropdownValueContains implements PerformAction {

	/**
	 * This method execute action for select drop down action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		if(testCaseDetailTO.getWorkSheetName().contains(FrameworkConstant.POS)) {
			GenericAction.selectDropdownPOS(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			GenericAction.SelectDropdownValueContains(excelTestCaseFieldsTO, testCaseDetailTO);
		}
	}

}
