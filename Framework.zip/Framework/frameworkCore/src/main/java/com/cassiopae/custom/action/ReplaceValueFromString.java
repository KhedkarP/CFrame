package com.cassiopae.custom.action;

import java.util.regex.Pattern;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;

public class ReplaceValueFromString implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();

		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputTestDatas = excelTestCaseFieldsTO.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String inputStringValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[0].trim());
		String inputValues[] = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String oldValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputValues[0].trim());
		String newValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputValues[1].trim());

		String finalValue = null;
		if (inputStringValue != null) {
			finalValue = CustomActionUtility.replaceValue(inputStringValue, oldValue, newValue, reportingLogger);
		} else {
			throw new CATTException(ErrorMessageConstant.INVALID_PARAMETERS);
		}

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), finalValue.trim());
		}
	}
}
