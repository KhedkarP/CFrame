/**
 * 
 */
package com.cassiopae.selenium.util.common;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.to.XlsFileRowDetails;
import com.cassiopae.framework.util.DashboardExcelReadOperation;
import com.cassiopae.framework.util.DashboardProcessingUtility;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author jraut
 *
 */

public class TestNGSuiteCreationUtility {
	private TestNGSuiteCreationUtility() {
	}

	private static Logger logger = LogManager.getLogger(TestNGSuiteCreationUtility.class);
	private static String listener1 = "com.selenium.testng.report.custom.TestNGEmailableReport";
	private static String listener2 = "com.cassiopae.selenium.services.listener.TestCaseListenerAdapter";

	/**
	 * This method will create testNG xml file
	 * 
	 * @param testNGuite
	 * @return
	 */
	public static void createTestNGsuiteFile(XmlSuite testNGuite, String suiteFileName) {
		File testNGsuiteFile = new File(
				InitializeConstants.currentPackageDirectoryPath + File.separator + InitializeConstants.cattProjectName
						+ File.separator + suiteFileName + CommonConstant.XML_FILE_EXTENSION);
		logger.info(testNGsuiteFile.getAbsolutePath());
		logger.info("Test NG suite File Path : " + testNGsuiteFile.getAbsolutePath());
		try (FileWriter writer = new FileWriter(testNGsuiteFile)) {
			writer.write(testNGuite.toXml());
			writer.flush();
		} catch (Exception e1) {
			logger.error(e1.getMessage());
			throw new CATTException(e1.getMessage());
		}
	}

	public static XmlTest createXMLTestClass(List<XlsFileRowDetails> xlsFileRowDetailsList) {
		XlsFileRowDetails xlsFileRowDetails = xlsFileRowDetailsList.get(0);
		LinkedList<XmlInclude> includedMethods = createXMLIncludes(xlsFileRowDetailsList);
		XmlClass xmlClass = null;
		XmlTest xmlTestClass = null;
		if (includedMethods.size() > 0) {
			try {
				xmlClass = new XmlClass(xlsFileRowDetails.getClassName());
				xmlClass.setIncludedMethods(includedMethods);
				xmlTestClass = new XmlTest();
				String onlyClassName = xlsFileRowDetails.getClassName().substring(
						xlsFileRowDetails.getClassName().lastIndexOf(CommonConstant.DOT_OPERATOR) + 1,
						xlsFileRowDetails.getClassName().length());
				xmlTestClass.setName(onlyClassName);
				xmlTestClass.getClasses().add(xmlClass);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw new CATTException(e.getMessage());
			}
		}
		return xmlTestClass;
	}

	private static LinkedList<XmlInclude> createXMLIncludes(List<XlsFileRowDetails> xlsFileRowDetailsList) {
		LinkedList<XmlInclude> includedMethods = new LinkedList<>();
		VersionComparator basetestExecutionVersion = new VersionComparator();
		VersionComparator endCompatibilityVersion = new VersionComparator();
		VersionComparator fixVersion = new VersionComparator();
		// 1st level filter

		for (XlsFileRowDetails xlsFileRowDetails : xlsFileRowDetailsList) {
			String endcompatibiltyTCVersion = xlsFileRowDetails.getEndCompatibiltyVersion();
			xlsFileRowDetails.getMethodName();
			basetestExecutionVersion.setVersionValue(getAccurateVersionValue(ApplicationContext.productVersion));
			endCompatibilityVersion.setVersionValue(getAccurateVersionValue(endcompatibiltyTCVersion.trim()));
			fixVersion.setVersionValue(getAccurateVersionValue(xlsFileRowDetails.getTCVersion().trim()));
			if (fixVersion.equals(basetestExecutionVersion) || fixVersion.compareTo(basetestExecutionVersion) <= 0) {
				if (endcompatibiltyTCVersion.contains(FrameworkConstant.END_COMPATIBILITY_VERSION_NEXT_VALUE)
						|| endCompatibilityVersion.compareTo(basetestExecutionVersion) >= 0) {
					Map<String, String> parameters = new HashMap<>();
					parameters.put("browserName", xlsFileRowDetails.getBrowser());
					parameters.put("domainName", xlsFileRowDetails.getDomain());
					XmlInclude xmlInclude = new XmlInclude(xlsFileRowDetails.getMethodName());
					xmlInclude.setParameters(parameters);
					includedMethods.add(xmlInclude);
				}
			}
		}
		return includedMethods;
	}

	/**
	 * @param domainName
	 * @param xmlSuiteMap
	 */
	public static void createTestNGSuiteXMLFIles(String domainName, Map<String, XmlSuite> xmlSuiteMap) {
		if (xmlSuiteMap.size() <= 0) {
			logger.info("Unable to create testNG suite file as no test cases are selected for execution");
		}
		for (Map.Entry<String, XmlSuite> xmlsuite : xmlSuiteMap.entrySet()) {
			String suiteName = xmlsuite.getKey();
			XmlSuite suitValue = xmlsuite.getValue();
			logger.info(ReportLoggerConstant.FORMAT_MESSAGE + domainName + CommonConstant.UNDER_SCORE + suiteName
					+ ReportLoggerConstant.FORMAT_MESSAGE);
			logger.info(suitValue.toXml());
			TestNGSuiteCreationUtility.createTestNGsuiteFile(suitValue,
					domainName + CommonConstant.UNDER_SCORE + suiteName);
		}
	}

	/**
	 * @param dashboardHashMap
	 * @param xmlSuiteMap
	 */
	public static void populateXMLSuite(Map<String, List<XlsFileRowDetails>> dashboardHashMap,
			Map<String, XmlSuite> xmlSuiteMap) {

		VersionComparator basetestExecutionVersion = new VersionComparator();
		VersionComparator fixVersion = new VersionComparator();
		VersionComparator defaultBaseVersion = new VersionComparator();
		VersionComparator endCompatibleVersion = new VersionComparator();
		defaultBaseVersion.setVersionValue(FrameworkConstant.VERSION_470);
		basetestExecutionVersion.setVersionValue(getAccurateVersionValue(ApplicationContext.productVersion.trim()));
		for (Map.Entry<String, List<XlsFileRowDetails>> object : dashboardHashMap.entrySet()) { // class level map
			List<XlsFileRowDetails> xlsFileRowDetailsList = object.getValue();
			for (int method = 0; method < xlsFileRowDetailsList.size(); method++) { // for each method w.r.t.class
				XlsFileRowDetails xlsFileRowDetails = xlsFileRowDetailsList.get(method);
				fixVersion.setVersionValue(getAccurateVersionValue(xlsFileRowDetails.getTCVersion().trim()));
				endCompatibleVersion
						.setVersionValue(getAccurateVersionValue(xlsFileRowDetails.getEndCompatibiltyVersion().trim()));
				if (fixVersion.compareTo(defaultBaseVersion) < 0) {
					throw new CATTException("Fix Version cannot be less than 4.7.0 for test case : "
							+ xlsFileRowDetails.getClassName());
				}

				if (xlsFileRowDetails.getEndCompatibiltyVersion()
						.contains(FrameworkConstant.END_COMPATIBILITY_VERSION_NEXT_VALUE)
						|| endCompatibleVersion.compareTo(basetestExecutionVersion) >= 0
						|| fixVersion.equals(basetestExecutionVersion)) {

					if (!StringUtils.isEmpty(xlsFileRowDetails.getSuiteName())) {
						if (!StringUtils.isEmpty(ApplicationContext.executionBrowserName)) {
							setGlobalBrowserName(ApplicationContext.executionBrowserName, xlsFileRowDetailsList);
						}
						if (xmlSuiteMap.containsKey(xlsFileRowDetails.getSuiteName())) {
							XmlTest xmlTest = TestNGSuiteCreationUtility.createXMLTestClass(xlsFileRowDetailsList);
							if (null != xmlTest) {
								xmlSuiteMap.get(xlsFileRowDetails.getSuiteName()).getTests().add(xmlTest);
							}
							break;
						}
					} else {
						throw new CATTException(
								"Suite name column value is empty for method : " + xlsFileRowDetails.getMethodName());
					}
				}
			}
		}
	}

	private static void setGlobalBrowserName(String browserName, List<XlsFileRowDetails> xlsFileRowDetailsList) {
		for (int row = 0; row < xlsFileRowDetailsList.size(); row++) { // for each method
			XlsFileRowDetails methodInfo = xlsFileRowDetailsList.get(row);
			methodInfo.setBrowser(browserName);
		}
	}

	/**
	 * @param domainName
	 * @param totalSuite
	 * @param xmlSuiteMap
	 */
	public static void createTestNGXMLSuites(String domainName, List<String> totalSuite,
			Map<String, XmlSuite> xmlSuiteMap) {
		for (int j = 0; j < totalSuite.size(); j++) {
			XmlSuite testNGSuite;
			String suiteTypeName = null;
			suiteTypeName = totalSuite.get(j);
			if (suiteTypeName.contains("Sanity")) {
				testNGSuite = configureSanitySuite(domainName, suiteTypeName);
			} else if (suiteTypeName.contains("Payment")) {
				testNGSuite = configurePaymentScheduleSuite(domainName, suiteTypeName);
			} else {
				testNGSuite = configureRegressionSuite(domainName, suiteTypeName);
			}
			xmlSuiteMap.put(suiteTypeName, testNGSuite);
		}
	}

	/**
	 * @param suiteMap
	 * @param totalSuite
	 */
	public static void getUniqueSuiteList(Map<String, String> suiteMap, List<String> totalSuite) {
		for (Map.Entry<String, String> entry : suiteMap.entrySet()) {
			if (!totalSuite.contains(entry.getValue())) {
				totalSuite.add(entry.getValue());
			}
		}
	}

	/**
	 * @param dashboardHashMap
	 * @param suiteMap
	 */
	public static void getSuiteNames(Map<String, List<XlsFileRowDetails>> dashboardHashMap,
			Map<String, String> suiteMap) {
		VersionComparator basetestExecutionVersion = new VersionComparator();
		VersionComparator fixVersion = new VersionComparator();
		basetestExecutionVersion.setVersionValue(getAccurateVersionValue(ApplicationContext.productVersion.trim()));
		for (String name : dashboardHashMap.keySet()) {
			List<XlsFileRowDetails> classDetails = dashboardHashMap.get(name);
			for (int method = 0; method < classDetails.size(); method++) {
				XlsFileRowDetails xlsFileRowDetails = classDetails.get(method);
				fixVersion.setVersionValue(getAccurateVersionValue(xlsFileRowDetails.getTCVersion().trim()));
				if (fixVersion.equals(basetestExecutionVersion)
						|| fixVersion.compareTo(basetestExecutionVersion) <= 0) {
					suiteMap.put(name, xlsFileRowDetails.getSuiteName());
					break;
				}
			}
		}
	}

	public static String getQualifiedSuiteName(String version, String suiteName) {
		return StringUtils.replaceChars(version, CommonConstant.DOT_OPERATOR, CommonConstant.UNDER_SCORE)
				+ CommonConstant.UNDER_SCORE + suiteName;
	}

	/**
	 * @param args
	 * @return
	 */
	public static String[] setDomainsValue(final String[] args) {
		String[] domains;
		if (args.length == 0) {
			domains = CommonUtility.getDomainName();
		} else {
			domains = args;
		}
		for (int i = 0; i < domains.length; i++) {
			logger.info("Qualified domain for testNG suite creation are : " + domains[i]);
		}
		return domains;
	}

	/**
	 * @param args
	 * @return
	 */
	public static String[] setProductExecutionEnv(final String[] args) {
		String[] domains;
		if (args.length == 0) {
			domains = CommonUtility.getProductExecutionEnvNames();
		} else {
			domains = args;
		}
		for (int i = 0; i < domains.length; i++) {
			logger.info("Qualified environment for testNG suite creation are : " + domains[i]);
		}
		return domains;
	}

	private static XmlSuite configureRegressionSuite(String domainName, String suiteName) {
		XmlSuite testNGSuite = new XmlSuite();
		testNGSuite.setName(domainName + CommonConstant.UNDER_SCORE + suiteName);
		testNGSuite.setParallel(InitializeConstants.regressionParallelLevel);
		testNGSuite.setThreadCount(InitializeConstants.regressionSuiteThreadCount);
		testNGSuite.setVerbose(InitializeConstants.regressionVerbose);
		testNGSuite.setAllowReturnValues(true);
		testNGSuite.addListener(listener1);
		testNGSuite.addListener(listener2);
		return testNGSuite;
	}

	private static XmlSuite configurePaymentScheduleSuite(String domainName, String suiteName) {
		XmlSuite testNGSuite = new XmlSuite();
		testNGSuite.setName(domainName + CommonConstant.UNDER_SCORE + suiteName);
		testNGSuite.setParallel(InitializeConstants.paymentScheduleParallelLevel);
		testNGSuite.setThreadCount(InitializeConstants.paymentScheduleSuiteThreadCount);
		testNGSuite.setVerbose(InitializeConstants.paymentScheduleVerbose);
		testNGSuite.setAllowReturnValues(true);
		testNGSuite.addListener(listener1);
		testNGSuite.addListener(listener2);
		return testNGSuite;
	}

	private static XmlSuite configureSanitySuite(String domainName, String suiteName) {
		XmlSuite testNGSuite = new XmlSuite();
		testNGSuite.setName(domainName + CommonConstant.UNDER_SCORE + suiteName);
		testNGSuite.setParallel(InitializeConstants.sanityParallelLevel);
		testNGSuite.setThreadCount(InitializeConstants.sanitySuiteThreadCount);
		testNGSuite.setVerbose(InitializeConstants.sanityVerbose);
		testNGSuite.setAllowReturnValues(true);
		testNGSuite.addListener(listener1);
		testNGSuite.addListener(listener2);
		return testNGSuite;
	}

	public static String getAccurateVersionValue(String versionValue) {
		if (!StringUtils.isEmpty(versionValue) && versionValue.contains(CommonConstant.UNDER_SCORE)) {
			return CommonUtility.splitStringUsingPattern(versionValue, CommonConstant.UNDER_SCORE)[1];
		} else {
			return versionValue;
		}
	}

	public static void launchTestSuiteCreation(final String[] envNames) {
		String[] domains;
		if (envNames.length == 0) {
			domains = TestNGSuiteCreationUtility.setProductExecutionEnv(envNames);
		} else {
			domains = envNames;
		}

		for (int i = 0; i < domains.length; i++) {
			String domainName = domains[i];
			ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
					.initializeDomainTestEnvDetailExcelPath(domainName);

			Map<String, List<XlsFileRowDetails>> dashboardHashMap = new LinkedHashMap<>();
			DashboardDetails dashboardDetails = new DashboardDetails();
			dashboardDetails.setDomainName(domainName);
			DashboardExcelReadOperation.readDashboardExcel(dashboardDetails);
			dashboardHashMap.putAll(DashboardProcessingUtility.getXlsFileRowDetailsMapForClass(domainName,
					dashboardDetails.getProjectTestCase()));

			// get the suite names associated with each class
			Map<String, String> suiteMap = new LinkedHashMap<>();
			TestNGSuiteCreationUtility.getSuiteNames(dashboardHashMap, suiteMap);

			// get unique names/count of suite name
			List<String> totalSuite = new ArrayList<>();
			TestNGSuiteCreationUtility.getUniqueSuiteList(suiteMap, totalSuite);

			// create XMLSuites
			Map<String, XmlSuite> xmlSuiteMap = new HashMap<>();
			TestNGSuiteCreationUtility.createTestNGXMLSuites(domainName, totalSuite, xmlSuiteMap);

			// populate each test suite with respective tests
			TestNGSuiteCreationUtility.populateXMLSuite(dashboardHashMap, xmlSuiteMap);

			// Write output of suite in .xml file
			TestNGSuiteCreationUtility.createTestNGSuiteXMLFIles(domainName, xmlSuiteMap);
		}
	}

}
