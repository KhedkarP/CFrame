/**
 * 
 */
package com.cassiopae.framework.util.constant;

/**
 * @author nbhil
 */
public interface ErrorMessageConstant {

	public String LOCATOR_KEY_IS_MANDATORY = "For Locator Key Module is mandatory.";
	public String TEST_CASE_STEP_IS_MANDATORY = "Test Case Steps is mandatory.";
	public String INPUT_TEST_DATA_IS_MANDATORY = "Input Test Data is mandatory when action class is ";
	public String WORK_BOOK_EMPTY = "Work book is empty.";
	public String WORK_SHEET_NAME_NOT_EXIST = "Work Sheet name does not listed in Master Status sheet.";
	public String LOCATOR_KEY_NOT_EXIST = "Locator Key does not exist in Locator Map - ";
	public String EXCEL_READING_FAILED = "Excel sheet reading failed - ";
	public String UNABLE_TO_LOAD_DRIVER = "Error: Unable to load driver class!";
	public String UNABLE_TO_EXECUTE_QUERY = "Error : Unable to execute database query.";
	public String METHOD_NAME_NOT_EXIST = "Method Name does not listed in Master Status sheet.";
	public String IE_DRIVER_INI_FAILED = " IE Driver initialization exception - ";
	public String CHROM_DRIVER_INI_FAILED = " Chrome Driver initialization exception - ";
	public String MOZILLA_DRIVER_INI_FAILED = " Mozilla Driver initialization exception -  ";
	public String EDGE_DRIVER_INI_FAILED = " Edge Driver initialization exception -  ";
	public String WORK_SHEET_NOT_FOUND = "In Test Data work book given work sheet not found : -";
	public String KEY_NOT_PRESENT = "Key is not present in test data Map : - ";
	public String INVALID_ACTION_ENTERED = "Invalid Action entered - ";
	public String ACTION_IS_NOT_PRESENT_FOR_LOACATOR_KEY = "Action is not present for locator key - ";
	public String ERROR_ROLLBACK_CONNECTION = "Error: Unable to  rollback transaction";
	public String ERROR_CLOSING_CONNECTION = "Error: Unable to  close connection";
	public String OBJECT_REPO_INI_FAILED = "Object Repository initialization failed.";
	public String BACK_UP_CREATION_FAILED = "Backup creation failed for file before reading data from Excel.";
	public String FILE_CORRUPTED = "While reading the Excel file got corrupt. Deleting corrupted file and renaming backupfile.";
	public String EXCEL_FILE_DELETION_FAILED = "Exception while deleting corrupted excel file";
	public String EXCEL_COPPING_FAILED = "Exception occureed while copying backup file to original : ";
	public String FILE_NOT_FOUND = "Object reposotory file is not found at : ";
	public String DUPLICATE_KEY_FOUND = " : Duplicate key present in worksheet : ";
	public String FILE_DELETION_FAILED = "Exception while deleting backup excel file";
	public String APPLICATION_CRASH_ERROR_MSG = " Application crash due to exception  :- ";
	public String EXTERNAL_WAIT_INPUT_ERROR_MSG = "Input Data should be only a Number without space";

	public String ARTHMTC_RLTNL_OPERATION_ACTION_INPUTDATA_INCORRECT = "Input data is not formatted correctly to perform ExecuteRelationalOp - ";

	public String CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE = "Row number to generate dynamic xpath should be a numeric, please check Input Test Data Column in test case for Action - ";

	public String INVALID_DATA_FORMAT_FOR_AMOUNT_CONVERSION_FROM_DB_TO_UI = "Data base amount format is different than decimal Formate, Please Configure/Update the amount formate conversion action";

	public String TEST_TYPE_CONT_SPEC_CHAR = "Test type should not contain any special character ";
	public String CLASS_NAME_SHOULD_START_WITH_REG_OR_SAN = "Workbook name should either starts with REG or SAN in its name.";
	public String CLASS_NAME_MAX_LENTH_CROSSED = "Length of Workbook cannnot be gretaer than 150 characters.";
	public String CLASS_NAME_CONT_SPEC_CHAR = "Workbook should not contain any special character except underscore(_).";
	public String DUPLICATE_METHOD_NAME_FOR_CLASS = "Duplicate worksheet found in Workbook ";
	public String DUPLICATE_METHOD_NAME = "Duplicate worksheet name is : ";
	public String METHOD_NAME_MAX_LENGTH_CROSSED = "Length of worksheet name cannnot be greater than 31 characters.";
	public String METHOD_NAME_CONT_SPEC_CHAR = "Worksheet name should not contain any special character except underscore(_).";
	public String METHOD_NAME_CONT_INVALID_WORD = "Worksheet name should contain  FO or BO or POS in its name ";
	public String INVALID_PAY_SCHED_VALUE = "PaymentScheduleScenerio should be either Yes or No ";
	public String INVALID_BROWSER_NAME = "Browser name should be either chrome or IE ";
	public String BROWSER_NAME_CONT_SPEC_CHAR = "Browser name should not contain any special character ";
	public String EMPTY_WORKBOOK = "No record qualified or workbook is empty ";
	public String SAME_CLASS_AND_METHOD_NAME = "Test case workbook name and Test case worksheet name should not be same ";
	public String TEST_CASE_WORKBOOK_NAME = " for Test case workbook name: ";
	public String TEST_CASE_WORKSHEET_NAME = " and Test case worksheet: ";
	public String AT_ROW_NO = "at row number : ";
	public String FOR_TICKET = "For test case : ";
	public String DUPLICATE_PIORITY_FOR_CLASS = "Duplicate priority found for Workbook : ";
	public String DUPLICATE_PRIORITY_FOR_METHOD = " and  worksheet name is : ";
	public String DEPENDENT_METHOD_NOT_EXIST = "There is dependency for the scenarios , please review test suite and correct dependancy ";
	public String INVALID_PRIORITY = "Priority of dependent scenario should be less then priority of actual worksheet ";
	public String TYPE_SAN_QA = "if test type is SAN then Workbook name should starts with SAN_ ";
	public String TYPE_REG_QA = "if test type is REG then Workbook name should starts with REG_ ";
	public String TEST_CASE_WORK_BOOK_EXIST = "Test case workbook aleady present in old test package. Please update worbook name ";
	public String TEST_CASE_WORK_BOOK_NOT_EXIST = "Test case workbook does not present in old test package. Please update this entry ";
	public String TEST_CASE_WORK_SHEET_NOT_PRESENT = " : test case worksheet is not present in old test case workbook. Please check this entry ";
	public String LOGIN_FAILED_ERROR_MESSAGE = "Login Into application Fail - ";

	// SQL pre-requisites constansts
	public String ERROR_WHILE_READING_EXCEL_FILE = "Error occured while reading .xlsx file ";
	public String DATABASE_CONNECTION_ERROR_MESSAGE = "Error occured while connectiong to database ";
	public String SQL_PRE_REQUISITE_LOCATION = "Prerequisite SQL's location : ";
	public String EXECUTION_STARTED_FOR_PRE_REQUISITES = " Number of domains qualified for executing sql pre-requisites are : ";

	// *** Test Class creation Error message constants

	public String BLANK_WORKBOOK_NAME_ERROR_MESSAGE = " Workbook name should not be blank";
	public String BLANK_WORKSHEET_NAME_ERROR_MESSAGE = " Worksheet name should not be blank";
	public String BLANK_TEST_TYPE_ERROR_MESSAGE = " Test type field value cannot be blank. It should contain either ";
	public String BLANK_BROWSER_NAME_ERROR_MESSAGE = " Browser name value cannot be blank ";
	public String BLANK_PRIORITY_NAME_ERROR_MESSAGE = " Priority value cannot be blank ";

	// compare Date constats
	public static final String COMPARE_DATE_ACTION_INPUTDATA_INCORRECT = "Please check the date parameters provided in compare date action, There should be 2 date parameters";
	public static final String CHECK_INBETWEEN_DATE_ACTION_INPUTDATA_INCORRECT = "Please check the date parameters provided in compare date action, There should be 3 date parameters";

	// dynamic date action constants

	public String REQUIRED_INPUT_TEST_DATA_IS_NOT_CORRECT = "Please check the parameters provided in generate dyanamic date action, There should be 3 parameters seprated by ',' and only digit value should be provided";

	// ErrorMSG for Re-name File
	public String GIVEN_FILE_NAMESEPRATOR_ISNOT_VALID = "File name seprator is not valid ,Please provide valid character other than [*?:,'/','\','[',']'] ";
	public String FAILED_FILE_RENAMING = " Unable to change file Name please check Input data";
	public String FILE_NAME_LENGTH_IS_NOT_VALID = "Length of File name is exceeding 150 character , please shorten the length";
	public String DATE_FORMATE_ERROR_MSG = "Expected DateFormat is Invalid Format should folow below Pattern \n MM//dd//yyyy = 01/02/2018 \n dd-M-yyyy hh:mm:ss = 02-1-2018 06:07:59  \n dd MMMM yyyy = 02 January 2018  \n dd MMMM yyyy zzzz = 02 January 2018 India Standard Time \n For more Details about DateFormat please refer below link ----> \n  https://docs.oracle.com//javase//10/docs//api/java//text//SimpleDateFormat.html \n";

	// jasper validation message
	public String JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE = "Input Test Data/Store Value In Variable not formatted correctly it should be a numeric, please check Input Test Data/Store Value In Variable Columns in test case for Action - ";
	public String JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE = "Input Test Data/Store Value In Variable are not formatted correctly Column Name is not provied, please check Input Test Data/Store Value In Variable Columns in test case for Action - ";
	public String NO_RECEIVABLE_GENERATED = "No receivable generated on given jasperReport";
	public String JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE = "Variables for storing data are not provided in correct format.";
	public String NO_EXPENSE_GENERATED = "Expenses are not generated on given Jasper Report";
	public String REQUIRED_VARABLE_MSG = " Stored variable count is not equals for Input Test Data varibles for Action > ";
	// drag and drop
	public String DRAG_AND_DROP_ERROR_MESSAGE = " Drag and Drop operation Faild Due to Error >>";

	// dump validation error messages

	public String DUMP_EXCEL_FILE_WRITE_ERROR_MESSAGE = "Error occured while writing data to dumpValidationSummary excel file :";
	public String DUMPA_VALIDATION_STARTED_MESSAGE = "Dump validation started for ";

	// IsDownlodedFileEmpty action error messagess
	public String PLEASE_CHECK_INPUT_PARAMETERS = "Please check InputTestData parameters";
	public String REQURIED_FILE_IS_NOT_MSG = "Requried file is not availe at location";
	public String DOWNLOD_FILE_EMPTY_MSG = "Downloaded file is empty";
	public String PLEASE_CHECK_INPUTPARAMETERS = " Please check InputTestData parameters for excel files ";
	public String ISSUE_OCCURED_WHILE_READ_MSG = " Issue occurs while reading file please check input fileName is present on location or not ";
	public String GIVEN_EXCEL_SHEET_MSG = " Given Excel  Sheet ";
	public String HAS_DATA_MSG = " Has data";
	public String DOESNOT_NOT_HAVE_ANY_DATA = " does not have any Data";
	
	// navigate to main module
	
	String OVERFLOWICON_NOT_PRESENT_MESSAGE="Overflow icon is not present on menu bar";

	// Replace value 
	String   INVALID_PARAMETERS= " Please check input parametrs it should correct format ";
	
	String EDGE_PROFILE_NOTFOUND=" Edge Profile folder does not Exist at Testcase BrowserInstance location ";
	String ERROR_MESSAGE_DELETEPROFILE=" Error occured while deleting Edge profile due to error: ";
	String ERROR_OCCURED_MESSAGE="Error occurred while copying Edge browser profile: ";
	
	//ExtractPDFDataAndValidate
	
	String INPUT_PARAMENTER_INCORRECT_MESSAGE= "Input parameters are incorrect please check Input Test Data | Store Value In Variable ";
	String ISSUE_OCCURED_PDF_EXTRACTION_MSG="Issue occured while extracting data from PDF and convert into log  ";
	
	//UnZip File Error messages
	String  EXPECTED_FILE_NOT_MSG="Issue occured while extracting zip file present at location: ";
	String  INPUT_FILE_NOT_ZIP_MSG="The input file is not a zip type";

	
	//rename Error message 
	String ERROR_OCCURED_FILE_MSG="Error occured while copying file at Loacation: ";
	
	// EnterDateAction
	String DATE_FIELD_NOT_EMPTY_MSG=" Date field is not empty, clearing it";
	
	
	// Compare Dates logs
	String INPUT_DATES_ORDER_MISMATCHED="The given input dates are not in the ascending order";
	String INPUT_DATES_DESCENDING_ORDER_MISMATCHED="The given input dates are not in the descending order";
	
}
