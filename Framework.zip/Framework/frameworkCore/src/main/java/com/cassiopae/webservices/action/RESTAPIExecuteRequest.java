package com.cassiopae.webservices.action;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.webservices.action.util.RestWSUtility;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;

public class RESTAPIExecuteRequest implements WSAction {

	private static Logger logger = LogManager.getLogger(RESTAPIExecuteRequest.class);

	@Override
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		/*
		 * Reading input data parameters
		 */
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String jsonBodyInputParameters[] = null;
		String inputJsonFileName = null;
		String apiRequestType = null;
		String endpointURL = null;
		String[] storedVariables = null;
		String[] inputData;
		try {
			inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData().trim(),
					CommonConstant.PIPE_SEPARATOR);
			jsonBodyInputParameters = null;
			inputJsonFileName = null;
			apiRequestType = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
					inputData[0]);
			endpointURL = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[1]);
			if (inputData.length == 2) {
				inputJsonFileName = testCaseDetailTO.getWorkSheetName();
			} else if (inputData.length == 3) {
				inputJsonFileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
						inputData[2]);
			} else if (inputData.length == 4) {
				jsonBodyInputParameters = CommonUtility.splitStringUsingPattern(inputData[3],
						CommonConstant.COMMA_SEPERATOR);
				inputJsonFileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
						inputData[2]);
			}
			storedVariables = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					CommonConstant.PIPE_SEPARATOR);
		} catch (Exception e) {
			logger.info(WSErrorMessageConstant.PLEASE_CHECK_INPUT_REQUEST_METHOD_MSG + e.getMessage());
			throw new CATTException(WSErrorMessageConstant.PLEASE_CHECK_INPUT_REQUEST_METHOD_MSG);

		}
		String[] updatedJsonBody = getUpdatedJSONBody(inputJsonFileName, jsonBodyInputParameters, testCaseDetailTO);
		ExtractableResponse<Response> extractResponse = RestWSUtility.executeRESTRequest(apiRequestType,
				updatedJsonBody[0], endpointURL, testCaseDetailTO);
		String statusCode = RestWSUtility.getResponseData(extractResponse, WSReportingLoggerConstant.STATUSCODE_MSG);
		String responseBody = RestWSUtility.getResponseData(extractResponse,
				WSReportingLoggerConstant.RESPONSEBODY_MSG);
		reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Code + statusCode);
		reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + responseBody);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(storedVariables[0], statusCode);
			testCaseDetailTO.getVariableHolder().put(storedVariables[1], responseBody);
		}
		RestWSUtility.saveRestAPIFiles(inputJsonFileName, WSReportingLoggerConstant.RESPONSE_NAME, updatedJsonBody[1],
				responseBody);
	}

	public static String[] getUpdatedJSONBody(String JsonFileName, String apiInputParameters[],
			TestCaseDetail testCaseDetailTO) {
		String outparms[] = new String[2];
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String productName = testCaseDetailTO.getTestCaseCommonData().getDomainName();
		/*
		 * InitializeDomainWiseRestAPIRequest folder path
		 */
		String requestPath = DomainInitialization.initializeDomainWiseRestAPIRequestsPath(productName);
		/*
		 * Create API response folder
		 */
		String responseFolderPath = RestWSUtility.createAPIResponseFolder(productName,
				testCaseDetailTO.getWorkBookName(), testCaseDetailTO.getWorkSheetName());

		/*
		 * Checking API request folder is available or not
		 */
		String fileStatus = SeleniumUtility.checkFileIsAvailableAtLocationOrNOT(requestPath, reportingLogger,
				JsonFileName);
		String updatedRequest = null;
		if (fileStatus.equals(CommonConstant.TRUE_VALUE)) {
			/* ReadJSon file from location and parse to JSON Object */
			String jsonObj = RestWSUtility.readJsonFile(reportingLogger, requestPath, JsonFileName);
			/* Update JSON based on User Input */
			updatedRequest = RestWSUtility.updateRestAPIRequest(apiInputParameters, jsonObj, testCaseDetailTO);
			reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_REQUEST_Body + updatedRequest);
			/* Save Updated Json file at API responses folder */
			RestWSUtility.saveRestAPIFiles(JsonFileName, WSReportingLoggerConstant.REQUEST_NAME, responseFolderPath,
					updatedRequest);
			/* Get RestURI end point */

		} else {
			updatedRequest = "{}";
		}
		outparms[0] = updatedRequest;
		outparms[1] = responseFolderPath;
		return outparms;
	}
}
