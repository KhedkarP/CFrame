package com.cassiopae.framework.xl.reader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

public class ReadExcelFile {
	private ReadExcelFile() {

	}

	private static Logger trace = LogManager.getLogger(ReadExcelFile.class);

	public static List<GenericRow> readExcelFile(final String testCaseExcelPath, final String workBookName,
			final String testCaseSheetName, String locale,
			Map<String, Integer> headerMap,String workSheetName) {
		List<GenericRow> genericRowList = new ArrayList<>();
		GenericRow genericRow = null;
		try (Workbook workbook = WorkbookFactory.create(new File(testCaseExcelPath + workBookName))) {
			workbook.setForceFormulaRecalculation(true);
			HSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			DataFormatter dataFormatter = new DataFormatter();
			boolean flag=false;
			
			for(int noOfsheet=0; noOfsheet<workbook.getNumberOfSheets();noOfsheet++) {
				String sheetName=workbook.getSheetAt(noOfsheet).getSheetName();
				if(sheetName.equals(testCaseSheetName)) {
					flag=true;
				}
			}
			if(!flag) {
				String errorMessage = testCaseSheetName+" - Sheet is not exists in excel - "+workBookName +" in excel file present at: "+testCaseExcelPath;
				trace.info(errorMessage);
				throw new CATTException(errorMessage);
			}
			Sheet sheet = workbook.getSheet(testCaseSheetName);
			Row topRow = sheet.getRow(sheet.getFirstRowNum()); // Get first row//sheet.getTopRow()
			int minColIx = topRow.getFirstCellNum(); // get the first column index for a row
			int maxColIx = topRow.getLastCellNum(); // get the last column index for a row
			Map<String, Integer> reqCells = new HashMap<>();
			reqCells = validateSheetColumns(topRow, minColIx, maxColIx, reqCells);
			headerMap.putAll(reqCells);
			String cellValue = null;
			for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
				genericRow = new GenericRow();
				Iterator itr = reqCells.entrySet().iterator();
				while (itr.hasNext()) {
					Map.Entry pair = (Map.Entry) itr.next();
					cellValue = ExcelReader.formulaEvaluator(sheet.getRow(rowNo).getCell((int) pair.getValue()),
							dataFormatter, locale,workSheetName);
					genericRow.setCellValue(Integer.parseInt(pair.getValue().toString()), cellValue);
				}
				genericRowList.add(genericRow);
			}
		} catch (EncryptedDocumentException |  IOException e) {
			trace.error("Test Case data file reading failed : " + testCaseSheetName, e);
			throw new ValidatorException("Test Case excel data file reading failed : " + e.getMessage());
		} catch(IllegalStateException ise) {
			trace.error("Test Case data file reading failed : " + testCaseSheetName, ise);
			
		}
		catch (ValidatorException l_l_ex) {
			throw l_l_ex;
		}
		return genericRowList;
	}

	public static Map<String, Integer> validateSheetColumns(final Row topRow, final int minColIx, final int maxColIx,
			final Map<String, Integer> reqCells) {
		String cellHeaderName = null;
		for (int colIx = minColIx; colIx < maxColIx; colIx++) {
			if (topRow.getCell(colIx) != null) {
				cellHeaderName = StringUtils.trimToEmpty(topRow.getCell(colIx).getStringCellValue())
						.replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
				reqCells.put(cellHeaderName, colIx);
			}
		}
		if (reqCells.isEmpty()) {
			throw new ExcelValidatorException(ReportLoggerConstant.WORKSHEET_EMPTY_MESSAGE);
		}
		return reqCells;
	}
}
