/**
 * 
 */
package com.cassiopae.custom.action;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateUtils;

/**
 * @author gmenakshi
 *
 */
public class ChangeDateFomatAction implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputTestDatas = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String givenDatevalue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[0]);
		String givenDateFormatvalue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[1]);
		String ChangeFormat = DateUtils.chageDateFormat(excelTestCaseFieldsTO, testCaseDetailTO, givenDatevalue,
				givenDateFormatvalue);

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), ChangeFormat);
		}
	}
}
