/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author jraut
 *
 */
public class GetAttributeNameAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String nameAttributeValue = GenericAction.getAttributeName(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + nameAttributeValue);
		
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), nameAttributeValue);
		}
	}

}
