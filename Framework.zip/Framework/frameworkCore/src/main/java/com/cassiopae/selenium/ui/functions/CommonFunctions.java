package com.cassiopae.selenium.ui.functions;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.dao.utility.DatabaseUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTSQLException;
import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class CommonFunctions {

	/*
	 * Login Operation
	 */
	private static Logger tracelogger = LogManager.getLogger(CommonFunctions.class);
	static Map<String, List<String>> generalLocatorMap = ObjectRepoInitialization.masterLocatorMap.get("General");
	static Map<String, List<String>> panelsLocatorMap = ObjectRepoInitialization.masterLocatorMap.get("Panels");
	static Map<String, List<String>> eventsLocatorMap = ObjectRepoInitialization.masterLocatorMap.get("Events");

	public static String login(final TestCaseDetail testCaseDetail) {
		String workSheetName = testCaseDetail.getTestCaseCommonData().getWorkSheetName();
		Logger reportingLogger = testCaseDetail.getTestCaseCommonData().getReportingLogger();
		WebDriver driver = testCaseDetail.getTestCaseCommonData().getDriver();
		String userName = testCaseDetail.getTestCaseCommonData().getUserName();
		String password = testCaseDetail.getTestCaseCommonData().getPassword();
		int excelRowNo = testCaseDetail.getTestCaseCommonData().getExcelRowNo();
		String excelRegressionDashboardSheetName = ApplicationConstant.excelStatusSheetName;
		String domainName = testCaseDetail.getTestCaseCommonData().getDomainName();

		String applicationVersion = null;
		String applicationURL = null;
		if (StringUtils.startsWith(workSheetName, DBConstant.CC_APP_SHEET_NAME)) {
			loginToApplicationConfigConsole(testCaseDetail, reportingLogger, driver, userName, password);
		} else if (workSheetName.contains(DBConstant.BO_APP_SHEET_NAME)
				|| workSheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
			if (workSheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
				applicationURL = ApplicationContext.baseUrlBO;
			} else if (workSheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
				applicationURL = ApplicationContext.baseUrlMO;
			}
			if (ApplicationContext.headlessModeOfExecution && (CommonConstant.CHROME_BROWSER
					.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName())
					|| CommonConstant.MS_EDGE_BROWSER
							.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName()))) {
				tracelogger.info("Setting window size to : 1382, 744");
				driver.manage().window().setSize(new Dimension(1382, 744));
			}
			applicationVersion = loginToApplicationFOBO(testCaseDetail, reportingLogger, driver, userName, password,
					excelRowNo, excelRegressionDashboardSheetName, domainName, applicationVersion, applicationURL);

		} else if (workSheetName.contains(DBConstant.POS_MODULE)) {
			loginToApplicationPOS(testCaseDetail, reportingLogger, driver, userName, password);

		} else {
			reportingLogger.info(ReportLoggerConstant.WORKSHEET_NAME_KO_MESSAGE);
		}
		return applicationVersion;
	}

	/**
	 * @param testCaseDetail
	 * @param reportingLogger
	 * @param driver
	 * @param userName
	 * @param password
	 */
	private static void loginToApplicationPOS(final TestCaseDetail testCaseDetail, Logger reportingLogger,
			WebDriver driver, String userName, String password) {
		String applicationURL = ApplicationContext.posURL;
		WebElement element1 = null;
		WebElement element2 = null;

		try {
			String versionURL = applicationURL + ReportLoggerConstant.VERSION_TEXT;
			reportingLogger.info(ReportLoggerConstant.CHECK_APPLICAITON_VERSION_MSG + versionURL);
			driver.get(versionURL);
			getPOSversionDetails(testCaseDetail, reportingLogger, driver);
		} catch (Exception er) {
			reportingLogger.info(ReportLoggerConstant.ISSUE_OCCURED_WHILE_GETTING_VERSION_MSG + er);
			tracelogger.error(er.getMessage());
		}

		reportingLogger.info(ReportLoggerConstant.NAVIGATE_TO_POS_MSG + applicationURL);
		driver.get(applicationURL);
		WebDriverWait wait = new WebDriverWait(driver, InitializeConstants.please_wait_icon_loading_time);
		wait.until(ExpectedConditions
				.elementToBeClickable(driver.findElement(By.xpath((generalLocatorMap.get("POS.UserName")).get(0)))));

		if (ApplicationContext.headlessModeOfExecution && (CommonConstant.CHROME_BROWSER
				.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName())
				|| CommonConstant.MS_EDGE_BROWSER
						.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName()))) {
			driver.manage().window().setSize(new Dimension(1366, 768));
		}
		try {
			driver.findElement(By.xpath((generalLocatorMap.get("POS.UserName")).get(0))).isDisplayed();
			CommonFunctions.explicitWait(2000);
		} catch (NoSuchElementException ele) {
			reportingLogger.info(ReportLoggerConstant.APP_NOT_ACCESSABLE + applicationURL);
			reportingLogger.info(ReportLoggerConstant.REDIRECT_MSG + applicationURL);
			driver.get(applicationURL);
			CommonFunctions.explicitWait(2000);
			wait.until(ExpectedConditions.elementToBeClickable(
					driver.findElement(By.xpath((generalLocatorMap.get("POS.UserName")).get(0)))));
		}
		reportingLogger.info(ReportLoggerConstant.APPLICAITON_LAUNCHED_SUCESSFULLY_MSG);
		reportingLogger.info(ReportLoggerConstant.ENTER_USERNAME_MSG + userName);
		element1 = driver.findElement(By.xpath((generalLocatorMap.get("POS.UserName")).get(0)));
		element1.clear();
		element1.sendKeys(userName);
		reportingLogger.info(ReportLoggerConstant.ENTER_PASSWORD_MSG + password);
		element2 = driver.findElement(By.xpath((generalLocatorMap.get("POS.PassWord")).get(0)));
		element2.clear();
		element2.sendKeys(password);
		GenericAction.clickOn(ReportLoggerConstant.CLICK_ON_LOGIN_MSG, "POS.Login", generalLocatorMap, driver,
				reportingLogger);
		wait.until(ExpectedConditions
				.visibilityOf(driver.findElement(By.xpath((generalLocatorMap.get("DealHomePage.Header")).get(0)))));
		String status = GenericAction.isPresentAndDisplayed(ReportLoggerConstant.CHECK_PROFILE_DROPDOWN_MSG,
				ReportLoggerConstant.ELEMENT_NOT_DISPLAYED_MSG, "DealHomePage.Header", generalLocatorMap, driver,
				reportingLogger, null);
		if (status.contentEquals(CommonConstant.TRUE_VALUE)) {
			reportingLogger.info(ReportLoggerConstant.LOGIN_TO_APP_SUCESSFULLY_MSG);
		}
	}

	/**
	 * @param testCaseDetail
	 * @param reportingLogger
	 * @param driver
	 * @param userName
	 * @param password
	 */
	private static void loginToApplicationConfigConsole(final TestCaseDetail testCaseDetail, Logger reportingLogger,
			WebDriver driver, String userName, String password) {
		String applicationURL = ApplicationContext.configConsoleURL;
		WebElement element1 = null;
		WebElement element2 = null;

		try {
			String versionURL = applicationURL + ReportLoggerConstant.VERSION_TEXT;
			reportingLogger.info(ReportLoggerConstant.CHECK_APPLICAITON_VERSION_MSG + versionURL);
			driver.get(versionURL);
			getPOSversionDetails(testCaseDetail, reportingLogger, driver);
		} catch (Exception er) {
			reportingLogger.info(ReportLoggerConstant.ISSUE_OCCURED_WHILE_GETTING_VERSION_MSG + er);
			tracelogger.error(er.getMessage());
		}

		reportingLogger.info(ReportLoggerConstant.NAVIGATE_TO_CC_URL_MSG + applicationURL);
		driver.get(applicationURL + CommonConstant.FORWARD_SLASH);
		WebDriverWait wait = new WebDriverWait(driver, InitializeConstants.please_wait_icon_loading_time);
		wait.until(ExpectedConditions.elementToBeClickable(
				driver.findElement(By.xpath((generalLocatorMap.get("ConfigConsole.Username")).get(0)))));

		if (ApplicationContext.headlessModeOfExecution && CommonConstant.CHROME_BROWSER
				.equalsIgnoreCase(testCaseDetail.getTestCaseCommonData().getBrowserName())) {
			driver.manage().window().setSize(new Dimension(1920, 1080));
		}
		try {
			driver.findElement(By.xpath((generalLocatorMap.get("ConfigConsole.Username")).get(0))).isDisplayed();
			CommonFunctions.explicitWait(2000);
		} catch (NoSuchElementException ele) {
			reportingLogger.info(ReportLoggerConstant.APP_NOT_ACCESSABLE + applicationURL);
			reportingLogger.info(ReportLoggerConstant.REDIRECT_MSG + applicationURL);
			driver.get(applicationURL);
			CommonFunctions.explicitWait(2000);
			wait.until(ExpectedConditions.elementToBeClickable(
					driver.findElement(By.xpath((generalLocatorMap.get("ConfigConsole.Username")).get(0)))));
		}
		reportingLogger.info(ReportLoggerConstant.APPLICAITON_LAUNCHED_SUCESSFULLY_MSG);
		reportingLogger.info(ReportLoggerConstant.ENTER_USERNAME_MSG + userName);
		element1 = driver.findElement(By.xpath((generalLocatorMap.get("ConfigConsole.Username")).get(0)));
		element1.clear();
		element1.sendKeys(userName);
		reportingLogger.info(ReportLoggerConstant.ENTER_PASSWORD_MSG + password);
		element2 = driver.findElement(By.xpath((generalLocatorMap.get("ConfigConsole.Password")).get(0)));
		element2.clear();
		element2.sendKeys(password);
		GenericAction.clickOn(ReportLoggerConstant.CLICK_ON_LOGIN_MSG, "ConfigConsole.Login", generalLocatorMap, driver,
				reportingLogger);
		/*
		 * wait.until(ExpectedConditions
		 * .visibilityOf(driver.findElement(By.xpath((generalLocatorMap.get(
		 * "DealHomePage.Header")).get(0))))); String status =
		 * GenericAction.isPresentAndDisplayed(ReportLoggerConstant.
		 * CHECK_PROFILE_DROPDOWN_MSG, ReportLoggerConstant.ELEMENT_NOT_DISPLAYED_MSG,
		 * "DealHomePage.Header", generalLocatorMap, driver, reportingLogger, null); if
		 * (status.contentEquals(CommonConstant.TRUE_VALUE)) {
		 * reportingLogger.info(ReportLoggerConstant.LOGIN_TO_APP_SUCESSFULLY_MSG); }
		 */
	}

	/**
	 * @param testCaseDetail
	 * @param reportingLogger
	 * @param webDriver
	 * @param userName
	 * @param password
	 * @param excelRowNo
	 * @param excelRegressionDashboardSheetName
	 * @param domainName
	 * @param applicationVersion
	 * @param applicationURL
	 * @return
	 */
	private static String loginToApplicationFOBO(final TestCaseDetail testCaseDetail, Logger reportingLogger,
			WebDriver webDriver, String userName, String password, int excelRowNo,
			String excelRegressionDashboardSheetName, String domainName, String applicationVersion,
			String applicationURL) {

		try {
			CommonUtility.logTransactions(webDriver,
					"T00_Clearing application/browser session - " + applicationURL + "sessiontermination");
			CommonUtility.logTransactions(webDriver, "T01_Navigate to TEST url - " + applicationURL);
			reportingLogger.info("T01_Navigate to TEST url - " + applicationURL);
			webDriver.get(applicationURL);
			String currentTitleOfapplication = webDriver.getTitle();
			reportingLogger.info("Title of window is : " + currentTitleOfapplication);
			String expectedTitles = returnExpectedApplicationTitle(domainName, testCaseDetail.getWorkSheetName());
			boolean isApplicationLaunched = true;
			if (null != expectedTitles) {
				isApplicationLaunched = validateTitle(currentTitleOfapplication, expectedTitles);
				if (!isApplicationLaunched) { // !currentTitleOfapplication.equals(expectedTitle)
					reportingLogger.info("Application homepage is not accessible : " + applicationURL);
					webDriver.navigate().refresh();
					Thread.sleep(2000);
					reportingLogger.info("Redirecting again to URL : " + applicationURL);
					webDriver.get(applicationURL);
					currentTitleOfapplication = webDriver.getTitle();
					isApplicationLaunched = validateTitle(currentTitleOfapplication, expectedTitles);
					if (!isApplicationLaunched) {
						reportingLogger.error(
								"Application URL is not accessible, please check network connectivity OR app server up & running");
						throw new CATTException(
								"Application URL is not accessible, please check network connectivity OR app server up & running");
					}
				}
			}
			WebElement webElement;
			reportingLogger.info("Application launched Successfully");
			CommonUtility.logTransactions(webDriver, "T02_Enter Username & Password");
			reportingLogger.info("Enter UserName as : " + userName);
			webElement = webDriver.findElement(By.xpath((generalLocatorMap.get("LoginPage.input.UserName")).get(0)));
			webElement.clear();
			webElement.sendKeys(userName);
			reportingLogger.info("Enter Password as : " + password);
			webElement = webDriver.findElement(By.xpath((generalLocatorMap.get("LoginPage.input.Password")).get(0)));
			webElement.clear();
			webElement.sendKeys(password);
			CommonUtility.logTransactions(webDriver, "T03_Click on login button");
			reportingLogger.info("Click on login button");
			webDriver.findElement(By.xpath((generalLocatorMap.get("LoginPage.button.Login")).get(0))).click();
			CommonUtility.logTransactions(webDriver, "T04_Click on User Link");
			// WebDriverListener.checkPleaseWaitLoadingStability(webDriver);
			reportingLogger.info("Click on User Link");
			webDriver.findElement(By.xpath((generalLocatorMap.get("HomePage.span.UserLink")).get(0))).click();
			CommonUtility.logTransactions(webDriver, "T05_Click on About option");
			reportingLogger.info("Click on About option");
			webDriver.findElement(By.xpath((generalLocatorMap.get("HomePage.UserLink.span.About")).get(0))).click();
			WebElement webElement2 = webDriver
					.findElement(By.xpath((generalLocatorMap.get("HomePage.about.span.Version")).get(0)));
			Assert.assertEquals(true, webElement2.isDisplayed());
			applicationVersion = webElement2.getText().split(":")[1];
			getBuildDetails(reportingLogger, webDriver);
			reportingLogger.info("Login into Application Successfully, version - " + applicationVersion);
			webDriver.findElement(By.xpath((generalLocatorMap.get("HomePage.button.Close")).get(0))).click();
			testCaseDetail.getTestCaseCommonData().getVariableHolder().put("AppVersion", applicationVersion);
		} catch (Exception e) {
			reportingLogger.error("Login into application failed" + e.getMessage());
			tracelogger.info("Login into application failed", e);
			throw new CATTException(ErrorMessageConstant.LOGIN_FAILED_ERROR_MESSAGE + e.getMessage());
		}
		return applicationVersion;
	}

	private static boolean validateTitle(String currentTitleOfapplication, String expectedTitles) {
		String[] appTitles = CommonUtility.splitStringUsingPattern(expectedTitles, CommonConstant.COMMA_SEPERATOR);
		return StringUtils.containsAny(currentTitleOfapplication, appTitles);
	}

	public static boolean validateExcelFileName(String currentExcelFileName, String expectedFilesArray) {
		String[] appTitles = CommonUtility.splitStringUsingPattern(expectedFilesArray, CommonConstant.COMMA_SEPERATOR);
		return StringUtils.containsAny(currentExcelFileName, appTitles);
	}

	/**
	 * This methods sets the locale for the particular user as per configuration
	 * 
	 * @param workSheetName
	 * @param userName
	 * @param domainName
	 */
	public static void updateUserLocale(String workSheetName, String userName, String domainName) {
		if (userName != null) {
			String locale = CommonFunctions.getLocaleForDomain(domainName);
			DatabaseUtility.executeUpdateQuery(workSheetName, "update UTIPREFERENCE set UPRSTRINGVALUE='" + locale
					+ "' where UPRCODE='LOCALE' AND UTICODE = '" + userName + "'");
		}
	}

	public static String getLocaleForDomain(String domainName) {
		if (InitializeConstants.localeDetails.containsKey(domainName)) {
			tracelogger.info("Setting locale to : " + InitializeConstants.localeDetails.get(domainName)
					+ " for product : " + domainName);
			return InitializeConstants.localeDetails.get(domainName);
		} else {
			tracelogger.info("Setting default locale to : " + InitializeConstants.localeDetails.get("DEFAULT")
					+ " for product - " + domainName);
			return InitializeConstants.localeDetails.get("DEFAULT");
		}
	}

	/**
	 * @param reportingLogger
	 * @param driver
	 */
	private static void getBuildDetails(Logger reportingLogger, WebDriver driver) {
		try {
			String buildNumber = driver
					.findElement(By.xpath(generalLocatorMap.get("HomePage.about.a.buildNumber").get(0)))
					.getAttribute("title");
			reportingLogger.info(buildNumber);
		} catch (Exception exp) {
			tracelogger.error("Issue occured while fetching build number: " + exp);
		}
	}

	/**
	 * @param testCaseDetail
	 * @param reportingLogger
	 * @param driver
	 */
	private static void getPOSversionDetails(final TestCaseDetail testCaseDetail, Logger reportingLogger,
			WebDriver driver) {
		String versioDetails = driver.findElement(By.xpath((generalLocatorMap.get("POS.Version.body.Version")).get(0)))
				.getText();
		reportingLogger.info("Version.txt details: " + versioDetails);
		String posAppVersion = versioDetails.split("version:")[1].split("\nbranch")[0];
		reportingLogger.info("Application version is : " + posAppVersion.trim());
		testCaseDetail.getTestCaseCommonData().getVariableHolder().put("AppVersion", posAppVersion.trim());
	}

	public static void logout(final TestCaseDetail testCaseDetail) {
		String workSheetName = testCaseDetail.getWorkSheetName();
		Logger logger = testCaseDetail.getReportingLogger();
		WebDriver driver = testCaseDetail.getDriver();

		if (StringUtils.startsWith(workSheetName, DBConstant.CC_APP_SHEET_NAME)) {
			GenericAction.clickForPOS("Click on Editeur button", "ConfigConsole.Editeur", generalLocatorMap, driver,
					logger);
			GenericAction.clickForPOS("Click on Logout button", "ConfigConsole.Logout", generalLocatorMap, driver,
					logger);
			logger.info("Logged out successfully");
			SeleniumUtility.takeScreenshotAugmenter(driver, testCaseDetail.getDomainName(),
					testCaseDetail.getWorkBookName(), workSheetName, testCaseDetail.getReportingLogger());
		} else if (workSheetName.contains(DBConstant.MO_MODULE) || workSheetName.contains(DBConstant.BO_MODULE)) {
			try {
				logger.info("Click on Editeur_Cassiopae");
				driver.findElement(By.xpath((generalLocatorMap.get("HomePage.span.UserLink")).get(0))).click();
				logger.info("Click on Logout option");
				driver.findElement(By.xpath((generalLocatorMap.get("HomePage.UserLink.span.Logout")).get(0))).click();
				logger.info("Logged out Successfully");
				driver.findElement(By.xpath((generalLocatorMap.get("LoginPage.a.GoToLogin")).get(0))).click();
			} catch (Exception e) {
				// driver.navigate().to(baseURL + "sessiontermination");
			}
		} else if (workSheetName.contains(FrameworkConstant.POS)) {
			GenericAction.clickForPOS("Click on Editeur_Cassiopae", "POS.Editeur Cassiopae", generalLocatorMap, driver,
					logger);
			GenericAction.clickForPOS("Click on Logged Out button", "POS.Logout", generalLocatorMap, driver, logger);
			logger.info("Logged Out Successfully");
			SeleniumUtility.takeScreenshotAugmenter(driver, testCaseDetail.getDomainName(),
					testCaseDetail.getWorkBookName(), workSheetName, testCaseDetail.getReportingLogger());
		}
	}

	public static void navigateToTab(final ExcelTestCaseFields excelTestCaseFields,
			final TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		try {
			driver.findElement(
					By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0)))
					.click();
		} catch (ElementNotVisibleException e) {
			navigateAndClickonTab(excelTestCaseFields, testCaseDetail);
		} catch (ElementNotInteractableException e) {
			navigateAndClickonTab(excelTestCaseFields, testCaseDetail);
		}
	}

	public static void navigateAndClickonTab(final ExcelTestCaseFields excelTestCaseFields,
			final TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		testCaseDetail.getReportingLogger().warn(ReportLoggerConstant.FORWARD_ICON_MESSAGE);
		try {
			driver.findElement(
					By.xpath(testCaseDetail.getLocatorHashMap().get(ReportLoggerConstant.FORWARD_LOCATOR_KEY).get(0)))
					.isDisplayed();
			driver.findElement(
					By.xpath(testCaseDetail.getLocatorHashMap().get(ReportLoggerConstant.FORWARD_LOCATOR_KEY).get(0)))
					.click();
			driver.findElements(
					By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0))).get(1)
					.click();
		} catch (ElementNotInteractableException e2) {
			testCaseDetail.getReportingLogger().warn(ReportLoggerConstant.BACKWARD_ICON_MESSAGE);
			try {
				driver.findElement(By.xpath(
						testCaseDetail.getLocatorHashMap().get(ReportLoggerConstant.BACKWARD_LOCATOR_KEY).get(0)))
						.isDisplayed();
				driver.findElement(By.xpath(
						testCaseDetail.getLocatorHashMap().get(ReportLoggerConstant.BACKWARD_LOCATOR_KEY).get(0)))
						.click();
				driver.findElements(
						By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0)))
						.get(1).click();
			} catch (Exception e21) {
				testCaseDetail.getReportingLogger().error(ReportLoggerConstant.TAB_NOT_PRESENT_MESG);
				throw new CATTException(ReportLoggerConstant.TAB_NOT_PRESENT_MESG);
			}
		}
	}

	public static void navigateToEvent(final ExcelTestCaseFields excelTestCaseFields,
			final TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		// testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		WebElement webElement = driver.findElement(
				By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0)));
		try {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.VERIFY_EVENT_PRESENT);
			if (webElement.isDisplayed()) {
				testCaseDetail.getReportingLogger().info("Event is present on event panel, launching event");
				webElement.click();
			} else {
				testCaseDetail.getReportingLogger().info(ReportLoggerConstant.ClICK_MORE_MESSAGE);
				driver.findElement(
						By.xpath(testCaseDetail.getLocatorHashMap().get(FunctionLocatorConstant.MORE_ICON).get(0)))
						.click();
				testCaseDetail.getReportingLogger().info("Event is present on event panel, launching event");
				driver.findElement(
						By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0)))
						.click();
			}
		} catch (NoSuchElementException e) {
			testCaseDetail.getReportingLogger().error(ReportLoggerConstant.EVENT_IS_NOT_PRESENT);
			throw new CATTException(ReportLoggerConstant.EVENT_IS_NOT_PRESENT);

		} catch (Exception er) {
			throw new CATTException(ReportLoggerConstant.EVENT_IS_NOT_PRESENT);
		}

	}

	/*
	 * Verify Phase and Step of Actor/Contract/Deal etc
	 * 
	 */
	public static void VerifyPhaseAndStep(final EventFiringWebDriver driver, final Logger logger, final String Module,
			final Map<String, List<String>> locatorHM, final String phaseExpected, final String stepExpected) {
		String phase;
		String step;
		phase = GenericAction.getDropDownValue("Phase", "select.Phase", locatorHM, driver, logger);
		step = GenericAction.getDropDownValue("Step", "select.Step", locatorHM, driver, logger);
		GenericAction.assertEquals(phase, phaseExpected, "Expected Phase Not Matched", logger);
		GenericAction.assertEquals(step, stepExpected, "Expected Step Doesnot Match", logger);
	}

	/*
	 * Expand Section/SubSection
	 */
	public static void expandSection(final Map<String, List<String>> locatorHM, final String locator,
			final String locator2, final EventFiringWebDriver driver, final Logger logger) {
		boolean isElementAvailable;
		WebElement webElement = driver.findElement(GenericAction.locator(locator, locatorHM));
		isElementAvailable = GenericAction.checkElementOnUI(webElement, locatorHM, driver, logger);
		if (!isElementAvailable) {
			GenericAction.clickOn("Click on Expand Section", locator2, locatorHM, driver, logger);
			GenericAction.clickOn("", locator2, locatorHM, driver, logger);
		} else {
			GenericAction.clickOn("", locator2, locatorHM, driver, logger);
		}
	}

	/*
	 * Open EventO
	 */
	public static void openEvent(final String logMessage, final String locator, final String locator2,
			final EventFiringWebDriver driver, final Logger logger) {
		boolean isElementAvailable;
		try {
			GenericAction.clickOn(logMessage, locator2, eventsLocatorMap, driver, logger);
		} catch (NoSuchElementException e) {
			WebElement webElement = driver.findElement(GenericAction.locator(locator, panelsLocatorMap));
			isElementAvailable = GenericAction.checkElementOnUI(webElement, panelsLocatorMap, driver, logger);
			if (isElementAvailable) {
				GenericAction.clickOn("Click on More >> icon ", "Events.span.More", panelsLocatorMap, driver, logger);
				GenericAction.clickOn("", locator2, eventsLocatorMap, driver, logger);
			} else {
				GenericAction.clickOn("Click on More >>", locator, panelsLocatorMap, driver, logger);
				GenericAction.clickOn("", locator2, eventsLocatorMap, driver, logger);
			}
		}
	}

	/*
	 * Check Control Report
	 */
	public static void checkControlReport(final Logger logger, final WebDriver arg2) {
		int counter = 0;
		try {
			if (arg2.findElement(By.xpath("//h1[contains(@class,'p_AFError')]")).isDisplayed()) {
				String error_count = arg2
						.findElement(By.xpath("//label[contains(text(),'Error(s)')]//following::input[1]"))
						.getAttribute("value");
				String warning_count = arg2
						.findElement(By.xpath("//label[contains(text(),'Warning')]//following::input[1]"))
						.getAttribute("value");
				int total = Integer.parseInt(error_count) + Integer.parseInt(warning_count);
				for (int m = 0; m < total; m++) {
					WebElement element = arg2.findElement(By.xpath("//span[contains(@id,'s_0n_aag:innerTbl:" + m
							+ ":codecontrole') or contains(@id,'IaNHboaO1ku3:innerTbl:" + m
							+ ":codecontrole')]//span"));
					try {
						JavascriptExecutor js = (JavascriptExecutor) arg2;
						js.executeScript("arguments[0].scrollIntoView(false);", element);
					} catch (java.lang.Exception e1) {
					}
					if (counter == 24) {
						counter = 0;
						arg2.findElement(By.xpath(
								"//img[contains(@id,'s_0n_aag:tbTableToolbar:next::icon') or contains(@id,'IaNHboaO1ku3:tbTableToolbar:next::icon')]"))
								.click();
					}
					String src = arg2.findElement(By.xpath("//img[contains(@id,'innerTbl:" + m + ":')]"))
							.getAttribute("src");
					if (src.contains("error")) {
						String code = arg2.findElement(By.xpath("//span[contains(@id,'s_0n_aag:innerTbl:" + m
								+ ":codecontrole') or contains(@id,'IaNHboaO1ku3:innerTbl:" + m
								+ ":codecontrole')]//span")).getText();
						String label = arg2.findElement(By.xpath("//a[contains(@id,'s_0n_aag:innerTbl:" + m
								+ ":controle') or contains(@id,'IaNHboaO1ku3:innerTbl:" + m + ":controle')]//span"))
								.getText();
						if (label == null || label.isEmpty()) {
							logger.info("Error code is " + code);
						} else {
							logger.info("Error code is " + code + " and its Control is: " + label);
						}
					}
					counter++;
				}
			}
		} catch (Exception e) {
			// logger.info("No any Error Control generated");
		}
	}

	/*
	 * Generate Dynamic Data
	 */
	/**
	 * This method is used to generate random sequence of values
	 * 
	 * @param outputType
	 * @param numCharsAppend
	 * @return random sequence of chars
	 */
	public static String generateDynamicData(final String outputType, final String numCharsAppend) {
		String radomdata = null;
		int noOfline = Integer.parseInt(numCharsAppend.trim());
		if (outputType.equalsIgnoreCase(CommonConstant.NUMBER_DATA_TYPE)) {
			radomdata = RandomStringUtils.randomNumeric(noOfline);
		} else if (outputType.equalsIgnoreCase(CommonConstant.STRING_DATA_TYPE)) {
			radomdata = RandomStringUtils.randomAlphabetic(noOfline);
		} else if (outputType.equalsIgnoreCase(CommonConstant.ALPHANUMERIC)) {
			radomdata = RandomStringUtils.randomAlphanumeric(noOfline);
		}
		return radomdata;
	}

	public static String executeQuery(final String[] inputQuery, String[] storeRetrievedValues,
			final Map<String, String> variableHolder, final Logger reportingLogger, String schema) {
		String value = null;
		String sqlQuery = inputQuery[0].trim();
		String variable = inputQuery[1].trim();
		boolean isVariableHolderEmpty = StringUtils.isEmpty(variable);

		String params[] = DatabaseUtility.getDBDetails(schema);
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			reportingLogger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
		}

		String[] placeHolders = null;
		if (!isVariableHolderEmpty) {
			placeHolders = variable.split(CommonConstant.COMMA_SEPERATOR);
		}
		try (Connection connection = DriverManager.getConnection(params[0], params[1], params[2]);
				PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);) {
			if (!isVariableHolderEmpty) {
				int count = 0;
				for (String placeHolder : placeHolders) {
					preparedStatement.setString(++count,
							VariableHolder.getValueFromVariableHolder(variableHolder, placeHolder));
					tracelogger.info(count + ReportLoggerConstant.QUERY_PARAM_VALUE_IS
							+ VariableHolder.getValueFromVariableHolder(variableHolder, placeHolder));
				}
			}
			reportingLogger.info("Compiled Query is : " + printSQLQuery(sqlQuery, variableHolder, placeHolders));
			try (ResultSet resultSet = preparedStatement.executeQuery();) {
				ResultSetMetaData metadata = resultSet.getMetaData();
				int columnCount = metadata.getColumnCount();
				/*
				 * if(!resultSet.next()) { logger.
				 * info("ExecuteQuery is not producing any result, please check above query"); }
				 */
				while (resultSet.next()) {
					// reportingLogger.info();
					for (int i = 1; i <= columnCount; ++i) {
						try {
							try {
								value = resultSet.getObject(i).toString();
							} catch (NullPointerException e) {
								value = null;
							}

							reportingLogger.info("Output of sql query is : \n " + " Value of '"
									+ metadata.getColumnName(i) + "' column is - '" + value + "'");
							variableHolder.put(metadata.getColumnName(i), value);
							if (storeRetrievedValues.length >= i
									&& !CommonUtility.isNullOREmpty(storeRetrievedValues[i - 1].trim())) {
								variableHolder.put(storeRetrievedValues[i - 1].trim(), value);
							}
						} catch (Exception e) {
							reportingLogger.error(e.getMessage());
							throw new CATTException(e.getMessage());
						}
					}
					break;
				}
			}
		} catch (SQLException e) {
			tracelogger.info(e.getMessage());
			reportingLogger.error(e.getMessage());
			throw new CATTSQLException(e.getMessage());
		}
		return value;

	}

	public static String executeUpdateDBQuery(final String[] inputQuery, final Map<String, String> variableHolder,
			final Logger reportingLogger, String application) {

		int totalRowProcessed = 0;
		String params[] = DatabaseUtility.getDBDetails(application);

		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			reportingLogger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);

		}
		String sqlQuery = inputQuery[0].trim();
		String variable = null;
		String[] placeHolders = null;

		if (inputQuery.length > 1) {
			variable = inputQuery[1].trim();
			placeHolders = variable.split(CommonConstant.COMMA_SEPERATOR);
		}
		try (Connection connection = DriverManager.getConnection(params[0], params[1], params[2]);
				PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);) {

			if (sqlQuery.contains(CommonConstant.QUESTION_MARK_SEPERATOR) && null != placeHolders) {
				int count = 0;
				for (String placeHolder : placeHolders) {
					preparedStatement.setString(++count,
							VariableHolder.getValueFromVariableHolder(variableHolder, placeHolder));
					tracelogger.info(count + ReportLoggerConstant.QUERY_PARAM_VALUE_IS
							+ VariableHolder.getValueFromVariableHolder(variableHolder, placeHolder));
				}
				reportingLogger.info("Compiled Query is : " + printSQLQuery(sqlQuery, variableHolder, placeHolders));
				totalRowProcessed = preparedStatement.executeUpdate();
			} else {
				totalRowProcessed = preparedStatement.executeUpdate();
			}
			connection.setAutoCommit(false);
			connection.commit();
			if (totalRowProcessed != 0) {
				reportingLogger.info("Total rows Processed/updated are : " + totalRowProcessed);
			}
		} catch (SQLException e) {
			tracelogger.info(e.getMessage());
			reportingLogger.error(e.getMessage());
			throw new CATTSQLException(e.getMessage());
		}
		return String.valueOf(totalRowProcessed);
	}

	public static String executeQuery(final String inputQuery, String[] storeRetrievedValues,
			final Map<String, String> variableHolder, final Logger logger, final String schema) {
		String params[] = DatabaseUtility.getDBDetails(schema);
		String value = null;

		if (ApplicationContext.DB_Validation.equalsIgnoreCase(CommonConstant.YES)) {
			try {
				Class.forName(DBConstant.ORACLE_DRIVER);
			} catch (ClassNotFoundException ex) {
				System.out.println("Error: unable to load driver class!");
				ex.printStackTrace();
				logger.info("Error: unable to load driver class!", ex);
				System.exit(1);
			}
			try (Connection connection = DriverManager.getConnection(params[0], params[1], params[2]);
					Statement st = connection.createStatement();) {
				try (ResultSet rs = st.executeQuery(inputQuery);) {
					ResultSetMetaData metadata = rs.getMetaData();
					int columnCount = metadata.getColumnCount();
					/*
					 * if(!rs.next()) { logger.
					 * info("ExecuteQuery is not producing any result, please check above query"); }
					 */
					while (rs.next()) {
						logger.info("Output of query as below : ");
						for (int i = 1; i <= columnCount; ++i) {
							try {
								try {
									value = rs.getObject(i).toString();
								} catch (NullPointerException e) {
									value = null;
								}
								logger.info("Value of '" + metadata.getColumnName(i) + "' column is - " + value);
								variableHolder.put(metadata.getColumnName(i), value);
								if (storeRetrievedValues.length >= i
										&& !CommonUtility.isNullOREmpty(storeRetrievedValues[i - 1].trim())) {
									variableHolder.put(storeRetrievedValues[i - 1].trim(), value);
								}

							} catch (Exception e) {
								e.printStackTrace();
								logger.error(e.getMessage());
								throw new CATTSQLException(e.getMessage());
							}
						}
						break;
					}
				}

			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(e.getMessage());
				throw new CATTSQLException(e.getMessage());
			}
		}
		return value;
	}

	/**
	 * OpenFile >> Useful to Open any file
	 */
	private Desktop desktop;

	public void OpenFile(final String filePath) {
		desktop = Desktop.getDesktop();
		try {
			desktop.open(new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @param inputString
	 * @param variableHolder
	 * @return Concatenated String Value
	 */
	public static String concatenateString(final String inputString, final Map<String, String> variableHolder) {
		String[] arr = CommonUtility.splitStringUsingPattern(inputString, CommonConstant.PIPE_SEPARATOR);
		StringBuilder finalString = new StringBuilder();
		for (int i = 0; i < arr.length; i++) {
			if (arr[i].trim().startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)) {
				String value = VariableHolder.getValueFromVariableHolder(variableHolder, arr[i].trim());
				finalString.append(value);
			} else {
				finalString.append(arr[i].trim());
			}
		}
		return finalString.toString().trim();
	}

	public static String executeOperation(String[] holder, List<String> relationalOp, List<String> arithmaticOp,
			TestCaseDetail testCaseDetailTO) {
		String operator = holder[1].trim();
		String operand1 = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				holder[0].trim());
		String operand2 = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				holder[2].trim());

		String result = null;
		if (relationalOp.contains(operator)) {
			result = performRelationalOperation(operator, operand1, operand2, testCaseDetailTO);
			testCaseDetailTO.getReportingLogger().info("Result is -" + result);
		} else if (arithmaticOp.contains(operator)) {
			result = performArithmaticOperation(operator, operand1, operand2);
		} else {
			testCaseDetailTO.getReportingLogger().warn("Incorrect operator");
		}
		return result;

	}

	public static String performArithmaticOperation(String operator, String operand1, String operand2) {
		return null;

	}

	public static String performRelationalOperation(String operator, String operand1, String operand2,
			TestCaseDetail testCaseDetail) {
		String result = null;
		if (operator.equals(CommonConstant.EQUAL_TO_OPERATOR)) {
			result = checkEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(CommonConstant.NOT_EQUAL_TO_OPERATOR)) {
			result = checkNotEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(CommonConstant.GREATER_THAN_OPERATOR)) {
			result = checkGreaterThanOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(CommonConstant.LESS_THAN_OPERATOR)) {
			result = checkLessThanOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(CommonConstant.GREATER_THAN_EQUAL_TO)) {
			result = checkGreaterThanEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(CommonConstant.LESS_THAN_EQUAL_TO)) {
			result = checkLessThanEqualToOperation(operand1, operand2, testCaseDetail);
		}

		return result;
	}

	private static String checkEqualToOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) == convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) == convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkNotEqualToOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is not equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) != convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) != convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}

		return result;
	}

	private static String checkGreaterThanOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is greater than '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) > convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) > convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkLessThanOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is less than '" + operand2 + "'");
		String result = null;
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) < convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) < convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkGreaterThanEqualToOperation(String operand1, String operand2,
			TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger()
				.info("Checking '" + operand1 + "' is greater than equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) >= convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) >= convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkLessThanEqualToOperation(String operand1, String operand2,
			TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger()
				.info("Checking '" + operand1 + "' is less than equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) <= convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (operand1.contains(CommonConstant.COMMA_SEPERATOR) || operand1.contains(CommonConstant.DOT_OPERATOR)
				|| operand2.contains(CommonConstant.COMMA_SEPERATOR)
				|| operand2.contains(CommonConstant.DOT_OPERATOR)) {
			result = convertDataToFloat(operand1.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR)
					.trim()) <= convertDataToFloat(
							operand2.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.DOT_OPERATOR).trim())
									? CommonConstant.TRUE_VALUE
									: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static Float convertDataToFloat(String value) {
		return Float.parseFloat(value);

	}

	private static int convertDataToInteger(String value) {
		return Integer.parseInt(value);
	}

	/**
	 * 
	 * formatQuery Utility function which will prepare SQL query
	 * 
	 * @param sql
	 * @param arguments
	 * @return
	 */
	public static String printSQLQuery(final String sql, Map<String, String> variableHolder, Object... arguments) {
		if (arguments != null && arguments.length <= 0) {
			return sql;
		}
		String query = sql;
		int count = 0;
		int placeHolderCount = 0;
		while (query.matches(CommonConstant.REGULAR_EXP_FOR_FINDING_QUESTION_MARK)) {
			query = query.replaceFirst("\\?", CommonConstant.OPENING_CULRY_BRACE_SEPERATOR + count
					+ CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR);
			count++;
		}
		if (arguments != null) {
			placeHolderCount = arguments.length;
		}
		Object[] tempArray = new Object[placeHolderCount];
		for (int i = 0; i < placeHolderCount; i++) {
			tempArray[i] = "'" + VariableHolder.getValueFromVariableHolder(variableHolder, arguments[i].toString())
					+ "'";
		}
		return java.text.MessageFormat.format(query, tempArray);
	}

	/**
	 * This method replaces the string having Question mark with the the values
	 * 
	 * @param stringvalue
	 * @param variableHolder
	 * @param arguments
	 * @return
	 */
	public static String parseQuestionMarkString(final String stringvalue, Map<String, String> variableHolder,
			String[] arguments) {

		if (arguments != null && arguments.length <= 0) {
			return stringvalue;
		}
		String finalStringValue = stringvalue;
		int count = 0;
		int totalQuestionMark = countCharacter(finalStringValue, '?');
		if (totalQuestionMark == arguments.length) {
			while (finalStringValue.matches(CommonConstant.REGULAR_EXP_FOR_FINDING_QUESTION_MARK)) {
				if (count < arguments.length) {
					String value = VariableHolder.getValueFromVariableHolder(variableHolder,
							arguments[count].toString());
					finalStringValue = finalStringValue.replaceFirst("\\?", value);
					count++;
				}
			}
		} else {
			tracelogger.info(
					"Please provide correct count of number separated by PIPE symbol in Input Test Data column, to be replaced in x-path");
			throw new CATTException(
					"Please provide correct count of number separated by PIPE symbol in Input Test Data column, to be replaced in Xpath");
		}
		return finalStringValue;
	}

	/**
	 * This method replaces the string having Question mark with the the values
	 * 
	 * @param stringvalue
	 * @param variableHolder
	 * @param arguments
	 * @return
	 */
	public static String parseQuestionMarkString(final String stringvalue, Map<String, String> variableHolder,
			String arguments) {
		if (arguments == null) {
			return stringvalue;
		}
		String finalStringValue = stringvalue;
		while (finalStringValue.matches(CommonConstant.REGULAR_EXP_FOR_FINDING_QUESTION_MARK)) {
			finalStringValue = finalStringValue.replaceFirst("\\?", arguments);
		}
		return finalStringValue;
	}

	public static int countCharacter(String string, char character) {
		int count = 0;
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) == character)
				count++;
		}
		return count;
	}

	/**
	 * This method will return the locator key value from object repository
	 * 
	 * @param xpathKey
	 * @param locatorHM
	 * @return
	 */
	public static String getLocatorKeyValue(final String xpathKey, final Map<String, List<String>> locatorHM) {
		String xpath = null;
		if (null != locatorHM.get(xpathKey)) {
			if (locatorHM.get(xpathKey).get(0) != null) {
				xpath = locatorHM.get(xpathKey).get(0);
			} else if (locatorHM.get(xpathKey).get(1) != null) {
				xpath = locatorHM.get(xpathKey).get(1);
			} else if (locatorHM.get(xpathKey).get(2) != null) {
				xpath = locatorHM.get(xpathKey).get(2);
			} else if (locatorHM.get(xpathKey).get(3) != null) {
				xpath = locatorHM.get(xpathKey).get(3);
			}
		} else {
			tracelogger.error(ErrorMessageConstant.LOCATOR_KEY_NOT_EXIST + xpathKey);
			throw new ValidatorException(ErrorMessageConstant.LOCATOR_KEY_NOT_EXIST + xpathKey);
		}
		return xpath;
	}

	/**
	 * This method will check the array elements are numeric or not
	 * 
	 * @param arraylist
	 * @return If array contain the numeric value then it will return True otherwise
	 *         False
	 */
	public static boolean checkArrayElementAreNumeric(String[] arraylist, TestCaseDetail testCaseDetail) {
		boolean flag = false;
		String value = null;
		for (int i = 0; i < arraylist.length; i++) {
			value = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), arraylist[i].trim());
			if (!StringUtils.isNumeric(value)) {
				flag = true;
			}
		}
		return flag;
	}

	/**
	 * This method is used to get the input data along with appending time stamps if
	 * any
	 * 
	 * @param excelTestCaseFields
	 * @param testCaseDetail
	 * @param variableHolderInputValue
	 * @param inputTestDataValue
	 * @return test data for input field
	 */
	public static String getInputTextBoxData(ExcelTestCaseFields excelTestCaseFields) {
		String inputTestDataValue;
		if (excelTestCaseFields.getInputTestData().contains(CommonConstant.TIME_STAMP)) {
			inputTestDataValue = excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[0]
					+ RandomStringUtils.randomAlphanumeric(5);// DateDefination.Timestamp;
		} else if (excelTestCaseFields.getInputTestData().contains(CommonConstant.TODAYDATE)) {
			if (excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[1]
					.contains(CommonConstant.DDMMYYY)) {
				inputTestDataValue = excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[0]
						+ DateDefination.TodayDate_DDMMYYYY;
			} else if (excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[1]
					.contains(CommonConstant.YYYYMMDD)) {
				inputTestDataValue = excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[0]
						+ DateDefination.TodayDate_YYYYMMDD;
			} else {
				inputTestDataValue = excelTestCaseFields.getInputTestData().split(CommonConstant.HASH_SEPERATOR)[0]
						+ DateDefination.Today;
			}
		} else {
			inputTestDataValue = excelTestCaseFields.getInputTestData();
		}
		return inputTestDataValue;
	}

	public static void explicitWait(int waittime) {
		try {
			Thread.sleep(waittime);
		} catch (InterruptedException e) {
		}
	}

	public static void navigateToMainModule(final ExcelTestCaseFields excelTestCaseFields,
			final TestCaseDetail testCaseDetail) {
		WebDriver driver = testCaseDetail.getDriver();
		Logger logger = testCaseDetail.getReportingLogger();
		String locatorKey = excelTestCaseFields.getLocatorKey();
		Map<String, List<String>> locatorHM = testCaseDetail.getLocatorHashMap();
		Map<String, List<String>> panelLoctorMap = ObjectRepoInitialization.masterLocatorMap
				.get(ObjectRepoInitialization.PANEL_LOCATOR);
		String overflowIconLocatorKey = testCaseDetail.getWorkSheetName().contains(DBConstant.BO_MODULE)
				? FunctionLocatorConstant.OVERFLOW_ICON_BO
				: FunctionLocatorConstant.OVERFLOW_ICON_MO;
		try {
			WebElement webElement = GenericAction.getWebElement(driver, GenericAction.locator(locatorKey, locatorHM),
					logger);
			boolean overflowIconStatus = driver.findElement(By.xpath(panelLoctorMap.get(overflowIconLocatorKey).get(0)))
					.isDisplayed();

			if (webElement.isDisplayed() && !overflowIconStatus) {
				GenericAction.mouseHoverOn("", locatorKey, locatorHM, driver, logger);
			} else {
				expandMenuListAndClickOnMenu(driver, panelLoctorMap, logger, locatorKey, locatorHM,
						overflowIconLocatorKey);
			}
		} catch (Exception e) {
			expandMenuListAndClickOnMenu(driver, panelLoctorMap, logger, locatorKey, locatorHM, overflowIconLocatorKey);
		}
	}

	public static void expandMenuListAndClickOnMenu(WebDriver driver, Map<String, List<String>> panelLoctorMap,
			Logger logger, String locatorKey, Map<String, List<String>> locatorHM, String overflowIconLocatorKey) {
		try {
			boolean status = driver.findElement(By.xpath(panelLoctorMap.get(overflowIconLocatorKey).get(0)))
					.isDisplayed();
			if (status) {
				GenericAction.clickOn(ReportLoggerConstant.OVER_FLOW_ICON_MSG, overflowIconLocatorKey, panelLoctorMap,
						driver, logger);
				WebElement webElement = GenericAction.getWebElement(driver,
						GenericAction.locator(locatorKey, locatorHM), logger);
				if (webElement.isDisplayed()) {
					GenericAction.mouseHoverOn(FunctionReportingConstant.CONFIGURATION_MOUSE_HOVER, locatorKey,
							locatorHM, driver, logger);
				}
			}
		} catch (Exception e) {
			logger.error(ErrorMessageConstant.OVERFLOWICON_NOT_PRESENT_MESSAGE);
			throw new CATTException(ErrorMessageConstant.OVERFLOWICON_NOT_PRESENT_MESSAGE);
		}
	}

	/**
	 * This method is used to perform logout operation when test case got failed
	 * 
	 * @param workSheetName
	 * @param logger
	 * @param driver
	 */
	public static void logoutOperationForFailedTC(String workSheetName, Logger logger, WebDriver driver,
			String domainName) {
		if (StringUtils.startsWith(workSheetName, DBConstant.CC_APP_SHEET_NAME)) {
			GenericAction.clickForPOS("Click on Editeur link", "ConfigConsole.Editeur", generalLocatorMap, driver,
					logger);
			GenericAction.clickForPOS("Click on Logout button", "ConfigConsole.Logout", generalLocatorMap, driver,
					logger);
			logger.info("Logged out successfully");
		} else if (workSheetName.contains(DBConstant.MO_MODULE) || workSheetName.contains(DBConstant.BO_MODULE)) {
			try {
				tracelogger.warn("Accept alert if any to proceed for logout");
				acceptAlertForLogoutOperation(driver);
				tracelogger.warn("Switch to default window");
				switchToDefaultWindow(workSheetName, driver, domainName);
				logger.info("Click on Editeur_Cassiopae");
				driver.findElement(By.xpath((generalLocatorMap.get("HomePage.span.UserLink")).get(0))).click();
				logger.info("Click on Logout option");
				driver.findElement(By.xpath((generalLocatorMap.get("HomePage.UserLink.span.Logout")).get(0))).click();
				logger.info("Logged out Successfully");
				driver.findElement(By.xpath((generalLocatorMap.get("LoginPage.a.GoToLogin")).get(0))).click();
			} catch (Exception e) {
				tracelogger.info("Issue occured during logout operation for failed test case : " + e.getMessage());
				tracelogger.error(e);
			}
		} else if (workSheetName.contains(FrameworkConstant.POS)) {
			try {
				GenericAction.clickForPOS("Click on Editeur_Cassiopae", "POS.Editeur Cassiopae", generalLocatorMap,
						driver, logger);
				GenericAction.clickForPOS("Click on Logged Out button", "POS.Logout", generalLocatorMap, driver,
						logger);
				logger.info("Logged Out Successfully");
			} catch (Exception exp) {
				tracelogger.error(exp);
				tracelogger.info("Issue occured during logout operation for failed test case : " + exp.getMessage());
			}
		}
	}

	/**
	 * This action is used to switch to default window
	 * 
	 * @param workSheetName
	 * @param driver
	 * @param domainName
	 */
	public static void switchToDefaultWindow(String workSheetName, WebDriver driver, String domainName) {
		try {
		driver.switchTo().defaultContent();
		Set<String> windowIterator = driver.getWindowHandles();
		if (windowIterator.size() >= 2) {
			tracelogger.info(ReportLoggerConstant.NUMBER_OF_WINDOW_PRESENT + windowIterator.size());
			for (String s : windowIterator) {
				String windowHandle = s;
				driver.switchTo().window(windowHandle);
				String currentTitleOfapplication = driver.getTitle();
				String expectedTitles = returnExpectedApplicationTitle(domainName, workSheetName);
				if (validateTitle(currentTitleOfapplication, expectedTitles)) {
					break;
				}
			}
		}
		} catch (Exception exp) {
			tracelogger.info("Issue occured while switching to default window for failed test case");
		}
	}

	private static void acceptAlertForLogoutOperation(WebDriver driver) {
		boolean flag = false;
		try {
			new WebDriverWait(driver, Duration.ofSeconds(1)).until(ExpectedConditions.alertIsPresent());
			flag = true;
		} catch (TimeoutException toe) {
			// ignores
		} catch (Exception te) {
			tracelogger.error(te);
			tracelogger.error(te.getMessage());
		}
		if (flag) {
			driver.switchTo().alert().accept();
		}
	}

	public static String returnExpectedApplicationTitle(String productName, String workSheetName) {
		if (productName.contains("SFP_ACF_COMMON")) {
			if (workSheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_ACF_ApplicationTitleBackOffice;
			} else if (workSheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_ACF_ApplicationTitleMiddleOffice;
			} else if (workSheetName.contains(DBConstant.POS_MODULE)) {
				return InitializeConstants.SFP_ACF_ApplicationTitlePOS;
			} else if (workSheetName.contains(DBConstant.CC_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_ACF_ApplicationTitleConfigConsole;
			}
		} else if (productName.contains("SFP_REAL_COMMON")) {
			if (workSheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_REAL_ApplicationTitleBackOffice;
			} else if (workSheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_REAL_ApplicationTitleMiddleOffice;
			} else if (workSheetName.contains(DBConstant.POS_MODULE)) {
				return InitializeConstants.SFP_REAL_ApplicationTitlePOS;
			} else if (workSheetName.contains(DBConstant.CC_APP_SHEET_NAME)) {
				return InitializeConstants.SFP_REAL_ApplicationTitleConfigConsole;
			}
		}
		return null;
	}
}
