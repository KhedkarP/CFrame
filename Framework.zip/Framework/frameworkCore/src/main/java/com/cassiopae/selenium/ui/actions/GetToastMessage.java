package com.cassiopae.selenium.ui.actions;

import java.time.Duration;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class GetToastMessage implements PerformAction {
	private static Logger logger = LogManager.getLogger(GetToastMessage.class);

	@Override
	public synchronized void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String alertMessage;
		if (ApplicationContext.productVersion.contains("4.7.1")) {
			alertMessage = getToastMessageFor471(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			alertMessage = getToastMessageFor480(excelTestCaseFieldsTO, testCaseDetailTO);
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), alertMessage);
		}

	}

	private String getToastMessageFor471(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		CurrentTestCase.getToastMessageOnPOS().set(true);
		String toastMessage = null;
		try {
			WebDriverWait wait = new WebDriverWait(testCaseDetailTO.getDriver(),
					InitializeConstants.toastMessageWaitingTimeForPOS);
			By by = By.xpath(testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0));
			WebElement ele = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			Actions act = new Actions(testCaseDetailTO.getDriver());
			act.moveToElement(ele).build().perform();
			toastMessage = testCaseDetailTO.getDriver()
					.findElement(By.xpath(
							testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0)
									+ FunctionLocatorConstant.DIV_ELEMENT))
					.getText();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.TOAST_MESSAGE_POP_UP + toastMessage);

			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), toastMessage);
			act.moveToElement(testCaseDetailTO.getDriver().findElement(By.xpath(FunctionLocatorConstant.POS_MYDEALS)))
					.build().perform();
			// wait until toast message is disabled or not
			wait.until(ExpectedConditions.invisibilityOf(ele));
		} catch (NoSuchElementException e) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.NOT_TOST_AVAILABLE);
		} catch (TimeoutException e) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.NOT_TOST_AVAILABLE);
		} catch (Exception e) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.NOT_TOST_AVAILABLE);
		}
		CurrentTestCase.getToastMessageOnPOS().set(false);
		return toastMessage;
	}

	private String getToastMessageFor480(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		CurrentTestCase.getToastMessageOnPOS().set(true);
		String toastMessage = null;
		WebDriver webDriver = testCaseDetailTO.getDriver();
		Wait<WebDriver> toastPopUpWait = new FluentWait<WebDriver>(webDriver)
				.withTimeout(Duration.ofSeconds(InitializeConstants.toastMessageWaitingTimeForPOS))
				.pollingEvery(Duration.ofMillis(1)).ignoring(NoSuchElementException.class);
		try {
			By by = By.xpath(testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0));
			WebElement ele = toastPopUpWait.until(ExpectedConditions.visibilityOfElementLocated(by));
			Actions act = new Actions(webDriver);
			act.moveToElement(ele).build().perform();
			toastMessage = ele.getText();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.TOAST_MESSAGE_POP_UP + toastMessage);
			act.moveToElement(testCaseDetailTO.getDriver().findElement(By.xpath(FunctionLocatorConstant.POS_MYDEALS)))
					.build().perform();
			// wait until toast message is disabled or not
			// toastPopUpWait.until(ExpectedConditions.invisibilityOf(ele));
		} catch (TimeoutException e) {
			logger.warn(ReportLoggerConstant.NOT_TOST_AVAILABLE);
		} catch (Exception exp) {
			logger.warn(exp);
		}
		CurrentTestCase.getToastMessageOnPOS().set(false);
		return toastMessage;
	}
}