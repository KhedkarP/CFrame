/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author mshik
 *
 */
public class CheckPaginationTableEntry implements CustomAction {

	int globtotalEntryCount = 24;

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {

		if (testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS) && testCaseDetail.getWorkSheetName().contains(DBConstant.CC_APP_SHEET_NAME)) {
			// out of scope
		} else {
			checkTableEntryWithPagination(excelTestCaseFields, testCaseDetail);
		}
	}

	public void checkTableEntryWithPagination(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		boolean recordStatus = false;
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] columnKeys = locatorKeys[0].split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String paginationKey = locatorMap.get(locatorKeys[1].trim()).get(0);
		String[] inputTestDatas = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] seleniumActions = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		globtotalEntryCount = Integer.parseInt(SelectPanelTableEntryUtility.getCountOfEntries(testCaseDetail,
				locatorMap.get(columnKeys[0].trim()).get(0)));
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		List<PanelTableDetails> panelTableDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap,
				columnKeys, seleniumActions, reqValues, testCaseDetail);
		int rowNumber = SelectPanelTableEntryUtility.executeCheckPaginateEntryInTable(panelTableDetailList,
				recordStatus, globtotalEntryCount, testCaseDetail, paginationKey);
		String[] variableHolderColumnData = CommonUtility
				.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);

		if (rowNumber == -1 && !recordStatus) {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.ENTRY_IS_NOT_LISTED_IN_TABLE);
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(), "null");
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.FALSE_VALUE);
		} else {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0].trim(), String.valueOf(rowNumber));
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1].trim(), CommonConstant.TRUE_VALUE);
		}

	}

}
