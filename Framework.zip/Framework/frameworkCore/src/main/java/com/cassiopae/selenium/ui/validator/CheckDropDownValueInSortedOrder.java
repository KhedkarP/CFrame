package com.cassiopae.selenium.ui.validator;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;

public class CheckDropDownValueInSortedOrder implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		boolean flag = GenericAction.checkSortingOrder(excelTestCaseFieldsTO, testCaseDetailTO);
		String dropdownIsSortedStatus = null;
		if (flag) {
			dropdownIsSortedStatus = CommonConstant.TRUE_VALUE;}
		else {
			dropdownIsSortedStatus = CommonConstant.FALSE_VALUE;}
		if (StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					dropdownIsSortedStatus);
		}
	}
}