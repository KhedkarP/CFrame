/**
 * 
 */
package com.cassiopae.excel.dataconvertor;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class NumericDataConvertor implements DataConvertor {

	/**
	 * This method convert the Cell data to numeric format.
	 * 
	 * @param cellvalue     Cell
	 * @param dataFormatter DataFormatter
	 * @param locale        String
	 * @return String
	 */
	@Override
	public String convertData(Cell cellvalue, DataFormatter dataFormatter, String locale,String worksSheetName) {
		String calculatedValue = null;
		if (DateUtil.isCellDateFormatted(cellvalue)) {
			if(worksSheetName.contains(DBConstant.POS_MODULE)) {
				locale = DBConstant.POS_MODULE+CommonConstant.UNDER_SCORE+locale;
			}
			calculatedValue = CommonUtility.getFormatedDate(cellvalue, locale);
		} else {
			calculatedValue = CommonUtility.getNumericDataFormatted(cellvalue, dataFormatter, locale,worksSheetName);
		}
		return calculatedValue;
	}

}
