package com.cassiopae.framework.dao.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

public class SQLLauncherUtility {
	
	private SQLLauncherUtility(){
		
	}
	private static Logger sqlLogger = LogManager.getLogger("SQLLogger");
	
	public static void closeConnections(Connection foConnection, Connection boConnection,
			Map<String, String> appDetail) {
		try {
			if (appDetail.containsKey(DBConstant.MO_MODULE)) {
				foConnection.close();
			} else if (appDetail.containsKey(DBConstant.BO_MODULE)) {
				boConnection.close();
			}
		} catch (SQLException e) {
			sqlLogger.debug(e.getMessage(), e);
		}
	}

	public static boolean executeSQLfile(Connection foConnection, Connection boConnection, String application,
			StringBuilder builder) {
		boolean isProcExecuted;
		if (application.equalsIgnoreCase(DBConstant.BO_MODULE)) {
			isProcExecuted = executeQuery(builder, boConnection);
		} else {
			isProcExecuted = executeQuery(builder, foConnection);
		}
		return isProcExecuted;
	}

	public static StringBuilder loadSQLfile(String sqlFilesPath) {
		File file = new File(sqlFilesPath);
		StringBuilder builder = new StringBuilder();
		try (FileInputStream fis = new FileInputStream(file);
				BufferedReader br = new BufferedReader(new InputStreamReader(fis, StandardCharsets.UTF_8));) {
			String line;
			while ((line = br.readLine()) != null) {
				builder.append(CommonConstant.LINE_SEPERATER);
				builder.append(line);
			}
		}
		catch (Exception e) {
			sqlLogger.error(e.getMessage(),e);
		}
		return builder;
	}

	public static boolean executeQuery(StringBuilder builder, Connection connection) {
		if (connection != null) {
			try (Statement statement = connection.createStatement()) {
				statement.execute(builder.toString());
				return true;
			} catch (Exception e) {
				sqlLogger.error(e.getMessage(), e);
			}
		}
		return false;
	}

	public static String getSQLProcedurePath(String filepath, String procedureName) {
		return filepath + File.separator + procedureName;
	}

	public static void executeSQLFiles(Connection foConnection, Connection boConnection,
			Map<String, LinkedList<String>> procedureDetails, String sqlFilesPath) {
		boolean isProcExecuted;
		String procedureName;
		String application;
		for (Map.Entry<String, LinkedList<String>> entry : procedureDetails.entrySet()) {
			LinkedList<String> value = entry.getValue();
			procedureName = value.get(1);
			application = value.get(3);
			if (FrameworkConstant.EXECUTED_USING_JDBC.equalsIgnoreCase(value.get(4))) {
				String procName = SQLLauncherUtility.getSQLProcedurePath(sqlFilesPath, procedureName);
				sqlLogger.info(ReportLoggerConstant.FORMAT_MESSAGE + ReportLoggerConstant.PROCEDURE_START_EXECUTION
						+ procedureName);
				StringBuilder builder = SQLLauncherUtility.loadSQLfile(procName);
				if (builder.length() != 0) {
					isProcExecuted = SQLLauncherUtility.executeSQLfile(foConnection, boConnection, application,
							builder);
					if (isProcExecuted) {
						sqlLogger.info(ReportLoggerConstant.FORMAT_MESSAGE
								+ ReportLoggerConstant.PROCEDURE_POST_EXECUTION + ReportLoggerConstant.FORMAT_MESSAGE);
					} else {
						sqlLogger.error(
								ReportLoggerConstant.FORMAT_MESSAGE + ReportLoggerConstant.ERROR_IN_PROCEDURE_EXECUTION
										+ ReportLoggerConstant.FORMAT_MESSAGE);
					}
				}
			}
		}
	}

public static void executeDumpValidationSQL(Connection foConnection, Connection boConnection,
		Map<String, LinkedList<String>> procedureDetails) {
	String actualValue;
	String sqlQuery;
	String application;
	String expectedResult;
		for (Map.Entry<String, LinkedList<String>> entry : procedureDetails.entrySet()) {
			LinkedList<String> sqlData = entry.getValue();
			sqlQuery = sqlData.get(1);
			application = sqlData.get(2);
			expectedResult = sqlData.get(3);
			sqlLogger.info(ReportLoggerConstant.FORMAT_MESSAGE + "Executing SQL query: " + sqlQuery);
			if (!StringUtils.isEmpty(sqlQuery) && !StringUtils.isBlank(sqlQuery)) {
				if (DBConstant.BO_MODULE.equalsIgnoreCase(application)) {
					actualValue = DatabaseUtility.executeQuery(boConnection, sqlLogger, sqlQuery);
				} else {
					actualValue = DatabaseUtility.executeQuery(foConnection, sqlLogger, sqlQuery);
				}
				sqlData.set(4, actualValue);
				if (expectedResult.equals(actualValue)) {
					sqlData.set(5, CommonConstant.TEST_CASE_PASSED);
					sqlLogger.info("Validation of "+entry.getKey() + "th query is "+ CommonConstant.TEST_CASE_PASSED);
				} else {
					sqlData.set(5, CommonConstant.TEST_CASE_FAILED);
					sqlLogger.info("Validation of "+entry.getKey() + "th query is "+ CommonConstant.TEST_CASE_FAILED + ". Actual result :"+actualValue+", Expected :"+expectedResult);
				}

			}
		}
	}
}
