/**
 *
 */

package com.cassiopae.framework.to;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

/**
 * @author jraut
 *
 */
//To be incorporated for future sprints
public class TestCaseDetail {

	private List<ExcelTestCaseFields> excelTestCaseFieldsList;
	private Map<String, String> variableHolder;
	private String workSheetName;
	private WebDriver driver;
	private Logger reportingLogger;
	private String domainName;
	private String WorkBookName;
	private TestCaseCommonData testCaseCommonData;

	public TestCaseCommonData getTestCaseCommonData() {
		return testCaseCommonData;
	}

	public void setTestCaseCommonData(TestCaseCommonData testCaseCommonData) {
		this.testCaseCommonData = testCaseCommonData;
	}

	public String getWorkBookName() {
		return WorkBookName;
	}

	public void setWorkBookName(String workBookName) {
		WorkBookName = workBookName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public List<ExcelTestCaseFields> getExcelTestCaseFieldsList() {
		return excelTestCaseFieldsList;
	}

	public void setExcelTestCaseFieldsList(List<ExcelTestCaseFields> excelTestCaseFieldsList) {
		this.excelTestCaseFieldsList = excelTestCaseFieldsList;
	}

	private Map<String, List<String>> locatorHashMap;


	public Map<String, String> getVariableHolder() {
		return variableHolder;
	}

	public void setVariableHolder(final Map<String, String> variableHolder) {
		this.variableHolder = variableHolder;
	}

	public String getWorkSheetName() {
		return workSheetName;
	}

	public void setWorkSheetName(final String scenarioName) {
		this.workSheetName = scenarioName;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(final WebDriver driver) {
		this.driver = driver;
	}

	public Logger getReportingLogger() {
		return reportingLogger;
	}

	public void setReportingLogger(final Logger logger) {
		this.reportingLogger = logger;
	}

	/**
	 * @return the locatorHashMap
	 */
	public Map<String, List<String>> getLocatorHashMap() {
		return locatorHashMap;
	}

	/**
	 * @param locatorHashMap the locatorHashMap to set
	 */
	public void setLocatorHashMap(final Map<String, List<String>> locatorHashMap) {
		this.locatorHashMap = locatorHashMap;
	}

}
