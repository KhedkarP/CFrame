/**
 * 
 */
package com.cassiopae.custom.action;

import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.ServerConnectionConstants;
import com.cassiopae.framework.dao.utility.SFTPConnectionUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.BatchAutomationUtility;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;

/**
 * @author jraut
 *
 */

public class FileUploadOnServer implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		boolean dirCreationFlag = false;
		Logger log = testCaseDetailTO.getReportingLogger();
		log.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String absoluteFileName = DomainInitialization.initializeDomainWiseUploadFilePath(
				testCaseDetailTO.getDomainName()) + InitializeConstants.fileSeparator
				+ VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0].trim());
		String remoteDirPath = BatchAutomationUtility.getUpdatedCommand(inputData[1].trim(),
				testCaseDetailTO.getVariableHolder());

		log.info(ServerConnectionConstants.CONNECTING_TO + ApplicationContext.applicationServerHostname);
		Session session = SFTPConnectionUtility.createSessionObject();
		SFTPConnectionUtility.configureSessionObject(session);
		ChannelSftp sftpChannel = SFTPConnectionUtility.sftpChannelCreation(session);
		SFTPConnectionUtility.configureChannel(sftpChannel);
		SFTPConnectionUtility.createDirectoryIfnotPresentOnServer(remoteDirPath, dirCreationFlag, sftpChannel);
		SFTPConnectionUtility.uploadFileOnServer(absoluteFileName, remoteDirPath, sftpChannel, log);
		SFTPConnectionUtility.closeConnection(sftpChannel);
	}
}
