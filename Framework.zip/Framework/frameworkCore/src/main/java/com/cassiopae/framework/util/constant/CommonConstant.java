/**
 *
 */
package com.cassiopae.framework.util.constant;

/**
 * @author nbhil
 *
 */
public interface CommonConstant {

	public String SPACE = " ";
	public String TAB = "	";
	public String EMPTY_STRING = "";
	public String UNDER_SCORE = "_";
	public String ZERO_VALUE = "0";
	public String FORWARD_SLASH = "/";
	public String AT_THE_RATE = "@";
	public String SINGLE_QUOTE = "'";

	public String WRITE_OPERATION = "Write";
	public String READ_OPERATION = "Read";
	public String CHECK_ALERT_ACCEPT = "Accept";
	public String CHECK_ALERT_DISMISS = "Dismiss";

	public String COLON_SEPERATOR = ":";
	public String HASH_SEPERATOR = "#";
	public String LESS_THAN_SEPERATOR = "<";
	public String GREATER_THAN_SEPERATOR = ">";
	public String DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR = "${";
	public String CLOSING_CULRY_BRACE_SEPERATOR = "}";
	public String OPENING_CULRY_BRACE_SEPERATOR = "{";
	public String HYPHEN_SEPERATOR = "-";

	public String TEST_CASE_PASSED = "Passed";
	public String TEST_CASE_FAILED = "Failed";

	public String FAILUARE_STATUS = "FAILURE";
	public String DATE_FORMATE = "dd/MM/yyyy";
	public String YES = "Yes";
	public String IS = " is ";
	public String STAR_SYMBOL = "**** ";

	public String IE_BROWSER = "IE";
	public String CHROME_BROWSER = "Chrome";
	public String MS_EDGE_BROWSER="Edge";
	public String MOZILLA_BROWSER = "Mozilla";
	public String WINDOWS = "Windows";
	public String LINUX = "Linux";
	public String DOT_OPERATOR = ".";
	public String TIME_STAMP = "#Timestamp";
	public String DDMMYYY = "DDMMYYYY";
	public String YYYYMMDD = "YYYYMMDD";
	public String MMMDDYYYY = "MMM/dd/yyyy";
	public String POS_APP_FORMAT="MM-dd-yyyy";
	public String BO_APP_FORMAT="dd-MM-yyyy";
	
	public String TODAYDATE = "#TodayDate";
	public String NUMBER = "Number";
	public String STRING = "String";
	public String DATE = "Date";
	public String CURSOR = "Cursor";
	public String OUT = "OUT";
	public String OR = " OR ";
	public String QUESTION_MARK_SEPERATOR = "?";
	public String LI_TAG = "li";
	public String UL_TAG = "ul";

	public String COMMA_SEPERATOR = ",";
	public String OPENING_BRACE_SEPERATOR = "(";
	public String CLOSING_BRACE_SEPERATOR = ")";
	public String PIPE_SEPARATOR = "|";
	public String TILDE_SEPARATOR = "~";

	String RIGHT_CONSTANT = "<<<<<<<";
	String LEFT_CONSTANT = ">>>>>>>";
	String NO_SUCH_ELEMENT_FOUND = "no such element: Unable to locate element";
	String SELCTOR = "selector";

	public String TRUE_VALUE = "True";
	public String FALSE_VALUE = "False";

	public String EXCEL_ACTION_COLUMN_HEADER = "Action";
	public String LINE_SEPERATER = "\n";
	public String WORK_BOOK_NAME = "Work book  Name is : ";
	public String WORK_SHEET_NAME = " ,Work sheet Name is : ";

	public String EXECUTION_STARTED = "//*******Execution Started for Test";
	public String BROWSER_ON = " browser and ";
	public String PLATFROM_MSG = " platform ********// ";

	public String XLSX_FILE_EXTENSION = ".xlsx";
	public String CSV_FILE_EXTENSION = ".csv";
	public String NEOLOAD_FILE_EXTENSION = ".nlp";
	public String JAVA_FILE_EXTENSION = ".java";
	public String XML_FILE_EXTENSION = ".xml";
	public String PDF_FILE_EXTENSION = ".pdf";
	public String ZIP_FILE_EXTENSION = ".zip";

	public String FALSE = "False";
	public String TRUE = "True";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME = "Payment_Schedule.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_US = "Payment_Schedule.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_FR_FR = "Ech_u00E9ancier.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_INTEREST_CALCULATION_FILE_NAME = "Interest_calculation_details.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_FR = "Payment_Schedule.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_AMMORTIZATION = "Plan_d_'_'amortissement.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_AMMORTIZATION_1 = "Plan_d_'amortissement.csv";
	public String DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_REIMBOURSEMENT = "Plan_de_remboursement.csv";
	public String DOWNLOADED_INVOICING_SCHEDULE_FILE_NAME = "Payment_schedule_summary.csv";
	public String DOWNLOADED_RECORDS_LIST_FILE_NAME = "Table_Data.csv";

	public String SANITY_SUITE_XML_NAME = "_Sanity_Test_Suite.xml";
	public String REGRESSION_SUITE_XML_NAME = "_Regression_Test_Suite.xml";
	public String SUITE_PARALLEL_LEVEL = "tests";
	public String SANITY_SUITE_NAME = " Sanity Test Suite";
	public String REGRESSION_SUITE_NAME = " Regression Test Suite";
	public String ERROR_FILE_NAME = "Error_File.txt";

	public String PAYMENT_SCHEDULE_WORK_SHEET_NAME = "TableData";
	public String PAYMENT_SCHEDULE_COLUMNS = "PaymentScheduleColumns.properties";

	public String TABLE_SEPARATOR_CONSTANT = "innerTbl:";
	public String PAGE_LABEL_COUNT_ENGLISH = "Page 1 of 1";
	public String PAGE_LABEL_COUNT_TRIM_STRING = "Page 1 of ";

	public String EQUAL_TO_OPERATOR = "==";
	public String NOT_EQUAL_TO_OPERATOR = "!=";
	public String GREATER_THAN_OPERATOR = ">";
	public String LESS_THAN_OPERATOR = "<";
	public String GREATER_THAN_EQUAL_TO = ">=";
	public String LESS_THAN_EQUAL_TO = "<=";

	public String ARITHMATIC_PLUS_OPERATOR = "+";
	public String ARITHMATIC_MINUS_OPERATOR = "-";
	public String ARITHMATIC_MULTIPLY_OPERATOR = "*";
	public String ARITHMATIC_DIVISION_OPERATOR = "/";
	public String ARITHMATIC_REMINDER_OPERATOR = "%";
	public String NO = "No";

	public String STRING_DATA_TYPE = "String";
	public String DATE_DATA_TYPE = "Date";
	public String NUMBER_DATA_TYPE = "Number";
	public String ALPHANUMERIC = "Alphanumeric";

	public String GET_TEXT = "getText";
	public String GET_ATTRIBUTE_VALUE = "getAttributeValue";
	public String GET_ATTRIBUTE_TITLE = "getAttributeTitle";
	public String GET_ATTRIBUTE_DATA_ROWS = "data-rows";
	public String GET_ATTRIBUTE_DATA_ROW_COUNT = "data-rowcount";
	public String GET_ATTRIBUTE_DATA_AFR_TLEN = "getAttributeDataAfrTlen";
	public String CLICK_ACTION = "click";
	public String HASH_VALUE = "Hash";
	public String GET_ATTRIBUTE_HREF = "getAttributeHrefvalue";

	public String MAX_DATA_SET_ROW_NUM = "MaxRowNumber";
	public String DATA_SET_HEADER_ROW_NUM = "HeaderRowNumber";
	public String DATA_SET_NAME = "DATA_SET_";
	public String VIDEO_LOCATION_FOR_MULTI_DATA_SET = "Video_Location";
	public String MULTI_DATA_SET_EXECUTION_STATUS = "Status";
	public String MULTI_DATA_SET_EXECUTION_RESULT = "Execution_Result";
	public String DATA_FIELD_NAME = "Field Value";

	public String FLOW_VALUE = "_flowId=";
	public String FLOW_KEY = "&_flowExecutionKey";

	/*
	 * Regular Expression Constant
	 */
	public String REGULAR_EXP_FOR_FINDING_QUESTION_MARK = "(.*)\\?(.*)";

	public String REGRESSION_PACKAGE_NAME = "regression";
	public String SANITY_PACKAGE_NAME = "sanity";

	public String SANITY_TEST_TYPE = "SAN";
	public String REGRESSION_TEST_TYPE = "REG";

	// page stability constants

	public String IFRAME_STABILIZATION_XPATH = "//body[contains(@class,'x13d p_AFMaximized')]";
	public String IFRAME_STABILIZATION_STYLE_ATTRIBUTE_NAME = "style";
	public String IFRAME_STABILIZATION_STYLE_ATTRIBUTE_VALUE_WAIT = "cursor: wait;";
	public String IFRAME_STABILIZATION_STYLE_ATTRIBUTE_VALUE_AUTO = "cursor: auto;";
	public String DROP_DOWN_CONVERTED_XPATH = "normalize-space(.)";

	public String PLEASE_WAIT_LOADING_GLASS_PANE_XPATH = "//div[contains(@id,'pleaseWaitGlassPane')]";
	public String PLEASE_WAIT_INVISIBILITY_WITH_STYLE_XPATH = "//div[contains(@id,'pleaseWaitGlassPane') and contains(@style,'display: block;')]";
	public String PLEASE_WAIT_LOADING_GLASS_PANE_XPATH_STYLE_ATTRIBUTE_VALUE_BLOCK = "display: block;";
	public String PLEASE_WAIT_LOADING_GLASS_PANE_XPATH_STYLE_ATTRIBUTE_VALUE_NONE = "display: none;";
	public String TOAST_POPUP_XPATH_POS = "//div[contains(@class,'toastr animated rrt-warning') or contains(@class,'toastr animated rrt-error') or contains(@class,'toastr animated rrt-success')]//div[@class='rrt-middle-container']";

	// browser system property constants

	public String CHROME_BROWSER_PROPERTY = "webdriver.chrome.driver";
	public String EDGE_BROWSER_PROPERTY = "webdriver.edge.driver";
	public String IE_BROWSER_PROPERTY = "webdriver.ie.driver";
	public String MOZILLA_BROWSER_PROPERTY = "webdriver.gecko.driver";

	// jasper
	public String RECEVIABLE_PDF_FILE_NAME = "dlgFacturation";
	public String EXPENSE_PDF_FILE_NAME = "batchDepenseJournal";
	public String PDF_TO_EXCEL_FILE_NAME = "dlgfacturation.xlsx";
	public String JASPER_EXCEL_SHEET_NAME = "JasperData";
	public String JASPER_EXCEL_HEADER1 = "Sr.No.";
	public String JASPER_EXCEL_HEADER_RECEIVABLES = "Receivables";
	public String JASPER_EXCEL_HEADER_EXPENSE = "Expense";
	public String DOT = "\\.";

	// IsDownlodedFileEmpty
	public String PDF_FILE_EXTENSION1 = ".PDF";
	public String LOG_FILE_EXTENSION = ".log";
	public String TXT_FILE_EXTENSION = ".txt";
	public String XLS_FILE_EXTENSION = ".xls";

	// convertPdfToExcel
	public String TAXESON_INVOICE = "TaxesonInvoice";
	public String TAXESSUR_FACTURE = "TaxessurFacture";
	public String DETAILSONRATE_CALCULATION = "Detailsonratecalculation";
	public String JASPER_DATA = "JasperData";
	
	// TestCaseSummaryMapDetails
	
	public String IS_WORKSHEET_PRESENT = "IsworkSheetPresent";
	public String DASHBOARD_ROW_NUMBER = "DashBoardRowNumber";
	public String USERNAME = "Username";
	public String PASSWORD = "Password";
	
	public String TEST_CASE_STATUS = "TestCaseStatus";
	public String VIDEO_LOCATION = "VideoLocation";
	public String EXECUTION_TIME = "ExecutionTime";
	public String DEFECT_ID = "DefectId";
	public String ERROR_MESSAGE = "ErrorMessage";
	

	//dynamicEProfilePath
	public String EDGEPROFILE="EdgeProfile";
	public String PROFILE_FOlDER_LENGTH="10";
	
	//ExtractPDFDataAndValidate
	public String DYNAMIC_STRING_LENGTH="5";
	

	public String TEST_CASES_EXCLUDED_STATUS = "Excluded";
	public String MAXIMUM = "Maximum";
	public String MINIMUM = "Minimum";
	
	// UAID File Name
		public String UAID_FILE_NAME = "UAID";
	public String EnvelopSoapBodyConstant ="SOAP-ENV:Envelope.SOAP-ENV:Body.";
	public String EnvelopSoapRequestBodyConstant ="soapenv:Envelope.soapenv:Body.";
		

}
