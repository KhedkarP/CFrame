/**
 * 
 */
package com.cassiopae.selenium.services;

import java.time.Duration;

import org.apache.logging.log4j.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.listener.WebDriverListener;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateDefination;

/**
 * @author jraut
 */
public class CFrameManager {

	private static Logger logger = LogManager.getLogger(CFrameManager.class);

	// ******************************** i-Frame Methods
	// ****************************************************//
	public static void eventPanelFrame(final WebDriver webDriver) {
		webDriver.switchTo().frame(webDriver.findElement(By.xpath(FrameworkConstant.EVENT_PANEL_FRMAE)));
	}

	public static void clientAreaFrame(final WebDriver webDriver) {
		webDriver.switchTo().frame(webDriver.findElement(By.xpath(FrameworkConstant.CLIENT_AREA_FRMAE)));
	}

	public static void headerFrame(final WebDriver webDriver) {
		webDriver.switchTo().frame(webDriver.findElement(By.xpath(FrameworkConstant.HEADER_FRAME)));
	}

	public static void otherFrame(final WebDriver webDriver) {
		webDriver.switchTo().frame(webDriver.findElement(By.xpath(FrameworkConstant.OTHER_FRAME)));
	}

	public static void autoSwitchFrame(By locator, final WebDriver webDriver, final String domainName,
			final String className, final String scenariosName, final Logger reportingLogger) {
		String appTitle = null;
		try {
			appTitle = webDriver.getTitle();
		} catch (UnhandledAlertException alertExp) {
			SeleniumUtility.unexpectAlert(webDriver, reportingLogger);
			appTitle = webDriver.getTitle();
		}
		if (appTitle.contains(FrameworkConstant.POS)) {
			try {
				SeleniumUtility.waitTillPageLoadingForPOS(locator, webDriver, reportingLogger);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			SeleniumUtility.invisibilityOfLoadingIcon(webDriver, reportingLogger);
		}
		try {
			webDriver.switchTo().defaultContent();
			if (!appTitle.contains(FrameworkConstant.POS)) {
				WebDriverListener.checkElementStabilityInIFrame(webDriver);
			}
			scrollToElement(locator, webDriver);
			webDriver.findElement(locator).isDisplayed();

		} catch (NoSuchElementException rty) {
			// logger.error( rty.getMessage(), rty );
			try {
				clientAreaFrame(webDriver);
				WebDriverListener.checkElementStabilityInIFrame(webDriver);
				scrollToElement(locator, webDriver);
				webDriver.findElement(locator).isDisplayed();
			} catch (Exception e) {
				// logger.error( e.getMessage(), e );
				try {
					webDriver.switchTo().defaultContent();
					clientAreaFrame(webDriver);
					eventPanelFrame(webDriver);
					WebDriverListener.checkElementStabilityInIFrame(webDriver);
					scrollToElement(locator, webDriver);
					webDriver.findElement(locator).isDisplayed();
				} catch (Exception exp) {
					// logger.error( exp.getMessage(), exp );
					try {
						webDriver.switchTo().defaultContent();
						clientAreaFrame(webDriver);
						eventPanelFrame(webDriver);
						headerFrame(webDriver);
						WebDriverListener.checkElementStabilityInIFrame(webDriver);
						scrollToElement(locator, webDriver);
						webDriver.findElement(locator).isDisplayed();
					} catch (Exception yt) {
						// logger.error( yt.getMessage(), yt );
						try {
							webDriver.switchTo().defaultContent();
							clientAreaFrame(webDriver);
							otherFrame(webDriver);
							WebDriverListener.checkElementStabilityInIFrame(webDriver);
							scrollToElement(locator, webDriver);
							webDriver.findElement(locator).isDisplayed();
						} catch (Exception e1) {
							// logger.error( e1.getMessage(), e1 );
							try {
								webDriver.switchTo().defaultContent();
								eventPanelFrame(webDriver);
								WebDriverListener.checkElementStabilityInIFrame(webDriver);
								scrollToElement(locator, webDriver);
								webDriver.findElement(locator).isDisplayed();
							} catch (Exception e2) {
								try {
									webDriver.switchTo().defaultContent();
									otherFrame(webDriver);
									scrollToElement(locator, webDriver);
									webDriver.findElement(locator).isDisplayed();
								} catch (Exception exception) {

									// logger.error( e2.getMessage(), e2 );
									By by = By.xpath(FrameworkConstant.APPLICATION_TECHNICAL_DEATILS_ERROR_XPATH);
									locator = by;
									try {
										webDriver.switchTo().defaultContent();
										scrollToElement(locator, webDriver);
										webDriver.findElement(locator).isDisplayed();
										SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName, className,
												scenariosName, reportingLogger);
										copyUAIDtoFile(webDriver, domainName, className, scenariosName);
										webDriver.findElement(locator).sendKeys(Keys.TAB);
										webDriver.findElement(locator).click();
										String Error = webDriver
												.findElement(By.xpath(FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
												.getText();
										reportingLogger.info(ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG + Error);
										SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName, className,
												scenariosName, reportingLogger);
									} catch (Exception rty1) {
										// logger.error( rty1.getMessage(), rty1 );
										try {
											clientAreaFrame(webDriver);
											scrollToElement(locator, webDriver);
											webDriver.findElement(locator).isDisplayed();
											SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName, className,
													scenariosName, reportingLogger);

											copyUAIDtoFile(webDriver, domainName, className, scenariosName);
											// back to original frame
											clientAreaFrame(webDriver);
											scrollToElement(locator, webDriver);

											webDriver.findElement(locator).sendKeys(Keys.TAB);
											webDriver.findElement(locator).click();
											String error = webDriver
													.findElement(
															By.xpath(FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
													.getText();
											reportingLogger
													.error(ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG + error);
											SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName, className,
													scenariosName, reportingLogger);
										} catch (Exception tr1) {
											// logger.error( tr1.getMessage(), tr1 );
											try {
												webDriver.switchTo().defaultContent();
												clientAreaFrame(webDriver);
												eventPanelFrame(webDriver);
												scrollToElement(locator, webDriver);
												webDriver.findElement(locator).isDisplayed();
												SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
														className, scenariosName, reportingLogger);

												copyUAIDtoFile(webDriver, domainName, className, scenariosName);
												// back to original frame clientAreaFrame(webDriver);
												eventPanelFrame(webDriver);
												scrollToElement(locator, webDriver);
												webDriver.findElement(locator).sendKeys(Keys.TAB);
												webDriver.findElement(locator).click();
												String error = webDriver
														.findElement(By
																.xpath(FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
														.getText();
												reportingLogger.error(
														ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG + error);
												SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
														className, scenariosName, reportingLogger);
											} catch (Exception exp4) {
												// logger.error( exp4.getMessage(), exp4 );
												try {
													webDriver.switchTo().defaultContent();
													clientAreaFrame(webDriver);
													eventPanelFrame(webDriver);
													headerFrame(webDriver);
													scrollToElement(locator, webDriver);
													webDriver.findElement(locator).isDisplayed();
													SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
															className, scenariosName, reportingLogger);

													copyUAIDtoFile(webDriver, domainName, className, scenariosName);
													// back to original frame clientAreaFrame(webDriver);
													eventPanelFrame(webDriver);
													headerFrame(webDriver);
													scrollToElement(locator, webDriver);

													webDriver.findElement(locator).sendKeys(Keys.TAB);
													webDriver.findElement(locator).click();
													String error = webDriver
															.findElement(By.xpath(
																	FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
															.getText();
													reportingLogger.error(
															ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG + error);
													SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
															className, scenariosName, reportingLogger);
												} catch (Exception exp6) {
													// logger.error( exp6.getMessage(), exp6 );
													try {
														webDriver.switchTo().defaultContent();
														clientAreaFrame(webDriver);
														otherFrame(webDriver);
														scrollToElement(locator, webDriver);
														webDriver.findElement(locator).isDisplayed();
														SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
																className, scenariosName, reportingLogger);

														copyUAIDtoFile(webDriver, domainName, className, scenariosName);
														// back to original frame
														clientAreaFrame(webDriver);
														otherFrame(webDriver);
														scrollToElement(locator, webDriver);

														webDriver.findElement(locator).sendKeys(Keys.TAB);
														webDriver.findElement(locator).click();
														try {
															webDriver.findElement(By.xpath(
																	FrameworkConstant.APPLICATION_TECHNICAL_DEATILS_ERROR_XPATH))
																	.click();
														} catch (Exception rt) {
															/// logger.error( rt.getMessage(), rt );
														}
														String error = webDriver
																.findElement(By.xpath(
																		FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
																.getText();
														reportingLogger
																.error(ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG
																		+ error);
														SeleniumUtility.takeScreenshotAugmenter(webDriver, domainName,
																className, scenariosName, reportingLogger);
													} catch (Exception exp8) {
														// logger.error( exp8.getMessage(), exp8 );
														try {
															webDriver.switchTo().defaultContent();
															eventPanelFrame(webDriver);
															scrollToElement(locator, webDriver);
															webDriver.findElement(locator).isDisplayed();
															SeleniumUtility.takeScreenshotAugmenter(webDriver,
																	domainName, className, scenariosName,
																	reportingLogger);

															copyUAIDtoFile(webDriver, domainName, className,
																	scenariosName);
															// back to original frame
															eventPanelFrame(webDriver);
															scrollToElement(locator, webDriver);

															webDriver.findElement(locator).sendKeys(Keys.TAB);
															webDriver.findElement(locator).click();
															try {
																webDriver.findElement(By.xpath(
																		FrameworkConstant.APPLICATION_TECHNICAL_DEATILS_ERROR_XPATH))
																		.click();
															} catch (Exception rt) {
																// logger.error( rt.getMessage(), rt );
															}
															String error = webDriver.findElement(By.xpath(
																	FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
																	.getText();
															reportingLogger.error(
																	ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG
																			+ error);
															SeleniumUtility.takeScreenshotAugmenter(webDriver,
																	domainName, className, scenariosName,
																	reportingLogger);

														} catch (Exception exp10) {

															try {
																webDriver.switchTo().defaultContent();
																otherFrame(webDriver);
																scrollToElement(locator, webDriver);
																webDriver.findElement(locator).isDisplayed();
																SeleniumUtility.takeScreenshotAugmenter(webDriver,
																		domainName, className, scenariosName,
																		reportingLogger);

																copyUAIDtoFile(webDriver, domainName, className,
																		scenariosName);
																// back to original frame
																webDriver.switchTo().defaultContent();
																otherFrame(webDriver);
																scrollToElement(locator, webDriver);

																webDriver.findElement(locator).sendKeys(Keys.TAB);
																webDriver.findElement(locator).click();
																try {
																	webDriver.findElement(By.xpath(
																			FrameworkConstant.APPLICATION_TECHNICAL_DEATILS_ERROR_XPATH))
																			.click();
																} catch (Exception rt) {
																	// logger.error( rt.getMessage(), rt );
																}
																String error = webDriver.findElement(By.xpath(
																		FrameworkConstant.APPLICATION_ERROR_MSGS_XPATH))
																		.getText();
																reportingLogger.error(
																		ErrorMessageConstant.APPLICATION_CRASH_ERROR_MSG
																				+ error);
																SeleniumUtility.takeScreenshotAugmenter(webDriver,
																		domainName, className, scenariosName,
																		reportingLogger);

															} catch (Exception exp11) {
																// logger.error( exp10.getMessage(), exp10 );
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/*
	 * This method is used to copy UAID from HTML DOM and paste it in a text file
	 */
	public static void copyUAIDtoFile(final WebDriver webDriver, final String domainName, final String className,
			final String scenariosName) {
		if (ApplicationContext.productVersion.equals("4.8.1")) {
			String uaidFilePath = CommonUtility.getConsoleLogFolderPath(domainName)
					+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator + className
					+ InitializeConstants.fileSeparator + scenariosName + InitializeConstants.fileSeparator
					+ CommonConstant.UAID_FILE_NAME + CommonConstant.TXT_FILE_EXTENSION;
			boolean uaidFileStatus = FileUtility.checkFileExists(uaidFilePath);
			if (!uaidFileStatus) {
				// accept alert if any
				try {
					new WebDriverWait(webDriver, Duration.ofMillis(500)).until(ExpectedConditions.alertIsPresent());
					Alert alert = webDriver.switchTo().alert();
					alert.accept();
				} catch (Exception e) {
				}
				CommonFunctions.switchToDefaultWindow(scenariosName, webDriver, domainName);
				try {
					String uaid = webDriver.findElement(By.xpath(FrameworkConstant.APPLICATION_UAID_XPATH))
							.getAttribute(ReportLoggerConstant.VALUE);

					if (!uaidFileStatus) {
						FileUtility.createNewFile(uaidFilePath);
						FileUtility.appendLogMessageToFileWithoutNewLine(uaidFilePath, uaid);
					}
				} catch (Exception e) {
					logger.warn("UAID is not found on page: " + e.getMessage());
				}
			}
		}
	}

	/**
	 * @param locator
	 * @param webDriver
	 */
	public static void scrollToElement(By locator, final WebDriver webDriver) {

		try {
			((JavascriptExecutor) webDriver).executeScript(FrameworkConstant.JAVASCRIPT_SCROLL,
					webDriver.findElement(locator));
			// ( (JavascriptExecutor) webDriver ).executeScript(
			// "javascript:window.scrollBy(250,350)", webDriver.findElement( locator ) );

		} catch (Exception ex) {
			// logger.error( ex.getMessage(), ex );
		}
	}

	/**
	 * @param locator
	 * @param webDriver
	 */
	public static void scrollToElementInMiddle(By locator, final WebDriver webDriver) {

		try {
			((JavascriptExecutor) webDriver).executeScript(
					"arguments[0].scrollIntoView(true); window.scrollBy(0, -window.innerHeight / 4);",
					webDriver.findElement(locator));
		} catch (Exception ex) {
			// logger.error( ex.getMessage(), ex );
		}
	}

}
