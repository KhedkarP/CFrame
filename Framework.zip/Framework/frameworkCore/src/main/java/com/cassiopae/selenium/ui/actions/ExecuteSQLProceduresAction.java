/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.dao.utility.DatabaseUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author ragrawal
 */
public class ExecuteSQLProceduresAction implements PerformAction {

	@Override
	public void executeAction( final ExcelTestCaseFields excelTestCaseFieldsTO, final TestCaseDetail testCaseDetailTO ) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String inputTestData = excelTestCaseFieldsTO.getInputTestData();
		String application = CommonUtility.getApplicationNameFromWorksheetName( testCaseDetailTO.getWorkSheetName() );
		String outputString = DatabaseUtility.executeGenericProcCall( inputTestData, application, testCaseDetailTO );
		if ( excelTestCaseFieldsTO.getStoreValuesInVariable() != null ) {
			testCaseDetailTO.getVariableHolder().put( excelTestCaseFieldsTO.getStoreValuesInVariable(), outputString );
		}
	}
}
