/**
 *
 */
package com.cassiopae.webservices.action;

import java.util.HashSet;
import java.util.Set;

/**
 * @author mshaik
 *
 */
public enum WSCustomType {
	REST_GetResponseData,
	REST_LoginRequest,
	REST_POSTRequest,
	REST_PUTRequest,
	REST_PATCHRequest,
	REST_GETRequest,
	REST_ExecuteRequest,
	SOAP_Request,
	SOAP_GetResponseData;

	private static HashSet<String> WScustomActionTypeSet = null;

	public static Set<String> getWSActionType() {
		if (WScustomActionTypeSet == null) {
			WScustomActionTypeSet = new HashSet<>();
			for (WSCustomType wsAction : WSCustomType.values()) {
				WScustomActionTypeSet.add(wsAction.name());
			}
		}
		return WScustomActionTypeSet;
	}

}
