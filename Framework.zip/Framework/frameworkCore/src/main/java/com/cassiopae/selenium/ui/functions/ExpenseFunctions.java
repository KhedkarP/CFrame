package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class ExpenseFunctions {

	/*
	 * Expense Functions
	 */

	private static Map<String, List<String>> expensesLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.EXPENSE_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger logger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.EXPENSE_MOUSE_HOVER, FunctionLocatorConstant.EXPENSE_MENU, expensesLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.EXPENSE_SUB_MENU, FunctionLocatorConstant.EXPENSE_SUB_MENU, expensesLocatorMap, driver, logger);
	}

	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail) {
	    navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_EXPENSE_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.EXPENSE_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(expensesLocatorMap);
		GenericAction.enterValueIn(reference,excelTestCaseFields,testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_EXPENSE_REFERENCE_ICON, FunctionLocatorConstant.EXPENSE_SEARCH_ICON, expensesLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_EXPENSE_REFERENCE_HYPERLINK+reference, FunctionLocatorConstant.EXPENSE_REFERNCE_HYPERLINK, expensesLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}

}
