/**
 * 
 */
package com.cassiopae.custom.action;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;

/**
 * @author jraut
 *
 */
public class GetDropDownIndexNumber implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String indexNumber ;
		if (testCaseDetailTO.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.POS_MODULE)
				|| testCaseDetailTO.getTestCaseCommonData().getWorkSheetName().contains(DBConstant.CC_APP_SHEET_NAME)) {
			indexNumber = GenericAction.getDropDownIndexForPOS(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			indexNumber = GenericAction.getDropDownIndex(excelTestCaseFieldsTO, testCaseDetailTO);
		}
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), indexNumber);
		}
	}
}
