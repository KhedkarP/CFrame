/**
 * 
 */
package com.cassiopae.framework.util;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.cassiopae.framework.to.XlsFileRowDetails;

/**
 * This method will generate the Java file for test case.
 * 
 * @author nbhil
 *
 */
public class CreateJavaFileUtility {

	private CreateJavaFileUtility() {

	}

	/**
	 * This method will generate the Java file for test case.
	 * 
	 * @param dataList                List<XlsFileRowDetails> dataList
	 * @param absolutePath            String
	 * @param className               String
	 * @param packageName             String
	 * @param paymentScheduleScenerio String
	 * @throws IOException
	 */
	public static void generateJavaFile(final List<XlsFileRowDetails> dataList, String absolutePath,String packageAbsolutePath, String className,
			String packageName) throws IOException {
		try (FileWriter aWriter = new FileWriter(absolutePath, false);) {
			addImportStatements(packageName, aWriter);
			declareClass(className, aWriter);
			addInstanceVariable(aWriter);
			addBeforeMethod(dataList, aWriter);
			addTestCaseMethod(dataList, aWriter);
			addAfterMethod(aWriter);
		}
	}

	/**
	 * This method will add class declaration statement.
	 * 
	 * @param className String
	 * @param aWriter   FileWriter
	 * @throws IOException
	 */
	private static void declareClass(String className, FileWriter aWriter) throws IOException {
		aWriter.write("\npublic class " + className + " {");
		aWriter.write("\n");
	}

	/**
	 * This method will add testCaseMethod java code.
	 * 
	 * @param dataList final List<XlsFileRowDetails> dataList
	 * @param aWriter  FileWriter
	 * @throws IOException
	 */
	private static void addTestCaseMethod(final List<XlsFileRowDetails> dataList, FileWriter aWriter)
			throws IOException {
		for (XlsFileRowDetails l_fileRowDetails : dataList) {
			if (l_fileRowDetails.getDependsOnScenerio() == null
					|| l_fileRowDetails.getDependsOnScenerio().trim().isEmpty()
					|| l_fileRowDetails.getDependsOnScenerio().equalsIgnoreCase("NULL")) {
				aWriter.write(" \n @Test(priority=" + l_fileRowDetails.getPriority() + ",enabled=true)");
			} else {
				aWriter.write(" \n @Test( priority =" + l_fileRowDetails.getPriority()
						+ ", enabled = true, dependsOnMethods =\"" + l_fileRowDetails.getDependsOnScenerio() + "\" )");
			}
			aWriter.write("\n");
			aWriter.write(" public void " + l_fileRowDetails.getMethodName() + "(final Method method) {");
			aWriter.write("\n");
			aWriter.write(
					" FrameworkUtil.executeTest(getTestCaseCommonData(),getTestCaseDetail(),method.getName(),getTestCaseRepoPath());");
			aWriter.write("\n");
			aWriter.write("\n}\n");
		}
	}

	/**
	 * This method will add instance variables in test class.
	 * 
	 * @param aWriter FileWriter
	 * @throws IOException
	 */
	private static void addInstanceVariable(FileWriter aWriter) throws IOException {
		aWriter.write(" \n private TestCaseDetail testCaseDetail;");
		aWriter.write("\n");
		aWriter.write(" private TestCaseCommonData testCaseCommonData;");
		aWriter.write("\n");
		aWriter.write(" private String testCasesPath=null;");
		aWriter.write("\n");
		aWriter.write(" private static Map<String, String> variableHolder=new HashMap<>();");
		aWriter.write("\n");
	}

	/**
	 * This method will add beforeTestMethod java code.
	 * 
	 * @param dataList                List<XlsFileRowDetails>
	 * @param paymentScheduleScenerio String
	 * @param aWriter                 FileWriter
	 * @throws IOException
	 */
	private static void addBeforeMethod(final List<XlsFileRowDetails> dataList,FileWriter aWriter) throws IOException {
		aWriter.write(" \n@Parameters(" + " { \"browserName\", \"domainName\" } )");
		aWriter.write("\n");
		aWriter.write("@BeforeMethod");
		aWriter.write("\n");
		aWriter.write(" public void beforeTestMethod(@Optional(\"" + dataList.get(0).getBrowser()
				+ "\") final String browserName,@Optional(\"" + dataList.get(0).getDomain()
				+ "\") final String domainName,final Method method){");
		aWriter.write("\n");
		aWriter.write(" testCaseCommonData=new TestCaseCommonData();");
		aWriter.write("\n");
		/*if (CommonConstant.YES.equalsIgnoreCase(getPaymentScheduleScenerio(dataList))) {
			aWriter.write(" testCaseCommonData.setComparePaymentSchedule(true);");
			aWriter.write("\n");
		}*/
		aWriter.write(" testCaseDetail=new TestCaseDetail();");
		aWriter.write("\n");
		aWriter.write(" testCasesPath=DomainInitialization.initializeDomainWiseTestCasesPath(domainName);");
		aWriter.write("\n");
		aWriter.write(
				" FrameworkUtil.populateTestCaseCommonData(testCaseCommonData,browserName,method.getName(),this.getClass().getSimpleName(),domainName,getVariableHolder());");
		aWriter.write(" \n}\n");
	}

	/*private static String getPaymentScheduleScenerio(final List<XlsFileRowDetails> dataList) {
		String resultValue = CommonConstant.NO;
		for (XlsFileRowDetails xlsFileRowDetails : dataList) {
			if (CommonConstant.YES.equals(xlsFileRowDetails.getPaymentScheduleScenerio())) {
				resultValue = xlsFileRowDetails.getPaymentScheduleScenerio();
				break;
			}
		}
		return resultValue;
	}*/
	/**
	 * This method will add import statements.
	 * 
	 * @param packageName String
	 * @param aWriter     FileWriter
	 * @throws IOException
	 */
	private static void addImportStatements(String packageName, FileWriter aWriter) throws IOException {
		aWriter.write("package " + packageName + ";");
		aWriter.write("\n");
		aWriter.write("import java.lang.reflect.Method;");
		aWriter.write("\n");
		aWriter.write("import java.util.HashMap;");
		aWriter.write("\n");
		aWriter.write("import java.util.Map;");
		aWriter.write("\n");
		aWriter.write("import org.testng.ITestResult;");
		aWriter.write("\n");
		aWriter.write("import org.testng.annotations.AfterMethod;");
		aWriter.write("\n");
		aWriter.write("import org.testng.annotations.BeforeMethod;");
		aWriter.write("\n");
		aWriter.write("import org.testng.annotations.Optional;");
		aWriter.write("\n");
		aWriter.write("import org.testng.annotations.Parameters;");
		aWriter.write("\n");
		aWriter.write("import org.testng.annotations.Test;");
		aWriter.write("\n");
		aWriter.write("import com.cassiopae.framework.to.TestCaseCommonData;");
		aWriter.write("\n");
		aWriter.write("import com.cassiopae.framework.to.TestCaseDetail;");
		aWriter.write("\n");
		aWriter.write("import com.cassiopae.framework.util.FrameworkUtil;");
		aWriter.write("\n");
		aWriter.write("import com.cassiopae.selenium.util.common.DomainInitialization;");
		aWriter.write("\n");
	}

	/**
	 * This method will add afterTestMethod java code.
	 * 
	 * @param aWriter FileWriter
	 * @throws IOException
	 */
	private static void addAfterMethod(FileWriter aWriter) throws IOException {
		aWriter.write(" @AfterMethod");
		aWriter.write("\n");
		aWriter.write(" public void afterTestMethod(final ITestResult testResult) {");
		aWriter.write("\n");
		aWriter.write(" FrameworkUtil.postTestCaseExecution(testResult, getTestCaseCommonData());");
		aWriter.write("\n}\n\n");

		aWriter.write(" public TestCaseDetail getTestCaseDetail() {");
		aWriter.write("\n");
		aWriter.write(" return testCaseDetail;");
		aWriter.write("\n}\n\n");

		aWriter.write(" public TestCaseCommonData getTestCaseCommonData() {");
		aWriter.write("\n");
		aWriter.write(" return testCaseCommonData;");
		aWriter.write("\n}\n\n");

		aWriter.write(" public String getTestCaseRepoPath() {");
		aWriter.write("\n");
		aWriter.write(" return testCasesPath;");
		aWriter.write("\n}\n\n");

		aWriter.write(" public void setTestCaseRepoPath(String testCaseRepoPath) {");
		aWriter.write("\n");
		aWriter.write(" this.testCasesPath=testCaseRepoPath;");
		aWriter.write("\n}\n\n");

		aWriter.write(" public static Map<String, String> getVariableHolder() {");
		aWriter.write("\n");
		aWriter.write(" return variableHolder;");
		aWriter.write("\n}\n");

		aWriter.write("\n}\n");
	}

}
