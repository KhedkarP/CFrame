/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;

/**
 * @author nbhil
 *
 */
public class NavigateAction implements PerformAction {

	/**
	 * This method execute action for navigate action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String url = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps()
				+ CommonConstant.HYPHEN_SEPERATOR + url);
		testCaseDetailTO.getDriver().get(url);

	}

}
