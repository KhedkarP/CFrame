/**
 * 
 */
package com.cassiopae.framework.to;

/**
 * @author jraut
 *
 */
public class restWebServiceData {

	private String[] inputTestData;
	private String datasetName;
	private String[] restHeaderInfo;
	private String sessionToken;
	private String cookies;
	private String resourceURL;
	private int dataSetRowNumber;
	private String pathOfTestCase;

	/**
	 * @return the inputTestData
	 */
	public String[] getInputTestData() {
		return inputTestData;
	}

	/**
	 * @param inputTestData the inputTestData to set
	 */
	public void setInputTestData(String[] inputTestData) {
		this.inputTestData = inputTestData;
	}

	/**
	 * @return the datasetName
	 */
	public String getDatasetName() {
		return datasetName;
	}

	/**
	 * @param datasetName the datasetName to set
	 */
	public void setDatasetName(String datasetName) {
		this.datasetName = datasetName;
	}

	/**
	 * @return the restHeaderInfo
	 */
	public String[] getRestHeaderInfo() {
		return restHeaderInfo;
	}

	/**
	 * @param restHeaderInfo the restHeaderInfo to set
	 */
	public void setRestHeaderInfo(String[] restHeaderInfo) {
		this.restHeaderInfo = restHeaderInfo;
	}

	/**
	 * @return the sessionToken
	 */
	public String getSessionToken() {
		return sessionToken;
	}

	/**
	 * @param sessionToken : sessionToken to set
	 */
	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	/**
	 * @return the cookies
	 */
	public String getCookies() {
		return cookies;
	}

	/**
	 * @param cookies the cookies to set
	 */
	public void setCookies(String cookies) {
		this.cookies = cookies;
	}

	/**
	 * @return the resourceURL
	 */
	public String getResourceURL() {
		return resourceURL;
	}

	/**
	 * @param resourceURL the resourceURL to set
	 */
	public void setResourceURL(String resourceURL) {
		this.resourceURL = resourceURL;
	}

	/**
	 * @return the dataSetRowNumber
	 */
	public int getDataSetRowNumber() {
		return dataSetRowNumber;
	}

	/**
	 * @param dataSetRowNumber the dataSetRowNumber to set
	 */
	public void setDataSetRowNumber(int dataSetRowNumber) {
		this.dataSetRowNumber = dataSetRowNumber;
	}

	/**
	 * @return the pathOfTestCase
	 */
	public String getPathOfTestCase() {
		return pathOfTestCase;
	}

	/**
	 * @param pathOfTestCase the pathOfTestCase to set
	 */
	public void setPathOfTestCase(String pathOfTestCase) {
		this.pathOfTestCase = pathOfTestCase;
	}

}
