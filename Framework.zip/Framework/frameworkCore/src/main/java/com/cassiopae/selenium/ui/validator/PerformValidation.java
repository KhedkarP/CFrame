/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author jraut
 *
 */
public interface PerformValidation
{
  public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO,TestCaseDetail testCaseDetailTO);
}
