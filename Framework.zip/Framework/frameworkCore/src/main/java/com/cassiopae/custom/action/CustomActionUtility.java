package com.cassiopae.custom.action;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

public class CustomActionUtility {

	public static String replaceValue(String originalValue, String oldValue, String newValue, Logger reportinglogger) {
		String resultValue = null;
		try {
			resultValue = originalValue.replace(StringUtils.defaultString(oldValue),
					StringUtils.defaultString(newValue));
			reportinglogger.info(ReportLoggerConstant.REPLACED_VALUE + resultValue);
		} catch (Exception e) {
			reportinglogger.info(ErrorMessageConstant.INVALID_PARAMETERS);
			throw new CATTException(ErrorMessageConstant.INVALID_PARAMETERS);
		}
		return resultValue;
	}
}
