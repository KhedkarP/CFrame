package com.cassiopae.ui.validation.constant;

public interface ValidationConstant {

	public String DISPLAY_VALIDATION = "SLVD_IsDisplayed";
	public String ASSERT_NOT_EQUALS_VALIDATION = "SLVD_AssertNotEquals";
	public String ASSERT_EQUALS_VALIDATION = "SLVD_AssertEquals";
	public String CHECKBOX_VALIDATION = "SLVD_IsSelected";
	public String FIELD_ENABLED_VALIDATION = "SLVD_IsEnabled";
	public String ASSERT_EQUAL_IGNORE_CASE = "SLVD_AssertEquals_CaseInSentitive";
	public String ASSERT_EQUAL_CONTAINS = "SLVD_AssertEquals_Contains";
	public String ASSERT_STARTS_WITH_IGNORECASE = "SLVD_AssertEquals_StartsWith";
	public String VALIDATE_PAYMENT_SCHEDULE_EXCEL = "XLS_PaymentScheduleValidation";
	public String TABLE_COLUMN_DATA_VALIDATION = "SLVD_TableColumnDataValidation";
	public String CHECK_DROPDOWN_VALUE_IS_PRESENT ="SLVD_CheckDropDownValueIsPresent";
	public String DATE_COMPARE="SLVD_CompareDate";
	public String DYNAMIC_CHECKBOX_VALIDAITON="SLVD_GenerateXpath_IsCheckboxSelected";
	public String CHECK_DROPDOWN_VALUE_IS_SORTED ="SLVD_CheckDropDownValueIsSorted";
	public String EXCEL_VALIDATE_DATA = "XLS_ValidateExcelData";
}
