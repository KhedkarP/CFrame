package com.cassiopae.custom.action;

import java.io.File;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;

public class ExtractPDFDataAndValidate implements CustomAction {

	/**
	 * @author mshaik
	 * @param excelTestCaseFields @ This method will perform
	 * @param testCaseDetail
	 * 
	 */
	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Logger reportingLogger = testCaseDetail.getReportingLogger();
		reportingLogger.info(excelTestCaseFields.getTestCaseSteps());
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		String randomString = CommonFunctions.generateDynamicData(CommonConstant.ALPHANUMERIC,
				CommonConstant.DYNAMIC_STRING_LENGTH);
		String[] inputTextData = excelTestCaseFields.getInputTestData().trim()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String actualPDFFileName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				inputTextData[0]);
		String actualPDFFilePath = downlodedPath + actualPDFFileName;
		SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, reportingLogger, actualPDFFileName);
		String pdfFileName = actualPDFFileName
				.split(actualPDFFileName.substring(actualPDFFileName.lastIndexOf(CommonConstant.DOT_OPERATOR)))[0];
		String renamedPDFFileName = pdfFileName + CommonConstant.UNDER_SCORE + randomString
				+ CommonConstant.PDF_FILE_EXTENSION1;
		String renamedPDFFilePath = downlodedPath + renamedPDFFileName;
		FileUtility.renameFile(actualPDFFilePath, renamedPDFFilePath, downlodedPath, reportingLogger,
				ReportLoggerConstant.GIVEN_FILE + actualPDFFileName + ReportLoggerConstant.RENAMED_SUCESSFULL_MESSAGE);
		PdfReaderUtility.validateInputParameters(excelTestCaseFields, testCaseDetail);
		List<String> pdfData = PdfReaderUtility.extractDatafromPDFAndConvertlog(renamedPDFFilePath, downlodedPath,
				randomString, testCaseDetail, pdfFileName);
		PdfReaderUtility.validatePDFData(excelTestCaseFields, testCaseDetail, pdfData, renamedPDFFileName);
	}
}
