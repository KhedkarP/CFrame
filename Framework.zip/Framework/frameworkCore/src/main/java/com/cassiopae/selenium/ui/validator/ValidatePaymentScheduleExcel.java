package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.util.common.FileStructureConstants;

public class ValidatePaymentScheduleExcel implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		if (testCaseDetailTO.getTestCaseCommonData().getBrowserName().equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			SeleniumUtility.downloadPaymentSchedule(FileStructureConstants.autoITExecutalePathForFileDownload,
					FileStructureConstants.closeAutoITInstancesBatFilePath,
					testCaseDetailTO.getTestCaseCommonData().getReportingLogger());
		}
		PaymentScheduleValidationUtility.comparePaymetScheduleExcel(excelTestCaseFieldsTO, testCaseDetailTO);
	}
}
