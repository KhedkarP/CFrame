/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;

/**
 * @author jraut
 *
 */
public class AssertEqualContains implements PerformValidation {

    @Override
    public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
	String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
	testCaseDetailTO.getReportingLogger()
			.info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + variableHolderExpectedValue);
	String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
			testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
	GenericAction.assertEqualsContains(variableHolderActualValue, variableHolderExpectedValue, excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());

    }
}
