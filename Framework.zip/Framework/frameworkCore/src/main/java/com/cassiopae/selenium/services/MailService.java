/**
 * 
 */

package com.cassiopae.selenium.services;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.MailConstants;

/**
 * @author jraut
 */
public class MailService implements FrameworkConstant {

	private static Logger logger = LogManager.getLogger( MailService.class );

	// *************************** Mail Sending Definition Method ***************************//
	// ************************** E Mail Methods ***********************//
	public static void mailToRecipents( final String method, final String issues, final String appVer, final Logger reportingLogger )
		{
		Properties props = new Properties();
		props.put( "mail.smtp.auth", "true" );
		props.put( "mail.smtp.starttls.enable", "true" );
		props.put( "mail.smtp.host", MailConstants.MAIL_SMTP_HOST );
		props.put( "mail.smtp.port", MailConstants.MAIL_PORT );
		Session session = Session.getInstance( props, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication( MailConstants.MAIL_USERNAME, MailConstants.MAIL_PASSOWORD );
			}
		} );
		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage( session );
			// Set From: header field of the header.
			message.setFrom( new InternetAddress( MailConstants.MAIL_FROM ) );
			// Set To: header field of the header.
			message.setRecipients( Message.RecipientType.TO, InternetAddress.parse( MailConstants.MAIL_TO ) );
			// Set CC: header field of the header.
			message.setRecipients( Message.RecipientType.CC, InternetAddress.parse( MailConstants.MAIL_TO ) );
			// Set Subject: header field
			message.setSubject( method + " Failing due to Issue -" + issues + " [" + appVer + "]" );
			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			messageBodyPart.setText( "Hi,\n\n" + "Please refer Issue ticket  - " + issues + "  in JIRA to reproduce issue .\n\n" + "Regards,\n" +
									 "Cassiopae Automation Team" );
			// Create a multiPart message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart( messageBodyPart );
			/*// Part two is attachment
									messageBodyPart=new MimeBodyPart();
									String filename="C://SeleniumWebDriver//Cass4_5//Trunk4_5//test-output.zip";
									String filename2="Trunk45 Automation Execution Report On" + app_ver + " Time : " + ReportDateTime() + ".zip";
									DataSource source=new FileDataSource(filename);
									messageBodyPart.setDataHandler(new DataHandler(source));
									messageBodyPart.setFileName(filename2);
									multipart.addBodyPart(messageBodyPart);*/
			// Send the complete message parts
			message.setContent( multipart );
			reportingLogger.info( "Sending Report..." );
			// Send message
			Transport.send( message );
			reportingLogger.info( "Report Sent successfully on Issue" );
		}
		catch ( MessagingException e ) {
			logger.error( e.getMessage(), e );
			throw new CATTException( e.getMessage() );
		}
	}

	public static void mailToRecipentsBeforeTest()  {
		Properties props = new Properties();
		props.put( "mail.smtp.auth", "true" );
		props.put( "mail.smtp.starttls.enable", "true" );
		props.put( "mail.smtp.host", MailConstants.MAIL_SMTP_HOST );
		props.put( "mail.smtp.port", MailConstants.MAIL_PORT );
		Session session = Session.getInstance( props, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication( MailConstants.MAIL_USERNAME, MailConstants.MAIL_PASSOWORD );
			}
		} );
		try {
			// Create a default MimeMessage object.
			Message message = new MimeMessage( session );
			// Set From: header field of the header.
			message.setFrom( new InternetAddress( MailConstants.MAIL_FROM ) );
			// Set To: header field of the header.
			message.setRecipients( Message.RecipientType.TO, InternetAddress.parse( MailConstants.MAIL_TO ) );
			// Set CC: header field of the header.
			message.setRecipients( Message.RecipientType.CC, InternetAddress.parse( MailConstants.MAIL_CC ) );
			// Set Subject: header field
			message.setSubject( MailConstants.MAIL_SUBJECT_BEFORE_EXECUTION );
			// Create the message part
			BodyPart messageBodyPart = new MimeBodyPart();
			// Now set the actual message
			messageBodyPart.setText( MailConstants.MAIL_BODY_BEFORE_EXECUTION );
			// Create a multipart message
			Multipart multipart = new MimeMultipart();
			// Set text message part
			multipart.addBodyPart( messageBodyPart );
			// Part two is attachment
			messageBodyPart = new MimeBodyPart();
			String filename = "d:\\Profiles\\mshaik\\Desktop\\TEST_File_Input.txt";
			//String filename2="Trunk45 Automation Execution Report On" + app_ver + " Time : " + ReportDateTime() + ".zip";
			DataSource source = new FileDataSource( filename );
			messageBodyPart.setDataHandler( new DataHandler( source ) );
			//messageBodyPart.setFileName(filename2);
			multipart.addBodyPart( messageBodyPart );
			// Send the complete message parts
			message.setContent( multipart );
			//logger.info("Sending Report...");
			// Send message
			Transport.send( message );
			//logger.info("Report Sent successfully on Issue");
		}
		catch ( MessagingException e ) {
			logger.error( e.getMessage(), e );
			throw new CATTException( e.getMessage() );
		}
	}

	public static void mailToRecipentsAfterTest()  {
		Properties props = new Properties();
		props.put( "mail.smtp.auth", "true" );
		props.put( "mail.smtp.starttls.enable", "true" );
		props.put( "mail.smtp.host", MailConstants.MAIL_SMTP_HOST );
		props.put( "mail.smtp.port", "587" );
		Session session = Session.getInstance( props, new javax.mail.Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return null;
				// return new PasswordAuthentication(MailCon_UserName, MailCon_Passoword);
			}
		} );
		try
		{
			// Create a default MimeMessage object.
			Message message=new MimeMessage(session);
			// Set From: header field of the header.
			message.setFrom( new InternetAddress( MailConstants.MAIL_FROM ) );
			// Set To: header field of the header.
			message.setRecipients( Message.RecipientType.TO, InternetAddress.parse( MailConstants.MAIL_TO ) );
			// Set CC: header field of the header.
			message.setRecipients( Message.RecipientType.CC, InternetAddress.parse( MailConstants.MAIL_CC ) );
			// Set Subject: header field
			message.setSubject( MailConstants.MAIL_SUBJECT_AFTER_EXECUTION );
			// Create the message part
			BodyPart messageBodyPart=new MimeBodyPart();
			// Now set the actual message
			messageBodyPart.setText( MailConstants.MAIL_BODY_AFTER_EXECUTION );
			// Create a multipart message
			Multipart multipart=new MimeMultipart();
			// Set text message part
			multipart.addBodyPart(messageBodyPart);
			// Part two is attachment
			if ( MailConstants.MailCon_FileToAttach_1.equalsIgnoreCase( "TestData.xls" ) &&
				 MailConstants.MailCon_FileToAttach_2.equalsIgnoreCase( "emailable-report.html" ) ) {
				addAttachment( multipart, MailConstants.EXCEL_Path, MailConstants.MailCon_FileToAttach_1 );
				addAttachment( multipart, MailConstants.TESTNG_PATH_EMAILABLE_REPORT, MailConstants.MailCon_FileToAttach_2 );
			}
			else if ( MailConstants.MailCon_FileToAttach_1.equalsIgnoreCase( "TestData.xls" ) &&
					  MailConstants.MailCon_FileToAttach_2.equalsIgnoreCase( "NA" ) ) {
				addAttachment( multipart, MailConstants.EXCEL_Path, MailConstants.MailCon_FileToAttach_1 );
			}
			else if ( MailConstants.MailCon_FileToAttach_1.equalsIgnoreCase( "NA" ) &&
					  MailConstants.MailCon_FileToAttach_2.equalsIgnoreCase( "emailable-report.html" ) ) {
				addAttachment( multipart, MailConstants.TESTNG_PATH_EMAILABLE_REPORT, MailConstants.MailCon_FileToAttach_2 );
			}
			// Send the complete message parts
			message.setContent(multipart);
			// Send message
			Transport.send(message);
		}
		catch ( MessagingException exp ) {
			logger.error( exp.getMessage(), exp );
			throw new CATTException( exp.getMessage() );
		}
	}

	private static void addAttachment( final Multipart multipart, final String filepath, final String fileName )  {
		try {
			DataSource source = new FileDataSource( filepath );
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setDataHandler( new DataHandler( source ) );
			messageBodyPart.setFileName( fileName );
			multipart.addBodyPart( messageBodyPart );
		}
		catch ( MessagingException exp ) {
			logger.error( exp.getMessage(), exp );
			throw new CATTException( exp.getMessage() );
		}
	}

	/*public static void logJIRA( final Logger logger, final Method method, final int Excel_Row_No, final String Execution_Time, final String Issue,
								final String Issue_Reproduce_steps_logs, final String App_Version, final String domainName,
								final String Excel_SheetName, final String Error_Message, final String New_Video_Location )
		throws Throwable {
		try {
			logger.info( "****" + method.getName() + " is Failed" + " :  Execution time in mins " + Execution_Time );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelStatusColumn, Excel_SheetName, domainName, "Fail" );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelTestDataColumn, Excel_SheetName, domainName, "" );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelTestDataColumn1, Excel_SheetName, domainName, "" );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelTestDataColumn2, Excel_SheetName, domainName, "" );
			ExcelOperation
				.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelVideoColumn, Excel_SheetName, domainName, New_Video_Location );
			ExcelOperation
				.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelExecutionTimeFailTC, Excel_SheetName, domainName, Execution_Time );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelErrorColumn, Excel_SheetName, domainName, Error_Message );
			ExcelOperation.ExcelAction( "Write", Excel_Row_No, ApplicationConstant.excelExecutionTimePassTC, Excel_SheetName, domainName, "" );
			try {
				Issue = NewIssueCreation( Project,
										  method.getName(),
										  username1,
										  password1,
										  description,
										  assignee,
										  issuetype,
										  components,
										  Module,
										  Feature );
				logger.info( " Issue " + Issue );
				AttachedDocumetToJira( Issue, Issue_Reproduce_steps_logs, Issue_Video_path, username1, password1 );
			}
			catch ( java.lang.Exception e ) {
				e.printStackTrace();
			}
			// Utility.ExcelAction("Write",Excel_Row_No,Excel_Issue_Column,Excel_SheetName,Issue);
			try {
				Mail_To_Recipents( method.getName(), Issue, App_Version, logger );
			}
			catch ( java.lang.Exception e ) {
			}
		}
		catch ( Exception e ) {
		}
	}*/

}
