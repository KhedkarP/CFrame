package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class ConstructionFunctions {

    private static Map<String, List<String>> constructionLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.CONSTRUCTION_LOCATOR);

    /*
     * Construction Functions
     */
    public static void navigateTo(WebDriver driver, Logger reportingLogger) {
	GenericAction.mouseHoverOn(FunctionReportingConstant.CONSTRUCTION_MOUSE_HOVER,
		FunctionLocatorConstant.CONSTRUCTION_MENU, constructionLocatorMap, driver, reportingLogger);
	GenericAction.clickOn(FunctionReportingConstant.CONSTRUCTION_SUB_MENU,
		FunctionLocatorConstant.CONSTRUCTION_SUB_MENU, constructionLocatorMap, driver, reportingLogger);
    }

    public static void open(String reference,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail) {
	navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_CONSTRUCTION_REFERENCE_NUMBER);
	excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.CONSTRUCTION_INPUT_REFERENCE);
	testCaseDetail.setLocatorHashMap(constructionLocatorMap);
	GenericAction.enterValueIn(reference,excelTestCaseFields,testCaseDetail);
	
	GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_CONSTRUCTION_REFERENCE_ICON,
		FunctionLocatorConstant.CONSTRUCTION_SEARCH_ICON, constructionLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_CONSTRUCTION_REFERENCE_HYPERLINK + reference,
		FunctionLocatorConstant.CONSTRUCTION_REFERNCE_HYPERLINK, constructionLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
    }

}
