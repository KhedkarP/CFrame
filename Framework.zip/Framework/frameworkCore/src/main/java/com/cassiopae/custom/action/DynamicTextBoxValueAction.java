/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class DynamicTextBoxValueAction implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {


		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		GenericAction.locator(locatorKeys[0], locatorMap);
		String[] inputDataColumnValues = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		
		String textBoxInputData=VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),inputDataColumnValues[1].trim());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps()+ReportLoggerConstant.AS + textBoxInputData);
		performEnterTextBoxValueAction(testCaseDetail, locatorMap, locatorKeys, inputDataColumnValues,excelTestCaseFields);
	}
	
	/**
	 * This method will create dynamic X-path and perform sendkeys operation on generated X-path
	 * @param testCaseDetail
	 * @param locatorMap
	 * @param locatorKeys
	 * @param inputTestDatas
	 * @param dataRowNumber
	 */
	private void performEnterTextBoxValueAction(TestCaseDetail testCaseDetail, Map<String, List<String>> locatorMap,
			String[] locatorKeys, String[] inputDataColumnValues,ExcelTestCaseFields excelTestCaseFields) {
		String xpathForSelect;
		String[] inputTestDataRowNumbers = inputDataColumnValues[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String textBoxInputData=VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),inputDataColumnValues[1].trim());
		if(CommonFunctions.checkArrayElementAreNumeric(inputTestDataRowNumbers,testCaseDetail)) {
			testCaseDetail.getReportingLogger().error(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
			throw new CATTException(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
		}
		String xpath=CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap);
		if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			String value = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), inputTestDataRowNumbers[0].trim());
			String[] prefixSufixID = SelectPanelTableEntryUtility
					.getPrefixAndSuffixID(CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap));
			xpathForSelect = SelectPanelTableEntryUtility.constructXPath(Integer.parseInt(value), prefixSufixID[0],
					prefixSufixID[1]);
		} else {
			xpathForSelect = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetail.getVariableHolder(), inputTestDataRowNumbers);
		}
		String storeVariable = excelTestCaseFields.getStoreValuesInVariable();
		excelTestCaseFields.setInputTestData(textBoxInputData);
		textBoxInputData = CommonFunctions.getInputTextBoxData(excelTestCaseFields);
		if(storeVariable != null) {
			testCaseDetail.getVariableHolder().put(storeVariable, textBoxInputData);
		}
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		enterValueIntextBox(testCaseDetail, xpathForSelect, textBoxInputData);
	}

	/**
	 * @param testCaseDetail
	 * @param xpathForSelect
	 * @param textBoxInputData
	 */
	private void enterValueIntextBox(TestCaseDetail testCaseDetail, String xpathForSelect, String textBoxInputData) {
		WebElement webElement = GenericAction.getWebElement(testCaseDetail.getDriver(), By.xpath(xpathForSelect), testCaseDetail.getReportingLogger());
		GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement,
				testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		
		if (testCaseDetail.getTestCaseCommonData().getBrowserName()
				.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			webElement.clear();
			testCaseDetail.getDriver().findElement(By.xpath(xpathForSelect)).click();
			testCaseDetail.getDriver().findElement(By.xpath(xpathForSelect)).sendKeys(textBoxInputData + Keys.ENTER);
		} else {
			webElement.click();
			testCaseDetail.getDriver().findElement(By.xpath(xpathForSelect)).clear();
			testCaseDetail.getDriver().findElement(By.xpath(xpathForSelect)).sendKeys(textBoxInputData + Keys.TAB);
		}
	}	
}
