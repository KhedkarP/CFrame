/**
 * 
 */
package com.cassiopae.framework.to;

import java.util.HashMap;
import java.util.Map;

/**
 * @author jraut
 *
 */
public class TestCaseDataRow {

	private Map<Integer, String> dataSetMap = new HashMap<>();
	private Map<String, Integer> headerMap = new HashMap<>();

	public void setCellValue(final Integer colNo, final String value) {
		dataSetMap.put(colNo, value);
	}

	public String getCellValue(final Integer colNo) {
		return dataSetMap.get(colNo);
	}

	public void setHeaderValue(final String value, final Integer colNo) {
		headerMap.put(value, colNo);
	}

	public int getHeaderValue(final String value) {
		return headerMap.get(value);
	}

	public Map<String, Integer> getHeaderMap() {
		return headerMap;
	}

}
