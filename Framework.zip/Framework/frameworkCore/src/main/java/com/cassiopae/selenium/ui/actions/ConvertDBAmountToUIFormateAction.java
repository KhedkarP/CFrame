package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.excel.dataconvertor.DataConvertorUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author jraut
 *
 */
public class ConvertDBAmountToUIFormateAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String calculatedValue = null;
		String amount = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData().trim());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + amount);
		calculatedValue = DataConvertorUtility.covertDataToUIFormat(testCaseDetailTO, amount);
		testCaseDetailTO.getReportingLogger().info("Converted amount is : " + calculatedValue);
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), calculatedValue);
		}
	}
}
