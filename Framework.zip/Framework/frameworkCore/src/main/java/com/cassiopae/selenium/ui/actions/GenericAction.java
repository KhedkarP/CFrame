package com.cassiopae.selenium.ui.actions;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;
import org.testng.Assert;

import com.cassiopae.custom.action.DownloadFile;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.utils.excel.ExcelComparator;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class GenericAction {

	// ********************Constant Starting and Ending

	private static Logger logger = LogManager.getLogger(GenericAction.class);

	/*
	 * LocatorSection
	 */
	public static By locator(final String xpathKey, final Map<String, List<String>> locatorHM) {
		By locType = null;
		/*
		 * if(null ==locatorHM) { logger.error(
		 * "Please initialize locator repository - (check initialization code) " );
		 * throw new CATTException(
		 * "Please initialize locator repository - (check initialization code) " ); }
		 */
		if (null != locatorHM.get(xpathKey)) {
			if (locatorHM.get(xpathKey).get(0) != null) {
				locType = By.xpath(locatorHM.get(xpathKey).get(0));
			} else if (locatorHM.get(xpathKey).get(1) != null) {
				locType = By.id(locatorHM.get(xpathKey).get(1));
			} else if (locatorHM.get(xpathKey).get(2) != null) {
				locType = By.linkText(locatorHM.get(xpathKey).get(2));
			} else if (locatorHM.get(xpathKey).get(3) != null) {
				locType = By.partialLinkText(locatorHM.get(xpathKey).get(3));
			}
		} else {
			logger.error(ErrorMessageConstant.LOCATOR_KEY_NOT_EXIST + xpathKey);
			throw new ValidatorException(ErrorMessageConstant.LOCATOR_KEY_NOT_EXIST + xpathKey);
		}
		return locType;
	}

	// ******************************** GenaricActions : Used to perform
	// SELENIUM
	// Actions ********************************************

	public static boolean checkElementOnUI(final WebElement element, final Map<String, List<String>> locatorHM,
			final WebDriver driver, final Logger reportingLogger) {
		boolean enablilityOfElement = false;
		boolean visibilityOfElement = false;
		try {
			enablilityOfElement = element.isEnabled();
			visibilityOfElement = element.isDisplayed();
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				reportingLogger.error(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
				throw new CATTException(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
			} else {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		} catch (ElementNotVisibleException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			reportingLogger.error(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
			throw new CATTException(e.getMessage());
		} catch (StaleElementReferenceException e) {
			logger.error(e);
		} catch (Exception e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(e.getMessage());
		}
		return (enablilityOfElement && visibilityOfElement);
	}

	public static boolean checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(final WebElement webElement,
			final WebDriver driver, final Logger reportingLogger) {
		boolean enablilityOfElement = false;
		boolean visibilityOfElement = false;
		try {
			enablilityOfElement = webElement.isEnabled();
			visibilityOfElement = webElement.isDisplayed();
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				reportingLogger.error(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
				throw new CATTException(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
			} else {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		} catch (ElementNotVisibleException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			reportingLogger.error(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
			throw new CATTException(e.getMessage());
		} catch (Exception e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(e.getMessage());
		}
		return (enablilityOfElement && visibilityOfElement);
	}

	public static boolean checkGeneratedDynamicXpathVisibilityOnUI(final String xpathKey, final WebDriver driver,
			final Logger reportingLogger) {
		boolean enablilityStatus = false;
		try {
			enablilityStatus = driver.findElement(By.xpath(xpathKey)).isDisplayed();
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
			} else {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		} catch (ElementNotVisibleException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			reportingLogger.error(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
		} catch (ElementClickInterceptedException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
		} catch (Exception e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(e.getMessage());
		}
		return enablilityStatus;
	}

	public static boolean checkElementDisplayNotEnabled(final WebElement webElement,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		boolean enablilityStatus = false;

		try {
			enablilityStatus = webElement.isDisplayed();
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
			} else {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		} catch (ElementNotVisibleException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			reportingLogger.error(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
		} catch (ElementClickInterceptedException e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_VISIBLE_MESSAGE);
		} catch (Exception e) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(e.getMessage());
		}
		return enablilityStatus;
	}

	public static String isPresentAndDisplayed(final String logMessage, final String errorMessage,
			final String xpathKey, final Map<String, List<String>> locatorHM, final WebDriver driver,
			final Logger reportingLogger, String validate) {
		String elecond = CommonConstant.FALSE_VALUE;
		reportingLogger.info(logMessage);
		try {
			driver.findElement(locator(xpathKey, locatorHM)).isDisplayed();
			reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
			elecond = CommonConstant.TRUE_VALUE;
		} catch (NoSuchElementException e) {
			if (!validate.equalsIgnoreCase(ReportLoggerConstant.CONTINUE)) {
				reportingLogger.error(errorMessage);
				throw new CATTException(errorMessage);
			}
		}
		return elecond;
	}

	public static boolean isSelected(final String logMessage, final String errorMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger logger) {
		boolean isSelected = false;
		logger.info(logMessage);
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, logger)) {
			isSelected = webElement.isSelected();
		}
		return isSelected;
	}

	public static boolean isEnabled(final String logMessage, final String errorMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger logger) {
		boolean isEnabled = false;
		logger.info(logMessage);
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, logger)) {
			isEnabled = webElement.isEnabled();
		}
		return isEnabled;
	}

	/*
	 * ClickActions
	 */
	public static void clickOn(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		boolean elementIsClickable = checkElementOnUI(webElement, locatorHM, driver, reportingLogger);
		CommonUtility.logTransactions(driver, logMessage);
		webElement = checkStaleOfElement(xpathKey, locatorHM, webElement, driver);
		if (elementIsClickable) {
			webElement.click();
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			logger.debug("Object property of element is :" + locator(xpathKey, locatorHM));
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_CLICKABLE);
		}
	}

	public static void rightClick(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		boolean elementIsClickable = checkElementOnUI(webElement, locatorHM, driver, reportingLogger);
		CommonUtility.logTransactions(driver, logMessage);
		webElement = checkStaleOfElement(xpathKey, locatorHM, webElement, driver);
		if (elementIsClickable) {
			Actions action = new Actions(driver);
			action.contextClick(webElement).build().perform();
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_CLICKABLE);
		}
	}

	public static void selectCheckBoxRadioButton(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		boolean checkstatus;
		reportingLogger.info(logMessage);
		WebElement webElement = null;
		try {
			webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		} catch (NoSuchElementException e2) {
			if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
				String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
						.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
				error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.LEFT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE);
			} else {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e2.getMessage());
			}
		}
		CommonUtility.logTransactions(driver, logMessage);
		checkstatus = webElement.isSelected();
		if (checkstatus) {
			reportingLogger.info(ReportLoggerConstant.CHECKBOX_ALREADY_CHECKED);
		} else {
			webElement.click();
			reportingLogger.info(ReportLoggerConstant.CHECKBOX_SELECTED_SUCESSFULLY);
		}
	}

	public static void unSelectCheckBoxRadioButton(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		boolean checkstatus;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			checkstatus = webElement.isSelected();
			if (checkstatus) {
				webElement.click();
				reportingLogger.info(ReportLoggerConstant.CHECKBOX_UN_CHECKED);
			} else {
				reportingLogger.info(ReportLoggerConstant.CHECKBOX_ALREADY_UN_CHECKED);
			}
		}
	}

	/**
	 * This method is used to select any drop-down value on UI
	 * 
	 * @param excelTestCaseFieldsTO
	 * @param testCaseDetailTO
	 */
	public static void selectValueOf(final ExcelTestCaseFields excelTestCaseFieldsTO,
			final TestCaseDetail testCaseDetailTO) {
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);

		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				new Select(webElement).selectByVisibleText(testData);
			} catch (NoSuchElementException g) {
				reportingLogger.info(ReportLoggerConstant.EXCEPTION + g.getMessage());
				String errorMessage1 = g.getMessage();
				if (errorMessage1.contains(ReportLoggerConstant.CANNOT_LOCATE_ELEMENT_WITH_TEXT)) {
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + testData
							+ ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT + CommonConstant.RIGHT_CONSTANT);
					try {
						String locator = locatorHM.get(xpathKey).get(0);
						locator = locator + ReportLoggerConstant.OPTION;
						List<WebElement> totalCombo = driver.findElements(By.xpath(locator));
						for (int k = 1; k <= totalCombo.size(); k++) {
							String newlocator = "(" + locator + ")[" + k + "]";
							reportingLogger.info(ReportLoggerConstant.AVILABLE_DROP_DOWN_VALUE
									+ driver.findElement(By.xpath(newlocator)).getText());
						}
						throw new CATTException(g.getMessage());
					} catch (Exception e1) {
						reportingLogger.error(CommonConstant.LEFT_CONSTANT + testData
								+ ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT + CommonConstant.RIGHT_CONSTANT);
						throw new CATTException(testData + ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
					}

				} else if (errorMessage1.contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String xpath = errorMessage1.split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					reportingLogger.warn(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + xpath);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + xpath);
				} else {
					throw new CATTException(g.getMessage());
				}
			} catch (StaleElementReferenceException e) {
				String errorMessage = e.getMessage();
				// reportingLogger.error(ReportLoggerConstant.TESTDATA_WHITE_SPACE_ISSUE
				// + errorMessage.split(ReportLoggerConstant.ELEMENT_INFO)[1]);
				try {
					String locator = locatorHM.get(xpathKey).get(0);
					locator = locator + ReportLoggerConstant.OPTION;
					List<WebElement> totalCombo = driver.findElements(By.xpath(locator));
					try {
						locator = locator + "[contains(text(),\"" + testData + "\")]"; // select Drop down value to
																						// handle apostrophe symbol
						driver.findElement(By.xpath(locator)).click();
					} catch (Exception er) {
						for (int p = 1; p <= totalCombo.size(); p++) {
							String newlocator = "(" + locator + ")[" + p + "]";
							reportingLogger.error(ReportLoggerConstant.AVILABLE_DROP_DOWN_VALUE
									+ driver.findElement(By.xpath(newlocator)).getText());
						}
						throw new CATTException(ReportLoggerConstant.TESTDATA_WHITE_SPACE_ISSUE
								+ errorMessage.split(ReportLoggerConstant.ELEMENT_INFO)[1]);
					}
				} catch (Exception e1) {
					logger.info(e1.getMessage());
					throw new CATTException(e1.getMessage());
				}

			} catch (UnexpectedTagNameException k) {
				String errorMessage1 = k.getMessage();
				reportingLogger.warn(errorMessage1 + ReportLoggerConstant.CHECK_ELEMENT_PROPERTY_WEB_ELEMENT);
				reportingLogger.error(ReportLoggerConstant.CHECK_ELEMENT_PROPERTY_WEB_ELEMENT);
				throw new CATTException(ReportLoggerConstant.INCORRECT_PROPERTY_MESSAGE);
			}
		} else {
			reportingLogger.error(ReportLoggerConstant.DROP_DOWN_FIELD_DISABLED_MESSAGE);
			throw new CATTException(ReportLoggerConstant.DROP_DOWN_FIELD_DISABLED_MESSAGE);
		}
	}

	public static void SelectDropdownValueContains(final ExcelTestCaseFields excelTestCaseFieldsTO,
			final TestCaseDetail testCaseDetailTO) {
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData()).trim();
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {
				String locator = locatorHM.get(xpathKey).get(0);
				locator = locator + ReportLoggerConstant.OPTION;
				List<WebElement> totalCombo = driver.findElements(By.xpath(locator));
				try {
					locator = locator + "[contains(text(),\"" + testData + "\")]";
					driver.findElement(By.xpath(locator)).click();
				} catch (Exception er) {
					for (int p = 1; p <= totalCombo.size(); p++) {
						String newlocator = "(" + locator + ")[" + p + "]";
						reportingLogger.error(ReportLoggerConstant.AVILABLE_DROP_DOWN_VALUE
								+ driver.findElement(By.xpath(newlocator)).getText());
					}
					throw new CATTException(ReportLoggerConstant.TESTDATA_WHITE_SPACE_ISSUE
							+ er.getMessage().split(ReportLoggerConstant.ELEMENT_INFO)[1]);
				}
			} catch (Exception e1) {
				logger.info(ReportLoggerConstant.UNABLETO_SELECT_DROPDOWN + e1.getMessage());
				throw new CATTException(ReportLoggerConstant.UNABLETO_SELECT_DROPDOWN + e1.getMessage());
			}
		} else {
			reportingLogger.error(ReportLoggerConstant.DROP_DOWN_FIELD_DISABLED_MESSAGE);
			throw new CATTException(ReportLoggerConstant.DROP_DOWN_FIELD_DISABLED_MESSAGE);
		}
	}

	public static void selectValueByIndexMethod(final String logMessage, final int index, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				new Select(driver.findElement(locator(xpathKey, locatorHM))).selectByIndex(index);
			} catch (Exception e1) {
				reportingLogger.error(ReportLoggerConstant.EXCEPTION_OCCURS_WHILE_SELECTING);
			}
			throw new CATTException(ReportLoggerConstant.EXCEPTION_OCCURS_WHILE_SELECTING);
		}
	}

	public static void SelectValuesFromList(final String logMessage, final String testData, final String errorMessage,
			final String xpathKey, final Map<String, List<String>> locatorHM, final WebDriver driver,
			final Logger reportingLogger) {
		reportingLogger.info(logMessage);
		List<WebElement> element = driver.findElements(locator(xpathKey, locatorHM));
		CommonUtility.logTransactions(driver, logMessage);
		String valueName = null;
		boolean valueNotPresent = false;
		for (int i = 1; i <= element.size(); i++) {
			valueName = driver.findElement(By.xpath("(" + locatorHM.get(xpathKey).get(0) + ")[" + i + "]")).getText();
			if (valueName.equals(testData)) {
				driver.findElement(By.xpath("(" + locatorHM.get(xpathKey).get(0) + ")[" + i + "]")).click();
				valueNotPresent = true;
				break;
			}
		}
		if (!valueNotPresent) {
			GenericAction.assertFail(errorMessage, reportingLogger);
		}
	}

	/*
	 * InputFieldActions
	 */
	public static void enterValueIn(String testDataValue, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {

		final String logMessage = excelTestCaseFields.getTestCaseSteps();
		final String testData = testDataValue;
		final String xpathKey = excelTestCaseFields.getLocatorKey();
		final Map<String, List<String>> locatorHM = testCaseDetail.getLocatorHashMap();
		final WebDriver driver = testCaseDetail.getDriver();
		final Logger reportingLogger = testCaseDetail.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
		if (testData == null) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.TESTDATA_VALUE_NULL
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.TESTDATA_VALUE_NULL);
		}
		WebElement element = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(element, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				if (testCaseDetail.getTestCaseCommonData().getBrowserName()
						.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
					if (testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS)) {
						driver.findElement(locator(xpathKey, locatorHM))
								.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE) + testData);
					} else {
						element.click();
						enterTextBoxValueForIEBrowser(driver, locator(xpathKey, locatorHM), testData);
					}
				} else if (testCaseDetail.getTestCaseCommonData().getBrowserName()
						.equalsIgnoreCase(CommonConstant.MS_EDGE_BROWSER)) {
					Actions navigator = new Actions(driver);
					navigator.click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT).sendKeys(Keys.HOME)
							.keyUp(Keys.SHIFT).sendKeys(Keys.BACK_SPACE).perform();
					element.sendKeys(testData + Keys.TAB);

					/*
					 * element.clear(); Actions navigator = new Actions(driver);
					 * navigator.click(element).sendKeys(testData + Keys.TAB).perform();
					 */} else if (testCaseDetail.getTestCaseCommonData().getBrowserName()
							.equalsIgnoreCase(CommonConstant.CHROME_BROWSER)) {
					Actions navigator = new Actions(driver);
					navigator.click(element).sendKeys(Keys.END).keyDown(Keys.SHIFT).sendKeys(Keys.HOME)
							.keyUp(Keys.SHIFT).sendKeys(Keys.BACK_SPACE).perform();
					element.sendKeys(testData + Keys.TAB);
				}
			} catch (NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (IllegalArgumentException e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
	}

	public static void enterTextAreaInputValue(String testDataValue, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		final String logMessage = excelTestCaseFields.getTestCaseSteps();
		final String testData = testDataValue;
		final String xpathKey = excelTestCaseFields.getLocatorKey();
		final Map<String, List<String>> locatorHM = testCaseDetail.getLocatorHashMap();
		final WebDriver driver = testCaseDetail.getDriver();
		final Logger reportingLogger = testCaseDetail.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
		if (testData == null) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.TESTDATA_VALUE_NULL
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.TESTDATA_VALUE_NULL);
		}
		WebElement element = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(element, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				if (testCaseDetail.getTestCaseCommonData().getBrowserName()
						.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
					if (testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS)) {

						WebElement element2 = driver.findElement(locator(xpathKey, locatorHM));
						element.click();
						element.clear();
						element2.sendKeys(testData + Keys.ENTER);
					} else {
						element.click();
						element.clear();
						element.sendKeys(testData);
					}
				} else {
					element.click();
					element.clear();
					driver.findElement(locator(xpathKey, locatorHM)).sendKeys(testData + Keys.TAB);
				}
			} catch (NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (IllegalArgumentException e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
	}

	public static void clearTextField(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				reportingLogger.info(logMessage);
				clearInputFieldData(driver, locator(xpathKey, locatorHM));
			} catch (NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
	}

	public static void clearTextPOSField(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				reportingLogger.info(logMessage);
				webElement.sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.BACK_SPACE));
			} catch (NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
	}

	/*
	 * GetActions
	 */
	public static String getAttributeByValue(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.VALUE);
				if (logMessage != null && logMessage.equals("")) {
					reportingLogger.info(ReportLoggerConstant.GET_VALUE_OF + logMessage
							+ ReportLoggerConstant.COLON_SYMBOL + inputFieldValue);
				}
			} catch (Exception e) {
				reportingLogger.info(e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getAttributeInnerText(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String value = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {

				value = webElement.getAttribute(ReportLoggerConstant.INNER_TEXT);
				if (logMessage != null && logMessage.equals("")) {
					reportingLogger.info(
							ReportLoggerConstant.GET_VALUE_OF + logMessage + ReportLoggerConstant.COLON_SYMBOL + value);
				}
			} catch (Exception e) {
				reportingLogger.info(e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return value;
	}

	public static String getAttributeValueByTitle(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.TITLE);
				if (logMessage != null && logMessage.equals("")) {
					reportingLogger.info(ReportLoggerConstant.GET_VALUE_OF + logMessage
							+ ReportLoggerConstant.COLON_SYMBOL + inputFieldValue);
				}
			} catch (Exception e) {
				reportingLogger.info(e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getAttributeName(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.NAME);
			} catch (Exception e) {
				reportingLogger.info(e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				logger.info(e.getMessage());
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getAttributeHref(final String logMessage, final String xpathKey,
										  final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.HREF);
				if (logMessage != null && logMessage.equals("")) {
					reportingLogger.info(ReportLoggerConstant.GET_VALUE_OF + logMessage
							+ ReportLoggerConstant.COLON_SYMBOL + inputFieldValue);
				}
			} catch (Exception e) {
				reportingLogger.info(e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getAttributeSrc(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.SRC);
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getTextValue(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getText();
				reportingLogger.info(ReportLoggerConstant.RECEIVED_VALUE + inputFieldValue);
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static String getDropDownValue(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String dropDownFieldValue = null;
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {
				dropDownFieldValue = webElement.getAttribute(ReportLoggerConstant.TITLE);
				if (logMessage != null && !logMessage.equals("")) {
					reportingLogger.info(ReportLoggerConstant.GET_VALUE_OF + logMessage + " : " + dropDownFieldValue);
				}
			} catch (Exception e) {
				reportingLogger
						.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_SELECT_VALUE_FROM_DROP_DOWN
								+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_SELECT_VALUE_FROM_DROP_DOWN);
			}
		}
		return dropDownFieldValue;
	}

	public static String getRowCount(final String xpathKey, final Map<String, List<String>> locatorHM,
			final WebDriver driver, final Logger reportingLogger) {
		String totalRows = "0";
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			String rowsCount = driver.findElement(locator(xpathKey, locatorHM))
					.getAttribute(ReportLoggerConstant.ROWCOUNT);
			totalRows = rowsCount;
			// reportingLogger.info(ReportLoggerConstant.TOTAL_NUMBER_OF_ROWS +
			// rowsCount);
		}
		return totalRows;
	}

	public static String getRowCountForPOS(final String xpathKey, final Map<String, List<String>> locatorHM,
			final WebDriver driver, final Logger reportingLogger) {
		String totalRows = "0";
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			String rowsCount = driver.findElement(locator(xpathKey, locatorHM))
					.getAttribute(ReportLoggerConstant.POS_ROWCOUNT);
			totalRows = rowsCount;
		}
		return totalRows;
	}

	public static String getTitle(final String xpathKey, final Map<String, List<String>> locatorHM,
			final WebDriver driver, final Logger reportingLogger) {
		String totalRows = "0";
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			String rowsCount = driver.getTitle();
			totalRows = rowsCount;
			reportingLogger.info(ReportLoggerConstant.TOTAL_NUMBER_OF_ROWS + rowsCount);
		}
		return totalRows;
	}

	public static int getElementsSize(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		int inputFieldValue = 0;
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		reportingLogger.info(logMessage);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {

				inputFieldValue = driver.findElements(locator(xpathKey, locatorHM)).size();
				if (logMessage != null) {
					reportingLogger.info(ReportLoggerConstant.COUNT_OF_VALUES + inputFieldValue);
				}
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_SIZE_OF_ELEMENT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_SIZE_OF_ELEMENT);
			}
		}
		return inputFieldValue;
	}

	public static void clickOnElementAt(final String logMessage, final String xpathKey, final int index,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		boolean elementIsClickable = checkElementOnUI(webElement, locatorHM, driver, reportingLogger);
		CommonUtility.logTransactions(driver, logMessage);
		if (elementIsClickable) {
			driver.findElements(locator(xpathKey, locatorHM)).get(index).click();
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_CLICKABLE);
		}
	}

	/*
	 * AssertActions
	 */
	public static void verifyDropdownTDValue(final String logMessage, final String testData, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String title = null;
		reportingLogger.info(logMessage + testData);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {
				title = webElement.getAttribute(ReportLoggerConstant.TITLE);
				Assert.assertEquals(title.trim(), testData, ReportLoggerConstant.MISSMATCH_ERROR_MESSAGE + title
						+ ReportLoggerConstant.EXPECTED_VALUE_MESSAGE + testData);
			} catch (AssertionError e) {
				reportingLogger.info(testData + CommonConstant.LEFT_CONSTANT
						+ ReportLoggerConstant.EXPECTED_VALUE_MESSAGE + testData + ReportLoggerConstant.EQUALS_SYMBOL
						+ ReportLoggerConstant.ACTUAL_VALUE_MESSAGE + title);
			}
		}
	}

	public static void verifyComboBoxValue(final String logMessage, final String testData, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String title = null;
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {
				reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
				title = webElement.getAttribute(ReportLoggerConstant.TITLE);
				Assert.assertEquals(title, testData);
				reportingLogger.info(ReportLoggerConstant.DROP_DOWN_VALUE_VERIFIED);
			} catch (AssertionError e) {
				reportingLogger.error(ReportLoggerConstant.ASSERTION_FAILED_VALUE + title
						+ ReportLoggerConstant.EXPECTED_MESSAGE + testData);
				Assert.assertEquals(title, testData);
			}
		}
	}

	public static void assertFail(final String message, final Logger logger) {
		logger.error(ReportLoggerConstant.ASSERTION_FAILED_MESSAGE + message);
		logger.error(CommonConstant.LEFT_CONSTANT + message + CommonConstant.RIGHT_CONSTANT);
		throw new CATTException(message);
	}

	public static void assertEquals(final String actual, String expected, final String errorMessage,
			final Logger reportingLogger) {
		boolean flag = false;
		if (expected.equalsIgnoreCase("null")) {
			expected = null;
		}
		if (!(actual == null && expected == null)) {
			try {
				Assert.assertEquals(actual, expected, errorMessage);
				reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
			} catch (AssertionError e) {
				flag = true;
				if (errorMessage == null) {
					reportingLogger.error(ReportLoggerConstant.ASSERTION_FAILED_VALUE + errorMessage);
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				} else {
					reportingLogger.error(errorMessage + ReportLoggerConstant.ACTUAL_VALUE_MESSAGE + actual
							+ ReportLoggerConstant.EXPECTED_VALUE_MESSAGE + expected);
				}
			} catch (Exception e) {
				flag = true;
				reportingLogger.error(ReportLoggerConstant.ASSERTION_FAILED_VALUE + e.getMessage());
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			}
			if (flag) {
				Assert.assertEquals(actual, expected, errorMessage);
			}
		} else {
			reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
		}
	}

	public static void assertEqualsIgnoreCase(final String actual, final String expected, final String errorMessage,
			final Logger reportingLogger) {
		if (actual.equalsIgnoreCase(expected)) {
			reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
		} else {
			reportingLogger.error(errorMessage + ReportLoggerConstant.ACTUAL_VALUE_MESSAGE + actual
					+ ReportLoggerConstant.EXPECTED_VALUE_MESSAGE + expected);
			throw new CATTException(errorMessage);
		}
	}

	public static void assertStartsWithIgnoreCase(final String referenceValue, final String prefix,
			final String errorMessage, final Logger reportingLogger) {
		reportingLogger.info("Checking : '" + referenceValue + "' value is starting with - " + prefix + " OR Not?");
		if (StringUtils.startsWithIgnoreCase(referenceValue, prefix)) {
			reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
		} else {
			reportingLogger.error(errorMessage);
			throw new CATTException(errorMessage);
		}
	}

	public static void assertEqualsContains(final String actual, final String expected, final String errorMessage,
			final Logger reportingLogger) {
		if (actual.contains(expected)) {
			reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
		} else {
			reportingLogger.error(errorMessage + ReportLoggerConstant.ACTUAL_VALUE_MESSAGE + actual
					+ ReportLoggerConstant.EXPECTED_VALUE_MESSAGE + expected);
			throw new CATTException(errorMessage);
		}
	}

	public static void assertNotEquals(final String value1, final String value2, final String errorMessage,
			final Logger reportingLogger) {
		Assert.assertNotEquals(value1, value2, errorMessage);
		reportingLogger.info(ReportLoggerConstant.VALIDATION_SUCESS_MESSAGE);
	}

	/*
	 * ActionFuctions
	 */
	public static void mouseHoverOn(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		/*
		 * try { SeleniumUtility.takeScreenshotAugmenter(driver,
		 * testCaseDetailTO.getDomainName(), testCaseDetailTO.getWorkBookName(),
		 * testCaseDetailTO.getWorkSheetName(), reportingLogger); } catch (Exception e)
		 * { logger.info(ReportLoggerConstant.EXCEPTION_WHILE_TAKING_SCREENSHOT, e); }
		 */
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				Actions builder = new Actions(driver);
				builder.moveToElement(webElement).perform();
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
			/*
			 * try { SeleniumUtility.takeScreenshotAugmenter(driver,
			 * testCaseDetailTO.getDomainName(), testCaseDetailTO.getWorkBookName(),
			 * testCaseDetailTO.getWorkSheetName(), reportingLogger); } catch (Exception e)
			 * { logger.info(ReportLoggerConstant. EXCEPTION_WHILE_TAKING_SCREENSHOT, e); }
			 */
		}
	}

	public static void doubleClick(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				Actions builder = new Actions(driver);
				reportingLogger.info(logMessage);
				builder.doubleClick(webElement).perform();
			} catch (org.openqa.selenium.NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		}
	}

	/*
	 * OtherActions
	 */
	public static int elementsList(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		List<WebElement> totalMenu = null;
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			try {
				totalMenu = driver.findElements(locator(xpathKey, locatorHM));
				reportingLogger.info(ReportLoggerConstant.TOTAL_NUMBER_OF_ELEMENTS + totalMenu.size());
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
			}
		}
		return totalMenu.size();
	}

	public static void excelCompare(final String excelSheet, final String variableStoreValue, final String domainName,
			final String workSheetName, final Logger reportingLogger, final Map<String, String> variableHolder) {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException ex1) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ex1.getMessage() + CommonConstant.RIGHT_CONSTANT);
		}
		String randomNo = RandomStringUtils.randomNumeric(5);
		Boolean fileDownloaded = Boolean.FALSE;
		Boolean fileUploaded = Boolean.FALSE;
		String downloadPath = DomainInitialization.initializeDomainwiseDownloadPath(domainName);
		String uploadPath = DomainInitialization.initializeDomainwiseTestDataDocumentPath(domainName);
		String xlsFileName = ApplicationConstant.PAYMENT_SCHEDULE + CommonConstant.UNDER_SCORE + workSheetName
				+ CommonConstant.UNDER_SCORE + randomNo + ".xlsx";

		try {
			if (null != downloadPath) {

				for (File file : new File(downloadPath).listFiles()) {
					if (file != null) {
						if (file.isFile() && file.getName().contains(".csv")) {
							fileDownloaded = Boolean.TRUE;
							break;
						}
					}
				}
			}
			if (!fileDownloaded) {
				reportingLogger.info("Payment Schedule file is not Downloaded");
				throw new CATTException("Payment Schedule file is not Downloaded");

			} else {
				reportingLogger.info("Payment Schedule file is  Downloaded Successfully");
				FileUtility.csvToExcel(reportingLogger, domainName, downloadPath + xlsFileName);
				try (Workbook downloadedWorkbook = WorkbookFactory.create(new File(downloadPath + xlsFileName))) {
					try (Workbook uploadedWorkbook = WorkbookFactory.create(new File(uploadPath + excelSheet))) {

						downloadedWorkbook.setSheetName(0, ApplicationConstant.PAYMENT_SCHEDULE);
						if (null != uploadPath) {

							for (File file : new File(uploadPath).listFiles()) {
								if (file != null) {
									if (file.isFile() && file.getName().equals(excelSheet)) {
										fileUploaded = Boolean.TRUE;
										break;
									}
								}
							}
						}
						if (!fileUploaded) {
							reportingLogger.info("Payment Schedule TEST file is not present at location : " + uploadPath
									+ excelSheet);
							throw new CATTException("Payment Schedule TEST file is not present at location : "
									+ uploadPath + excelSheet);
						} else {
							uploadedWorkbook.setSheetName(0, ApplicationConstant.PAYMENT_SCHEDULE);
							List<String> listOfDifferences = ExcelComparator.compare(downloadedWorkbook,
									uploadedWorkbook);
							if (!listOfDifferences.isEmpty()) {

								for (String differences : listOfDifferences) {
									if (differences.contains("Cell Data")) {
										reportingLogger.info(
												"Differences of Excel sheet of Payment Schedules : " + differences);
										variableHolder.put(variableStoreValue, "False");

									}
								}
								throw new CATTException("Payment Schedule is not Generated correctly");
							}
							if (listOfDifferences.isEmpty()) {
								reportingLogger.info("Payment Schedule Generated correctly .");
								variableHolder.put(variableStoreValue, CommonConstant.TRUE_VALUE);
							}
						}
					}
				}
			}
		} catch (EncryptedDocumentException | IOException ex1) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ex1.getMessage() + CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ex1.getMessage());
		}
	}

	public static void selectDropdownPOS(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		if (ApplicationContext.productVersion.equals("4.7.1")
				|| ApplicationContext.productVersion.equals("ACF_4.7.1")) {
			selectDropDownActionForPOS471(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			selectDropdownForPOS_ConfigConsole(excelTestCaseFieldsTO, testCaseDetailTO);
		}
	}

	private static void selectDropDownActionForPOS471(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + ReportLoggerConstant.AS + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorModule = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		locator(xpathKey, locatorModule);
		xpathKey = locatorModule.get(xpathKey).get(0);

		if (xpathKey.contains("caption") || xpathKey.contains("dropdownInside")) {
			WebElement webElement = GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(xpathKey),
					testCaseDetailTO.getReportingLogger());
			boolean elementIsClickable = checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement,
					testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
			if (elementIsClickable) {
				String xpathForSelection = xpathKey + "/option[text()=\"" + testData + "\"]";
				List<WebElement> optionsAvailable = testCaseDetailTO.getDriver()
						.findElements(By.xpath(xpathKey + "/option"));
				if (!optionsAvailable.isEmpty()) {
					WebElement element = testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection));
					if (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element, testCaseDetailTO.getDriver(),
							testCaseDetailTO.getReportingLogger())) {
						element.click();
					}
				}
			}
			SeleniumUtility.takeScreenshotAugmenter(testCaseDetailTO.getDriver(), CurrentTestCase.getDomainname().get(),
					CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
					CurrentTestCase.getReportinglogger().get());
		} else {
			xpathKey = xpathKey + FunctionLocatorConstant.SELECT_CONTROL_KEY;
			WebElement webElement = GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(xpathKey),
					testCaseDetailTO.getReportingLogger());
			boolean elementIsClickable = checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement,
					testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
			CommonUtility.logTransactions(testCaseDetailTO.getDriver(), excelTestCaseFieldsTO.getTestCaseSteps());
			if (elementIsClickable) {
				webElement.click();
				String xpathForSelection = "//div[contains(@class,'Select-option') and text()=\"" + testData + "\"]";
				List<WebElement> optionsAvailable = testCaseDetailTO.getDriver()
						.findElements(By.xpath("//div[contains(@class,'Select-option')]"));
				if (!optionsAvailable.isEmpty()) {
					WebElement element = testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection));
					if (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element, testCaseDetailTO.getDriver(),
							testCaseDetailTO.getReportingLogger())) {
						element.click();
					}
				} else {
					WebElement element = testCaseDetailTO.getDriver().findElement(By.xpath(xpathKey + "//input"));
					element.sendKeys(testData);
					if (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element, testCaseDetailTO.getDriver(),
							testCaseDetailTO.getReportingLogger())) {
						testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection)).click();
					}
				}
			}
			SeleniumUtility.takeScreenshotAugmenter(testCaseDetailTO.getDriver(), CurrentTestCase.getDomainname().get(),
					CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
					CurrentTestCase.getReportinglogger().get());
		}
	}

	public static void selectDropdownForPOS_ConfigConsole(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + ReportLoggerConstant.AS + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorModule = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		locator(xpathKey, locatorModule);
		xpathKey = locatorModule.get(xpathKey).get(0);

		/*
		 * if (xpathKey.contains("caption") || xpathKey.contains("dropdownInside")) {
		 * WebElement webElement =
		 * GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(xpathKey),
		 * testCaseDetailTO.getReportingLogger()); boolean elementIsClickable =
		 * checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement,
		 * testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger()); if
		 * (elementIsClickable) { String xpathForSelection = xpathKey +
		 * "/option[text()=\"" + testData + "\"]"; List<WebElement> optionsAvailable =
		 * testCaseDetailTO.getDriver() .findElements(By.xpath(xpathKey + "/option"));
		 * if (!optionsAvailable.isEmpty()) { WebElement element =
		 * testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection)); if
		 * (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element,
		 * testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger())) {
		 * element.click(); } } }
		 * SeleniumUtility.takeScreenshotAugmenter(testCaseDetailTO.getDriver(),
		 * CurrentTestCase.getDomainname().get(),
		 * CurrentTestCase.getCurrentworkbook().get(),
		 * CurrentTestCase.getCurrentworksheetname().get(),
		 * CurrentTestCase.getReportinglogger().get()); } else {
		 */
		xpathKey = xpathKey + FunctionLocatorConstant.SELECT_CONTROL_KEY_CONFIGCONSOLE;
		WebElement webElement = GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(xpathKey),
				testCaseDetailTO.getReportingLogger());
		boolean elementIsClickable = checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement,
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		CommonUtility.logTransactions(testCaseDetailTO.getDriver(), excelTestCaseFieldsTO.getTestCaseSteps());
		if (elementIsClickable) {
			webElement.click();
			String xpathForSelection = "//div[contains(@class,'k-react-select__option') and text()=\"" + testData
					+ "\"]";
			List<WebElement> optionsAvailable = testCaseDetailTO.getDriver()
					.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
			if (!optionsAvailable.isEmpty()) {
				WebElement element = testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection));
				if (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element, testCaseDetailTO.getDriver(),
						testCaseDetailTO.getReportingLogger())) {
					element.click();
				}
			} else {
				WebElement element = testCaseDetailTO.getDriver().findElement(By.xpath(xpathKey + "//input"));
				element.sendKeys(testData);
				if (checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element, testCaseDetailTO.getDriver(),
						testCaseDetailTO.getReportingLogger())) {
					testCaseDetailTO.getDriver().findElement(By.xpath(xpathForSelection)).click();
				}
			}
		}
		SeleniumUtility.takeScreenshotAugmenter(testCaseDetailTO.getDriver(), CurrentTestCase.getDomainname().get(),
				CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
				CurrentTestCase.getReportinglogger().get());
	}

	public static boolean checkDropDownValue(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		boolean valueIsPresent = false;
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			String locator = locatorHM.get(xpathKey).get(0);
			locator = locator + ReportLoggerConstant.OPTION;
			List<WebElement> comboBoxValues = driver.findElements(By.xpath(locator));
			reportingLogger.info(ReportLoggerConstant.QUERY_PARAM_VALUE_IS + comboBoxValues.size());
			for (WebElement DropDownValues : comboBoxValues) {
				String value = DropDownValues.getText();
				if (value.equals(testData)) {
					valueIsPresent = true;
					break;
				}
			}
			if (valueIsPresent) {
				reportingLogger.info(ReportLoggerConstant.GIVEN_DATA + testData + ReportLoggerConstant.COLON_SYMBOL
						+ ReportLoggerConstant.DROP_DOWN_VALUE_PRESENT);
			} else {
				reportingLogger.info(ReportLoggerConstant.GIVEN_DATA + testData + ReportLoggerConstant.COLON_SYMBOL
						+ ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
			}
		} else {
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
		return valueIsPresent;
	}

	public static boolean checkDropDownValueforPOS(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		boolean valueIsPresent = false;
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		reportingLogger.info(logMessage + " - " + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			webElement.click();
			List<WebElement> comboBoxValues = driver.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
			reportingLogger.info(ReportLoggerConstant.TOTAL_VALUE_IN_DROPDOWN + comboBoxValues.size());
			for (WebElement DropDownValues : comboBoxValues) {
				String value = DropDownValues.getText();
				logger.info("Available drop-down is: " + value);
				if (value.equals(testData)) {
					valueIsPresent = true;
					break;
				}
			}
			if (valueIsPresent) {
				reportingLogger.info(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.DROP_DOWN_VALUE_PRESENT);
			} else {
				reportingLogger.warn(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
			}
			webElement.click();
		} else {
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
		return valueIsPresent;
	}

	public static String getDropDownIndexForPOS(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		String indexNumber = "0";
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		reportingLogger.info(logMessage + " - " + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			int indexCounter = 0;
			webElement.click();
			List<WebElement> comboBoxValues = driver.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
			reportingLogger.info(ReportLoggerConstant.TOTAL_VALUE_IN_DROPDOWN + comboBoxValues.size());
			for (WebElement DropDownValues : comboBoxValues) {
				indexCounter++;
				String value = DropDownValues.getText();
				logger.info("Available drop-down is: " + CommonConstant.SINGLE_QUOTE + value
						+ CommonConstant.SINGLE_QUOTE + " at index number: " + indexCounter);
				if (value.equals(testData)) {
					indexNumber = String.valueOf(indexCounter);
					break;
				}
			}
			if (!indexNumber.equals("0")) {
				reportingLogger.info(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.PRESENT_AT + " at index/number: "
						+ indexNumber);
			} else {
				reportingLogger.warn(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
			}
			webElement.click();
		} else {
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
		return indexNumber;
	}

	public static String getDropDownIndex(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String indexNumber = "0";
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		reportingLogger.info(logMessage + " - " + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			int indexCounter = 0;
			String locator = locatorHM.get(xpathKey).get(0);
			locator = locator + ReportLoggerConstant.OPTION;
			List<WebElement> comboBoxValues = driver.findElements(By.xpath(locator));
			reportingLogger.info(ReportLoggerConstant.TOTAL_VALUE_IN_DROPDOWN + comboBoxValues.size());
			for (WebElement dropDownValues : comboBoxValues) {
				indexCounter++;
				String value = dropDownValues.getText();
				logger.info("Available drop-down is: " + CommonConstant.SINGLE_QUOTE + value
						+ CommonConstant.SINGLE_QUOTE + " at index number: " + indexCounter);
				if (value.equals(testData)) {
					indexNumber = String.valueOf(indexCounter);
					break;
				}
			}
			if (!indexNumber.equals("0")) {
				reportingLogger.info(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.PRESENT_AT + " at index/number: "
						+ indexNumber);
			} else {
				reportingLogger.warn(ReportLoggerConstant.DROP_DOWN_VALUE + CommonConstant.SINGLE_QUOTE + testData
						+ CommonConstant.SINGLE_QUOTE + ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
			}
			webElement.click();
		} else {
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_AVAILABLE_MESSAGE);
		}
		return indexNumber;
	}

	public static WebElement checkStaleOfElement(String xpathKey, final Map<String, List<String>> locatorHM,
			WebElement webElement, WebDriver driver) {
		try {
			webElement.isEnabled();
			return webElement;
		} catch (StaleElementReferenceException stale) {
			System.err.println("--------Element Stale Occured-----");
			try {
				return driver.findElement(locator(xpathKey, locatorHM));
			} catch (Exception e) {
				return webElement;
			}
		}
	}

	public static WebElement getWebElement(WebDriver webDriver, By by, Logger reportingLogger) {
		WebElement element = null;
		try {
			element = webDriver.findElement(by);
		} catch (UnhandledAlertException alertException) {
			SeleniumUtility.unexpectAlert(webDriver, reportingLogger);
			element = webDriver.findElement(by);
		}
		return element;
	}

	public static void enterTextBoxValueForIEBrowser(WebDriver driver, By locator, String testData) {
		WebElement webElement = driver.findElement(locator);
		String eleValue = webElement.getAttribute("value");
		if (eleValue.equals("")) {
			webElement.click();
			webElement.clear();
			driver.findElement(locator).sendKeys(testData + Keys.ENTER);
		} else {
			clearInputFieldData(driver, locator);
			driver.findElement(locator).sendKeys(testData + Keys.ENTER);
		}
	}

	public static synchronized void clearInputFieldData(WebDriver driver, By by) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript(FrameworkConstant.CLEAR_FIELD_JAVASCRIPT, driver.findElement(by));
	}

	public static void getDropDownValueCount(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String locator = testCaseDetailTO.getLocatorHashMap().get(excelTestCaseFieldsTO.getLocatorKey()).get(0);
		WebElement webElement = testCaseDetailTO.getDriver().findElement(By.xpath(locator));
		if (checkElementOnUI(webElement, testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
				testCaseDetailTO.getReportingLogger())) {
			locator = locator + ReportLoggerConstant.OPTION;
			List<WebElement> dropDownValues = testCaseDetailTO.getDriver().findElements(By.xpath(locator));
			int dropDownValuesCount = dropDownValues.size();
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.DROP_VALUE_COUNT + dropDownValuesCount);
			if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
				testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
						Integer.toString(dropDownValuesCount));
			}
		}
	}

	public static void getDropDownValueCountForPOS(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		reportingLogger.info(logMessage + " - " + testData);
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		WebDriver driver = testCaseDetailTO.getDriver();
		WebElement webElement = driver.findElement(locator(xpathKey, locatorHM));
		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			webElement.click();
			List<WebElement> comboBoxValues = driver.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.DROP_VALUE_COUNT + comboBoxValues.size());
			if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
				testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
						Integer.toString(comboBoxValues.size()));
			}
		}
	}

	public static boolean checkSortingOrder(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		boolean valueIsPresent = false;
		String testData = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		String xpathKey = excelTestCaseFieldsTO.getLocatorKey();
		Map<String, List<String>> locatorHM = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		WebDriver driver = testCaseDetailTO.getDriver();
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);

		if (checkElementOnUI(webElement, locatorHM, driver, reportingLogger)) {
			String locator = locatorHM.get(xpathKey).get(0);
			locator = locator + ReportLoggerConstant.OPTION;
			List<WebElement> availablevalues = driver.findElements(By.xpath(locator));
			List<String> sortedvalues = new ArrayList<>();
			for (WebElement DropDownValues : availablevalues) {
				String value = DropDownValues.getText();
				sortedvalues.add(DropDownValues.getText());
				if (testData.contentEquals("Ascending")) {
					Collections.sort(sortedvalues);
					if (sortedvalues.contains(value)) {
						valueIsPresent = true;
						if (valueIsPresent) {
							reportingLogger.info(
									ReportLoggerConstant.ASCENDING_SORTED_VALUES + ReportLoggerConstant.COLON_SYMBOL
											+ ReportLoggerConstant.DROPDOWN_VALUE_ASCENDING_ORDER);
						} else {
							reportingLogger.info(
									ReportLoggerConstant.ASCENDING_SORTED_VALUES + ReportLoggerConstant.COLON_SYMBOL
											+ ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
						}
						break;
					}
				} else if (testData.contentEquals("Descending")) {
					Collections.sort(sortedvalues, Collections.reverseOrder());
					if (sortedvalues.contains(value)) {
						valueIsPresent = true;
						if (valueIsPresent) {
							reportingLogger.info(
									ReportLoggerConstant.DESCENDNG_SORTED_VALUES + ReportLoggerConstant.COLON_SYMBOL
											+ ReportLoggerConstant.DROPDOWN_VALUE_DESCENDING_ORDER);
						} else {
							reportingLogger.info(
									ReportLoggerConstant.DESCENDNG_SORTED_VALUES + ReportLoggerConstant.COLON_SYMBOL
											+ ReportLoggerConstant.DROP_DOWN_VALUE_NOT_PRESENT);
						}
						break;
					}
				} else {
					reportingLogger.info(ReportLoggerConstant.SORTED_ERROR_MESSAGE);
					break;
				}
			}
		} else {
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_ASORTED_MESSAGE);
		}
		return valueIsPresent;
	}

	public static String getAttributeClass(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		String inputFieldValue = null;
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		if (checkElementDisplayNotEnabled(webElement, locatorHM, driver, reportingLogger)) {
			try {
				inputFieldValue = webElement.getAttribute(ReportLoggerConstant.CLASS);
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT
						+ e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(ReportLoggerConstant.UNABLE_TO_GET_VALUE_FROM_INPUT);
			}
		}
		return inputFieldValue;
	}

	public static void clickForPOS(final String logMessage, final String xpathKey,
			final Map<String, List<String>> locatorHM, final WebDriver driver, final Logger reportingLogger) {
		reportingLogger.info(logMessage);
		WebElement webElement = getWebElement(driver, locator(xpathKey, locatorHM), reportingLogger);
		boolean elementIsClickable = checkElementOnUI(webElement, locatorHM, driver, reportingLogger);
		CommonUtility.logTransactions(driver, logMessage);
		webElement = checkStaleOfElement(xpathKey, locatorHM, webElement, driver);
		if (elementIsClickable) {
			if (DownloadFile.DownloadFileActionIE == true && DownloadFile.DownloadFileActionPOS == true) {
				Actions act = new Actions(driver);
				act.moveToElement(webElement).click().build().perform();
			} else {
				webElement.click();
			}
		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_CLICKABLE);
		}
	}

	public static synchronized void dragAndDrop(ExcelTestCaseFields excelTestCaseFieldsTO,
			TestCaseDetail testCaseDetailTO) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFieldsTO.getModule());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFieldsTO.getLocatorKey()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String sourceXpath = locatorMap.get(locatorKeys[0].trim()).get(0);
		String destXpath = locatorMap.get(locatorKeys[1].trim()).get(0);

		WebDriver driver = testCaseDetailTO.getDriver();
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String logMessage = excelTestCaseFieldsTO.getTestCaseSteps();
		WebElement source = GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(sourceXpath),
				testCaseDetailTO.getReportingLogger());
		WebElement dest = GenericAction.getWebElement(testCaseDetailTO.getDriver(), By.xpath(destXpath),
				testCaseDetailTO.getReportingLogger());

		boolean elementIsClickable = checkElementOnUI(source, locatorMap, driver, reportingLogger);
		CommonUtility.logTransactions(driver, logMessage);
		CommonFunctions.explicitWait(5000);
		if (elementIsClickable) {
			try {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript(FunctionLocatorConstant.DRAG_AND_DROP_JS, source, dest);
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + ErrorMessageConstant.DRAG_AND_DROP_ERROR_MESSAGE
						+ e.getMessage());
				throw new CATTException(CommonConstant.LEFT_CONSTANT + ErrorMessageConstant.DRAG_AND_DROP_ERROR_MESSAGE
						+ e.getMessage());
			}

		} else {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.ELEMENT_NOT_ENABLED_MESSAGE
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.ELEMENT_NOT_CLICKABLE);
		}

	}

}
