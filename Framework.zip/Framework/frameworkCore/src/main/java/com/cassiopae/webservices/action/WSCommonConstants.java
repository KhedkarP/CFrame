package com.cassiopae.webservices.action;

public interface WSCommonConstants {
	String CONTENTTYPE_URLENC = "x-www-form-urlencoded";
	String UFT_8 = "UTF-8";
	String USER_NAME_KEY = "ksiopuser";
	String PASSWORD_KEY = "ksiopvalue";
	String LoginURL = "RestServices/login";
	String RestAPIBody = "RestServices";
	String SESSION_TOKEN = "ksiop-session-token";
	String SET_COOKIE = "Set-Cookie";
	String FORWARD_ICON = " >> ";
	String KSIOPE_SESION_TOKEN = "ksiop-session-token";
	String COKIE_TOKEN = "Cookie";
	String POST_MSG = "POST";
	String PUT_MSG = "PUT";
	String GET_MSG = "GET";
	String PATCH_MSG = "PATCH";
}
