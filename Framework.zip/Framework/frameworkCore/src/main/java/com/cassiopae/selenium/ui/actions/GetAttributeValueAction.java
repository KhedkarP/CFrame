/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author nbhil
 *
 */
public class GetAttributeValueAction implements PerformAction {
	/**
	 * This method execute action for get attribute value action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String attributeValue = GenericAction.getAttributeByValue(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + attributeValue);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), attributeValue);
		}
		if (excelTestCaseFieldsTO.getExpectedResult() != null || excelTestCaseFieldsTO.getActualValue() != null) {
			String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
			String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
			GenericAction.assertEquals(variableHolderActualValue, variableHolderExpectedValue,
					excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
		}

	}
}
