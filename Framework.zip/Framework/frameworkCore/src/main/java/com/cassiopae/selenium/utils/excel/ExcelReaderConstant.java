/**
 * 
 */
package com.cassiopae.selenium.utils.excel;

import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public interface ExcelReaderConstant {

	public static final int SR_NO = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("SrNoColumn"), InitializeConstants.excelPropertyFileName);
	public static final int LOCATOR_MODULE = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("LocatorModuleColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int LOCATOR_KEY = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("LocatorKeyColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int TEST_CASE_STEP = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("TestCaseStepColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int ACTION_TYPE = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("ActionTypeColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int INPUT_TEST_DATA = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("InputTestDataColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int STORE_VALUE = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("StoreValueInVariableColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int ACTUAL_VALUE = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("ActualValueColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int EXPECTED_RESULT = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("ExpectedResultColumn"),
			InitializeConstants.excelPropertyFileName);
	public static final int ERROR_MESSAGE = CommonUtility.convertStringToInteger(
			InitializeConstants.dashboardExcelDetails.get("ErrorMessageColumn"),
			InitializeConstants.excelPropertyFileName);
}
