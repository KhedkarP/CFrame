/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class GenerateDynamicDataAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),CommonConstant.PIPE_SEPARATOR);
		String datatype = inputData[0].trim();
		String noOfChars = inputData[1].trim();
		String data = CommonFunctions.generateDynamicData(datatype, noOfChars);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), data);
		}
	}

}
