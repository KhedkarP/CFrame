package com.cassiopae.framework.to;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

// To be incorporated for future sprints
public class CurrentTestCase {
	private CurrentTestCase() {

	}

	private static final ThreadLocal<String> currentWorkSheetName = new ThreadLocal<>();
	private static final ThreadLocal<String> currentWorkBook = new ThreadLocal<>();
	private static final ThreadLocal<String> domainName = new ThreadLocal<>();
	private static final ThreadLocal<String> browserName = new ThreadLocal<>();
	private static final ThreadLocal<Logger> reportingLogger = new ThreadLocal<>();
	private static final ThreadLocal<String> currentRowNumber = new ThreadLocal<>();
	private static final ThreadLocal<Boolean> comparePaymentSchedule = new ThreadLocal<>();
	private static final ThreadLocal<Boolean> toastMessagePopUp = new ThreadLocal<>();
	private static final ThreadLocal<WebDriver> currentDriver = new ThreadLocal<>();
	private static final ThreadLocal<String> consoleLogs = new ThreadLocal<>();
	private static final ThreadLocal<String> appSynchronizationSwitch = new ThreadLocal<>();

	public static ThreadLocal<String> getAppsynchronizationswitch() {
		return appSynchronizationSwitch;
	}
	
	public static ThreadLocal<String> getCurrentworksheetname() {
		return currentWorkSheetName;
	}

	public static ThreadLocal<String> getCurrentworkbook() {
		return currentWorkBook;
	}

	public static ThreadLocal<String> getDomainname() {
		return domainName;
	}

	public static ThreadLocal<String> getBrowsername() {
		return browserName;
	}

	public static ThreadLocal<Logger> getReportinglogger() {
		return reportingLogger;
	}

	public static ThreadLocal<String> getCurrentrownumber() {
		return currentRowNumber;
	}

	public static ThreadLocal<Boolean> getComparePaymentSchedule() {
		return comparePaymentSchedule;
	}
	
	public static ThreadLocal<Boolean> getToastMessageOnPOS() {
		return toastMessagePopUp;
	}

	public static ThreadLocal<WebDriver> getCurrentdriver() {
		return currentDriver;
	}

	public static ThreadLocal<String> getConsolelogs() {
		return consoleLogs;
	}

}
