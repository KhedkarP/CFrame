/**
 * 
 */
package com.cassiopae.selenium.services.listener;

import java.time.Duration;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.CFrameManager;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.functions.DealFunctions;

/**
 * @author nbhil
 *
 */
public class WebDriverListener extends AbstractWebDriverEventListener {
	private static Logger logger = LogManager.getLogger(WebDriverListener.class);

	@Override
	public void beforeFindBy(final By by, final WebElement webElement, final WebDriver webDriver) {
		Logger reportinglogger = CurrentTestCase.getReportinglogger().get();
		String workBookName = CurrentTestCase.getCurrentworkbook().get();
		String domainName = CurrentTestCase.getDomainname().get();
		// String currentWorkSheetName =
		// CurrentTestCase.getCurrentworksheetname().get();
		String currentWorkSheetName = CurrentTestCase.getAppsynchronizationswitch().get();
		if (currentWorkSheetName.contains(FrameworkConstant.POS)
				|| StringUtils.startsWith(currentWorkSheetName, DBConstant.CC_APP_SHEET_NAME)) {
			waitForPageLoadingPOS(by, webDriver, workBookName, domainName, currentWorkSheetName);
		} else {
			waitForPageStabiltyCassiopaeFOBO(by, webDriver, reportinglogger, workBookName, domainName,
					currentWorkSheetName);
		}
	}

	/**
	 * @param by
	 * @param webElement
	 * @param webDriver
	 * @param reportinglogger
	 * @param workBookName
	 * @param domainName
	 * @param currentWorkSheetName
	 */
	public static void waitForPageLoadingPOS(final By by, final WebDriver webDriver, String workBookName,
			String domainName, String currentWorkSheetName) {
		int thinktime = InitializeConstants.pageLoadTimeForPOSApplication;
		try {
			CFrameManager.scrollToElement(by, webDriver);
			if (!CurrentTestCase.getToastMessageOnPOS().get()) {
				waitForElementStabilityForPOS(by, thinktime, webDriver, CurrentTestCase.getReportinglogger().get());
			}
			CFrameManager.scrollToElement(by, webDriver);
			SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
					CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
					CurrentTestCase.getReportinglogger().get());
		} catch (Exception e) {
			logger.error(e.getMessage());
			CFrameManager.scrollToElement(by, webDriver);
			SeleniumUtility.waitTillPageLoadingForPOS(by, webDriver, CurrentTestCase.getReportinglogger().get());
			SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
					CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
					CurrentTestCase.getReportinglogger().get());
		}
	}

	/**
	 * @param by
	 * @param webElement
	 * @param webDriver
	 */
	public static void waitForElementStabilityForPOS(final By by, final int thinktime, final WebDriver webDriver,
			Logger reportinglogger) {

		Wait<WebDriver> wait = new FluentWait<WebDriver>(webDriver).withTimeout(Duration.ofSeconds(thinktime))
				.pollingEvery(Duration.ofMillis(300)).ignoring(NoSuchElementException.class);
		Wait<WebDriver> toastPopUpWait = new FluentWait<WebDriver>(webDriver).withTimeout(Duration.ofMillis(200))
				.pollingEvery(Duration.ofMillis(1)).ignoring(NoSuchElementException.class);

		if (ApplicationContext.productVersion.equals("4.7.1") || ApplicationContext.productVersion.equals("4.7.2")) {
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'pace-activity')]")));
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//i[@class='fa fa-circle-o-notch fa-spin fa-2x fa-fw']")));
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'redux-toastr top-center')]")));
		} else {
			CurrentTestCase.getToastMessageOnPOS().set(true);
			try {
				toastPopUpWait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath(CommonConstant.TOAST_POPUP_XPATH_POS)));
				DealFunctions.checkToastMessagePopup(webDriver, reportinglogger);
			} catch (Exception exp) {
				// exp.printStackTrace();
			}
			CurrentTestCase.getToastMessageOnPOS().set(false);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(
					By.xpath("//div[contains(@class,'k-loading sopra-loading type-pace loading-visible')]")));
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'toastr animated rrt')]")));
			wait.until(ExpectedConditions
					.invisibilityOfElementLocated(By.xpath("//tbody[@class='k-griddle-loading-body']")));
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		if (CommonConstant.CHROME_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())
				|| CommonConstant.MS_EDGE_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())
				|| webDriver.findElement(by).isEnabled()) {
			wait.until(ExpectedConditions.elementToBeClickable(by));
		}
	}

	/**
	 * @param by
	 * @param webElement
	 * @param webDriver
	 */
	public static void waitForElementStability(final By by, final int thinktime, final int pollingTime,
			final WebDriver webDriver) {
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(webDriver).withTimeout(Duration.ofSeconds(thinktime))
				.pollingEvery(Duration.ofMillis(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
		if (CommonConstant.CHROME_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())
				|| CommonConstant.MS_EDGE_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())) {
			wait.until(ExpectedConditions.elementToBeClickable(by));
		}
	}

	/**
	 * This method is used for synchronization [to achieve page stability] for
	 * cassiopae application
	 * 
	 * @param by
	 * @param webDriver
	 * @param reportinglogger
	 * @param workBookName
	 * @param domainName
	 * @param currentWorkSheetName
	 */
	private void waitForPageStabiltyCassiopaeFOBO(final By by, final WebDriver webDriver, Logger reportinglogger,
			String workBookName, String domainName, String currentWorkSheetName) {
		int thinktime = InitializeConstants.pageLoadTimeForChromeBrowserInSeconds;
		int pollingTime = 410;
		if (!by.toString().contains(CommonConstant.DROP_DOWN_CONVERTED_XPATH)) {
			try {
				SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
						CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
						CurrentTestCase.getReportinglogger().get());
				CFrameManager.scrollToElement(by, webDriver);
				if (CommonConstant.CHROME_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())) {
					checkElementStabilityInIFrame(webDriver);
				}
				if (CommonConstant.MS_EDGE_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())) {
					checkElementStabilityInIFrame(webDriver);
				}
				CFrameManager.autoSwitchFrame(by, webDriver, domainName, workBookName, currentWorkSheetName,
						reportinglogger);
				if (CommonConstant.IE_BROWSER.equalsIgnoreCase(CurrentTestCase.getBrowsername().get())) {
					thinktime = InitializeConstants.pageLoadTimeForIEBrowserInSeconds;
					pollingTime = 450;
				}
				waitForElementStability(by, thinktime, pollingTime, webDriver);
				webDriver.findElement(by).isDisplayed();// for chrome
				CFrameManager.scrollToElement(by, webDriver);
				SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
						CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
						CurrentTestCase.getReportinglogger().get());

			} catch (Exception exception) {
				SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
						CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
						CurrentTestCase.getReportinglogger().get());
				CFrameManager.autoSwitchFrame(by, webDriver, domainName, workBookName, currentWorkSheetName,
						reportinglogger);
				CFrameManager.scrollToElement(by, webDriver);
				SeleniumUtility.takeScreenshotAugmenter(webDriver, CurrentTestCase.getDomainname().get(),
						CurrentTestCase.getCurrentworkbook().get(), CurrentTestCase.getCurrentworksheetname().get(),
						CurrentTestCase.getReportinglogger().get());
			}
		}
	}

	/**
	 * This method is used to stabilize the page within i-frame
	 * 
	 * @param webDriver
	 */
	public static void checkElementStabilityInIFrame(final WebDriver webDriver) {
		String defaultValue;
		defaultValue = SeleniumUtility.getAttributeValue(webDriver, CommonConstant.IFRAME_STABILIZATION_XPATH,
				CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_NAME);
		if (!StringUtils.isEmpty(defaultValue)
				&& defaultValue.contains(CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_VALUE_WAIT)) {
			customizedDOMattributeCheck(webDriver, CommonConstant.IFRAME_STABILIZATION_XPATH,
					CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_NAME,
					CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_VALUE_WAIT,
					InitializeConstants.please_wait_icon_loading_time);
		}
	}

	/**
	 * This method is used to stabilize the page within i-frame
	 * 
	 * @param webDriver
	 */
	public static void checkPleaseWaitLoadingStability(final WebDriver webDriver) {
		String defaultValue;
		defaultValue = SeleniumUtility.getAttributeValue(webDriver, CommonConstant.PLEASE_WAIT_LOADING_GLASS_PANE_XPATH,
				CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_NAME);
		if (!StringUtils.isEmpty(defaultValue) && defaultValue
				.contains(CommonConstant.PLEASE_WAIT_LOADING_GLASS_PANE_XPATH_STYLE_ATTRIBUTE_VALUE_BLOCK)) {
			customizedDOMattributeCheck(webDriver, CommonConstant.PLEASE_WAIT_LOADING_GLASS_PANE_XPATH,
					CommonConstant.IFRAME_STABILIZATION_STYLE_ATTRIBUTE_NAME,
					CommonConstant.PLEASE_WAIT_LOADING_GLASS_PANE_XPATH_STYLE_ATTRIBUTE_VALUE_BLOCK,
					InitializeConstants.please_wait_icon_loading_time / 2);
		}
	}

	/**
	 * This method is used to wait until we get the expected value of the html tag
	 * for given attribute
	 * 
	 * @param webDriver
	 */
	public static void customizedDOMattributeCheck(final WebDriver webDriver, String xpath, String attribute,
			String expectedValue, int globalWait) {
		String defaultValue = null;
		int maxWait = globalWait * 1000;
		Duration duration = Duration.ofMillis(Calendar.getInstance().getTimeInMillis() + maxWait);
		Duration currentDuration = Duration.ofMillis(Calendar.getInstance().getTimeInMillis());
		while (currentDuration.getSeconds() < duration.getSeconds()) {
			defaultValue = webDriver.findElement(By.xpath(xpath)).getAttribute(attribute);
			if (!defaultValue.contains(expectedValue)) {
				break;
			}
			currentDuration = Duration.ofMillis(Calendar.getInstance().getTimeInMillis());
		}
	}

}
