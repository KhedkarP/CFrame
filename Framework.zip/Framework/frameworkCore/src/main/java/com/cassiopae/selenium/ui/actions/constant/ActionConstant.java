/**
 * 
 */
package com.cassiopae.selenium.ui.actions.constant;

/**
 * @author jraut
 */
public interface ActionConstant {

	public String NAVIGATE_ACTION = "SLAC_NavigateToURL";
	public String CLICK_ACTION = "SLAC_Click";
	public String ENTER_INPUT_VALUE_ACTION = "SLAC_EnterTextboxValue";
	public String MOUSE_HOVER_ACTION = "SLAC_MouseHover";
	public String GETTEXT_ACTION = "SLAC_GetText";
	public String SELECT_ACTION = "SLAC_SelectDropdown";
	public String SELECT_CHECKBOX_ACTION = "SLAC_SelectCheckbox";
	public String UNSELECT_CHECKBOX_ACTION = "SLAC_UnSelectCheckbox";
	public String GET_ATTRIBUTE_VALUE_ACTION = "SLAC_GetAttributeValue";
	public String GET_ATTRIBUTE_SRC_ACTION = "SLAC_GetAttributeSrc";
	public String GET_ATTRIBUTE_NAME_ACTION = "SLAC_GetAttributeName";
	public String EXECUTE_QUERY_ACTION = "DB_ExecuteQuery";
	public String GET_ATTRIBUTE_TITLE_ACTION = "SLAC_GetAttributeTitle";
	public String CONCATENATE_STRING_ACTION = "CSMZ_ConcatenateInputs";
	public String GET_ROWCOUNT_ACTION = "SLAC_GetRowCountOfTable";
	public String CHECK_ALERT_ACTION = "SLAC_CheckAlert";
	public String SWITCH_TO_WINDOW_ACTION = "SLAC_WindowSwitch";
	public String EXECUTE_SQL_PROC_ACTION = "DB_ExecuteProcedure";
	public String CLEAR_TEXT_FIELD_ACTION = "SLAC_ClearTextField";
	public String SELECT_PANEL_ENTRY = "CSMZ_SelectTableEntry";
	public String CHECK_PANEL_ENTRY = "CSMZ_CheckTableEntry";
	public String CHECK_BLANK_VALUE_ACTION = "SLAC_CheckValueIsBlank";
	public String GET_TOTAL_POPULATED_WINDOW_COUNT = "SLAC_GetWindowCount";
	public String CONVERT_DB_AMOUNT_TO_UI_FORMAT = "SLAC_ConvertDBAmountToUIFormat";
	String FILE_UPLOAD_ACTION = "SLAC_UploadFile";
	String GET_COUNT_OF_ELEMENTS = "SLAC_GetCountOfElement";
	public String PAGINATION_NEXT_ICON = "Click on Pagination Icon";
	public String SWITCH_TO_WINDOW_BY_FLOWID_ACTION = "SLAC_WindowSwitchByFlowid";
	public String OPEN_NEW_TAB_NAVIGATE_TO_URL = "SLAC_OpenNewTab_NavigateToURL";
	public String GET_TOAST_MESSAGE = "SLAC_GetToastMessage";
	public String GET_DROPDOWN_VALUE_COUNT = "SLAC_GetDropDownValueCount";

	public String ENTER_TEXT_AREA_INPUT_VALUE = "SLAC_EnterTextAreaInputValue";

	public String GET_ATTRIBUTE_INNER_TEXT = "SLAC_GetAttributeInnerText";
	public String GET_TOTAL_COUNT_OF_ENTITY_IN_TABLE = "SLAC_GetTotalCountOfEntries";
	public String GET_VALUE_FROM_EVENT_SUMMARY_PANEL = "SLAC_GetValueFromEventSummary";
	public static final String GENERATE_DYNAMIC_DATA = "CSMZ_GenerateRandomData";
	public static final String CREATE_EXECUTE_DYNAMIC_XPATH = "CSMZ_GenerateXpath_PerformAction";
	public static final String EXTERNAL_WAIT = "SLAC_Wait";
	public static final String DB_UPDATE_QUERY = "DB_UpdateQuery";
	public static final String XLS_PUT_DATA_IN_EXCEL = "XLS_PutDataInTestCaseSummaryXL";
	public static final String XLS_GET_DATA_FROM_EXCEL = "XLS_GetDataFromTestCaseSummaryXL";
	public String GET_ATTRIBUTE_CLASS_ACTION = "SLAC_GetAttributeClass";
	public String SELECT_CHECK_UNORDER_ACTION =  "SLAC_CheckUnorderTableEntry";
	public String READ_RECEIVABLES_FROM_EXCEL="SLAC_ReadValuesFromExcel";
	public String GET_VALUES_FROM_JASPER="SLAC_GetValuesFromJasperReport";
	public String SLAC_DRAG_AND_DROP="SLAC_DragAndDrop";
	public String SLAC_SELECT_VALUE_CONTAINS="SLAC_SelectDropdownValueContains";
	public String SLAC_SwitchTo_Window_Close="SLAC_SwitchToWindowAndClose";
	public String SLAC_RIGHT_CLICK="SLAC_Right_Click";
	public String SLAC_LAUNCH_EVENT_FOR_POS = "SLAC_LaunchEvent";
	public String SLAC_SELECT_INPUT_LOOKUPVALUE = "SLAC_SelectInputLookupValue";
	public String SLAC_ENTER_DATE = "SLAC_EnterDate";
	public String SLAC_NAVIGATE_TO_SERVICE_ACCOUNT = "SLAC_NavigateToServiceAccount";
	public String GET_ATTRIBUTE_HREF_ACTION  = "SLAC_GetAttributeHref";
	
	
}
