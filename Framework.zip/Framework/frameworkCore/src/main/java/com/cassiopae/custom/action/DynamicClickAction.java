/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class DynamicClickAction implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		GenericAction.locator(locatorKeys[0], locatorMap);
		String[] inputDataColumnValues = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDataRowNumbers= inputDataColumnValues[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		
		if(CommonFunctions.checkArrayElementAreNumeric(inputTestDataRowNumbers,testCaseDetail)) {
			testCaseDetail.getReportingLogger().error(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
			throw new CATTException(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
		}
		
		performClickOperation(testCaseDetail, locatorMap, locatorKeys, inputTestDataRowNumbers,excelTestCaseFields.getTestCaseSteps());
	}
	
	

	/**
	 * This method will create dynamic Xpath and perform click operation on generated xpath
	 * @param testCaseDetail
	 * @param locatorMap
	 * @param locatorKeys
	 * @param inputTestDataRowNumbers
	 * @param dataRowNumber
	 */
	private void performClickOperation(TestCaseDetail testCaseDetail, Map<String, List<String>> locatorMap,
			String[] locatorKeys, String[] inputTestDataRowNumbers,String logMessage) {
		String clickXpath;
		String xpath=CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap);
		if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			String value = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), inputTestDataRowNumbers[0].trim());
			String[] prefixSufixID = SelectPanelTableEntryUtility
					.getPrefixAndSuffixID(CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap));
			clickXpath = SelectPanelTableEntryUtility.constructXPath(Integer.parseInt(value), prefixSufixID[0],
					prefixSufixID[1]);
		} else {
			clickXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetail.getVariableHolder(), inputTestDataRowNumbers);
		}
		WebElement element = GenericAction.getWebElement(testCaseDetail.getDriver(), By.xpath(clickXpath), testCaseDetail.getReportingLogger());
		GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element,
				testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		CommonUtility.logTransactions(testCaseDetail.getDriver(), logMessage);
		element.click();
	}
}
