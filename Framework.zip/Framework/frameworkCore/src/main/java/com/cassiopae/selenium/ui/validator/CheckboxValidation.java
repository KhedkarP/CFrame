/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;

/**
 * @author jraut
 *
 */
public class CheckboxValidation implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		boolean flag = GenericAction.isSelected(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getErrorMessage(), excelTestCaseFieldsTO.getLocatorKey(),
				testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
				testCaseDetailTO.getReportingLogger());
		String checkboxSelectStatus = null;
		if (flag)
			checkboxSelectStatus = CommonConstant.TRUE_VALUE;
		else
			checkboxSelectStatus = CommonConstant.FALSE_VALUE;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					checkboxSelectStatus);
	}
	
}
