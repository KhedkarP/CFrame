
package com.cassiopae.framework.to;

/**
 * @author jraut
 *
 */
public class ExcelTestCaseFields
{

		private String srNo;
		private String module;
		private String locatorKey;
		private String testCaseSteps;
		private String action;
		private String inputTestData;
		private String errorMessage;
		private String expectedResult;
		private String storeValuesInVariable;
		private String actualValue;

		public String getActualValue()
		{
				return actualValue;
		}

		public void setActualValue(String actualValue)
		{
				this.actualValue=actualValue;
		}

		public String getSrNo()
		{
				return srNo;
		}

		public void setSrNo(String srNo)
		{
				this.srNo=srNo;
		}

		public String getModule()
		{
				return module;
		}

		public void setModule(String module)
		{
				this.module=module;
		}

		public String getLocatorKey()
		{
				return locatorKey;
		}

		public void setLocatorKey(String locatorKey)
		{
				this.locatorKey=locatorKey;
		}

		public String getTestCaseSteps()
		{
				return testCaseSteps;
		}

		public void setTestCaseSteps(String testCaseSteps)
		{
				this.testCaseSteps=testCaseSteps;
		}

		public String getAction()
		{
				return action;
		}

		public void setAction(String action)
		{
				this.action=action;
		}

		public String getInputTestData()
		{
				return inputTestData;
		}

		public void setInputTestData(String inputTestData)
		{
				this.inputTestData=inputTestData;
		}

		public String getErrorMessage()
		{
				return errorMessage;
		}

		public void setErrorMessage(String errorMessage)
		{
				this.errorMessage=errorMessage;
		}

		public String getExpectedResult()
		{
				return expectedResult;
		}

		public void setExpectedResult(String expectedResult)
		{
				this.expectedResult=expectedResult;
		}

		public String getStoreValuesInVariable()
		{
				return storeValuesInVariable;
		}

		public void setStoreValuesInVariable(String storeValuesInVariable)
		{
				this.storeValuesInVariable=storeValuesInVariable;
		}

}
