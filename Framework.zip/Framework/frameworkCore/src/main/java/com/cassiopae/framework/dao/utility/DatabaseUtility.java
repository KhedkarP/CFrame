
package com.cassiopae.framework.dao.utility;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTSQLException;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class DatabaseUtility {

	private static Logger logger = LogManager.getLogger(DatabaseUtility.class);

	// ******** DB UpdateCommit/ Validation/ Retrieve Records Methods ************//
	private DatabaseUtility() {

	}

	/**
	 * This method execute update query.
	 * @param application   String
	 * @param sqlexpression String
	 */
	public static void executeUpdateQuery(final String sheetname, final String sqlexpression) {
		String connectionURLBO = getConnectionULRForBO();
		String connectionURLFO = getConnectionULRForMO();
		if (sheetname.contains(DBConstant.BO_APP_SHEET_NAME) || sheetname.contains(DBConstant.POS_MODULE)) {
			executeUpdateQuery(sqlexpression, connectionURLBO, ApplicationContext.username_DB_BO,
					ApplicationContext.password_DB_BO);
		} else if (sheetname.contains(DBConstant.MO_APP_SHEET_NAME)) {
			executeUpdateQuery(sqlexpression, connectionURLFO, ApplicationContext.username_DB_MO,
					ApplicationContext.password_DB_MO);
		}
	}

	public static void insertDepence(final Logger logger, final String depenseRef, final int defenceNuber,
			final String jalCode) {
		String sqlQuery = "{ call QA1_PROC_EXPENSE_CREATION.QA_INSERT_TC_DEPENSE (?,?,?) }";

		String connectionURLBO = getConnectionULRForBO();
		String[] requiredValues = { depenseRef, String.valueOf(defenceNuber), jalCode };
		logger.info(ReportLoggerConstant.PROCEDURE_START_EXECUTION);
		executeCallableStatement(sqlQuery, connectionURLBO, ApplicationContext.username_DB_BO,
				ApplicationContext.password_DB_BO, requiredValues);
		logger.info(ReportLoggerConstant.PROCEDURE_POST_EXECUTION);

	}

	public static void executeProc(final Logger logger, final String sqlQuery, final String[] requiredValues) {
		String connectionURLBO = getConnectionULRForBO();
		logger.info(ReportLoggerConstant.PROCEDURE_START_EXECUTION);
		executeCallableStatement(sqlQuery, connectionURLBO, ApplicationContext.username_DB_BO,
				ApplicationContext.password_DB_BO, requiredValues);
		logger.info(ReportLoggerConstant.PROCEDURE_POST_EXECUTION);
	}

	/**
	 * This method method will return the UPRSTRINGVALUE value.
	 * 
	 * @param userName String
	 * @return String
	 */
	public static String getUPRSTRINGVALUE(final String userName) {
		String value = null;
		String sqlQuery = "select UPRSTRINGVALUE from UTIPREFERENCE  where UPRCODE='LOCALE' AND UTICODE = ?";
		logger.debug("SQL Query to get LOCALE value from DB - "+sqlQuery);
		String connectionURL = getConnectionULRForBO();
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, ApplicationContext.username_DB_BO,
				ApplicationContext.password_DB_BO);
				PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);) {
			preparedStatement.setString(1, userName);
			try (ResultSet resultSet = preparedStatement.executeQuery();) {
				while (resultSet.next()) {
					value = resultSet.getString("UPRSTRINGVALUE");
				}
			} catch (Exception exception) {
				logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
				throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY+exception.getMessage());
		}
		return value;
	}

	/**
	 * This method return the required column value.
	 * 
	 * @param sqlQuery            String
	 * @param requiredColumnValue String
	 * @param workSheetName       String
	 * @return String
	 */
	public static String getRequiredColumnValue(final String sqlQuery, final String requiredColumnValue,
			final String workSheetName) {
		String connectionURLBO = getConnectionULRForBO();
		String connectionURLFO = getConnectionULRForMO();

		String resultValue = null;
		if (workSheetName.contains(DBConstant.BO_MODULE)) {
			resultValue = executeQuery(sqlQuery, connectionURLBO, ApplicationContext.username_DB_BO,
					ApplicationContext.password_DB_BO, requiredColumnValue);
		}
		if (workSheetName.contains(DBConstant.MO_MODULE)) {
			resultValue = executeQuery(sqlQuery, connectionURLFO, ApplicationContext.username_DB_MO,
					ApplicationContext.password_DB_MO, requiredColumnValue);
		}
		return resultValue;
	}

	public static List<String> getMultipleRowsForSingleColumn(final String sqlQuery, final String requiredColumn) {
		String connectionURLBO = getConnectionULRForBO();
		return executeQueryMultipleRowsForSingleColumn(sqlQuery, connectionURLBO, ApplicationContext.username_DB_BO,
				ApplicationContext.password_DB_BO, requiredColumn);
	}

	/**
	 * This method will execute the query for multiple column.
	 * 
	 * @param sqlQuery String
	 * @return Map<String, String>
	 */
	public static Map<String, String> getMultipleColumnValue(final String sqlQuery) {
		String connectionURLBO = getConnectionULRForBO();
		return executeQueryForMultipleColumn(sqlQuery, connectionURLBO, ApplicationContext.username_DB_BO,
				ApplicationContext.password_DB_BO);
	}

	/**
	 * This method execute query.
	 * 
	 * @param sqlexpression String
	 * @param connectionURL String
	 * @param userName      String
	 * @param password      String
	 */
	private static Map<String, String> executeQueryForMultipleColumn(final String sqlQuery, final String connectionURL,
			final String userName, final String password) {
		Map<String, String> resultMap = new HashMap<String, String>();
		int columnCount = 0;
		String colName = null;
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, userName, password);
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sqlQuery)) {
			ResultSetMetaData metadata = resultSet.getMetaData();
			while (resultSet.next()) {
				colName = metadata.getColumnLabel(++columnCount);
				resultMap.put(colName, resultSet.getString(colName));
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
		}
		return resultMap;
	}

	/**
	 * This method execute query for Multiple rows for single column.
	 * 
	 * @param sqlQuery       String
	 * @param connectionURL  String
	 * @param userName       String
	 * @param password       String
	 * @param requiredColumn String
	 * @return List<String>
	 */
	private static List<String> executeQueryMultipleRowsForSingleColumn(final String sqlQuery,
			final String connectionURL, final String userName, final String password, final String requiredColumn) {
		List<String> resultList = new ArrayList<String>();
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, userName, password);
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sqlQuery)) {
			while (resultSet.next()) {
				resultList.add(resultSet.getString(requiredColumn));
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
		}
		return resultList;
	}

	/**
	 * This method execute query.
	 * 
	 * @param sqlQuery      String
	 * @param connectionURL String
	 * @param userName      String
	 * @param password      String
	 */
	private static void executeCallableStatement(final String sqlQuery, final String connectionURL,
			final String userName, final String password, final String[] requiredValues) {
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, userName, password);
				CallableStatement callableStatement = connection.prepareCall(sqlQuery);) {
			callableStatement.setString(1, requiredValues[0]);
			callableStatement.setInt(2, Integer.valueOf(requiredValues[1]));
			callableStatement.setString(3, requiredValues[2]);
			callableStatement.execute();
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
		}
	}

	/**
	 * This method execute update query.
	 * 
	 * @param sqlexpression String
	 * @param connectionURL String
	 * @param userName      String
	 * @param password      String
	 */
	private static void executeUpdateQuery(final String sqlexpression, final String connectionURL,
			final String userName, final String password) {
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, userName, password);
				Statement statement = connection.createStatement()) {
			statement.executeUpdate(sqlexpression);
			connection.setAutoCommit(false);
			connection.commit();
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY+exception.getMessage());
		}
	}

	/**
	 * This method execute query.
	 * 
	 * @param sqlexpression String
	 * @param connectionURL String
	 * @param userName      String
	 * @param password      String
	 */
	public static String executeQuery(final String sqlexpression, final String connectionURL, final String userName,
			final String password, final String requiredColumnValue) {
		String returnValue = null;
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		try (Connection connection = DriverManager.getConnection(connectionURL, userName, password);
				Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sqlexpression)) {
			while (resultSet.next()) {
				returnValue = resultSet.getString(requiredColumnValue);
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
		}
		return returnValue;
	}
	
	/**
	 * This method execute query.
	 * 
	 * @param sqlexpression String
	 * @param connectionURL String
	 * @param userName      String
	 * @param password      String
	 */
	public static String executeQuery(Connection connection,
			Logger sqlLogger, String sqlQuery) {
		String returnValue = null;
		try (Statement statement = connection.createStatement();
				ResultSet resultSet = statement.executeQuery(sqlQuery)) {
			if (resultSet.next()) {
				returnValue = resultSet.getString(1);
			} else  {
				returnValue =CommonConstant.EMPTY_STRING;
			}
		} catch (Exception exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
			sqlLogger.info(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
		}
		return returnValue;
	}

	/**
	 * @return
	 */
	public static String getConnectionULRForBO() {
		StringBuilder connectionURLBuider = new StringBuilder();
		connectionURLBuider.append(DBConstant.DRIVER_URL).append(ApplicationContext.iphostBO)
				.append(CommonConstant.COLON_SEPERATOR).append(ApplicationContext.PortBO)
				.append(CommonConstant.COLON_SEPERATOR).append(ApplicationContext.dbsidBO);
		return connectionURLBuider.toString();
	}

	public static String getConnectionULRForMO() {
		StringBuilder connectionURLBuider = new StringBuilder();
		connectionURLBuider.append(DBConstant.DRIVER_URL).append(ApplicationContext.iphostMO)
				.append(CommonConstant.COLON_SEPERATOR).append(ApplicationContext.PortMO)
				.append(CommonConstant.COLON_SEPERATOR).append(ApplicationContext.dbsidMO);
		return connectionURLBuider.toString();
	}
	
	public static String getSQLplusConnectionURLforMO() {
		StringBuilder connectionURLBuider = new StringBuilder();
		connectionURLBuider.append(ApplicationContext.username_DB_MO).append(CommonConstant.FORWARD_SLASH)
				.append(ApplicationContext.password_DB_MO).append(CommonConstant.AT_THE_RATE)
				.append(CommonConstant.FORWARD_SLASH).append(CommonConstant.FORWARD_SLASH)
				.append(ApplicationContext.iphostMO).append(CommonConstant.COLON_SEPERATOR)
				.append(ApplicationContext.PortMO).append(CommonConstant.FORWARD_SLASH).
				append(ApplicationContext.dbsidMO).append(CommonConstant.SPACE)
				.append(CommonConstant.AT_THE_RATE);
		return connectionURLBuider.toString();
	}
	
	public static String getSQLplusConnectionURLforBO() {
		StringBuilder connectionURLBuider = new StringBuilder();
		connectionURLBuider.append(ApplicationContext.username_DB_BO).append(CommonConstant.FORWARD_SLASH)
				.append(ApplicationContext.password_DB_BO).append(CommonConstant.AT_THE_RATE)
				.append(CommonConstant.FORWARD_SLASH).append(CommonConstant.FORWARD_SLASH)
				.append(ApplicationContext.iphostBO).append(CommonConstant.COLON_SEPERATOR)
				.append(ApplicationContext.PortBO)
				.append(CommonConstant.FORWARD_SLASH).append(ApplicationContext.dbsidBO).append(CommonConstant.SPACE)
				.append(CommonConstant.AT_THE_RATE);
		return connectionURLBuider.toString();
	}

	public static String executeGenericProcCall(final String inputString, final String application,
			final TestCaseDetail testCaseDetailTO) {
		int intValue = 0;
		String stringValue = null;
		Date dateValue = null;
		boolean outParamFlag = Boolean.FALSE;
		String outParamType = null;
		String procCallRebuild = null;

		String[] inputTestDataSplitString = CommonUtility.splitStringUsingPattern(inputString,CommonConstant.PIPE_SEPARATOR);
		if (null != inputTestDataSplitString) {
			procCallRebuild = getQueryForCallableStatements(inputTestDataSplitString);
			String outParam[] = CommonUtility.splitString(inputTestDataSplitString[inputTestDataSplitString.length - 1],
					CommonConstant.COMMA_SEPERATOR);
			if (outParam[0].equals(CommonConstant.OUT)) {
				outParamFlag = Boolean.TRUE;
				outParamType = outParam[1];
			}
		}
		try {
			Class.forName(DBConstant.ORACLE_DRIVER);
		} catch (ClassNotFoundException exception) {
			logger.error(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER, exception);
			throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_LOAD_DRIVER);
		}
		String params[] = getDBDetails(application);
		if (null != procCallRebuild && null != params) {
			try (Connection connection = DriverManager.getConnection(params[0], params[1], params[2]);
					CallableStatement cstmt = connection.prepareCall(procCallRebuild);) {
				int paramPosition = 1;
				for (int index = 1; index < inputTestDataSplitString.length ; index++) {
					String[] parameters = CommonUtility.splitString(inputTestDataSplitString[index],
							CommonConstant.COMMA_SEPERATOR);
					if (null != parameters) {
						if (parameters[1].equals(CommonConstant.NUMBER)) {
							intValue = Integer.parseInt(VariableHolder
									.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), parameters[0]));
							logger.info(index+ReportLoggerConstant.PROCEDURE_PARAM_VALUE_IS+intValue);
							cstmt.setInt(index, intValue);
						} else if (parameters[1].equals(CommonConstant.STRING)) {
							stringValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
									parameters[0]);
							logger.info(index+ReportLoggerConstant.PROCEDURE_PARAM_VALUE_IS+stringValue);
							cstmt.setString(index, stringValue);
						} else if (parameters[1].equals(CommonConstant.DATE)) {
							dateValue = new SimpleDateFormat(CommonConstant.DATE_FORMATE).parse(VariableHolder
									.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), parameters[0]));
							Object param = new java.sql.Date(dateValue.getTime());
							logger.info(index+ReportLoggerConstant.PROCEDURE_PARAM_VALUE_IS+dateValue);
							cstmt.setObject(index, param);
						}
						paramPosition++;
					}
				}
				if (outParamFlag) {
					if (outParamType.equals(CommonConstant.NUMBER)) {
						cstmt.registerOutParameter(paramPosition, oracle.jdbc.OracleTypes.NUMBER);
					} else if (outParamType.equals(CommonConstant.CURSOR)) {
						cstmt.registerOutParameter(paramPosition, oracle.jdbc.OracleTypes.CURSOR);
					} else if (outParamType.equals(CommonConstant.STRING)) {
						cstmt.registerOutParameter(paramPosition, oracle.jdbc.OracleTypes.VARCHAR);
					} else if (outParamType.equals(CommonConstant.DATE)) {
						cstmt.registerOutParameter(paramPosition, oracle.jdbc.OracleTypes.DATE);
					}

				}
				cstmt.execute();
				testCaseDetailTO.getReportingLogger().info(inputTestDataSplitString[0] +" - Procedure Executed Successfully");
				if (outParamFlag) {
					if (outParamType.equals(CommonConstant.NUMBER)) {
						return String.valueOf(cstmt.getInt(paramPosition));
					} else if (outParamType.equals(CommonConstant.STRING)) {
						return cstmt.getString(paramPosition);
					} else if (outParamType.equals(CommonConstant.DATE)) {
						return String.valueOf(cstmt.getDate(paramPosition));
					}

				}
			} catch (Exception exception) {
				logger.error(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY, exception);
				throw new CATTSQLException(ErrorMessageConstant.UNABLE_TO_EXECUTE_QUERY);
			}
		}
		return null;
	}

	public static String[] getDBDetails(final String application) {
		String params[] = new String[3];
		String connectionURL;
		String userName;
		String password;
		if (application.equals(DBConstant.BO_MODULE)) {
			connectionURL = getConnectionULRForBO();
			userName = ApplicationContext.username_DB_BO;
			password = ApplicationContext.password_DB_BO;
		} else {
			connectionURL = getConnectionULRForMO();
			userName = ApplicationContext.username_DB_MO;
			password = ApplicationContext.password_DB_MO;
		}
		params[0] = connectionURL;
		params[1] = userName;
		params[2] = password;

		return params;
	}

	private static String getQueryForCallableStatements(final String[] inputTestDataSplitString) {
		StringBuilder procCallRebuild = new StringBuilder(
				"call " + inputTestDataSplitString[0] + CommonConstant.OPENING_BRACE_SEPERATOR);
		for (int paramIndex = 0; paramIndex < inputTestDataSplitString.length - 1; paramIndex++) {
			if (paramIndex < inputTestDataSplitString.length - 2) {
				procCallRebuild.append(CommonConstant.QUESTION_MARK_SEPERATOR + CommonConstant.COMMA_SEPERATOR);
			} else {
				procCallRebuild.append(CommonConstant.QUESTION_MARK_SEPERATOR);
			}
		}
		procCallRebuild.append(CommonConstant.CLOSING_BRACE_SEPERATOR);
		return procCallRebuild.toString();
	}
	
	public static Connection getConnection(String application) throws SQLException {
		Connection connection = null;
		if (application.equals(DBConstant.BO_MODULE)) {
			connection = DriverManager.getConnection(getConnectionULRForBO(), ApplicationContext.username_DB_BO, ApplicationContext.password_DB_BO);
		} else {
			connection = DriverManager.getConnection(getConnectionULRForMO(), ApplicationContext.username_DB_MO, ApplicationContext.password_DB_MO);
		}
		return connection;
	}
	

}
