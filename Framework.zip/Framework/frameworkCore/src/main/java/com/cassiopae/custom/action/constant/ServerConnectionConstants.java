package com.cassiopae.custom.action.constant;

public class ServerConnectionConstants {
	
	public static String CONNECTING_TO = "Connecting to server: ";
	public static String SESSION_CONFIGURATION_ERROR_MESSAGE = "Error occured while configuring session connection: ";
	public static String CLOSE_CONNECTION_ERROR_MESSAGE = "Error occured while closing session: ";
	public static String FILE_PERMISSION_VALUE = "777";
	
	public static String FILE_UPLOAD_SUCCESS_MESSAGE_ALONG_WITH_LOCATION = "File uploaded successfully on app server present at location: ";
	public static String FILE_COPY_MESSAGE = "File is copied on app server: '";
	public static String AT_LOCATION = "' at location: ";
	public static String SFTP = "sftp";
	public static String EXEC = "exec";
	public static String DIREXTORY_CREATION_MESSAGE = "Directory is not present on server, creating new: ";
	public static String DIREXTORY_CREATION_ERROR_MESSAGE = "Error occured while creating directory on app server: ";
	public static String SERVER_CONNECTION_CREATION_MESSAGE = "Connection created with app server: ";
	public static String SERVER_CONNECTION_ERROR_MESSAGE = "Error occured while session connection to application server: ";
	 
	
	
	
	
	
}
