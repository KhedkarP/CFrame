package com.cassiopae.webservices.action;

public interface WSErrorMessageConstant {
	
	
String PARAMETERS_IMPROPER_ERRORMSG="Input parameters count and Stored Variable parameters count missmatched, please check for same";
String INPUT_PARAMETER =" Input parameter >> ";
String NOT_AVAILABLE_MSG =" >> Not available given response body >>  ";
String PLEASE_CHECK_INPUT_REQUEST_METHOD_MSG="Input parameters are incorrect, Please check Input Test Data and Store Value In Variable ";
	
}
