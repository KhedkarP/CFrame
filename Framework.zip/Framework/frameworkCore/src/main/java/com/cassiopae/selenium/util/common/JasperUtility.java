/**
 * 
 */

package com.cassiopae.selenium.util.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

/**
 * @author jraut
 *
 */
public class JasperUtility {

	private static Logger logger = LogManager.getLogger(JasperUtility.class);

	public static void executeExeFile(String exefilePath, Logger reportingLogger, String... sarameters) {

		if (sarameters.length == 0) {
			CommonFunctions.explicitWait(5000);
			try {
				Process proc = Runtime.getRuntime().exec(exefilePath);
				proc.waitFor();
				CommonFunctions.explicitWait(15000);
				reportingLogger.info(ReportLoggerConstant.AUTO_IT_EXECUTED_SUCESSFULLY);
			} catch (IOException | InterruptedException e) {
				reportingLogger.info(ReportLoggerConstant.ERROR_OCCURED_WHILE_EXE_FILE_EXECUTION, e);
				logger.error(e);
			}
		} else {
			CommonFunctions.explicitWait(5000);
			try {
				String[] filePath = sarameters;
				Process proc = Runtime.getRuntime().exec(exefilePath + " " + filePath[0]);
				proc.waitFor();
				CommonFunctions.explicitWait(15000);
				reportingLogger.info(ReportLoggerConstant.AUTO_IT_EXECUTED_SUCESSFULLY);
			} catch (IOException | InterruptedException e) {
				reportingLogger.info(ReportLoggerConstant.ERROR_OCCURED_WHILE_EXE_FILE_EXECUTION, e);
				logger.error(e);
			}

		}

	}

	public static int getDataFromJasperReport(String pdfFileName, String ExcelFile, TestCaseDetail testCaseDetail,
			Logger reportingLogger) {

		List<String> allMatches = new ArrayList<String>();
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		String flag = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, logger, pdfFileName);
		String parsedText = null;
		if (flag.equals(CommonConstant.TRUE_VALUE)) {
			String randomNo = RandomStringUtils.randomNumeric(5);
			String newPdfFileName = CommonUtility.splitString(pdfFileName, CommonConstant.DOT)[0]
					+ CommonConstant.UNDER_SCORE + testCaseDetail.getWorkSheetName() + CommonConstant.UNDER_SCORE
					+ randomNo + CommonConstant.PDF_FILE_EXTENSION;
			if (FileUtility.renameFile(downlodedPath + pdfFileName, downlodedPath + newPdfFileName, downlodedPath,
					testCaseDetail.getReportingLogger(), pdfFileName + ReportLoggerConstant.FILE_RENAMED_MSG)) {
				pdfFileName = newPdfFileName;
			}
			PDDocument document = null;
			String PdfFile = downlodedPath + pdfFileName;
			try {
				document = PDDocument.load(new File(PdfFile));
				PDFTextStripperByArea stripper = new PDFTextStripperByArea();
				stripper.setSortByPosition(true);
				PDFTextStripper Tstripper = new PDFTextStripper();
				parsedText = Tstripper.getText(document);
			} catch (IOException ioe) {
				reportingLogger.error(ioe.getMessage());
				throw new CATTException(ioe.getMessage());
			} finally {
				if (document != null) {
					try {
						document.close();
						reportingLogger.info(ReportLoggerConstant.DATA_SET_MSG + ExcelFile);
					} catch (IOException e) {
						reportingLogger.error(e.getMessage());
						throw new CATTException(e.getMessage());
					}
				}
			}

			Pattern pattern = Pattern.compile(FrameworkConstant.REGEX_EXP_FOR_RECEIVABLE + CommonConstant.PIPE_SEPARATOR +
					FrameworkConstant.REGEX_EXP_FOR_RECEIVABLE_WITHOUT_SPLIT + CommonConstant.PIPE_SEPARATOR+
					FrameworkConstant.REGEX_EXP_FOR_DEPENSE + CommonConstant.PIPE_SEPARATOR
					+ FrameworkConstant.REGEX_EXP_FOR_SIMULATION + CommonConstant.PIPE_SEPARATOR
					+ FrameworkConstant.REGEX_EXP_FOR_FACTURE, Pattern.MULTILINE);
			       
			Matcher matcher = pattern.matcher(parsedText);
			int count = 1;
			while (matcher.find()) {
				for (int i = 0; i <= matcher.groupCount(); i++) {
					allMatches.add(matcher.group(i));
					reportingLogger.info(" Retrieved" + count + "th value from PDF : " + matcher.group(i));
				}
				count++;
			}
			String flag1 = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, logger, ExcelFile);
			try {
				String ExcelPath = downlodedPath + ExcelFile;
				FileOutputStream out = null;
				XSSFWorkbook workbook = null;
				XSSFSheet firstSheet = null;
				int rowCount = 0;
				int columnCount = 0;
				int i = 1;
				Row row = null;
				Cell cell = null;
				if (flag1.equals(CommonConstant.TRUE_VALUE)) {
					FileInputStream input = new FileInputStream(ExcelPath);
					workbook = new XSSFWorkbook(input);
					firstSheet = workbook.getSheet(CommonConstant.JASPER_EXCEL_SHEET_NAME);
					for (String field : allMatches) {
						row = firstSheet.getRow(++rowCount);
						try {
							cell = row.getCell(0);
						} catch (Exception e1) {
							int lastRow = firstSheet.getPhysicalNumberOfRows();
							row = firstSheet.createRow(rowCount);
							cell = row.createCell(0);
							cell.setCellValue((Integer) lastRow++);
						}
						if (pdfFileName.contains(CommonConstant.RECEVIABLE_PDF_FILE_NAME)) {
							try {
								cell = row.getCell(1);
							} catch (Exception e) {
							}
							if (cell == null || cell.getCellTypeEnum() == CellType.BLANK
									|| cell.getStringCellValue().trim().isEmpty()) {
								cell = row.createCell(1);
								cell.setCellValue((String) field);
							} else {
								continue;
							}

						}
						if (pdfFileName.contains(CommonConstant.EXPENSE_PDF_FILE_NAME)) {
							try {
								cell = row.getCell(2);
							} catch (Exception e) {
							}
							if (cell == null || cell.getCellTypeEnum() == CellType.BLANK
									|| cell.getStringCellValue().trim().isEmpty()) {
								cell = row.createCell(2);
								cell.setCellValue((String) field);
							} else {
								continue;
							}

						}
					}
					input.close();
					out = new FileOutputStream(new File(ExcelPath));
					workbook.write(out);
					out.close();
				} else {
					out = new FileOutputStream(new File(ExcelPath));
					workbook = new XSSFWorkbook();
					firstSheet = workbook.createSheet(CommonConstant.JASPER_EXCEL_SHEET_NAME);
					row = firstSheet.createRow(rowCount);
					cell = row.createCell(columnCount);
					row.createCell(columnCount).setCellValue(CommonConstant.JASPER_EXCEL_HEADER1);
					row.createCell(++columnCount).setCellValue(CommonConstant.JASPER_EXCEL_HEADER_RECEIVABLES);
					row.createCell(++columnCount).setCellValue(CommonConstant.JASPER_EXCEL_HEADER_EXPENSE);
					for (String field : allMatches) {
						row = firstSheet.createRow(++rowCount);
						cell = row.createCell(0);
						cell.setCellValue((Integer) i++);
						if (pdfFileName.contains(CommonConstant.RECEVIABLE_PDF_FILE_NAME)) {
							cell = row.createCell(1);
							cell.setCellValue((String) field);
						}
						if (pdfFileName.contains(CommonConstant.EXPENSE_PDF_FILE_NAME)) {
							cell = row.createCell(2);
							cell.setCellValue((String) field);
						}
					}
					workbook.write(out);
					out.close();
				}
			} catch (IOException e) {
				reportingLogger.error(e.getMessage());
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.info(ReportLoggerConstant.EXPECTED_FILE_MSG + pdfFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
			throw new CATTException(ReportLoggerConstant.EXPECTED_FILE_MSG + pdfFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
		}

		return allMatches.size();
	}

	public static Collection<String> readReceivableFromExcel(String[] startEndRow, String[] inputDataColumnValues,
			ExcelTestCaseFields excelTestCaseFieldsTO, final Map<String, String> variableHolder, Logger reportinglogger,
			TestCaseDetail testCaseDetail, String ExcelFileName) {
		Collection<String> value = null;
		int startIndex = Integer.parseInt(startEndRow[0].trim());
		int endIndex = Integer.parseInt(startEndRow[1].trim());
		String[] storeRetrievedValues = null;
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		String flag1 = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, logger, ExcelFileName);
		Multimap<Integer, String> dataMap = ArrayListMultimap.create();
		List<String> receivablelist = new ArrayList<>();
		List<String> expenseList = new ArrayList<>();
		if (flag1.equals(CommonConstant.TRUE_VALUE)) {
			try {
				FileInputStream input = new FileInputStream(downlodedPath + ExcelFileName);
				Workbook workbook = new XSSFWorkbook(input);
				Sheet sheet = workbook.getSheet(CommonConstant.JASPER_EXCEL_SHEET_NAME);
				int lastRow = sheet.getPhysicalNumberOfRows();
				DataFormatter formatter = new DataFormatter();
				Row row = sheet.getRow(0);
				if (row.getCell(0).getStringCellValue().equals(CommonConstant.JASPER_EXCEL_HEADER1)) {
					for (int i = startIndex; i <= endIndex; i++) {
						row = sheet.getRow(i);
						Cell receivable = null;
						Cell expenseCount = null;
						try {
							receivable = row.getCell(1);
						} catch (Exception e) {
						}
						try {
							expenseCount = row.getCell(2);
						} catch (Exception e) {
						}
						String receivables = formatter.formatCellValue(receivable);
						String expenseCountv = formatter.formatCellValue(expenseCount);
						receivablelist.add(receivables);
						expenseList.add(expenseCountv);
					}

					multipleTestDataColumnValues(excelTestCaseFieldsTO, storeRetrievedValues, inputDataColumnValues,
							variableHolder, reportinglogger, receivablelist, expenseList);

				} else {
					reportinglogger.error(ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE);
					throw new CATTException(ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE);
				}
			} catch (Exception ioe) {
				reportinglogger.error(ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE);
				throw new CATTException(ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE);
			}

		} else {
			reportinglogger.error(ReportLoggerConstant.EXPECTED_FILE_MSG + ExcelFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
			throw new CATTException(ReportLoggerConstant.EXPECTED_FILE_MSG + ExcelFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
		}
		return value;
	}

	public static void multipleTestDataColumnValues(ExcelTestCaseFields excelTestCaseFieldsTO,
			String[] storeRetrievedValues, String[] inputDataColumnValues, final Map<String, String> variableHolder,
			Logger reportinglogger, List<String> receivablelist, List<String> expenseList) {
		storeRetrievedValues = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getStoreValuesInVariable(),
				CommonConstant.PIPE_SEPARATOR);
		try {
			int count = 0;
			for (String element : inputDataColumnValues) {
				String[] storeRetrievedValues1 = CommonUtility.splitStringUsingPattern(storeRetrievedValues[count],
						CommonConstant.COMMA_SEPERATOR);
				if (element.trim().equals(CommonConstant.JASPER_EXCEL_HEADER_RECEIVABLES)) {
					for (int i = 0; i < storeRetrievedValues1.length; i++) {
						variableHolder.put(storeRetrievedValues1[i].trim(), String.valueOf(receivablelist.get(i)));
						if (String.valueOf(receivablelist.get(i)).equals("")) {
							reportinglogger.info(ReportLoggerConstant.VALUE_EMPTY_GENERATED_MSG
									+ storeRetrievedValues1[i] + ReportLoggerConstant.JASPER_REPORT_VALIDATION);
						} else {
							reportinglogger
									.info(ReportLoggerConstant.VALUE_OF_STORE_VARIABLE + storeRetrievedValues1[i].trim()
											+ CommonConstant.IS + String.valueOf(receivablelist.get(i)));
						}
					}
				} else if (element.trim().equals(CommonConstant.JASPER_EXCEL_HEADER_EXPENSE)) {
					for (int i = 0; i < storeRetrievedValues1.length; i++) {
						variableHolder.put(storeRetrievedValues1[i].trim(), String.valueOf(expenseList.get(i)));
						if (String.valueOf(expenseList.get(i)).equals("")) {
							reportinglogger.info(ReportLoggerConstant.VALUE_EMPTY_GENERATED_MSG
									+ storeRetrievedValues1[i] + ReportLoggerConstant.JASPER_REPORT_VALIDATION);
						} else {
							reportinglogger
									.info(ReportLoggerConstant.VALUE_OF_STORE_VARIABLE + storeRetrievedValues1[i].trim()
											+ CommonConstant.IS + String.valueOf(expenseList.get(i)));
						}
					}
				}
				count++;
			}
		}

		catch (Exception e) {
			reportinglogger.error(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
			throw new CATTException(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
		}
	}

	public static int getRequiredDataFromExcel(final Map<String, String> variableHolder, TestCaseDetail testCaseDetail,
			Logger replogger, String[] inputDataRequiredValues, String[] storeRetrievedValues) throws IOException {
		String[] requiredData = CommonUtility.splitStringUsingPattern(inputDataRequiredValues[0],
				CommonConstant.COMMA_SEPERATOR);
		String[] requiredvraible = CommonUtility.splitStringUsingPattern(inputDataRequiredValues[1],
				CommonConstant.COMMA_SEPERATOR);
		String excelFileName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				requiredData[0].trim());
		String requiredHeader = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				requiredData[1].trim());
		String headder_occurence = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				requiredData[2].trim());
		int requiredIndex = Integer.parseInt(headder_occurence);
		LinkedHashMap<Integer, HashMap<String, String>> dataMap = new LinkedHashMap<>();
		HashMap<String, String> NewDataMap = new LinkedHashMap<>();
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		String flag = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, replogger, excelFileName);
		if (flag.equals(CommonConstant.TRUE_VALUE)) {
			FileInputStream input = new FileInputStream(downlodedPath + excelFileName);
			Workbook workbook = new XSSFWorkbook(input);
			org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheet(CommonConstant.JASPER_DATA);
			HashMap<String, String> childMap = new HashMap<String, String>();
			int lastRow = sheet.getLastRowNum();
			int Count = 1;
			for (int i = 0; i < lastRow; i++) {
				try {
					Row row = sheet.getRow(i);

					for (int j = 0; j <= row.getLastCellNum(); j++) {
						Cell c = row.getCell(j, MissingCellPolicy.RETURN_BLANK_AS_NULL);
						if (!(c == null) && c.getStringCellValue().equals(requiredHeader)) {
							String key = "";
							String value = "";
							for (int k = 0; k <= row.getLastCellNum(); k++) {
								Cell key1 = row.getCell(k, MissingCellPolicy.RETURN_BLANK_AS_NULL);
								if (!(key1 == null)) {
									key = key1.getStringCellValue();
									value = sheet.getRow(row.getRowNum() + 1)
											.getCell(k, MissingCellPolicy.RETURN_BLANK_AS_NULL).getStringCellValue();
									childMap.put(key, value);
								}
							}
							dataMap.put(Count, new HashMap<String, String>(childMap));
							Count++;
						}
					}
				} catch (NullPointerException e) {
				}
			}
			NewDataMap = dataMap.get(requiredIndex);
			int count = 0;
			for (String a : requiredvraible) {
				if (NewDataMap.containsKey(a)) {
					replogger.info(ReportLoggerConstant.RETRIVED_HEADER + a + ReportLoggerConstant.Value_MSG
							+ String.valueOf(NewDataMap.get(a)));
					variableHolder.put(storeRetrievedValues[count], String.valueOf(NewDataMap.get(a)));
					count++;
				}
			}

		} else {
			replogger.error(ReportLoggerConstant.EXPECTED_FILE_MSG + excelFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
			throw new CATTException(ReportLoggerConstant.EXPECTED_FILE_MSG + excelFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
		}
		return dataMap.size();
	}

	public static String convertPdfToExcel(TestCaseDetail testCaseDetail, Logger reportingLogger, String inputData) {
		String excelFileName = null;
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		String pdfFileName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), inputData);
		reportingLogger.info(ReportLoggerConstant.INPUT_FIELD_MSG + pdfFileName);
		String flag = SeleniumUtility.checkFileIsAvailableORNot(downlodedPath, reportingLogger, pdfFileName);
		String parsedText = null;
		if (flag.equals(CommonConstant.TRUE_VALUE)) {
			String randomNo = RandomStringUtils.randomNumeric(5);
			String newPdfFileName = CommonUtility.splitString(pdfFileName, CommonConstant.DOT)[0]
					+ CommonConstant.UNDER_SCORE + testCaseDetail.getWorkSheetName() + CommonConstant.UNDER_SCORE
					+ randomNo + CommonConstant.PDF_FILE_EXTENSION;
			if (FileUtility.renameFile(downlodedPath + pdfFileName, downlodedPath + newPdfFileName, downlodedPath,
					testCaseDetail.getReportingLogger(), pdfFileName + ReportLoggerConstant.FILE_RENAMED_MSG)) {
				pdfFileName = newPdfFileName;
			}
			excelFileName = testCaseDetail.getWorkSheetName() + CommonConstant.UNDER_SCORE + randomNo
					+ CommonConstant.XLSX_FILE_EXTENSION;
			String ExcelPath = downlodedPath + excelFileName;
			PDDocument document = null;
			String PdfFile = downlodedPath + pdfFileName;
			String str[] = null;
			try {
				document = PDDocument.load(new File(PdfFile));
				LayoutTextStripper stripper = new LayoutTextStripper();
				stripper.setSortByPosition(true);
				stripper.fixedCharWidth = 1000;
				parsedText = stripper.getText(document);
				str = parsedText.trim().split("\\r?\\n");
				FileOutputStream fos = new FileOutputStream(new File(ExcelPath));
				XSSFWorkbook workbook = new XSSFWorkbook();
				XSSFSheet firstSheet = workbook.createSheet(CommonConstant.JASPER_DATA);
				int rowCount = 0;
				int columnCount = 0;
				String a[] = null;
				String b[] = null;
				for (String field : str) {
					Row row = firstSheet.createRow(++rowCount);
					String str1[] = field.trim().split("\\s+");
					for (String field1 : str1) {
						if (field1.equals(CommonConstant.TAXESON_INVOICE)
								|| field1.equals(CommonConstant.TAXESSUR_FACTURE)
								|| field1.equals(CommonConstant.DETAILSONRATE_CALCULATION)) {
							row = firstSheet.createRow(rowCount);
							Cell cell = row.createCell(columnCount);
							cell.setCellValue((String) field1);
						} else if (field1.contains(":")) {
							a = field1.replaceAll("[0-9]", "").split(",");
							for (String c : a) {
								row = firstSheet.createRow(rowCount);
								Cell cell = row.createCell(columnCount++);
								cell.setCellValue((String) c);
							}
							b = field1.split(":");
							for (String c : b) {
								StringBuffer strBuff = new StringBuffer();
								for (int i = 0; i < c.length(); i++) {
									char ab;
									ab = c.charAt(i);
									if (Character.isDigit(ab) || ab == ',') {
										strBuff.append(ab);
									}
								}
								row = firstSheet.createRow(rowCount);
								Cell cell = row.createCell(columnCount++);
								cell.setCellValue((String) c);
							}
						}

						else {
							Cell cell = row.createCell(columnCount++);
							cell.setCellValue((String) field1);
						}
					}
					columnCount = 0;
				}
				workbook.write(fos);
				fos.close();
			} catch (IOException ioe) {
				reportingLogger.error(ioe.getMessage());
				throw new CATTException(ioe.getMessage());
			} finally {
				if (document != null) {
					try {
						document.close();
						reportingLogger.info(ReportLoggerConstant.DATA_SET_MSG + excelFileName);
					} catch (IOException e) {
						reportingLogger.error(e.getMessage());
						throw new CATTException(e.getMessage());
					}
				}
			}
		} else {
			reportingLogger.error(ReportLoggerConstant.EXPECTED_FILE_MSG + pdfFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);
			throw new CATTException(ReportLoggerConstant.EXPECTED_FILE_MSG + pdfFileName
					+ ReportLoggerConstant.IS_NOT_AVAILABLE_MSG + downlodedPath);

		}
		return excelFileName;
	}

}
