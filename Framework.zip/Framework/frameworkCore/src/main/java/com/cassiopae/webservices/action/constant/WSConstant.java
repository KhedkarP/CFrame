/**
 *
 */
package com.cassiopae.webservices.action.constant;

/**
 * @author mshaik
 *
 */
public interface WSConstant {

	static String WS_GENERATE_POST_REQUST = "RWS_Execute_POST_Request"; 
	static String WS_REQUEST_REST_HEADER = "RWS_Execute_Login_Request"; //Deprecated
	static String REST_API_GET_RESPONSE_DATA = "REST_GetResponseData";
	static String REST_API_LOGIN_REQUEST = "REST_LoginRequest";
	static String REST_API_POST_REQUEST = "REST_POSTRequest";
	static String REST_API_PUT_REQUEST = "REST_PUTRequest";
	static String REST_API_PATCH_REQUEST="REST_PATCHRequest";
	static String REST_API_GET_REQUEST="REST_GETRequest";
	static String REST_API_EXECUTE_REQUEST="REST_ExecuteRequest";

	static String SOAP_API_POST_REQUEST = "SOAP_Request";
	static String SOAP_API_GET_RESPONSE_DATA = "SOAP_GetResponseData";

}
