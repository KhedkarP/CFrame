/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.JasperUtility;

/**
 * @author nbhil
 *
 */
public class ReadValuesFromExcel implements PerformAction {

	/**
	 * This method execute action for get value action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR))
		{
				String[] inputDataRequiredValues=CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),CommonConstant.PIPE_SEPARATOR);
				String[] inputDataColumnRequiredValues=CommonUtility.splitString(inputDataRequiredValues[0],CommonConstant.COMMA_SEPERATOR);
				String[] startEndRow=CommonUtility.splitString(inputDataRequiredValues[1],CommonConstant.COMMA_SEPERATOR);
				if (CommonFunctions.checkArrayElementAreNumeric(startEndRow,testCaseDetailTO))
				{
						testCaseDetailTO.getReportingLogger().error(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
						throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
				}
			try {
				String excelName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
						inputDataRequiredValues[2]);
				excelName = excelName + CommonConstant.XLSX_FILE_EXTENSION;
				JasperUtility.readReceivableFromExcel(startEndRow, inputDataColumnRequiredValues, excelTestCaseFieldsTO,
						testCaseDetailTO.getVariableHolder(), testCaseDetailTO.getReportingLogger(), testCaseDetailTO,
						excelName);
			} catch (Exception e) {
					testCaseDetailTO.getReportingLogger().error(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
					throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_INPUT_DATA_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
				}
		}
		else
		{
				testCaseDetailTO.getReportingLogger().error(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
				throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE + excelTestCaseFieldsTO.getAction());
		}
		
	}

}
