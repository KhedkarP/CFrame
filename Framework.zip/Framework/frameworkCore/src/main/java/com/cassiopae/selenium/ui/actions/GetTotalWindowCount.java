/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author jraut
 *
 */
public class GetTotalWindowCount implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		try {
			Thread.sleep(5000);
		} catch (InterruptedException exception) {
			testCaseDetailTO.getReportingLogger().error(exception.getMessage());
		}
		int count = getTotalWindowCount(testCaseDetailTO);

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					String.valueOf(count));
		}
	}

	/**
	 * This method will return total number of windows/tabs present in browser
	 * 
	 * @param testCaseDetailTO
	 * @return It will return count of total number of windows populated by current
	 *         browser
	 */
	private int getTotalWindowCount(TestCaseDetail testCaseDetailTO) {
		int count = 0;
		int currentWindow = 1;
		Set<String> windowIterator = testCaseDetailTO.getDriver().getWindowHandles();
		count = windowIterator.size();

		testCaseDetailTO.getReportingLogger().info("Total number of windows:  " + count);
		for (String windowHandle : windowIterator) {
			WebDriver newDriver = testCaseDetailTO.getDriver().switchTo().window(windowHandle);
			try {
				testCaseDetailTO.getDriver().findElement(By.xpath("//html"));
			} catch (Exception e) {
				//e.printStackTrace();
			}
			newDriver.manage().window().maximize();
			testCaseDetailTO.getReportingLogger().info(currentWindow + ". window title  is : " + newDriver.getTitle());
			currentWindow = currentWindow + 1;
		}
		return count;
	}

}
