/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author nbhil
 *
 */
public class GetAttributeTitleAction implements PerformAction {

	/**
	 * This method execute action for get attribute title action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String attributeTitle = GenericAction.getAttributeValueByTitle(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + attributeTitle);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), attributeTitle);
		}
		if (excelTestCaseFieldsTO.getExpectedResult() != null || excelTestCaseFieldsTO.getActualValue() != null) {
			String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
			String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
			GenericAction.assertEquals(variableHolderActualValue, variableHolderExpectedValue,
					excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
		}
	}

}
