package com.cassiopae.framework.xl.reader;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

public class GenericExcelFileReader {
	private GenericExcelFileReader() {
		
	}
	private static Logger trace = LogManager.getLogger( GenericExcelFileReader.class );
	
	public static List<GenericRow> readExcelFile(final String testCaseExcelPath, final String workBookName,
			final String testCaseSheetName, final String propertiesFileName, String locale,
			Map<String, Integer> headerMap, String workSheetName) {
		EnvironmentXLFormat testCaseFormat = EnvironmentXLFormat.getInstance();
		testCaseFormat.setColumns("resources/" + propertiesFileName);
		List<GenericRow> genericRowList = new ArrayList<>();
		GenericRow genericRow = null;
		try (Workbook workbook = WorkbookFactory.create(new File(testCaseExcelPath + workBookName))) {
			workbook.setForceFormulaRecalculation(true);
			HSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			DataFormatter dataFormatter = new DataFormatter();
			Sheet sheet = workbook.getSheet(testCaseSheetName);
			Row topRow = sheet.getRow(sheet.getTopRow()); // Get first row
			int minColIx = topRow.getFirstCellNum(); // get the first column index for a row
			int maxColIx = topRow.getLastCellNum(); // get the last column index for a row
			Map<String, Integer> reqCells = new HashMap<>();
			List<Column> columns = testCaseFormat.getColumns();
			reqCells = validateSheetColumns(topRow, minColIx, maxColIx, columns, reqCells);
			headerMap.putAll(reqCells);
			String cellValue = null;
			for (int rowNo = 1; rowNo <= sheet.getLastRowNum(); rowNo++) {
				genericRow = new GenericRow();
				Iterator itr = reqCells.entrySet().iterator();
				while (itr.hasNext()) {
					Map.Entry pair = (Map.Entry) itr.next();
					cellValue = ExcelReader.formulaEvaluator(sheet.getRow(rowNo).getCell((int) pair.getValue()),
							dataFormatter, locale , workSheetName);
					if(cellValue !=null && (cellValue.equals("-0.00") || cellValue.equals("-0,00"))) {
						cellValue = covertZeroValue(cellValue, locale);
					}
					genericRow.setCellValue(Integer.parseInt(pair.getValue().toString()), cellValue);
				}
				genericRowList.add(genericRow);
			}
		} catch (EncryptedDocumentException | IOException e) {
			trace.error("Test Case data file reading failed. " + testCaseSheetName, e);
			throw new ValidatorException("Test Case data file reading failed. " + testCaseSheetName);
		} catch (ValidatorException l_l_ex) {
			trace.info(l_l_ex.getMessage(),l_l_ex);
			throw l_l_ex;
		}
		return genericRowList;
	}
	
	public static String covertZeroValue(String value,String locale ) {
		if (value.equals("-0.00")) {
			return "0.00";
		} else if (value.equals("-0,00")) {
			return "0,00";
		}
		return value;
	}

	public static Map<String, Integer> validateSheetColumns(final Row topRow, final int minColIx, final int maxColIx,
			final List<Column> columns, final Map<String, Integer> reqCells) {
		for (Column column : columns) {
			String colNameFromFormat = column.getName();
			String cellHeaderName = null;
			for (int colIx = minColIx; colIx < maxColIx; colIx++) {
				if (topRow.getCell(colIx) != null) {
					cellHeaderName = StringUtils.trimToEmpty(topRow.getCell(colIx).getStringCellValue())
							.replace(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
					if (colNameFromFormat.equals(cellHeaderName)) {
						reqCells.put(colNameFromFormat, colIx);
						break;
					}
				}
			}
		}
		if (reqCells.isEmpty()) {
			throw new ExcelValidatorException(ReportLoggerConstant.WORKSHEET_EMPTY_MESSAGE);
		} else if (columns.size() < reqCells.size()) {
			throw new ExcelValidatorException(ReportLoggerConstant.INCORRECT_COLUMN_COUNT);
		}
		return reqCells;
	}
}
