/**
 *
 */
package com.cassiopae.framework.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.util.PostTestCaseExecutorUtility;
import com.neotys.selenium.proxies.NLWebDriver;

/**
 * @author nbhil
 *
 */
public class PostTestCaseExecutor {

	private static Logger logger = LogManager.getLogger(PostTestCaseExecutor.class);

	/**
	 * This method perform post test execution activity.
	 * 
	 * @param testCaseCommonData TestCaseCommonData
	 * @param executionTime      String
	 * @param testResult         ITestResult
	 * @param issue              String
	 * @param statusSheetName    String
	 * @param errorMessgae       String
	 */
	public void postTestCaseExecutionActivity(final TestCaseCommonData testCaseCommonData, final String executionTime,
			final ITestResult testResult, final String issue, final String statusSheetName, final String errorMessgae) {
		try {
			if (testCaseCommonData.getExcelRowNo() != 0) {
				PostTestCaseExecutorUtility.postTestCaseExecutionActivity(testCaseCommonData, executionTime, testResult,
						issue, statusSheetName, errorMessgae);
			}
		} catch (CATTException exception) {
			logger.error(exception.getMessage(), exception);
			Assert.fail(exception.getMessage());
		}
	}
	
	public String getErrorMessageFromITestListener(final ITestResult testResult) {
		String errorMessage = null;
		try { 
			errorMessage = testResult.getThrowable().getMessage();
		} catch (Exception exp) {
			//logger.error("Exception occured while retriving error message from listener ", exp);
		}
		return errorMessage;
	}
	
	public static void addFailedScreenshotInReport(WebDriver driver,ITestResult testResult,String logLink) {
		testResult.getThrowable().printStackTrace();
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String methodName = testResult.getName();
		File screenShot = null;
		try {
			if(null !=driver && !(driver instanceof NLWebDriver)) {
				screenShot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE); 
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage(), exception);
		}
		if (null != screenShot) {
			try {
				String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/test-output";
				File destFile = new File(reportDirectory + "/failure_screenshots/" + methodName + "_"
						+ formater.format(calendar.getTime()) + ".png");
				FileUtils.copyFile(screenShot, destFile);
				Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
						+ "' height='60' width='60'/> </a>");
				Reporter.log("<a href="+logLink+">Automation Logs</a>");
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

}
