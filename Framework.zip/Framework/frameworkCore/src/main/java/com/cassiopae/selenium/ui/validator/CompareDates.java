/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import java.util.regex.Pattern;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.utils.date.DateUtils;

/**
 * @author nkale
 *
 */
public class CompareDates implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] inputTestDatas = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String reqOperations = inputTestDatas[1];
		String[] reqValues = inputTestDatas[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		testCaseDetail.getReportingLogger().info(ReportLoggerConstant.OPERATION + reqOperations);
		String date[] = new String[reqValues.length];
		for (int i = 0; i < reqValues.length; i++) {
			String reqValue = reqValues[i].trim();
			date[i] = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), reqValue);
		}
		if (DateUtils.validateInputDates(reqValues, testCaseDetail)
				&& DateUtils.validateParameter(reqOperations, date, testCaseDetail)) {
			DateUtils.dateCompare(excelTestCaseFields, testCaseDetail, reqValues, date, reqOperations);
		} else {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.DATES_VALIDATION_ERROR);
		}
	}
}
