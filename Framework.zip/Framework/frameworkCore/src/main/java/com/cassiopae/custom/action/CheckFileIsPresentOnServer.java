package com.cassiopae.custom.action;

import java.util.Vector;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.ServerConnectionConstants;
import com.cassiopae.framework.dao.utility.SFTPConnectionUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.BatchAutomationUtility;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class CheckFileIsPresentOnServer implements CustomAction {

	private static Logger tracelogger = LogManager.getLogger(CheckFileIsPresentOnServer.class);

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger logger = testCaseDetailTO.getReportingLogger();
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String filename = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]);
		logger.info(excelTestCaseFieldsTO.getTestCaseSteps()+ ": "+filename);
		String sourcePath = BatchAutomationUtility.getUpdatedCommand(inputData[1],
				testCaseDetailTO.getVariableHolder());

		logger.info(ServerConnectionConstants.CONNECTING_TO + ApplicationContext.applicationServerHostname);
		Session session = SFTPConnectionUtility.createSessionObject();
		SFTPConnectionUtility.configureSessionObject(session);
		ChannelSftp sftpChannel = SFTPConnectionUtility.sftpChannelCreation(session);
		SFTPConnectionUtility.configureChannel(sftpChannel);
		boolean isFilePresent = Boolean.FALSE;
		try {
			isFilePresent = checkFileIsPresentOnLinux(logger, filename, sourcePath, sftpChannel);
		} catch (SftpException e) {
			throw new CATTException("Error occured while checking file on app server: " + e.getMessage());
		}

		if (isFilePresent) {
			logger.info("'"+filename +"' file is present on application server at location: " + sourcePath);
		}
		sftpChannel.disconnect();
		session.disconnect();
		
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			String status;
			if (isFilePresent) {
				status = CommonConstant.TRUE_VALUE;
			} else {
				status = CommonConstant.FALSE_VALUE;
			}
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), status);
		}

	}

	/**
	 * @param logger
	 * @param sourcePath
	 * @param destinationPath
	 * @param sftpChannel
	 * @throws SftpException
	 */
	private boolean checkFileIsPresentOnLinux(Logger logger, String sourcefilename, String sourcePath,
			ChannelSftp sftpChannel) throws SftpException {
		Vector<ChannelSftp.LsEntry> fileAndFolderList = sftpChannel.ls(sourcePath); // list of folder content
		Boolean isFilePresent = Boolean.FALSE;
		// Iterate through list of folder content
		for (ChannelSftp.LsEntry item : fileAndFolderList) {
			String fileName = item.getFilename();
			if (!item.getAttrs().isDir()) {
				tracelogger.info("Available file is : " + fileName);
				if (fileName.equals(sourcefilename)) {
					isFilePresent = Boolean.TRUE;
				}
			}
		}
		return isFilePresent;
	}

}
