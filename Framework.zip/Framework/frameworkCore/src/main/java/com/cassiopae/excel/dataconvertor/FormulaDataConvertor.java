/**
 * 
 */
package com.cassiopae.excel.dataconvertor;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class FormulaDataConvertor extends AbstractDataConvertor implements DataConvertor {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.selenium.excel.dataconvertor.DataConvertor#convertData(org.apache.poi.ss.
	 * usermodel.Cell, org.apache.poi.ss.usermodel.DataFormatter)
	 */
	@Override
	public String convertData(Cell cellvalue, DataFormatter dataFormatter, String locale, String worksSheetName) {
		String calculatedValue = null;
		if (!cellvalue.getCellFormula().contains("CONCATENATE")) {
			if (DateUtil.isCellDateFormatted(cellvalue)) {
				if(worksSheetName.contains(DBConstant.POS_MODULE)) {
					locale = DBConstant.POS_MODULE+CommonConstant.UNDER_SCORE+locale;
				}
				calculatedValue = CommonUtility.getFormatedDate(cellvalue, locale);
			} else {
				calculatedValue = CommonUtility.getNumericDataFormatted(cellvalue, dataFormatter, locale,worksSheetName);
			}
		} else {
			calculatedValue = cellvalue.getStringCellValue();
		}
		return calculatedValue;
	}
}
