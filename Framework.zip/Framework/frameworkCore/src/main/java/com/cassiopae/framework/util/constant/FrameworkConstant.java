package com.cassiopae.framework.util.constant;

import com.cassiopae.selenium.utils.date.DateDefination;

public interface FrameworkConstant {

	public String TODAY = DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator;
	public String CSV_TO_EXCEL = "ConverionCSVtoEXCEL.vbs";
	public String STATIC = "Static";
	public String REGEX_EXP_FOR_DECIMAL = "^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$";
	public String REGEX_EXP_FOR_FLOATING = "^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$";

	// IFrame Constants
	public String EVENT_PANEL_FRMAE = "//iframe[contains(@id,'s_bes_aae') or contains(@id,'jidInlinFrmC')]";
	public String CLIENT_AREA_FRMAE = "//iframe[contains(@id,'__CASSIOPAE_CLIENT_AREA_FRAME_ID__::f')]";
	public String PUSH_FRMAE = "//iframe[contains(@id,'afr::PushIframe')]";
	public String HEADER_FRAME = "//iframe[contains(@id,'header:s_bes_aae') or contains(@id,'header:jidInlinFrmC')]";
	public String OTHER_FRAME = "//iframe[contains(@id,'s_buy_aae') or contains(@id,'jidInlinFrmF')]";
	public String JAVASCRIPT_SCROLL = "arguments[0].scrollIntoView(false);";
	public String JAVASCRIPT_SCROLL_TRUE = "arguments[0].scrollIntoView(true);";
	public String POS = "POS";
	public String APPLICATION_ERROR_MSGS_XPATH = "//textarea[contains(@id,'tfdTechnicalDetails::content')]";
	public String APPLICATION_TECHNICAL_DEATILS_ERROR_XPATH = "//a[contains(@id,'lnkViewTechnicalDetails')]";
	public String APPLICATION_UAID_XPATH ="//input[@id='uaid']";
	public String APP_DATE_FORMAT = "AppDateFormat";
	public String LOCALE = "Locale";
	public String PRODUCT_TEAM = "Product team";
	public String TEST_TYPE_SAN_QA = "SAN";
	public String TEST_TYPE_REG_QA = "REG";

	// enterInputFieldData and Clear field actions
	public static final String CLEAR_FIELD_JAVASCRIPT = "arguments[0].value = '';";
	public static final String SET_INPUT_VALUE = "arguments[0].value = '";

	public String COMMON_TC_FOLDER_NAME = "Common";
	public String CBI_TC_FOLDER_NAME = "CBI";
	public String PRODUCT_FOLDER_NAME = "PRODUCT";
	public String END_COMPATIBILITY_VERSION_NEXT_VALUE_ = "_NEXT";
	public String END_COMPATIBILITY_VERSION_NEXT_VALUE = "NEXT";

	public String QA_CBI_SQL_FOLDER_NAME = "QA_CBI";
	public String QA_COMMON_SQL_FOLDER_NAME = "QA_Common";

	public String QA_CBI470_SQL_FOLDER_NAME = "QA_CBI_470";
	public String QA_COMMON470_SQL_FOLDER_NAME = "QA_Common_470";

	public String CBI_ENV_NMAE = "CBI";
	public String COMMON_ENV_NMAE = "COMMON";
	public String MOTOR_ENV_NMAE = "MOT";

	public String VERSION_470 = "4.7.0";
	public String VERSION_471 = "4.7.1";
	// jasper
	public String REGEX_EXP_FOR_RECEIVABLE = "^.*[R][0-9]{6}/[0-9]{7}\\s";
	public String REGEX_EXP_FOR_RECEIVABLE_WITHOUT_SPLIT = "^.*[R][0-9]{4,20}\\s";
	public String REGEX_EXP_FOR_FACTURE = "^.*[F][0-9]{4}/[0-9]{6}\\s";
	public String REGEX_EXP_FOR_DEPENSE = "^.*[D][0-9]{4}/[0-9]{6}\\s";
	public String REGEX_EXP_FOR_SIMULATION = "^.*[SIMU][0-9]{4,20}\\s";
	public String REGEX_EXP_FOR_EXPENSE = "^.*[D][0-9]{6}/[0-9]{7}\\s";

	// SQL pre requisites
	public String EXECUTED_USING_JDBC = "JDBC";
	public String EXECUTED_ON_DB_SERVER = "DB Server";
	
	// suite file names
	public String SUITE_FILE_CONSTANT_CONTENT = "Test_Suite";
	
	//Test jrxml constansta
	public String BO_FOLDER_NAME = "bo";
	public String MO_FOLDER_NAME = "mo";
	
	// ENV Variable constant
	public String BO_URL = "BackOfficeURL";
	public String MO_URL = "MiddleOfficeURL";
	public String POS_URL = "POSUrl";
	public String ConfigConsole_URL = "ConfigConsoleURL";
	
	public String username_DB_BO = "DB_BackOfficeUsername";
	public String password_DB_BO = "DB_BackOfficePassword";
	public String PortBO = "DB_BackOfficePort";
	public String iphostBO = "DB_BackOfficeHostname";
	public String dbsidBO = "DB_BackOfficeSID";
	
	public String username_DB_MO = "DB_MiddleOfficeUsername";
	public String password_DB_MO = "DB_MiddleOfficePassword";
	public String PortMO = "DB_MiddleOfficePort";
	public String iphostMO = "DB_MiddleOfficeHostname";
	public String dbsidMO = "DB_MiddleOfficeSID";
	
	public String applicationServerHostname = "Application_Server_Hostname";
	public String applicationServerUsername = "Application_Server_Username";
	
	public String tcUsername = "TC_Username";
	public String tcPassword = "TC_Password";
	
	public String installationDirectoryName = "AppInstallationDirectoryName";
	
	public String engageoneConnectorPort = "EngageoneConnectorPort";
	public String ariadnextdigisignConnectorPort = "AriadnextdigisignConnectorPort";
	public String externalratingprotectelConnectorPort = "ExternalratingprotectelConnectorPort";
	
}
