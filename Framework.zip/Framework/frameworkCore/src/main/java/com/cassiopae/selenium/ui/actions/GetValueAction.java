/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class GetValueAction implements PerformAction {

	/**
	 * This method execute action for get value action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String referenceValue = GenericAction.getTextValue(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		
		if (StringUtils.isEmpty(referenceValue)
				&& (excelTestCaseFieldsTO.getLocatorKey().contains(FunctionLocatorConstant.GENERATED_ACTOR_REFERENCE))
				|| excelTestCaseFieldsTO.getLocatorKey().contains(FunctionLocatorConstant.GENERATED_ASSET_REFERENCE)
				|| excelTestCaseFieldsTO.getLocatorKey()
						.contains(FunctionLocatorConstant.GENERATED_CONTRACT_REFERENCE)) {
			referenceValue = CommonUtility.getReferenceNumber(excelTestCaseFieldsTO, testCaseDetailTO, referenceValue);
		}
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), referenceValue);
		if (excelTestCaseFieldsTO.getExpectedResult() != null || excelTestCaseFieldsTO.getActualValue() != null) {
			String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
			String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
			GenericAction.assertEquals(variableHolderActualValue, variableHolderExpectedValue,
					excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
		}

	}

}
