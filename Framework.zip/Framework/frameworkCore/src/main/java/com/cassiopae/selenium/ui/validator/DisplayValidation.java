/**
 * 
 */

package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;

/**
 * @author jraut
 *
 */
public class DisplayValidation implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String validate = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				excelTestCaseFieldsTO.getInputTestData());
		String flag = GenericAction.isPresentAndDisplayed(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getErrorMessage(), excelTestCaseFieldsTO.getLocatorKey(),
				testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
				testCaseDetailTO.getReportingLogger(), validate);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), flag);

	}

}
