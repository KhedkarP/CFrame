package com.cassiopae.selenium.ui.validator;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.framework.xl.reader.GenericExcelFileReader;
import com.cassiopae.framework.xl.reader.GenericRow;
import com.cassiopae.framework.xl.reader.ReadExcelFile;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;

public class PaymentScheduleValidationUtility {
	private static Logger logger = LogManager.getLogger(PaymentScheduleValidationUtility.class);

	private PaymentScheduleValidationUtility() {

	}

	public static boolean comparePaymetScheduleExcel(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		boolean isFailed = false;
		String randomNo = RandomStringUtils.randomNumeric(5);
		String xlsFileName = testCaseDetail.getWorkSheetName() + CommonConstant.UNDER_SCORE
				+ randomNo + CommonConstant.CSV_FILE_EXTENSION;
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator
				+ testCaseDetail.getTestCaseCommonData().getBaseWorksheetName() + File.separator;
		// deleteExistingFile(downlodedPath);
		List<GenericRow> paymentScheduleList = null;
		Map<String, Integer> headerNameMapApp = new HashMap<>();

		String downloadFileName = getDownloadedPaymentScheduleFileName(
				testCaseDetail.getTestCaseCommonData().getLocale(), downlodedPath, testCaseDetail.getReportingLogger());
		validateFileDownload(downlodedPath, downloadFileName, testCaseDetail.getReportingLogger());
		if (renameFile(downlodedPath + downloadFileName, downlodedPath + xlsFileName,
				testCaseDetail.getReportingLogger())) {
			downloadFileName = xlsFileName;
		}
		paymentScheduleList = GenericExcelFileReader.readExcelFile(downlodedPath, downloadFileName,
				CommonConstant.PAYMENT_SCHEDULE_WORK_SHEET_NAME, CommonConstant.PAYMENT_SCHEDULE_COLUMNS,
				testCaseDetail.getTestCaseCommonData().getLocale(), headerNameMapApp,testCaseDetail.getWorkSheetName());

		String[] countOftotalStdXLSCompare = excelTestCaseFields.getInputTestData()
				.split(CommonConstant.TILDE_SEPARATOR);

		isFailed = processPaymentScheduleComparision(testCaseDetail, paymentScheduleList, headerNameMapApp,
				countOftotalStdXLSCompare);
		if (isFailed) {
			throw new CATTException(ReportLoggerConstant.PAYMENT_SCHEDULE_VALIDATION_FAILED_MESSAGE);
		}
		return isFailed;
	}
	
	public static boolean compareExcelCoulumnData(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		boolean isFailed = false;
		String randomNo = RandomStringUtils.randomNumeric(5);
		String xlsFileName = testCaseDetail.getWorkSheetName() + CommonConstant.UNDER_SCORE
				+ randomNo + CommonConstant.CSV_FILE_EXTENSION;
		String downlodedPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator
				+ testCaseDetail.getTestCaseCommonData().getBaseWorksheetName() + File.separator;
		// deleteExistingFile(downlodedPath);
		List<GenericRow> paymentScheduleList = null;
		Map<String, Integer> headerNameMapApp = new HashMap<>();

		String downloadFileName = getDownloadedPaymentScheduleFileName(
				testCaseDetail.getTestCaseCommonData().getLocale(), downlodedPath, testCaseDetail.getReportingLogger());
		validateFileDownload(downlodedPath, downloadFileName, testCaseDetail.getReportingLogger());
		if (renameFile(downlodedPath + downloadFileName, downlodedPath + xlsFileName,
				testCaseDetail.getReportingLogger())) {
			downloadFileName = xlsFileName;
		}
		
		String inputData[] = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String stdExcelSheetName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				inputData[0].split(CommonConstant.COMMA_SEPERATOR)[1]);
		paymentScheduleList = GenericExcelFileReader.readExcelFile(downlodedPath, downloadFileName,
				stdExcelSheetName, CommonConstant.PAYMENT_SCHEDULE_COLUMNS,
				testCaseDetail.getTestCaseCommonData().getLocale(), headerNameMapApp,testCaseDetail.getWorkSheetName());

		String[] countOftotalStdXLSCompare = excelTestCaseFields.getInputTestData()
				.split(CommonConstant.TILDE_SEPARATOR);
		isFailed = processPaymentScheduleComparision(testCaseDetail, paymentScheduleList, headerNameMapApp,
				countOftotalStdXLSCompare);
		if (isFailed) {
			throw new CATTException(ReportLoggerConstant.PAYMENT_SCHEDULE_VALIDATION_FAILED_MESSAGE);
		}
		return isFailed;
	}

	/**
	 * @param testCaseDetail
	 * @param validationStatus
	 * @param paymentScheduleList
	 * @param headerNameMapApp
	 * @param countOftotalStdXLSCompare
	 * @return
	 */
	private static boolean processPaymentScheduleComparision(TestCaseDetail testCaseDetail,
			List<GenericRow> paymentScheduleList, Map<String, Integer> headerNameMapApp,
			String[] countOftotalStdXLSCompare) {
		boolean validationStatus = false;
		boolean isFailed = false;
		for (int k = 0; k < countOftotalStdXLSCompare.length; k++) {

			String inputData[] = CommonUtility.splitStringUsingPattern(countOftotalStdXLSCompare[k],
					CommonConstant.PIPE_SEPARATOR);
			String stdExcelName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					inputData[0].split(CommonConstant.COMMA_SEPERATOR)[0]);
			String stdExcelSheetName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					inputData[0].split(CommonConstant.COMMA_SEPERATOR)[1]);

			Map<String, Integer> headerNameMapToCompare = new HashMap<>();
			List<GenericRow> compareTOList = null;
			String expectedExcelFilePath = DomainInitialization
					.initializeDomainwiseTestDataDocumentPath(testCaseDetail.getDomainName());
			compareTOList = ReadExcelFile.readExcelFile(expectedExcelFilePath, stdExcelName, stdExcelSheetName,
					testCaseDetail.getTestCaseCommonData().getLocale(), headerNameMapToCompare,testCaseDetail.getWorkSheetName());
			testCaseDetail.getReportingLogger().info(
					"*** Validate '" + stdExcelName + "' excel file against downloaded file from application ***");
			validationStatus = validateColumnData(paymentScheduleList, headerNameMapApp, inputData,
					headerNameMapToCompare, compareTOList, testCaseDetail.getReportingLogger());
			if (validationStatus) {
				testCaseDetail.getReportingLogger()
						.info(ReportLoggerConstant.PAYMENT_SCHEDULE_VALIDATION_PASSED_MESSAGE);
			} else {
				isFailed = true;
			}
		}
		return isFailed;
	}

	/**
	 * @param paymentScheduleList
	 * @param headerMapApp
	 * @param inputData
	 * @param headerMapToCompare
	 * @param compareTOList
	 */
	private static boolean validateColumnData(List<GenericRow> paymentScheduleList, Map<String, Integer> headerMapApp,
			String[] inputData, Map<String, Integer> headerMapToCompare, List<GenericRow> compareTOList,
			Logger reportingLogger) {
		int length = inputData.length;
		boolean validationFailed = true;
		for (int i = 1; i < length; i++) {
			String[] inputDataOfColumn = CommonUtility.splitString(inputData[i], CommonConstant.COMMA_SEPERATOR);
			String columnNamesOfAppFile = inputDataOfColumn[0];
			String columnNameOfStandardFile = inputDataOfColumn[1];
			int startRowNum = Integer.parseInt(inputDataOfColumn[2].trim());
			int endRowNum = Integer.parseInt(inputDataOfColumn[3].trim());
			columnNamesOfAppFile = StringUtils.trimToEmpty(columnNamesOfAppFile).replace(CommonConstant.SPACE,
					CommonConstant.EMPTY_STRING);
			columnNameOfStandardFile = StringUtils.trimToEmpty(columnNameOfStandardFile).replace(CommonConstant.SPACE,
					CommonConstant.EMPTY_STRING);
			if (headerMapApp.get(columnNamesOfAppFile) == null) {
				throw new CATTException(columnNamesOfAppFile
						+ ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_PAYMENT_APP_PAYMENT_SCHEDULE_FILE);
			}
			if (headerMapToCompare.get(columnNameOfStandardFile) == null) {
				throw new CATTException(
						columnNamesOfAppFile + ReportLoggerConstant.COLUMN_NOT_PRESENT_IN_STANDARD_TO_COMPARE_FILE);
			}
			int columnIndex = headerMapApp.get(columnNamesOfAppFile);
			int columnIndexForCom = headerMapToCompare.get(columnNameOfStandardFile);

			reportingLogger.info(ReportLoggerConstant.VALIDATION_START_MESSAGE + columnNameOfStandardFile);
			for (int rowNum = startRowNum - 1; rowNum < endRowNum; rowNum++) {
				GenericRow genericRow = paymentScheduleList.get(rowNum);
				GenericRow genericRowForComparision = compareTOList.get(rowNum);
				if (!StringUtils.equals(genericRow.getCellValue(columnIndex),
						genericRowForComparision.getCellValue(columnIndexForCom))) {
					validationFailed = false;
					reportingLogger.info(ReportLoggerConstant.VALIDATION_FAILED_MESSAGE + columnNamesOfAppFile
							+ ", for Row Number : " + (rowNum + 1));
					reportingLogger.error(ReportLoggerConstant.VALIDATION_FAILED_MESSAGE + columnNamesOfAppFile
							+ ", for Row Number : " + (rowNum + 1) + ",  Expected Value : "
							+ genericRowForComparision.getCellValue(columnIndexForCom) + " & Found : "
							+ genericRow.getCellValue(columnIndex));
					break;
				}
			}
			if (!validationFailed) {
				break;
			}
		}
		return validationFailed;
	}

	/**
	 * This method is used to get downloaded payment schedule.csv file name as per
	 * locale
	 * 
	 * @param locale
	 * @return Payment schedule File Name as per Locale
	 */
	private static String getDownloadedPaymentScheduleFileName(String locale, String downlodedPath,
			Logger reportinglogger) {
		String fileName = getFileNamePresentInFolder(downlodedPath, reportinglogger);
		if (fileName == null) {
			throw new CATTException("No file for validation present at location : " + downlodedPath);
		}
		if (fileName.contains(CommonConstant.XLSX_FILE_EXTENSION)
				|| fileName.contains(CommonConstant.CSV_FILE_EXTENSION)) {
			return fileName;
		} else {
			reportinglogger
					.info("File Comparison is configured for Excel/CSV files only. Other formats are not supported");
			throw new CATTException(
					"File Comparison is configured for Excel/CSV files only. Other formats are not supported");
		}

		/*
		 * if(locale.equals(ConvertorConstant.EN_US_LOCALE_KEY)) { return
		 * CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_US; } else if
		 * (locale.equals(ConvertorConstant.FR_FR_LOCALE_KEY)) { return
		 * CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_FR_FR; } else if
		 * (locale.equals(ConvertorConstant.EN_FR_LOCALE_KEY)){ return
		 * CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_FR; } return
		 * CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_US;
		 */
	}

	private static String getFileNamePresentInFolder(String downlodedPath, Logger reportinglogger) {
		File file = new File(downlodedPath);
		File[] filesList = file.listFiles();
		String fileName = null;
		String tempFileName = null;
		reportinglogger.info("Total Files at location '" + downlodedPath + "' are : " + filesList.length);
		for (int i = 0; i < filesList.length; i++) {
			tempFileName = filesList[i].getName();
			reportinglogger.info((i + 1) + ". " + tempFileName);
			if (CommonFunctions.validateExcelFileName(tempFileName,
					InitializeConstants.listofPaymentcalculationFileames)) {
				fileName = filesList[i].getName();
			} else {
				logger.warn("File is not considered for computation. Kindly check configuration in 'ExpectedPaymentCalculationFileNames.properties' files");
			}
		}
		return fileName;
	}

	private static boolean renameFile(String oldFile, String newFile, Logger reportingLogger) {
		File oldfile = new File(oldFile);
		File newfile = new File(newFile);

		if (oldfile.renameTo(newfile)) {
			reportingLogger.info("Downloaded file renamed successfully - " + newfile);
			return true;
		} else {
			reportingLogger.info("Renaming Of payment schedule file is failed ");
			return false;
		}
	}

	private static void deleteExistingFile(String folderPath) {
		if (null != folderPath) {

			for (File file : new File(folderPath).listFiles()) {
				if (file != null) {
					if (file.isFile() && (file.getName()
							.equals(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_US)
							|| file.getName().equals(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_EN_FR)
							|| file.getName().equals(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_FR_FR))) {
						logger.info("Deleting existing file - " + file.getName());
						if (file.delete()) {
							logger.info("File deleted successfully - " + file.getName());
						}
					}
				}
			}
		}
	}

	private static void validateFileDownload(String downloadPath, String fileName, Logger reportingLogger) {
		boolean fileDownloaded = false;
		if (null != downloadPath) {
			for (File file : new File(downloadPath).listFiles()) {
				if (file != null) {
					if (file.isFile() && file.getName().equals(fileName)) {
						fileDownloaded = Boolean.TRUE;
						break;
					}
				}
			}
		}
		if (!fileDownloaded) {
			reportingLogger.info(ReportLoggerConstant.PAYMENT_SCHEDULE_FILE_DOWNLOAD_FAILURE_MESSAGE + fileName);
			throw new CATTException(ReportLoggerConstant.PAYMENT_SCHEDULE_FILE_DOWNLOAD_FAILURE_MESSAGE + fileName);
		} else {
			reportingLogger.info(ReportLoggerConstant.PAYMENT_SCHEDULE_FILE_DOWNLOAD_SUCCESS_MESSAGE + fileName);
		}
	}

	/**
	 * This method is used to compare payment schedule from different Excel files
	 * 
	 * @param datainput
	 * @param locale
	 * @param domainName
	 * @param scenarioName
	 * @param className
	 * @param reportingLogger
	 * @deprecated this method is only wrapper of comparePaymetScheduleExcel
	 * @return Boolean True value if comparison successfull else False
	 */
	@Deprecated
	public static boolean wrapperComparePaymetScheduleExcel(String datainput, String locale, String domainName,
			String scenarioName, String className, Logger reportingLogger) {

		ExcelTestCaseFields excelTestCaseFields = new ExcelTestCaseFields();
		TestCaseDetail testCaseDetail = new TestCaseDetail();
		TestCaseCommonData caseCommonData = new TestCaseCommonData();
		caseCommonData.setLocale(locale);
		testCaseDetail.setTestCaseCommonData(caseCommonData);
		excelTestCaseFields.setInputTestData(datainput);
		testCaseDetail.setDomainName(domainName);
		testCaseDetail.setWorkBookName(className);
		testCaseDetail.setWorkSheetName(scenarioName);
		testCaseDetail.setReportingLogger(reportingLogger);
		return comparePaymetScheduleExcel(excelTestCaseFields, testCaseDetail);

	}
}
