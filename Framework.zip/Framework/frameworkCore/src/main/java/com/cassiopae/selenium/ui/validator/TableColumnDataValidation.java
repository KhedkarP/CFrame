/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import java.util.List;
import java.util.Map;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class TableColumnDataValidation implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());

		String locatorKey = excelTestCaseFields.getLocatorKey().trim();
		GenericAction.locator(locatorKey, locatorMap);
		String[] inputDataColumnValues = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getInputTestData(), CommonConstant.PIPE_SEPARATOR);
		String[] startEndRow = CommonUtility.splitString(inputDataColumnValues[0], CommonConstant.COMMA_SEPERATOR);
		if(CommonFunctions.checkArrayElementAreNumeric(startEndRow,testCaseDetail)) {
			testCaseDetail.getReportingLogger().error(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
			throw new CATTException(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE+excelTestCaseFields.getAction());
		}
		performTableColumnValidation(testCaseDetail, locatorMap, locatorKey, inputDataColumnValues);
	}
	
	/**
	 * This method will create dynamic Xpath and perform validation
	 * @param testCaseDetail
	 * @param locatorMap
	 * @param locatorKeys
	 * @param inputTestDataRowNumbers
	 * @param dataRowNumber
	 */
	private void performTableColumnValidation(TestCaseDetail testCaseDetail, Map<String, List<String>> locatorMap,
			String locatorKey, String[] inputDataColumnValues) {
		String dynamicXpathForGettingReference;
		String xpath = CommonFunctions.getLocatorKeyValue(locatorKey, locatorMap);
		String seleniumAction = inputDataColumnValues[1];
		String valueTobecompare = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				inputDataColumnValues[2].trim());	

		String[] startEndRow = CommonUtility.splitString(inputDataColumnValues[0], CommonConstant.COMMA_SEPERATOR);
		String startRow = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				startEndRow[0].trim());
		int startIndex = Integer.parseInt(startRow);
		int endIndex = Integer.parseInt(
				VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), startEndRow[1].trim()));
		if(testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS)) {
			startIndex = startIndex+1;
			endIndex = endIndex+1;
		}
		
		for (int k = startIndex - 1; k < endIndex; k++) {
			if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
				String[] prefixSufixID = SelectPanelTableEntryUtility
						.getPrefixAndSuffixID(CommonFunctions.getLocatorKeyValue(locatorKey, locatorMap));
				dynamicXpathForGettingReference = SelectPanelTableEntryUtility.constructXPath(k, prefixSufixID[0],
						prefixSufixID[1]);
			} else {
				dynamicXpathForGettingReference = CommonFunctions.parseQuestionMarkString(xpath,
						testCaseDetail.getVariableHolder(), String.valueOf(k));
			}
			GenericAction.checkGeneratedDynamicXpathVisibilityOnUI(dynamicXpathForGettingReference,
					testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());

			String referenceValue = SelectPanelTableEntryUtility.getValueForXPath(seleniumAction, testCaseDetail,
					dynamicXpathForGettingReference);
			if(testCaseDetail.getWorkSheetName().contains(FrameworkConstant.POS)){
				testCaseDetail.getReportingLogger().info("Value at row number "+k+" is : "+referenceValue);
			} else {
				testCaseDetail.getReportingLogger().info("Value at row number "+(k+1)+" is : "+referenceValue);
			}
			if (!referenceValue.equals(valueTobecompare)) {
				String errorMessage = "Exact match failed on row number : " + startIndex
						+ ",Actual value is : " + referenceValue + ", Expected : " + valueTobecompare;
				testCaseDetail.getReportingLogger().error(errorMessage);
				throw new CATTException(errorMessage);
			}

		}

	}

}
