/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author nkale
 *
 */
public class DragAndDrop implements PerformAction {

	/**
	 * This method execute action for get attribute title action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		GenericAction.dragAndDrop(excelTestCaseFieldsTO, testCaseDetailTO);
	}

}
