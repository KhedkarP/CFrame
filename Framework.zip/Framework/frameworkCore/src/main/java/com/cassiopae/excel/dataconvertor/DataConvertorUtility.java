package com.cassiopae.excel.dataconvertor;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.excel.dataconvertor.constant.ConvertorConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class DataConvertorUtility {

	private DataConvertorUtility() {
	}
	
	private static Logger logger = LogManager.getLogger(DataConvertorUtility.class);

	
	/**
	 * This method used to convert amount present in database/event summary panel to current amount format of application
	 * @param testCaseDetailTO
	 * @param amount
	 * @return locale specific amount value which will be displayed on application
	 */
	public static String covertDataToUIFormat(TestCaseDetail testCaseDetailTO, String amount) {
		if (CommonUtility.checkForDecimal(amount)) {
			return convertAmountAsPerLocale(testCaseDetailTO, amount);
		} else {
			// convert given value in decimal format first and then covert it into locale specific format
			String convertedDecimalValue = convertAmountInDecimalFormat(amount);
			if (CommonUtility.checkForDecimal(convertedDecimalValue)) {
				return convertAmountAsPerLocale(testCaseDetailTO, convertedDecimalValue);
			} else {
				logger.error("Amount is not converted correctly in decimal format : " + amount);
				testCaseDetailTO.getReportingLogger()
						.warn(ErrorMessageConstant.INVALID_DATA_FORMAT_FOR_AMOUNT_CONVERSION_FROM_DB_TO_UI);
				throw new CATTException(ErrorMessageConstant.INVALID_DATA_FORMAT_FOR_AMOUNT_CONVERSION_FROM_DB_TO_UI);
			}
		}
	}

	/** This method converts amount in decimal format into current application locale format
	 * @param testCaseDetailTO
	 * @param decimalValue
	 * @return locale specific converted amount value
	 */
	public static String convertAmountAsPerLocale(TestCaseDetail testCaseDetailTO, String decimalValue) {
		String calculatedValue = null;
		BigDecimal bigDecimalCurrency = new BigDecimal(decimalValue);
		if (ConvertorConstant.FR_FR_LOCALE_KEY.equals(testCaseDetailTO.getTestCaseCommonData().getLocale())
				|| ConvertorConstant.EN_FR_LOCALE_KEY
						.equals(testCaseDetailTO.getTestCaseCommonData().getLocale())) {
			int scale = CommonUtility.getScaleValue(bigDecimalCurrency);
			calculatedValue = CommonUtility.formatAmountToFranceLocale(bigDecimalCurrency,
					testCaseDetailTO.getTestCaseCommonData().getLocale(), scale);
		} else {
			int scale = CommonUtility.getScaleValue(bigDecimalCurrency);
			calculatedValue = CommonUtility.formateAmountToUSLocale(bigDecimalCurrency,
					testCaseDetailTO.getTestCaseCommonData().getLocale(), scale);
		}
		return calculatedValue;
	}
	
	/**
	 * This method converts the given value in decimal format
	 * @param value
	 * @return decimal value
	 */
	public static String convertAmountInDecimalFormat(String value) {
		String amount = value;
		amount = amount.replaceAll(CommonConstant.COMMA_SEPERATOR, CommonConstant.EMPTY_STRING);
		amount = amount.replaceAll(CommonConstant.SPACE, CommonConstant.EMPTY_STRING);
		amount = StringUtils.replaceChars(amount, CommonConstant.DOT_OPERATOR, CommonConstant.EMPTY_STRING);
		int len = amount.length();
		StringBuilder sb = new StringBuilder(amount);
		sb.insert(len - 2, CommonConstant.DOT_OPERATOR);
		return sb.toString();
	}

	
}
