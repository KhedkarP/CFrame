package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class XLSPutValueInExcel implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		String[] inputValue = CommonUtility.splitString(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.COMMA_SEPERATOR);
		int referenceColumnNumber = Integer.parseInt(inputValue[0].trim());
		String value = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputValue[1].trim());

		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + " : " + value);
		int excelColumnNumber = CommonUtility.getGeneratedReferenceColumn(referenceColumnNumber);
		CommonUtility.updateReferenceToStatusSheet(value, excelColumnNumber,
				testCaseDetailTO.getTestCaseCommonData());
	}

	
	

}
