/**
 * 
 */
package com.cassiopae.framework.exception;

/**
 * @author nbhil
 *
 */
public class CATTSQLException extends CATTException {

	private static final long serialVersionUID = 417226994293535010L;

	public CATTSQLException(final String message) {
		super(message);
	}

	public CATTSQLException() {
		super();
	}

}
