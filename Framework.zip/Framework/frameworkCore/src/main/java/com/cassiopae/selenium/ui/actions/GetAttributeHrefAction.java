/**
 *
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author abisaria
 *
 */
public class GetAttributeHrefAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String hrefAttributeValue = GenericAction.getAttributeHref(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
				testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());

		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + hrefAttributeValue);

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), hrefAttributeValue);
		}
	}

}
