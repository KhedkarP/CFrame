package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;


public class CasflowCollectionDisbursement {
	
	/*  Disbursement Functions 
	 */
    	
    private static Map<String, List<String>> cashFlowLocator=ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.CASHFLOW_LOCATOR);
    
	public static void navigateTo(WebDriver driver, Logger logger){
		GenericAction.mouseHoverOn(FunctionReportingConstant.CASHFLOW_MOUSE_HOVER, FunctionLocatorConstant.CASHFLOW_MENU, cashFlowLocator, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.CASHFLOW_COLLECTION_DISBURSEMENT_SUB_MENU, FunctionLocatorConstant.CASHFLOW_COLLECTIONDISBURSEMENT_SUB_MENU, cashFlowLocator, driver, logger);
	}	
	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail){
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_CASHFLOW_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.CASHFLOW_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(cashFlowLocator);
		GenericAction.enterValueIn(reference,excelTestCaseFields,testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_CASHFLOW_REFERENCE_ICON , FunctionLocatorConstant.CASHFLOW_SEARCH_ICON, cashFlowLocator, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_CASHFLOW_REFERENCE_HYPERLINK, FunctionLocatorConstant.CASHFLOW_REFERNCE_HYPERLINK, cashFlowLocator, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
