/**
 * 
 */
package com.cassiopae.selenium.ui.functions.constant;

/**
 * @author jraut
 *
 */
public interface FunctionLocatorConstant {

	String LAST_ICON_OF_PAGINATION = "//img[contains(@id,'tbTableToolbar:last::icon')]";
	String CURRENT_PAGE_LABEL_XPATH="PaginationScreen.span.pagecount";

	String ACTOR_MENU = "actor.a.actors";
	String ACTOR_SUB_MENU = "actor.tr.actors";
	String ACTOR_INPUT_REFERENCE = "actor.search.input.Reference";
	String ACTOR_SEARCH_ICON = "actor.DFsearch.img.SearchActor";
	String ACTOR_REFERNCE_HYPERLINK = "actor.find.a.OpenActor";
	String WINDOW_LOCATOR = "//html";
	String MORE_ICON = "Events.span.More";
	String POS_EVENT_DROPDOWN_KEY = "Events.button.OpenMenu";

	String POS_MYDEALS="//a[@href='#/pos/deals']";
	String DIV_ELEMENT="//div";
	String ASSET_MENU = "asset.a.asset";
	String ASSET_SUB_MENU = "asset.td.Asset";
	String ASSET_INPUT_REFERENCE = "asset.input.Asset";
	String ASSET_SEARCH_ICON = "asset.div.search";
	String ASSET_REFERNCE_HYPERLINK = "Asset.a.Asset_Ref";

	String CONSTRUCTION_MENU = "Construction.a.Construction";
	String CONSTRUCTION_SUB_MENU = "Construction.td.Constructionsubmodule";
	String CONSTRUCTION_INPUT_REFERENCE = "Construction.DFsearch.input.Constructionref";
	String CONSTRUCTION_SEARCH_ICON = "Construction.DFsearch.div.searchicon";
	String CONSTRUCTION_REFERNCE_HYPERLINK = "Construction.DFsearch.a.Number";

	String CASHFLOW_MENU = "cashflow.a.cahsflow module";
	String CASHFLOW_COLLECTIONDISBURSEMENT_SUB_MENU = "cashflow.a.cahsflow submodule";
	String CASHFLOW_INPUT_REFERENCE = "CashFlow.input.Reference";
	String CASHFLOW_SEARCH_ICON = "Cashflow.SearchFilter.img.ContractSearchicon";
	String CASHFLOW_REFERNCE_HYPERLINK = "Cash Flow.a.Cashflow Ref";

	String CONTRACT_MENU = "contract.a.contract";
	String CONTRACT_SUB_MENU = "contract.tr.contract";
	String CONTRACT_INPUT_REFERENCE = "contract.Dfsearch.input.contractrefrence";
	String CONTRACT_SEARCH_ICON = "contract.div.Search";
	String CONTRACT_REFERNCE_HYPERLINK = "contract.a.Open";

	String DEAL_MENU = "Deal.a.Deal";
	String DEAL_SUB_MENU = "Deal.td.listofdeal";
	String DEAL_INPUT_REFERENCE = "Deal.input.referance";
	String DEAL_SEARCH_ICON = "Deal.tr.Search";
	String DEAL_REFERNCE_HYPERLINK = "Deal.a.Fristref";

	String EXPENSE_MENU = "Expenses.a.Expenses";
	String EXPENSE_SUB_MENU = "Expenses.td.ExpensesSubmenu";
	String EXPENSE_INPUT_REFERENCE = "Expenses.DFsearch.input.ExpenseReference";
	String EXPENSE_SEARCH_ICON = "Expenses.DFsearch.div.searchicon";
	String EXPENSE_REFERNCE_HYPERLINK = "Expenses.DFSearch.a.Number";

	String GENERATED_ACTOR_REFERENCE = "identity.general.span.actorReference";
	String GENERATED_ASSET_REFERENCE = "asset.label.Asset_ref";
	String GENERATED_CONTRACT_REFERENCE = "Contract Details.label.contract Reference";
	String GENERATED_PROPERTY_REFERENCE = "Property Detail.span.Property";

	String RECEIVABLES_MENU = "Receivable.a.ReceivableMenu";
	String RECEIVABLES_SUB_MENU = "Receivable.td.ReceivableSubMenu";
	String RECEIVABLES_INPUT_REFERENCE = "Receivable.DFSearch.input.Number";
	String RECEIVABLES_SEARCH_ICON = "Receivable.Search.div.Seaechicon";
	String RECEIVABLES_REFERNCE_HYPERLINK = "ListofReceivables.a.receivableref";

	String SITES_SUB_MENU = "asset.td.Properties";
	String IMMOBILIERS_SUB_MENU_OF_SITES = "asset.property.td.Properties";
	String PROPERTY_INPUT_REFERENCE = "Property Details.input.Reference";
	String PROPERTY_SEARCH_ICON = "Properties.img.Search Reference";
	String PROPERTY_REFERNCE_HYPERLINK = "Properties.a.Properties_Row1";
	String OVERFLOW_ICON_BO = "General.div.ovelfowIcon";
	String OVERFLOW_ICON_MO = "General.div.ovelfowIconMO";
	//DownloadFile
	String LOCATION_URL="window.open = function(url) {window.location=url}";
	
	
	//selectDropdownPOS
	String SELECT_CONTROL_KEY ="//div[@class='Select-control']";
	//selectDropdownPOS
	String SELECT_CONTROL_KEY_CONFIGCONSOLE ="//div[contains(@class,'k-react-select__control')]";
	String SELECT_CONTROl_KEY = "//div[contains(@class,'k-react-select__option')]";
	//Drag and drop POS
	String DRAG_AND_DROP_JS="function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n"
            + "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n" + "data: {},\n"
            + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
            + "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n"
            + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
            + "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
            + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
            + "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
            + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
            + "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n"
            + "var dropEvent = createEvent('drop');\n"
            + "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
            + "var dragEndEvent = createEvent('dragend');\n"
            + "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
            + "var source = arguments[0];\n" + "var destination = arguments[1];\n"
            + "simulateHTML5DragAndDrop(source,destination);";
	
	String COLLATERAL_MENU = "Collatral.a.collatral";
	String COLLATERALS_SUB_MENU = "Collatral.td.collatral";
	String COLLATERALS_INPUT_REFERENCE = "Collaterals.input.Number";
	String COLLATERALS_SEARCH_ICON = "Collaterals.img.find";
	String COLLATERALS_REFERNCE_HYPERLINK = "Collaterals.a.collateral reference";
	String LOOKUP_VALUE = "//following::div";
	
	
}
