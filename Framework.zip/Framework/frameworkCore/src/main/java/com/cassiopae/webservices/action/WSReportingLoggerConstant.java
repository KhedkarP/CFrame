package com.cassiopae.webservices.action;

public interface WSReportingLoggerConstant {
	String WEBSERVICES_PARAMETERLIST = "Webservices ParametersList > ";
	String REST_BODY_RESPONSE = "Rest body response > ";
	String FETCH_BODY_RESPONSE = "Inavid Body format";
	String THE_HEADER_MSG = "The header from the Post URL is: ";
	String SESSION_ID_MESSAGE = "Generated Login request sessionID is: ";
	String COOKIE_ID_MESSAGE = "Generated Login request cookie is: ";
	String REQUEST_URL_MSG = "Login request end point is: ";
	String LOGIN_REST_API_MSG = "Login via REST API with end point: ";
	String USERNAME_MSG="Username: '";
	String PASSWORD_MSG="Password: '";
	String AND_MSG="' and ";
	String USING=" using ";
	
	String THE_LOGIN_REUEST_MESSGE = "The login request from the post URL is created > ";
	public String CHECK_INPUT_URL = "The input URL provided is incorrect ";
	public String Check_THE_REQUESTED_LOGIN_HEADER = "Has been deleted or modified";
	public String Check_THE_JSON_REQUEST_BODY_CREATED = "Created Request body for DataSet  ";
	public String THE_REST_API_RESPONSE_Body = "Response body is: ";
	public String THE_REST_API_REQUEST_Body = "Request body is: ";
	public String THE_REST_API_RESPONSE_Code = "Response code is: ";
	public String VALIFDATION_OF_RESPOSE_MESSAGE = "The repose code validation is successfull :";
	String REQUEST_END_POINT = "Request end point is: ";
	String LOGIN_REQUEST_FAILED_ERROR_MESSAGE = "Login REST webservice is not executed successfully: ";
	public String STATUSCODE_MSG ="StatusCode";
	public String RESPONSEBODY_MSG="ResponseBody";
	public String REQUEST_NAME="_Request_";
	public String RESPONSE_NAME="_Response_";
	public String RETRIVED_VALUE="Retrived value of ";
	public String FACING_ISSUE_READING_FILE_MSG=" Facing issue while reading Json request file, please check file at location: ";
	public String FILE_READING_ISSUE_MESSAGE=" Facing issue while reading Json request file: ";
	public String JSON_FILE_WRITE_MESSAGE=" Facing issue writing response to json file: ";
	
	public String PARAMETER=" parameter ";
	

	
}
