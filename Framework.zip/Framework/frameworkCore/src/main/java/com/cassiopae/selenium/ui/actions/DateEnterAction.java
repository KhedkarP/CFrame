/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateUtils;

/**
 * @author jraut
 * @author mshaik [Enhancements]
 *
 */
public class DateEnterAction implements PerformAction {
	private static Logger logger = LogManager.getLogger(DateEnterAction.class);

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {

		final String logMessage = excelTestCaseFields.getTestCaseSteps();
		final String testData = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				excelTestCaseFields.getInputTestData());
		final String xpathKey = excelTestCaseFields.getLocatorKey();
		final Map<String, List<String>> locatorHM = testCaseDetail.getLocatorHashMap();
		final WebDriver driver = testCaseDetail.getDriver();
		final Logger reportingLogger = testCaseDetail.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
		if (testData == null) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.TESTDATA_VALUE_NULL
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.TESTDATA_VALUE_NULL);
		}
		By by = GenericAction.locator(xpathKey, locatorHM);
		WebElement element = GenericAction.getWebElement(driver, by, reportingLogger);
		if (GenericAction.checkElementOnUI(element, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);

			if (!StringUtils.isEmpty(element.getAttribute(ReportLoggerConstant.VALUE))) {
				element.click();
				logger.warn(ErrorMessageConstant.DATE_FIELD_NOT_EMPTY_MSG);
				element.sendKeys(Keys.chord(Keys.CONTROL + "a") + Keys.DELETE);
			}
			element.click();
			CommonFunctions.explicitWait(100);
			int year=DateUtils.processInputDateAndGetYear(testData);
			String month=DateUtils.processInputDateAndGetMonth(testData, testCaseDetail);
			String day=DateUtils.processInputDateAndGetDay(testData);
			DateUtils.selectYear(year, excelTestCaseFields, testCaseDetail);
			DateUtils.selectMonth(month, testCaseDetail, excelTestCaseFields);
			DateUtils.selectDay(day, testCaseDetail);
		}
	}

	@Deprecated
	public void typeInField(WebElement element, String value) {
		String val = value;
		if (!StringUtils.isEmpty(element.getAttribute(ReportLoggerConstant.VALUE))) {
			System.err.println("Date field is not empty, clearing it");
			element.click();
			element.sendKeys(Keys.chord(Keys.CONTROL + "a") + Keys.DELETE);
		}
		CommonFunctions.explicitWait(100);
		StringBuilder s = new StringBuilder();
		for (int i = 0; i < val.length(); i++) {
			char c = val.charAt(i);
			s.append(c);
			if (i == 1 || i == 3 || i == 7) {
				element.sendKeys(s);
				s = new StringBuilder();
				CommonFunctions.explicitWait(400);
			}
		}
	}

}
