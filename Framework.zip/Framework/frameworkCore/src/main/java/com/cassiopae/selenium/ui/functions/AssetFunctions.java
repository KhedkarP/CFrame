package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class AssetFunctions  {

	/*
	 * Asset Functions
	 */

	private static Map<String, List<String>> assetLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.ASSET_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger logger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.ASSET_MOUSE_HOVER, FunctionLocatorConstant.ASSET_MENU, assetLocatorMap, driver, logger);
		GenericAction.clickOn(FunctionReportingConstant.ASSET_SUB_MENU, FunctionLocatorConstant.ASSET_SUB_MENU, assetLocatorMap, driver, logger);
	}

	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_ASSET_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.ASSET_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(assetLocatorMap);
		GenericAction.enterValueIn(reference,excelTestCaseFields, testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_ASSET_REFERENCE_ICON,FunctionLocatorConstant.ASSET_SEARCH_ICON, assetLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_ASSET_REFERENCE_HYPERLINK + reference, FunctionLocatorConstant.ASSET_REFERNCE_HYPERLINK, assetLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
