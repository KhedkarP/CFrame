/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class EnterInputValueAction implements PerformAction {

    /**
     * This method execute action for enter input value action.
     * @param excelTestCaseFieldsTO ExcelTestCaseFields
     * @param testCaseDetailTO      TestCaseDetail
     */
    @Override
		public void executeAction(ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail)
	{
		String inputTestDataValue = null;
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		inputTestDataValue = CommonFunctions.getInputTextBoxData(excelTestCaseFields);
		if (!StringUtils.isEmpty(inputTestDataValue)
				&& inputTestDataValue.trim().startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)
				&& inputTestDataValue.trim().endsWith(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)) {
			inputTestDataValue = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					inputTestDataValue);
		}
		GenericAction.enterValueIn(inputTestDataValue, excelTestCaseFields, testCaseDetail);
		if (!StringUtils.isEmpty(excelTestCaseFields.getStoreValuesInVariable())) {
			testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), inputTestDataValue);
		}

	}

}
