package com.cassiopae.webservices.action;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

import io.restassured.path.json.JsonPath;

public class RESTAPIGetResponseData implements WSAction {

	private static Logger log = LogManager.getLogger(RESTAPIGetResponseData.class);

	@Override
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getTestCaseCommonData().getReportingLogger();
		String[] inputTestData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String responseBody = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestData[0]);
		String[] requiredData = inputTestData[1].split(CommonConstant.COMMA_SEPERATOR);
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		JsonPath jsonPath = new JsonPath(responseBody);
		int count = 0;
		String[] variablesList = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getStoreValuesInVariable(),
				CommonConstant.COMMA_SEPERATOR);
		if (requiredData.length == variablesList.length) {
			for (String parameter : requiredData) {
				try {
					String parvalue = jsonPath.getString(parameter);
					if (parvalue == null) {
						reportingLogger.error(WSErrorMessageConstant.INPUT_PARAMETER + parameter
								+ WSErrorMessageConstant.NOT_AVAILABLE_MSG + responseBody);
						throw new CATTException(WSErrorMessageConstant.INPUT_PARAMETER + parameter
								+ WSErrorMessageConstant.NOT_AVAILABLE_MSG + responseBody);
					}
					reportingLogger.info(WSReportingLoggerConstant.RETRIVED_VALUE +WSReportingLoggerConstant.PARAMETER + "'"+variablesList[count] + "'" +CommonConstant.SPACE
							+ CommonConstant.COLON_SEPERATOR +CommonConstant.SPACE+ parvalue);
					testCaseDetailTO.getVariableHolder().put(variablesList[count], parvalue);
				} catch (ClassCastException e) {
					log.error(e);
				}
				count++;
			}
		} else {
			reportingLogger.error(WSErrorMessageConstant.PARAMETERS_IMPROPER_ERRORMSG);
			throw new CATTException(WSErrorMessageConstant.PARAMETERS_IMPROPER_ERRORMSG);
		}
	}
}