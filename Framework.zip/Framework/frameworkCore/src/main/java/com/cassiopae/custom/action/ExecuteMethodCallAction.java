/**
 * 
 */
package com.cassiopae.custom.action;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class ExecuteMethodCallAction implements CustomAction {

	/**
	 * This method execute action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@SuppressWarnings("rawtypes")
	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String[] inputTest = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String[] methodArgumentType = inputTest.length > 3
				? CommonUtility.splitStringUsingPattern(inputTest[3], CommonConstant.COMMA_SEPERATOR)
				: null;
		Object[] parameterValue = inputTest.length > 3
				? CommonUtility.splitStringUsingPattern(inputTest[4], CommonConstant.COMMA_SEPERATOR)
				: null;
		Class[] parameterTypes = null;
		parameterTypes = getParameterType(inputTest, methodArgumentType, parameterTypes);
		boolean isInstanceMethod = isInstanceMethodCall(inputTest[0]);
		Object resultObject = CommonUtility.reflectionCall(inputTest[1], inputTest[2], parameterTypes, parameterValue,
				isInstanceMethod);

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					String.valueOf(resultObject));
		}

	}

	/**
	 * This method return the argument type.
	 * 
	 * @param inputTest          String[]
	 * @param methodArgumentType String[]
	 * @param parameterTypes     Class[]
	 * @return Class[]
	 */
	@SuppressWarnings("rawtypes")
	private Class[] getParameterType(String[] inputTest, String[] methodArgumentType, Class[] parameterTypes) {
		if (inputTest.length > 3 && methodArgumentType != null) {
			parameterTypes = new Class[methodArgumentType.length];
			CommonUtility.getMethodArgumentType(methodArgumentType, parameterTypes);
		}
		return parameterTypes;
	}

	/**
	 * This method return true when it is instance method or Non static method.
	 * 
	 * @param methodType String
	 * @return boolean boolean
	 */
	private boolean isInstanceMethodCall(String methodType) {
		boolean isInstanceMethod = true;
		if (FrameworkConstant.STATIC.equals(methodType)) {
			isInstanceMethod = false;
		}
		return isInstanceMethod;
	}

}
