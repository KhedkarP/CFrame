/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.functions.PanelTableFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;

/**
 * @author jraut
 *
 */
public class PanelTableFunctionExecutor implements FunctionExecutor {

	@Override
	public void executeFunction(String methodName, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
			testCaseDetail.getTestCaseCommonData().getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
			// String[] inputData = CommonUtility.getInputData(excelTestCaseFields, testCaseDetail);
			
			if (FunctionConstant.VALIDATE_ENTRIES.equals(methodName)) {
				PanelTableFunctions.validatePanelTableEntries(excelTestCaseFields,testCaseDetail);
			}
	}
}
