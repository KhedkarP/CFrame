/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebElement;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class GetCountOfElementAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Map<String, List<String>> locatorHashMap = ObjectRepoInitialization.masterLocatorMap.get( excelTestCaseFieldsTO.getModule() );
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		List<WebElement> elementsList = testCaseDetailTO.getDriver().findElements(GenericAction.locator(excelTestCaseFieldsTO.getLocatorKey(), locatorHashMap));
		testCaseDetailTO.getReportingLogger().info("Total Number Of Element Found are : "+elementsList.size());
		if(excelTestCaseFieldsTO.getStoreValuesInVariable() !=null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), String.valueOf(elementsList.size()));
		}
	}

}
