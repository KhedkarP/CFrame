package com.cassiopae.framework.dao.constant;

public interface DBConstant {

	public String BO_MODULE = "BO";
	public String MO_MODULE = "MO";
	public String POS_MODULE = "POS";
	public String DRIVER_URL = "jdbc:oracle:thin:@";
	public String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver";
	
	public String BO_APP_SHEET_NAME = "_BO_";
	public String MO_APP_SHEET_NAME = "_MO_";
	public String CC_APP_SHEET_NAME = "CC_";
	public String API_APP_SHEET_NAME = "_API_";
}
