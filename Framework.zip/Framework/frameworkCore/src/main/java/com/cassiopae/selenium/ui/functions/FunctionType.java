/**
 * 
 */
package com.cassiopae.selenium.ui.functions;

import java.util.HashSet;
import java.util.Set;

/**
 * @author jraut
 *
 */
public enum FunctionType {
    
    Function_Asset_open,
    Function_Actor_open,
    Function_Contract_open,
    Function_Construction_open,
    Function_Deal_open,
    Function_Deal_navigateTo,
    Function_Deal_checkDealIsSaved,
    Function_CollectionDisbursement_open,
    Function_Expenses_open,
    Function_Receivables_open,
    Function_Property_open,
    Function_Asset_navigateTo,
    Function_Actor_navigateTo,
    Function_Contract_navigateTo,
    Function_Construction_navigateTo,
    Function_CollectionDisbursement_navigateTo,
    Function_Expenses_navigateTo,
    Function_Receivables_navigateTo,
    Function_Common_login,
    Function_Common_logout,
    Function_Property_navigateTo,
    Function_Common_navigateToTab,
    Function_Common_navigateToEvent,
    Function_Common_navigateToMainModule,
    Function_Table_ValidateEntries,
    Function_Collaterals_open,
    Function_Collaterals_navigateTo;
    
    private static HashSet<String> functionTypeSet = null;

	public static Set<String> getFunctionType() {
		if (functionTypeSet == null) {
		    functionTypeSet = new HashSet<String>();
			for (FunctionType action : FunctionType.values()) {
			    functionTypeSet.add(action.name());
			}
		}
		return functionTypeSet;
	}

}
