package com.cassiopae.webservices.action;

import java.util.regex.Pattern;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.webservices.action.util.RestWSUtility;

import io.restassured.response.Response;

public class RWSLoginRequest implements WSAction {

	@Override
	@Deprecated // Action is deprecated now please refer RESTAPILoginRequest
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String userName = testCaseDetailTO.getTestCaseCommonData().getUserName();
		String password = testCaseDetailTO.getTestCaseCommonData().getPassword();

		reportingLogger.info(
				WSReportingLoggerConstant.REQUEST_URL_MSG + ApplicationContext.baseUrlBO + WSCommonConstants.LoginURL);
		Response responseObject = RestWSUtility.executeLoginRestService(userName, password);
		String generatedSessionID = responseObject.getHeader(WSCommonConstants.SESSION_TOKEN);
		reportingLogger.info(WSReportingLoggerConstant.SESSION_ID_MESSAGE + generatedSessionID);
		String cookies = RestWSUtility.generateCookie(responseObject);
		reportingLogger.info(WSReportingLoggerConstant.COOKIE_ID_MESSAGE + cookies);
		reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + responseObject.asString());
		int loginResponseCode = responseObject.getStatusCode();
		String[] storeValueInVariable = excelTestCaseFieldsTO.getStoreValuesInVariable()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));

		String[] tokens = storeValueInVariable[2].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[0], String.valueOf(loginResponseCode));
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[1], responseObject.asString());
			testCaseDetailTO.getVariableHolder().put(tokens[0], String.valueOf(generatedSessionID));
			testCaseDetailTO.getVariableHolder().put(tokens[1], String.valueOf(cookies));
		}
	}
}
