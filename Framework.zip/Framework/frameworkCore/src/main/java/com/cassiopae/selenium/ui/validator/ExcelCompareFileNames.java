/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import java.util.HashSet;
import java.util.Set;

import com.cassiopae.framework.util.constant.CommonConstant;

/**
 * @author jraut
 *
 */
public class ExcelCompareFileNames {
	
	protected static Set<String> fileNameSet = new HashSet<>();
	public static Set<String> getExcelFileNames() {
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME);
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_FR_FR);
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_INTEREST_CALCULATION_FILE_NAME);
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_AMMORTIZATION);
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_AMMORTIZATION_1);
		fileNameSet.add(CommonConstant.DOWNLOADED_PAYMENT_SCHEDULE_FILE_NAME_REIMBOURSEMENT);
		fileNameSet.add(CommonConstant.DOWNLOADED_INVOICING_SCHEDULE_FILE_NAME);
		fileNameSet.add(CommonConstant.DOWNLOADED_RECORDS_LIST_FILE_NAME);
		return fileNameSet;
	}
	
}
