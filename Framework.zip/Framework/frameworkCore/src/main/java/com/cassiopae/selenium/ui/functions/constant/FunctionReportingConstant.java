package com.cassiopae.selenium.ui.functions.constant;

public interface FunctionReportingConstant {
    
    String ACTOR_MOUSE_HOVER="Mouse Hover on Actor Menu";
    String ACTOR_SUB_MENU="Click on Actors Sub-Menu";
    String ENTER_ACTOR_REFERENCE_NUMBER="Enter Actor reference Number ";
    String CLICK_ON_SEARCH_ACTOR_REFERENCE_ICON="Click on Search Icon to find Actor ";
    String CLICK_ON_ACTOR_REFERENCE_HYPERLINK="Click on Actor reference Hyper link to open Actor - ";
    
    String ASSET_MOUSE_HOVER="Mouse Hover on Asset Menu";
    String ASSET_SUB_MENU="Click on Asset Sub-Menu";
    String ENTER_ASSET_REFERENCE_NUMBER="Enter Asset reference Number ";
    String CLICK_ON_SEARCH_ASSET_REFERENCE_ICON="Click on Search Icon to find Asset ";
    String CLICK_ON_ASSET_REFERENCE_HYPERLINK="Click on Asset reference Hyper link to open Asset - ";

    String CASHFLOW_MOUSE_HOVER="Mouse Hover on Cashflow Menu";
    String CASHFLOW_COLLECTION_DISBURSEMENT_SUB_MENU="Click on Collection and Disbursement sub-Menu";
    String ENTER_CASHFLOW_REFERENCE_NUMBER="Enter Cashflow reference Number ";
    String CLICK_ON_SEARCH_CASHFLOW_REFERENCE_ICON="Click on Search Icon to find Cashflow ";
    String CLICK_ON_CASHFLOW_REFERENCE_HYPERLINK="Click on Cashflow reference Hyper link to open Cashflow - ";
 
    String CONSTRUCTION_MOUSE_HOVER="Mouse Hover on Construction Menu";
    String CONSTRUCTION_SUB_MENU="Click on Construction Sub-Menu";
    String ENTER_CONSTRUCTION_REFERENCE_NUMBER="Enter Construction reference Number ";
    String CLICK_ON_SEARCH_CONSTRUCTION_REFERENCE_ICON="Click on Search Icon to find Construction ";
    String CLICK_ON_CONSTRUCTION_REFERENCE_HYPERLINK="Click on Construction reference Hyperlink to open Construction - ";
    
    String CONTRACT_MOUSE_HOVER="Mouse Hover on Contract Menu";
    String CONTRACT_SUB_MENU="Click on Contract Sub-Menu";
    String ENTER_CONTRACT_REFERENCE_NUMBER="Enter Contract reference Number ";
    String CLICK_ON_SEARCH_CONTRACT_REFERENCE_ICON="Click on Search Icon to find Contract ";
    String CLICK_ON_CONTRACT_REFERENCE_HYPERLINK="Click on Contract reference Hyperlink to open Contract - ";
    
    String DEAL_MOUSE_HOVER="Mouse Hover on Deal Menu";
    String DEAL_SUB_MENU="Click on List of Deal Sub-Menu";
    String ENTER_DEAL_REFERENCE_NUMBER="Enter Deal reference Number ";
    String CLICK_ON_SEARCH_DEAL_REFERENCE_ICON="Click on Search Icon to find Deal ";
    String CLICK_ON_DEAL_REFERENCE_HYPERLINK="Click on Deal reference Hyperlink to open Deal - ";
    
    String EXPENSE_MOUSE_HOVER="Mouse Hover on Expenses Menu";
    String EXPENSE_SUB_MENU="Click on List of Expenses Sub-Menu";
    String ENTER_EXPENSE_REFERENCE_NUMBER="Enter Expense reference Number ";
    String CLICK_ON_SEARCH_EXPENSE_REFERENCE_ICON="Click on Search Icon to find Expense ";
    String CLICK_ON_EXPENSE_REFERENCE_HYPERLINK="Click on Expense reference Hyperlink to open Expense - ";

    String RECEIVABLE_MOUSE_HOVER="Mouse Hover on Receivable Menu";
    String RECEIVABLESUB_MENU="Click on List of Receivable Sub-Menu";
    String ENTER_RECEIVABLE_REFERENCE_NUMBER="Enter Receivable reference Number ";
    String CLICK_ON_SEARCH_RECEIVABLE_REFERENCE_ICON="Click on Search Icon to find Receivable ";
    String CLICK_ON_RECEIVABLE_REFERENCE_HYPERLINK="Click on Receivable reference Hyperlink to open Receivable - ";

    String PROPERTY_SITES_SUB_MENU="Click on PROPERTY_SITES Sub-Menu";
    String PROPERTY_SUB_MENU_OF_SITES="Click on PROPERTY_SUB_MENU_OF_SITES";
    String ENTER_PROPERTY_REFERENCE_NUMBER="Enter PROPERTY reference Number ";
    String CLICK_ON_SEARCH_PROPERTY_REFERENCE_ICON="Click on Search Icon to find PROPERTY ";
    String CLICK_ON_PROPERTY_REFERENCE_HYPERLINK="Click on PROPERTY reference Hyperlink to open PROPERTY - ";
    
    
    String COLLATERAL_MOUSE_HOVER="Mouse Hover on Collaterals Menu";
    String COLLATERALSUB_MENU="Click on List of Collaterals Sub-Menu";
    String ENTER_COLLATERAL_REFERENCE_NUMBER="Enter Collateral reference  ";
    String CLICK_ON_SEARCH_COLLATERAL_REFERENCE_ICON="Click on Search Icon to find Collateral ";
    String CLICK_ON_COLLATERAL_REFERENCE_HYPERLINK="Click on Collateral reference Hyperlink to open Collateral - ";
    
    String CONFIGURATION_MOUSE_HOVER="Mouse Hover on Configuration Menu";

}
