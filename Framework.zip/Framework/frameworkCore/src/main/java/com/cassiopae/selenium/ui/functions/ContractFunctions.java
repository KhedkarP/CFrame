package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class ContractFunctions {

	/*
	 * Contract Functions
	 */
	private static Map<String, List<String>> contractLocatorMap = ObjectRepoInitialization.masterLocatorMap.get(ObjectRepoInitialization.CONTRACT_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger reportingLogger) {
		//CommonUtility.logTransactions(driver, "Open Contract Module homepage");
		GenericAction.mouseHoverOn(FunctionReportingConstant.CONTRACT_MOUSE_HOVER, FunctionLocatorConstant.CONTRACT_MENU, contractLocatorMap, driver, reportingLogger);
		GenericAction.clickOn(FunctionReportingConstant.CONTRACT_SUB_MENU, FunctionLocatorConstant.CONTRACT_SUB_MENU, contractLocatorMap, driver, reportingLogger);
	}
	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail) {
	    navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_CONTRACT_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.CONTRACT_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(contractLocatorMap);
		CommonUtility.logTransactions(testCaseDetail.getDriver(), "Open Contract "+reference);
		GenericAction.enterValueIn(reference,excelTestCaseFields,testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_CONTRACT_REFERENCE_ICON, FunctionLocatorConstant.CONTRACT_SEARCH_ICON, contractLocatorMap, testCaseDetail.getDriver(),
			testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_CONTRACT_REFERENCE_HYPERLINK +reference, FunctionLocatorConstant.CONTRACT_REFERNCE_HYPERLINK, contractLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
