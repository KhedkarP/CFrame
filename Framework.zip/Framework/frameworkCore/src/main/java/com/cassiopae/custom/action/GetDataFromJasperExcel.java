package com.cassiopae.custom.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.util.common.JasperUtility;

public class GetDataFromJasperExcel implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger replogger = testCaseDetailTO.getReportingLogger();
		String[] inputDataRequiredValues = CommonUtility
				.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(), CommonConstant.PIPE_SEPARATOR);
		int Count = 0;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			String[] storedVariableslist= CommonUtility.splitStringUsingPattern(
					excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
			String[] requriedStoredVariablesList = CommonUtility.splitStringUsingPattern(storedVariableslist[0],CommonConstant.COMMA_SEPERATOR);
			String[] requriedInputVariablesList = CommonUtility.splitStringUsingPattern(inputDataRequiredValues[1],
					CommonConstant.COMMA_SEPERATOR);
			if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR)) {
				if (requriedStoredVariablesList.length == requriedInputVariablesList.length) {
					try {
						Count = JasperUtility.getRequiredDataFromExcel(testCaseDetailTO.getVariableHolder(),
								testCaseDetailTO, replogger, inputDataRequiredValues, requriedStoredVariablesList);
						testCaseDetailTO.getVariableHolder().put(storedVariableslist[1], String.valueOf(Count));
						replogger.info(ReportLoggerConstant.COUNT_OF_ENTITY + Count);
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					testCaseDetailTO.getReportingLogger()
							.error(ErrorMessageConstant.REQUIRED_VARABLE_MSG
									+ excelTestCaseFieldsTO.getAction());
					throw new CATTException(ErrorMessageConstant.REQUIRED_VARABLE_MSG
							+ excelTestCaseFieldsTO.getAction());
				}
			} else {
				testCaseDetailTO.getReportingLogger()
						.error(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE
								+ excelTestCaseFieldsTO.getAction());
				throw new CATTException(ErrorMessageConstant.JASPER_RECEIVABLE_COLUMNNAME_VALIDATION_ERROR_MESSAGE
						+ excelTestCaseFieldsTO.getAction());
			}
		} else {
			testCaseDetailTO.getReportingLogger()
					.error(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
							+ excelTestCaseFieldsTO.getAction());
			throw new CATTException(ErrorMessageConstant.JASPER_REPORT_STORED_DATA_VALIDATION_ERROR_MESSAGE
					+ excelTestCaseFieldsTO.getAction());
		}
	}

	

}
