/**
 *
 */
package com.cassiopae.webservices.action.factory;

import com.cassiopae.webservices.action.*;
import com.cassiopae.webservices.action.constant.WSConstant;

/**
 * @author mshaik
 */
public class WSActionFactory {

	private WSActionFactory() {
	}

	public static WSAction getWSActionInstance(final String type) {
		WSAction wsAction = null;

		if (WSConstant.WS_REQUEST_REST_HEADER.equals(type)) {
			wsAction = new RWSLoginRequest();
		} else if (WSConstant.WS_GENERATE_POST_REQUST.equals(type)) {
			wsAction = new RWSPerformPostRequest();
		} else if (WSConstant.REST_API_GET_RESPONSE_DATA.equals(type)) {
			wsAction = new RESTAPIGetResponseData();
		} else if (WSConstant.REST_API_LOGIN_REQUEST.equals(type)) {
			wsAction = new RESTAPILoginRequest();
		} else if (WSConstant.REST_API_POST_REQUEST.equals(type)) {
			wsAction = new RESTAPIPOSTRequest();
		} else if (WSConstant.REST_API_PATCH_REQUEST.equals(type)) {
			wsAction = new RESTAPIPATCHRequest();
		} else if (WSConstant.REST_API_GET_REQUEST.equals(type)) {
			wsAction = new RESTAPIGETRequest();
		} else if (WSConstant.REST_API_EXECUTE_REQUEST.equals(type)) {
			wsAction = new RESTAPIExecuteRequest();
		} else if (WSConstant.REST_API_PUT_REQUEST.equals(type)) {
			wsAction = new RESTAPIPUTRequest();
		}
		else if(WSConstant.SOAP_API_POST_REQUEST.equals(type))
		{
			wsAction=new SOAPAPIPOSTRequest();
		}
		else if(WSConstant.SOAP_API_GET_RESPONSE_DATA.equals(type))
		{
			wsAction=new SOAPAPIGetResponseData();
		}
		return wsAction;
	}

}
