/**
 * 
 */
package com.cassiopae.custom.action;

import java.io.File;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.DomainInitialization;

/**
 * @author mshik
 *
 */
public class Check_Downloaded_File implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Logger reportingLogger = testCaseDetail.getTestCaseCommonData().getReportingLogger();
		String File_status = CommonConstant.FALSE_VALUE;
		String downloded_Path = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetail.getDomainName())
				+ testCaseDetail.getWorkBookName() + File.separator + testCaseDetail.getWorkSheetName()
				+ File.separator;
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String textBoxInputData = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				excelTestCaseFields.getInputTestData().trim());
		if (textBoxInputData == null) {
			reportingLogger.info(ReportLoggerConstant.CHECK_INPUT_TESTDATA_MSG + textBoxInputData
					+ ReportLoggerConstant.FILE_NOT_AVAILABLE_MSG);
		}
		try {
			CommonFunctions.explicitWait(7000);
			File_status = SeleniumUtility.checkFileIsAvailableORNot(downloded_Path, reportingLogger,
					textBoxInputData);
		} catch (NullPointerException e) {
			reportingLogger.info(ReportLoggerConstant.CHECK_INPUT_TESTDATA_MSG + textBoxInputData
					+ ReportLoggerConstant.FILE_NOT_AVAILABLE_MSG);
		} catch (Exception e) {
			reportingLogger.info(ReportLoggerConstant.CHECK_INPUT_TESTDATA_MSG + textBoxInputData
					+ ReportLoggerConstant.FILE_NOT_AVAILABLE_MSG);
		}
		if (excelTestCaseFields.getStoreValuesInVariable() != null)
			testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), File_status);
	}
}
