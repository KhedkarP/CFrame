/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.FrameworkCommonUtility;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;

/**
 * @author nbhil
 *
 */
public class CommonFunctionsExecutor implements FunctionExecutor {

	@Override
	public void executeFunction(String methodName, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		testCaseDetail.getTestCaseCommonData().getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		if (FunctionConstant.LOGIN.equals(methodName)) {
			String appVersion = null;
			String input = excelTestCaseFields.getInputTestData();
			if (StringUtils.isEmpty(input)) {
				String worksheetName = testCaseDetail.getTestCaseCommonData().getBaseWorksheetName();
				testCaseDetail.setWorkSheetName(worksheetName);
				testCaseDetail.getTestCaseCommonData().setWorkSheetName(worksheetName);
				testCaseDetail.getTestCaseCommonData().setUserName(testCaseDetail.getTestCaseCommonData().getDefaultUserName());
				testCaseDetail.getTestCaseCommonData().setPassword(testCaseDetail.getTestCaseCommonData().getDefaultPassword());
				appVersion = CommonFunctions.login(testCaseDetail);
				
			} else {
				String[] inputTestDatas = excelTestCaseFields.getInputTestData()
						.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
				String userName = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
						inputTestDatas[0]);
				String password = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
						inputTestDatas[1]);
				String application = null;
				if (inputTestDatas.length > 2) {
					application = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
							inputTestDatas[2]);
				} else {
					String worksheetName = testCaseDetail.getTestCaseCommonData().getBaseWorksheetName();
					if (worksheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
						application = DBConstant.BO_APP_SHEET_NAME;
					} else if (worksheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
						application = DBConstant.MO_APP_SHEET_NAME;
					} else if (worksheetName.contains(DBConstant.POS_MODULE)) {
						application = DBConstant.POS_MODULE;
					}
				}

				testCaseDetail.setDomainName(testCaseDetail.getDomainName());
				testCaseDetail.setReportingLogger(testCaseDetail.getTestCaseCommonData().getReportingLogger());
				testCaseDetail.setDriver(testCaseDetail.getTestCaseCommonData().getDriver());
				testCaseDetail.getTestCaseCommonData().setUserName(userName);
				testCaseDetail.getTestCaseCommonData().setPassword(password);
				testCaseDetail.getTestCaseCommonData()
						.setExcelRowNo(testCaseDetail.getTestCaseCommonData().getExcelRowNo());
				testCaseDetail.getTestCaseCommonData()
						.setDomainName(testCaseDetail.getTestCaseCommonData().getDomainName());
				String updatedSheetName;
				if (application.contains(DBConstant.POS_MODULE)) {
					updatedSheetName = findAndReplaceWorkSheetName(
							testCaseDetail.getTestCaseCommonData().getWorkSheetName(), DBConstant.POS_MODULE);
				} else if (application.contains(DBConstant.MO_MODULE)) {
					updatedSheetName = findAndReplaceWorkSheetName(
							testCaseDetail.getTestCaseCommonData().getWorkSheetName(), DBConstant.MO_APP_SHEET_NAME);
				} else {
					updatedSheetName = findAndReplaceWorkSheetName(
							testCaseDetail.getTestCaseCommonData().getWorkSheetName(), DBConstant.BO_APP_SHEET_NAME);
				}
				testCaseDetail.getTestCaseCommonData().setWorkSheetName(updatedSheetName);
				testCaseDetail.setWorkSheetName(updatedSheetName);
				CurrentTestCase.getAppsynchronizationswitch().set(updatedSheetName);
				String locale = FrameworkCommonUtility.configureLocaleSettings(testCaseDetail.getTestCaseCommonData(), testCaseDetail.getTestCaseCommonData().getWorkSheetName(), userName);
				FrameworkCommonUtility.updateDateAmountFormat(testCaseDetail.getTestCaseCommonData(), testCaseDetail.getTestCaseCommonData().getWorkSheetName(), locale);
				appVersion = CommonFunctions.login(testCaseDetail);
			}

			if (!StringUtils.isEmpty(excelTestCaseFields.getStoreValuesInVariable())) {
				testCaseDetail.getTestCaseCommonData().getVariableHolder()
						.put(excelTestCaseFields.getStoreValuesInVariable(), appVersion);
			}

		} else if (FunctionConstant.LOGOUT.equals(methodName)) {
			CommonFunctions.logout(testCaseDetail);
		} else if (FunctionConstant.NAVIGATION_TO_TAB.equals(methodName)) {
			CommonFunctions.navigateToTab(excelTestCaseFields, testCaseDetail);
		} else if (FunctionConstant.NAVIGATE_TO_EVENT.equals(methodName)) {
			CommonFunctions.navigateToEvent(excelTestCaseFields, testCaseDetail);
		} else if (FunctionConstant.NAVIGATE_TO_MAIN_MODULE.equals(methodName)) {
			CommonFunctions.navigateToMainModule(excelTestCaseFields, testCaseDetail);
		}
	}

	public static String findAndReplaceWorkSheetName(String oldWorkSheetName, String stringToReplace) {
		if (oldWorkSheetName.contains(DBConstant.BO_APP_SHEET_NAME)) {
			return StringUtils.replaceOnce(oldWorkSheetName, DBConstant.BO_APP_SHEET_NAME, stringToReplace);
		} else if (oldWorkSheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
			return StringUtils.replaceOnce(oldWorkSheetName, DBConstant.MO_APP_SHEET_NAME, stringToReplace);
		} else {
			if(oldWorkSheetName.contains(CommonConstant.UNDER_SCORE+DBConstant.POS_MODULE+CommonConstant.UNDER_SCORE)) {
				return StringUtils.replaceOnce(oldWorkSheetName, CommonConstant.UNDER_SCORE+DBConstant.POS_MODULE+CommonConstant.UNDER_SCORE, stringToReplace);
			}
			else {
				return StringUtils.replaceOnce(oldWorkSheetName, DBConstant.POS_MODULE, stringToReplace);
			}
			
		}
	}

}
