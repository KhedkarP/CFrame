/**
 * 
 */
package com.cassiopae.selenium.ui.functions.constant;

/**
 * @author nbhil
 *
 */
public interface FunctionConstant {

	public static final String NAVIGATE_TO = "navigateTo";
	public static final String OPEN = "open";
	
	public static final String ACTOR = "Actor";
	public static final String ASSET = "Asset";
	public static final String CONSTRUCTION = "Construction";
	public static final String CONTRACT = "Contract";
	public static final String DEAL = "Deal";
	public static final String COLLECTION_DISBURSEMENT = "CollectionDisbursement";
	public static final String EXPENSE = "Expenses";
	public static final String RECEIVABLE = "Receivables";
	public static final String CASHFLOW = "Cashflow";
	public static final String PROPERTY = "Property";
	public static final String PROPERTY_MODULE = "Properties";
	public static final String FUNCTION = "Function";
	public static final String COMMON = "Common";
	public static final String COLLATERALS = "Collaterals";
	
	// - not yet used/released
	public static final String TABLE = "Table";
	public static final String VALIDATE_ENTRIES = "ValidateEntries";
	
	public static final String LOGIN = "login";
	public static final String LOGOUT = "logout";
	public static final String NAVIGATION_TO_TAB = "navigateToTab";
	public static final String NAVIGATE_TO_EVENT = "navigateToEvent";
	public static final String NAVIGATE_TO_MAIN_MODULE = "navigateToMainModule";
	public static final String CHECK_DEAL_IS_SAVED_SUCCESSFULY = "checkDealIsSaved";


}
