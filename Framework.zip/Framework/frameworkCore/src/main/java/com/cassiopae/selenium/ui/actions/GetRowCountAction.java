/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author nbhil
 *
 */
public class GetRowCountAction implements PerformAction {

	/**
	 * This method execute action for get attribute title action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String rowcount = null;
		String worksheetName = testCaseDetailTO.getWorkSheetName();
		if (worksheetName.contains(DBConstant.POS_MODULE)
				|| StringUtils.startsWith(testCaseDetailTO.getWorkSheetName(), DBConstant.CC_APP_SHEET_NAME)) {
			rowcount = GenericAction.getRowCountForPOS(excelTestCaseFieldsTO.getLocatorKey(),
					testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
					testCaseDetailTO.getReportingLogger());
		} else {
			rowcount = GenericAction.getRowCount(excelTestCaseFieldsTO.getLocatorKey(),
					testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
					testCaseDetailTO.getReportingLogger());
		}

		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + rowcount);
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), rowcount);
		if (excelTestCaseFieldsTO.getExpectedResult() != null || excelTestCaseFieldsTO.getActualValue() != null) {
			String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
			String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
					testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
			GenericAction.assertEquals(variableHolderActualValue, variableHolderExpectedValue,
					excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
		}

	}

}
