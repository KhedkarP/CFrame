/**
 * 
 */
package com.cassiopae.selenium.operator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.operator.utils.OperatorUtility;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class RelationalOperation implements PerformOperation {

    @Override
    public void executeOperation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
	
	testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
	String result=null;
	if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR)) {
	    String[] holder=  CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(), CommonConstant.PIPE_SEPARATOR);
	    result = OperatorUtility.executeOperator(holder,testCaseDetailTO);
	}
	if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
		testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), result);
	testCaseDetailTO.getReportingLogger().info("Result is : "+result);
    }

}
