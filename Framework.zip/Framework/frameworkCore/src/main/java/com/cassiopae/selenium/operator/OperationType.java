/**
 * 
 */
package com.cassiopae.selenium.operator;

import java.util.HashSet;
import java.util.Set;

/**
 * @author jraut
 *
 */
public enum OperationType {

    CSMZ_CompareNumericValues,
	CSMZ_ArithmaticOperations;

    private static HashSet<String> OperationTypeSet = null;

    public static Set<String> getOperationType() {
	if (OperationTypeSet == null) {
	    OperationTypeSet = new HashSet<>();
	    for (OperationType action : OperationType.values()) {
		OperationTypeSet.add(action.name());
	    }
	}
	return OperationTypeSet;
    }

}
