/**
 * 
 */
package com.cassiopae.selenium.util.common;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.BatchUtilityConstants;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.utils.date.DateDefination;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * @author jraut
 *
 */
public class BatchAutomationUtility {

	private static Logger tracelogger = LogManager.getLogger(BatchAutomationUtility.class);

	public static void closeConnection(Session session, InputStream inputStream, InputStream errorStream,
			Channel channel) {
		channel.disconnect();
		session.disconnect();
		try {
			inputStream.close();
			errorStream.close();
		} catch (IOException e) {
			tracelogger.warn(BatchUtilityConstants.CLOSE_CONNECTION_ERROR_MESSAGE, e);
		}
	}

	public static String createBatchLogFile(StringBuilder builder, TestCaseDetail testCaseDetailTO, String batchName) {
		testCaseDetailTO.getReportingLogger().info(builder);
		String batchFileName = batchName + BatchUtilityConstants.BATCH_LOG_NAME + DateDefination.Date
				+ RandomStringUtils.randomNumeric(4) + BatchUtilityConstants.BATCH_FILE_EXTENSION;
		String batchLogPath = CommonUtility.getConsoleLogFolderPath(testCaseDetailTO.getDomainName())
				+ DateDefination.execution_evidences_date_format + InitializeConstants.fileSeparator
				+ testCaseDetailTO.getWorkBookName() + InitializeConstants.fileSeparator
				+ testCaseDetailTO.getWorkSheetName() + InitializeConstants.fileSeparator + batchFileName;
		File file = new File(batchLogPath);
		try {
			FileUtils.writeStringToFile(file, builder.toString(), "UTF-8");
		} catch (IOException e) {
			tracelogger.error(BatchUtilityConstants.BATCH_LOGS_WRITING_ERROR, e);
		}
		return batchLogPath;
	}

	public static String printConsoleMessage(Logger reportingLogger, InputStream inputStream, Channel channel,
			StringBuilder builder) throws CATTException {
		byte[] tmp = new byte[150];
		String batchReturnCode = null;
		boolean errorFlag = false;
		while (true) {
			try {
				while (inputStream.available() > 0) {
					int i = inputStream.read(tmp, 0, 100);
					if (i < 0) {
						break;
					}

					String line = new String(tmp, 0, i);
					builder.append(line);
					if (line.contains(BatchUtilityConstants.RETURN_CODE)) {
						String text = line.replace('\u00A0', ' ').trim();
						String batchReturnCode1 = (text.split("ReturnCode"))[1];
						batchReturnCode = ((batchReturnCode1.trim()).split(" ")[0]).split("\n")[0];
						reportingLogger.info(BatchUtilityConstants.RETURN_CODE_MESSAGE_IS + batchReturnCode);
					} 
					else if (line.contains(BatchUtilityConstants.JAVA_BATCH_EXIT_CODE)) {
						String text = line.replace('\u00A0', ' ').trim();
						String batchReturnCode1 = (text.split("Exit with code :"))[1];
						batchReturnCode = ((batchReturnCode1.trim()).split(" ")[0]).split("\n")[0];
						reportingLogger.info(BatchUtilityConstants.EXIT_CODE_MESSAGE_IS + batchReturnCode);
					}else if (line.contains("ERROR [")) { // || line.contains("Err") || line.contains("error")
						errorFlag = true;
					} else if (line.contains(BatchUtilityConstants.PERMISSION_KO_MESSAGE)) {
						reportingLogger.error(BatchUtilityConstants.PERMISSION_ERROR_MEESAGE + line);
						errorFlag = true;
					}
				}
			} catch (IOException e) {
				tracelogger.error(e);
			}
			if (channel.isClosed()) {
				break;
			}
		}
		if (errorFlag) {
			reportingLogger.error(BatchUtilityConstants.BATCH_KO_MESSAGE);
			throw new CATTException(BatchUtilityConstants.BATCH_KO_MESSAGE);
		} else {
			return batchReturnCode;
		}
	}

	public static String configurePathVariables() {
		// -- for Linux
		String batchLocation = ApplicationContext.batchLocationOnserver;
		String pathSetting = "cd " + batchLocation + "\n" + "export JAVA_HOME=" + ApplicationContext.javaHome + "\n"
				+ "export LD_LIBRARY_PATH=" + ApplicationContext.ldLibraryPath + "\n" + "export TNS_ADMIN="
				+ ApplicationContext.tnsAdmin + "\n" + "export TEMP_PATH=" + ApplicationContext.batchTempPath + "\n"
				+ "\n" + "export PATH=/usr/bin:/bin:/sbin:" + batchLocation + ":$LD_LIBRARY_PATH:$PATH" + "\n";
		return pathSetting;
	}

	public static Channel createChannel(Logger logger, Session session, String command, InputStream inputStream,
			InputStream outputStream) {
		Channel channel;

		try {
			channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);
			channel.setInputStream(null);
			inputStream = channel.getInputStream(); // need another catch
			outputStream = channel.getExtInputStream();
			try {
				logger.info(BatchUtilityConstants.BATCH_START_MESSAGE);
				channel.connect();
			} catch (JSchException e) {
				logger.error(BatchUtilityConstants.CHANNEL_CONNECTION_ERROR_MESSAGE);
				throw new CATTException(BatchUtilityConstants.CHANNEL_CONNECTION_ERROR_MESSAGE);
			}
		} catch (JSchException | IOException exp) {
			logger.error(BatchUtilityConstants.CHANNEL_ERROR_OPEN_MESSAGE, exp);
			throw new CATTException(BatchUtilityConstants.CHANNEL_ERROR_OPEN_MESSAGE + exp.getMessage());
		}

		// check session connection
		if (session.isConnected()) {
			logger.info("Session with server is established.");
		} else {
			logger.error("Session is not created with server");
		}
		return channel;
	}

	public static Session createSessionWithServer(Logger logger, String serverUserName, String serverPassword,
			String hostName, String serverPort) {
		int portNumber;
		if (StringUtils.isNumeric(serverPort)) {
			portNumber = Integer.parseInt(serverPort.trim());
		} else {
			throw new CATTException("Server port number should be numeric");
		}
		JSch jsch = new JSch();
		Session session;
		try {
			session = jsch.getSession(serverUserName, hostName, portNumber);
		} catch (JSchException e1) {
			logger.error("username or host are invalid: " + e1.getMessage(), e1);
			throw new CATTException("Unable to create session with server: " + e1.getMessage());
		}
		session.setPassword(serverPassword);
		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);
		try {
			session.connect();
		} catch (Exception e) {
			logger.info("Facing issue while creation session connection with server: " + e.getMessage());
			logger.info("Trying to connect again with server....");
			session.disconnect();
			try {
				session.connect();
			} catch (JSchException e1) {
				logger.error("Facing issue while creation session connection with server: ", e);
				throw new CATTException(
						"Facing issue while creation session connection with server: " + e.getMessage());
			}
		}
		return session;
	}

	public static String getUpdatedCommand(String rawCommand, Map<String, String> variableHolder) {
		boolean endCurlyBraceFound = false;
		String part1;
		String part2;
		for (int i = 0; i < rawCommand.length(); i++) {
			part1 = null;
			part2 = null;
			int totalLength = rawCommand.length();
			// access each character
			char a = rawCommand.charAt(i);
			if (a == '$') {
				i++;
				char b = rawCommand.charAt(i);
				if (b == '{') {
					i++;
					int indexOfEndCurlyBrace = 0;
					endCurlyBraceFound = false;
					for (int k = i; k <= totalLength; k++) {
						char c = rawCommand.charAt(k);
						if (c == '}') {
							indexOfEndCurlyBrace = k;
							endCurlyBraceFound = true;
							break;
						} else if (c == '{') {
							break;
						}
					}
					if (!endCurlyBraceFound) {
						throw new CATTException(
								"Incorrect batch command - opening and curly braces are not closed properly for dynamic input");
					}
					part1 = rawCommand.substring(0, i - 2);
					part2 = rawCommand.substring(indexOfEndCurlyBrace + 1, totalLength);
					String dataValue = rawCommand.substring(i - 2, indexOfEndCurlyBrace + 1);
					String valueFromVH = VariableHolder.getValueFromVariableHolder(variableHolder, dataValue);
					rawCommand = part1 + valueFromVH + part2;
				}
			}
		}
		return rawCommand;
	}
}
