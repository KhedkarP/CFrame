/**
 * 
 */
package com.cassiopae.excel.dataconvertor;

import java.util.HashMap;
import java.util.Map;

import com.cassiopae.excel.dataconvertor.constant.ConvertorConstant;

/**
 * @author nbhil
 *
 */
public abstract class AbstractDataConvertor implements DataConvertor {

	private static Map<String, Map<String, String>> localeMap = new HashMap<>();
	static {
		Map<String, String> formatorMapFR = new HashMap<>();
		formatorMapFR.put(ConvertorConstant.DATE_FORMATE_KEY, ConvertorConstant.FR_DATE_FORMATE_VALUE);
		formatorMapFR.put(ConvertorConstant.DATA_FORMATE_KEY, ConvertorConstant.FR_DATA_FORMATE_VALUE);

		Map<String, String> formatorMapEN = new HashMap<>();
		formatorMapEN.put(ConvertorConstant.DATE_FORMATE_KEY, ConvertorConstant.EN_DATE_FORMATE_VALUE);
		formatorMapEN.put(ConvertorConstant.DATA_FORMATE_KEY, ConvertorConstant.EN_DATA_FORMATE_VALUE);
		
		Map<String, String> formatorMapGB = new HashMap<>();
		formatorMapGB.put(ConvertorConstant.DATE_FORMATE_KEY, ConvertorConstant.FR_DATE_FORMATE_VALUE);
		formatorMapGB.put(ConvertorConstant.DATA_FORMATE_KEY, ConvertorConstant.EN_DATA_FORMATE_VALUE);
		
		Map<String, String> formatorMapPOS_FR = new HashMap<>();
		formatorMapPOS_FR.put(ConvertorConstant.DATE_FORMATE_KEY, ConvertorConstant.POS_FR_DATE_FORMATE_VALUE);
		formatorMapPOS_FR.put(ConvertorConstant.DATA_FORMATE_KEY, ConvertorConstant.POS_FR_DATA_FORMATE_VALUE);

		Map<String, String> formatorMapPOS_EN = new HashMap<>();
		formatorMapPOS_EN.put(ConvertorConstant.DATE_FORMATE_KEY, ConvertorConstant.POS_EN_DATE_FORMATE_VALUE);
		formatorMapPOS_EN.put(ConvertorConstant.DATA_FORMATE_KEY, ConvertorConstant.POS_EN_DATA_FORMATE_VALUE);

		localeMap.put(ConvertorConstant.FR_FR_LOCALE_KEY, formatorMapFR);
		localeMap.put(ConvertorConstant.EN_FR_LOCALE_KEY, formatorMapFR);
		localeMap.put(ConvertorConstant.EN_US_LOCALE_KEY, formatorMapEN);
		localeMap.put(ConvertorConstant.EN_UK_LOCALE_KEY, formatorMapEN);
		localeMap.put(ConvertorConstant.EN_GB_LOCALE_KEY, formatorMapGB);
		
		localeMap.put(ConvertorConstant.POS_FR_FR_LOCALE_KEY, formatorMapPOS_FR);
		localeMap.put(ConvertorConstant.POS_EN_FR_LOCALE_KEY, formatorMapPOS_FR);
		localeMap.put(ConvertorConstant.POS_EN_US_LOCALE_KEY, formatorMapPOS_EN);
		localeMap.put(ConvertorConstant.POS_EN_UK_LOCALE_KEY, formatorMapPOS_EN);
		

	}

	public static Map<String,Map<String,String>> getLocaleMap() {
		return localeMap;
	}

}
