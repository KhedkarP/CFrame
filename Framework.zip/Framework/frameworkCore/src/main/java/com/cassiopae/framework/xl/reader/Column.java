package com.cassiopae.framework.xl.reader;


public class Column {

	private boolean isEmptyAllowed;
	private DataType dataType;
	private String name;

	/**
	 * @return the isEmptyAllowed
	 */
	public boolean isEmptyAllowed() {
		return isEmptyAllowed;
	}

	/**
	 * @param p_isEmptyAllowed
	 *                             the isEmptyAllowed to set
	 */
	public void setEmptyAllowed( final boolean p_isEmptyAllowed ) {
		isEmptyAllowed = p_isEmptyAllowed;
	}

	/**
	 * @return the dataType
	 */
	public DataType getDataType() {
		return dataType;
	}

	/**
	 * @param p_dataType
	 *                       the dataType to set
	 */
	public void setDataType( final DataType p_dataType ) {
		dataType = p_dataType;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param p_name
	 * the name to set
	 */
	public void setName( final String p_name ) {
		name = p_name;
	}

}
