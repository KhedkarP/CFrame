package com.cassiopae.custom.action;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.BatchUtilityConstants;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.util.common.BatchAutomationUtility;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.Session;

public class BatchProcessAutomation implements CustomAction {

	private static Logger tracelogger = LogManager.getLogger(BatchProcessAutomation.class);

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		String pathSetting = BatchAutomationUtility.configurePathVariables();
		String batchCommand = BatchAutomationUtility.getUpdatedCommand(excelTestCaseFieldsTO.getInputTestData(),
				testCaseDetailTO.getVariableHolder());
		reportingLogger.info(BatchUtilityConstants.BATCH_COMMAND_MESSAGE + batchCommand);
		String batchName = CommonUtility.splitStringUsingPattern(batchCommand, CommonConstant.SPACE)[0].trim();
		batchName = org.apache.commons.lang.StringUtils.substring(batchName, 2).trim();
		/// ----------------- Server Connections -------------------------
		Session session = BatchAutomationUtility.createSessionWithServer(reportingLogger,
				ApplicationContext.applicationServerUsername, ApplicationContext.applicationServerPassword,
				ApplicationContext.applicationServerHostname, ApplicationContext.applicationServerPort);
		String batchCmd = pathSetting + batchCommand;
		reportingLogger.info(BatchUtilityConstants.BATCH_COMMOND_WITH_PATH_MESSAGE + batchCmd);

		InputStream inputStream = null;
		InputStream errorStream = null;
		Channel channel = BatchAutomationUtility.createChannel(reportingLogger, session, batchCmd, inputStream,
				errorStream);
		try {
			inputStream = channel.getInputStream();
			errorStream = channel.getExtInputStream();
		} catch (IOException e) {
			tracelogger.error(BatchUtilityConstants.ERROR_WHILE_FETCHING_LOGS, e);
		}
		StringBuilder builder = new StringBuilder();
		String returnCode2 = null;
		String returnCode1 = null;
		String batchLogPath;
		try {
			returnCode1 = BatchAutomationUtility.printConsoleMessage(reportingLogger, inputStream, channel, builder);
			returnCode2 = BatchAutomationUtility.printConsoleMessage(reportingLogger, errorStream, channel, builder);
		} catch (CATTException cexp) {
			batchLogPath = BatchAutomationUtility.createBatchLogFile(builder, testCaseDetailTO, batchName);
			throw new CATTException(cexp.getMessage() + batchLogPath);
		}
		batchLogPath = BatchAutomationUtility.createBatchLogFile(builder, testCaseDetailTO, batchName);
		tracelogger.info("Batch execution logs are stored at location: " + batchLogPath);
		BatchAutomationUtility.closeConnection(session, inputStream, errorStream, channel);

		if (StringUtils.isNotEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			String batchReturnCode = null;
			if (null != returnCode1) {
				batchReturnCode = returnCode1;
			} else {
				batchReturnCode = returnCode2;
			}

			if (CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					CommonConstant.PIPE_SEPARATOR).length > 1) {
				String[] storage = CommonUtility.splitStringUsingPattern(
						excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
				testCaseDetailTO.getVariableHolder().put(storage[0], batchReturnCode);
				testCaseDetailTO.getVariableHolder().put(storage[1], batchLogPath);
			} else {
				testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
						batchReturnCode);
			}
		}
	}
}
