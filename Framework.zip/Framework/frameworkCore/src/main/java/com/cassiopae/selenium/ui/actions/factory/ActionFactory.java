/**
 * 
 */
package com.cassiopae.selenium.ui.actions.factory;

import com.cassiopae.selenium.ui.actions.*;
import org.apache.commons.lang.StringUtils;

import com.cassiopae.selenium.ui.actions.constant.ActionConstant;

/**
 * @author jraut
 */
public class ActionFactory {

	private ActionFactory() {
	}

	public static PerformAction getActionInstance(final String action) {
		PerformAction performAction = null;

		if (StringUtils.isEmpty(action)) {
			return performAction;
		}
		if (ActionConstant.NAVIGATE_ACTION.equals(action)) {
			performAction = new NavigateAction();
		} else if (ActionConstant.CLICK_ACTION.equals(action)) {
			performAction = new ClickAction();
		} else if (ActionConstant.ENTER_INPUT_VALUE_ACTION.equals(action)) {
			performAction = new EnterInputValueAction();
		} else if (ActionConstant.MOUSE_HOVER_ACTION.equals(action)) {
			performAction = new MouseHoverAction();
		} else if (ActionConstant.GETTEXT_ACTION.equals(action)) {
			performAction = new GetValueAction();
		} else if (ActionConstant.SELECT_ACTION.equals(action)) {
			performAction = new SelectDropDownAction();
		} else if (ActionConstant.SELECT_CHECKBOX_ACTION.equals(action)) {
			performAction = new SelectCheckboxAction();
		} else if (ActionConstant.UNSELECT_CHECKBOX_ACTION.equals(action)) {
			performAction = new UnSelectCheckboxAction();
		} else if (ActionConstant.GET_ATTRIBUTE_VALUE_ACTION.equals(action)) {
			performAction = new GetAttributeValueAction();
		} else if (ActionConstant.EXECUTE_QUERY_ACTION.equals(action)) {
			performAction = new ExecuteQueryAction();
		} else if (ActionConstant.GET_ATTRIBUTE_TITLE_ACTION.equals(action)) {
			performAction = new GetAttributeTitleAction();
		} else if (ActionConstant.CONCATENATE_STRING_ACTION.equals(action)) {
			performAction = new ConcatenateValueAction();
		} else if (ActionConstant.GET_ROWCOUNT_ACTION.equals(action)) {
			performAction = new GetRowCountAction();
		} else if (ActionConstant.CHECK_ALERT_ACTION.equals(action)) {
			performAction = new CheckAlertAction();
		} else if (ActionConstant.SWITCH_TO_WINDOW_ACTION.equals(action)) {
			performAction = new SwitchToWindowAction();
		} else if (ActionConstant.EXECUTE_SQL_PROC_ACTION.equals(action)) {
			performAction = new ExecuteSQLProceduresAction();
		} else if (ActionConstant.CLEAR_TEXT_FIELD_ACTION.equals(action)) {
			performAction = new ClearTextFieldAction();
		} else if (ActionConstant.SELECT_PANEL_ENTRY.equals(action)) {
			performAction = new SelectPanelEntryAction();
		} else if (ActionConstant.GET_ATTRIBUTE_INNER_TEXT.equals(action)) {
			performAction = new GetAttributeInnerTextAction();
		} else if (ActionConstant.GET_TOTAL_COUNT_OF_ENTITY_IN_TABLE.equals(action)) {
			performAction = new GetTotalCountOfEntityInTable();
		} else if (ActionConstant.GET_VALUE_FROM_EVENT_SUMMARY_PANEL.equals(action)) {
			performAction = new GetValueFromEventSummaryPanel();
		} else if (ActionConstant.GENERATE_DYNAMIC_DATA.equals(action)) {
			performAction = new GenerateDynamicDataAction();
		} else if (ActionConstant.CREATE_EXECUTE_DYNAMIC_XPATH.equals(action)) {
			performAction = new CreateExecuteDynamicXpath();
		} else if (ActionConstant.EXTERNAL_WAIT.equals(action)) {
			performAction = new ExternalWait();
		} else if (ActionConstant.GET_ATTRIBUTE_NAME_ACTION.equals(action)) {
			performAction = new GetAttributeNameAction();
		} else if (ActionConstant.GET_ATTRIBUTE_SRC_ACTION.equals(action)) {
			performAction = new GetAttributeSrcAction();
		} else if (ActionConstant.DB_UPDATE_QUERY.equals(action)) {
			performAction = new DBUpdateQueryAction();
		} else if (ActionConstant.CHECK_PANEL_ENTRY.equals(action)) {
			performAction = new CheckPanelEntryAction();
		} else if (ActionConstant.CHECK_BLANK_VALUE_ACTION.equals(action)) {
			performAction = new CheckBlankValueAction();
		} else if (ActionConstant.GET_TOTAL_POPULATED_WINDOW_COUNT.equals(action)) {
			performAction = new GetTotalWindowCount();
		} else if (ActionConstant.CONVERT_DB_AMOUNT_TO_UI_FORMAT.equals(action)) {
			performAction = new ConvertDBAmountToUIFormateAction();
		} else if (ActionConstant.FILE_UPLOAD_ACTION.equals(action)) {
			performAction = new FileUploadAction();
		} else if (ActionConstant.GET_COUNT_OF_ELEMENTS.equals(action)) {
			performAction = new GetCountOfElementAction();
		} else if (ActionConstant.SWITCH_TO_WINDOW_BY_FLOWID_ACTION.equals(action)) {
			performAction = new SwitchToWindowByFlowidAction();
		} else if (ActionConstant.OPEN_NEW_TAB_NAVIGATE_TO_URL.equals(action)) {
			performAction = new OpenNewTabAndNavigateToURL();
		} else if (ActionConstant.XLS_GET_DATA_FROM_EXCEL.equals(action)) {
			performAction = new XLSGetValueFromExcel();
		} else if (ActionConstant.XLS_PUT_DATA_IN_EXCEL.equals(action)) {
			performAction = new XLSPutValueInExcel();
		} else if (ActionConstant.GET_TOAST_MESSAGE.equals(action)) {
			performAction = new GetToastMessage();
		} else if (ActionConstant.GET_DROPDOWN_VALUE_COUNT.equals(action)) {
			performAction = new GetDropDownValueCount();
		} else if (ActionConstant.ENTER_TEXT_AREA_INPUT_VALUE.equals(action)) {
			performAction = new EnterTextAreaInputValue();
		} else if (ActionConstant.GET_ATTRIBUTE_CLASS_ACTION.equals(action)) {
			performAction = new GetAttributeClassAction();
		} else if (ActionConstant.SELECT_CHECK_UNORDER_ACTION.equals(action)) {
			performAction = new CheckUnorderTableEntry();
		} else if (ActionConstant.GET_VALUES_FROM_JASPER.equals(action)){
			performAction=new GetValuesFromJasperReport();
	     } else if (ActionConstant.READ_RECEIVABLES_FROM_EXCEL.equals(action)){
			performAction=new ReadValuesFromExcel();
	     }else if (ActionConstant.SLAC_DRAG_AND_DROP.equals(action)){
			performAction=new DragAndDrop();
	     }else if (ActionConstant.SLAC_SELECT_VALUE_CONTAINS.equals(action)){
			performAction=new SelectDropdownValueContains();
	     }else if (ActionConstant.SLAC_SwitchTo_Window_Close.equals(action)){
			performAction=new SwithToWindowAndClose();
	     }else if (ActionConstant.SLAC_RIGHT_CLICK.equals(action)){
			performAction=new RightClickAction();
	     } else if (ActionConstant.SLAC_LAUNCH_EVENT_FOR_POS.equals(action)){
			performAction=new LaunchPOSEventAction();
	     }else if (ActionConstant.SLAC_SELECT_INPUT_LOOKUPVALUE.equals(action)) {
				performAction = new SelectInputLookupValue();	
	     }else if (ActionConstant.SLAC_ENTER_DATE.equals(action)) {
				performAction = new DateEnterAction();	
	     }else if(ActionConstant.SLAC_NAVIGATE_TO_SERVICE_ACCOUNT.equals(action))		{
				performAction=new NavigateToServiceAccount();
		}else if (ActionConstant.GET_ATTRIBUTE_HREF_ACTION.equals(action)) {
			performAction = new GetAttributeHrefAction();
		}


		return performAction;
	}
}
