/**
 * 
 */
package com.cassiopae.selenium.operator.factory;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.selenium.operator.ArthmaticOperations;
import com.cassiopae.selenium.operator.PerformOperation;
import com.cassiopae.selenium.operator.RelationalOperation;
import com.cassiopae.selenium.operator.constant.OperatorConstant;

/**
 * @author jraut
 *
 */
public class OperatorFactory {
    
	public static PerformOperation getOperationInstance(final String action) {
		PerformOperation performOperation = null;
		if (StringUtils.isEmpty(action)) {
			return performOperation;
		}
		if (OperatorConstant.RELATIONAL_OPERATION.equals(action)) {
			performOperation = new RelationalOperation();
		} else if (OperatorConstant.ARTHMATIC_OPERATION.equals(action)) {
			performOperation = new ArthmaticOperations();
		}
		return performOperation;
	}
}
