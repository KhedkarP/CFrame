/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class CheckAlertAction implements PerformAction {

	/**
	 * This method execute action for checkAlert action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String message = null;
		CommonUtility.logTransactions(testCaseDetailTO.getDriver(), excelTestCaseFieldsTO.getTestCaseSteps());
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		message = SeleniumUtility.checkAlert(testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger(),
				excelTestCaseFieldsTO.getInputTestData());

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() !=null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), message);
		}

	}

}
