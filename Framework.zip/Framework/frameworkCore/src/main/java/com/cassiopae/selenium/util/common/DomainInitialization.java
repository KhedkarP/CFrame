package com.cassiopae.selenium.util.common;

public class DomainInitialization {

	public static String initializeDomainwiseDownloadPath(final String domainName) {
		return CommonUtility.getDownloadPath(domainName);
	}

	public static String initializeDomainwiseTestDataDocumentPath(final String domainName) {
		return CommonUtility.getPaymentScheduleDocumentPath(domainName);
	}

	public static String initializeDomainTestDataExcelPath(final String domainName) {
		return CommonUtility.getDashboardExcelPath(domainName);
	}
	
	public static String initializeDomainTestEnvDetailExcelPath(final String domainName) {
		return CommonUtility.getEnvDetailExcelPath(domainName);
	}

	public static String initializeDomainWiseTestCasesPath(final String domainName) {
		return CommonUtility.getTestCaseFolderPath(domainName);
	}
	
	public static String initializeDomainWiseRestAPIRequestsPath(final String domainName) {
		return CommonUtility.getRestAPIRequestsFolderPath(domainName);
	}

	public static String initializeDomainWiseNeoLoadProjectsPath(String domainName) {
		return CommonUtility.getNeoLoadProjectFolderPath(domainName);
	}
	
	public static String initializeDomainWisePreRequisiteSQLPath(String domainName) {
		return CommonUtility.getPreRequisiteSQLPath(domainName);
	}
	
	public static String initializeDomainWiseUploadFilePath(final String domainName) {
		return CommonUtility.getUploadDocumentPath(domainName);
	}
	
	public static String initializeDomainWiseDumpValidationFilePath(final String domainName) {
		return CommonUtility.getDumpValidationPath(domainName);
	}
	
	public static String initializeProductWiseORFilePath(final String domainName) {
		return CommonUtility.getObjectRepositoryPath(domainName);
	}
	
	public static String initializeProductWiseWSResponseFilePath(final String domainName) {
		return CommonUtility.getApiResponsePath(domainName);
	}
	
}
