/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;

/**
 * @author jraut
 *
 */
public class FieldEnabledValidation implements PerformValidation {

    @Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		boolean flag = GenericAction.isEnabled(excelTestCaseFieldsTO.getTestCaseSteps(),
				excelTestCaseFieldsTO.getErrorMessage(), excelTestCaseFieldsTO.getLocatorKey(),
				testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
				testCaseDetailTO.getReportingLogger());
		String fieldEnabledStatus = null;
		if (flag) {
			fieldEnabledStatus = CommonConstant.TRUE_VALUE;
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FIELD_ENABILITY);
		} else {
			fieldEnabledStatus = CommonConstant.FALSE_VALUE;
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.FIELD_DISABILITY);
		}
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					fieldEnabledStatus);
		}
	}
}
