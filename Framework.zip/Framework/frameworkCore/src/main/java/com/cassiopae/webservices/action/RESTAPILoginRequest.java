package com.cassiopae.webservices.action;

import java.util.regex.Pattern;

import org.apache.logging.log4j.*;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.webservices.action.util.RestWSUtility;

import io.restassured.response.Response;

public class RESTAPILoginRequest implements WSAction {

	private static Logger logger = LogManager.getLogger(RESTAPILoginRequest.class);

	@Override
	public void performWSAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		Logger reportingLogger = testCaseDetailTO.getReportingLogger();
		String userName = testCaseDetailTO.getTestCaseCommonData().getUserName();
		String password = testCaseDetailTO.getTestCaseCommonData().getPassword();
		String inputParameter = excelTestCaseFieldsTO.getInputTestData();
		/*
		 * Below code will read parameters from input data if user name and password are
		 * Provided then it will override
		 */
		String parlist[] = inputParameter.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String endPointurl = null;
		if (parlist.length == 2) {
			String credentials[] = parlist[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
			userName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), credentials[0]);
			password = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), credentials[1]);
		} 
		endPointurl = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), parlist[0]);
		reportingLogger.info(excelTestCaseFieldsTO.getTestCaseSteps());
		reportingLogger.info(WSReportingLoggerConstant.REQUEST_URL_MSG + endPointurl);
		reportingLogger.info(WSReportingLoggerConstant.LOGIN_REST_API_MSG + endPointurl + WSReportingLoggerConstant.USING
				+ WSReportingLoggerConstant.USERNAME_MSG + userName + WSReportingLoggerConstant.AND_MSG
				+ WSReportingLoggerConstant.PASSWORD_MSG + password + CommonConstant.SINGLE_QUOTE);
		Response responseObject = RestWSUtility.executeRestAPILoginService(userName, password, endPointurl);
		String generatedSessionID = responseObject.getHeader(WSCommonConstants.SESSION_TOKEN);
		logger.info(WSReportingLoggerConstant.SESSION_ID_MESSAGE + generatedSessionID);
		String cookies = RestWSUtility.generateCookie(responseObject);
		logger.info(WSReportingLoggerConstant.COOKIE_ID_MESSAGE + cookies);
		reportingLogger.info(WSReportingLoggerConstant.THE_REST_API_RESPONSE_Body + responseObject.asString());
		int loginResponseCode = responseObject.getStatusCode();
		String[] storeValueInVariable = CommonUtility.splitStringUsingPattern(
				excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);

		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[0], String.valueOf(loginResponseCode));
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[1], responseObject.asString());
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[2], String.valueOf(generatedSessionID));
			testCaseDetailTO.getVariableHolder().put(storeValueInVariable[3], String.valueOf(cookies));
		}
	}

}
