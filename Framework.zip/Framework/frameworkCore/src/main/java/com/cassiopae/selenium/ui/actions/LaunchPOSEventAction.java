package com.cassiopae.selenium.ui.actions;

import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;

public class LaunchPOSEventAction implements PerformAction {

	private static Logger tracelogger = LogManager.getLogger(LaunchPOSEventAction.class);

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		WebDriver driver = testCaseDetail.getDriver();
		try {
			driver.findElement(By.xpath(
					testCaseDetail.getLocatorHashMap().get(FunctionLocatorConstant.POS_EVENT_DROPDOWN_KEY).get(0)))
					.click();
		} catch (Exception e) {
			tracelogger.info("Drop-down icon is not present for populating events: "+e.getMessage());
		}
		try {
			WebElement webElement = driver.findElement(
					By.xpath(testCaseDetail.getLocatorHashMap().get(excelTestCaseFields.getLocatorKey()).get(0)));
			webElement.click();
		} catch (Exception er) {
			tracelogger.error(ReportLoggerConstant.EVENT_IS_NOT_PRESENT, er);
			throw new CATTException(ReportLoggerConstant.EVENT_IS_NOT_PRESENT);
		}

	}

}
