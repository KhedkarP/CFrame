/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.FrameworkConstant;

/**
 * @author nbhil
 *
 */
public class RightClickAction implements PerformAction {

	/**
	 * This method execute action for click action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		
			GenericAction.rightClick(excelTestCaseFieldsTO.getTestCaseSteps(), excelTestCaseFieldsTO.getLocatorKey(),
					testCaseDetailTO.getLocatorHashMap(), testCaseDetailTO.getDriver(),
					testCaseDetailTO.getReportingLogger());
	}

}
