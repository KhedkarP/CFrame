package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

public class GetDropDownValueCount implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		
		if (testCaseDetailTO.getWorkSheetName().contains(DBConstant.BO_APP_SHEET_NAME)
				|| testCaseDetailTO.getWorkSheetName().contains(DBConstant.MO_APP_SHEET_NAME)) {
			GenericAction.getDropDownValueCount(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			GenericAction.getDropDownValueCountForPOS(excelTestCaseFieldsTO, testCaseDetailTO);
		}
	}

}
