/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.FrameworkConstant;

/**
 * @author nbhil
 *
 */
public class SelectDropDownAction implements PerformAction {

	/**
	 * This method execute action for select drop down action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		if (testCaseDetailTO.getWorkSheetName().contains(FrameworkConstant.POS)
				|| StringUtils.startsWith(testCaseDetailTO.getWorkSheetName(), DBConstant.CC_APP_SHEET_NAME)) {
			GenericAction.selectDropdownPOS(excelTestCaseFieldsTO, testCaseDetailTO);
		} else {
			GenericAction.selectValueOf(excelTestCaseFieldsTO, testCaseDetailTO);
		}
	}

}
