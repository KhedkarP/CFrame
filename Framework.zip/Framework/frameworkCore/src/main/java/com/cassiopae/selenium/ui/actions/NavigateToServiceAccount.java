/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v93.network.Network;
import org.openqa.selenium.devtools.v93.network.model.Headers;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * @author nbhil
 *
 */
public class NavigateToServiceAccount implements PerformAction {

	/**
	 * This method execute action for click action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String[] inputTestData = excelTestCaseFieldsTO.getInputTestData().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		inputTestData[0]=VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),inputTestData[0]);
		inputTestData[1]=VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),inputTestData[1]);
		if(Objects.nonNull(testCaseDetailTO.getTestCaseCommonData().getDevTools())) {
			DevTools chromeDevConfig = testCaseDetailTO.getTestCaseCommonData().getDevTools();
			setDevToolConfig(chromeDevConfig, inputTestData[0], inputTestData[1]);
			testCaseDetailTO.getReportingLogger().info("Outlook profile loaded successfully");
			return;
		}
		testCaseDetailTO.getReportingLogger().warn("No Outlook profile found");
	}

	private void setDevToolConfig(DevTools devToolConfig,String userName,String password)
	{
		devToolConfig.createSession();
		devToolConfig.send(Network.enable(Optional.<Integer>empty(), Optional.<Integer>empty(), Optional.<Integer>empty()));
		Map<String, Object> map = new HashMap<>();
		String idAndPassword=userName+":"+password;
		map.put("Authorization", "Basic " + new String(org.apache.commons.codec.binary.Base64.encodeBase64(idAndPassword.getBytes())));
		devToolConfig.send(Network.setExtraHTTPHeaders(new Headers(map)));
	}

}
