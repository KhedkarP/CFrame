package com.cassiopae.framework.xl.reader;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.cassiopae.framework.util.constant.CommonConstant;

// To be incorporated for future sprints
public interface XlFileFormat {

	default Map<String, String> readProperties( final String propertyRead ) {
		try {
			FileReader reader = new FileReader( propertyRead );
			Properties properties = new Properties();
			properties.load( reader );
			Set set = properties.entrySet();
			Iterator itr=set.iterator();
			Map<String,String> columnsData=new HashMap<String, String>();
			while(itr.hasNext()){
				Map.Entry entry=(Map.Entry)itr.next();
				columnsData.put( entry.getKey().toString(), entry.getValue().toString() );
			}
			return columnsData;
		}
		catch ( IOException l_ex ) {
			l_ex.printStackTrace();
		}
		return null;
	}

	public default Map<String, Column> initialize( final String propertyFileName ) {

		Map<String, String> columnProperties = readProperties( propertyFileName );
		Map<String, Column> columns = new HashMap<>();
		Iterator it = columnProperties.entrySet().iterator();

		while ( it.hasNext() ) {
			Column column = new Column();
			Map.Entry pair = (Map.Entry) it.next();
			column.setEmptyAllowed( false );
			if ( null != DataType.valueOf( pair.getValue().toString() ) ) {
				column.setDataType( DataType.valueOf( pair.getValue().toString() ) );
			}
			if (CommonConstant.HASH_VALUE.equals(pair.getKey().toString())) {
				column.setName(CommonConstant.HASH_SEPERATOR);
				columns.put( CommonConstant.HASH_SEPERATOR, column );
			} else {
				column.setName( pair.getKey().toString() );
				columns.put( pair.getKey().toString(), column );
			}
			
			it.remove();
		}
		return columns;
	}


	List getColumns();


}
