package com.cassiopae.selenium.services.listener;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.cassiopae.framework.service.PostTestCaseExecutor;
import com.cassiopae.framework.to.CurrentTestCase;

public class TestCaseListenerAdapter extends TestListenerAdapter {

	@Override
	public void onTestFailure(ITestResult result) {
		if (null != CurrentTestCase.getCurrentdriver().get()) {
			PostTestCaseExecutor.addFailedScreenshotInReport(CurrentTestCase.getCurrentdriver().get(), result,CurrentTestCase.getConsolelogs().get());
		} 
	}
}
