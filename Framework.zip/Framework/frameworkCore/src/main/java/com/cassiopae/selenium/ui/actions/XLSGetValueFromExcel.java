package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class XLSGetValueFromExcel implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		String[] inputValue = CommonUtility.splitString(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.COMMA_SEPERATOR);
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		int excelInputDatareferenceCol = Integer.parseInt(inputValue[0].trim());
		int excelColumnNumber = CommonUtility.getGeneratedReferenceColumn(excelInputDatareferenceCol);
		String scenarioNameOnDashboard = inputValue[1].trim();
		String retrievedValue = CommonUtility.getReferenceFromStatusSheet(excelColumnNumber,
				scenarioNameOnDashboard, testCaseDetailTO.getTestCaseCommonData());
		testCaseDetailTO.getReportingLogger().info("Retrived value from excel is :- " + retrievedValue);

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), retrievedValue);
		}
	}

	
	
	
}
