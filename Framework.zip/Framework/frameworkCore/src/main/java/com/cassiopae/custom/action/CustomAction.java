/**
 * 
 */
package com.cassiopae.custom.action;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author nbhil
 *
 */
public interface CustomAction {
	/**
	 * This method calls the method using reflection.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO);

}
