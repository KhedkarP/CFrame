/**
 * 
 */
package com.cassiopae.framework.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

/**
 * This method will perform the Dashboard Excel read operation.
 * 
 * @author nbhil
 *
 */
public class DashboardExcelReadOperation {

	private DashboardExcelReadOperation() {

	}

	private static Logger logger = LogManager.getLogger(DashboardExcelReadOperation.class);

	/**
	 * This method will be reading the Dashboard excel.
	 * 
	 * @param dashboardDetails  DashboardDetails
	 * @param sheetName         String
	 * @param testDataExcelpath String
	 */
	public static synchronized void readDashboardExcel(final DashboardDetails dashboardDetails) {
		final String sheetName = ApplicationConstant.excelStatusSheetName;
		String testDataExcelpath = CommonUtility.getDashboardExcelPath(dashboardDetails.getDomainName());
		Path backupFile = Paths
				.get(testDataExcelpath.replace(ReportLoggerConstant.XLS, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE, new String[0]);
		try {
			File inputWorkbook = new File(testDataExcelpath);
			if ((inputWorkbook.exists()) && (inputWorkbook.length() > 0L)) {
				processFileOperation(dashboardDetails, sheetName, testDataExcelpath, backupFile, inputWorkbook);
			} else {
				logger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
				throw new CATTFileOperationException(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT+testDataExcelpath);
			}
		} catch (Exception exp) {
			logger.error(exp.getMessage(), exp);
			logger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
			throw new CATTFileOperationException(exp.getMessage());
		}
		logger.info(ReportLoggerConstant.RECORDS_QUALIFIED_FOR_PROCESSING_CLIENT + dashboardDetails.getDomainName()
				+ " Product is " + dashboardDetails.getProjectTestCase().size());
	}

	/**
	 * This method will do copy file operation.
	 * 
	 * @param dashboardDetails  DashboardDetails
	 * @param sheetName         String
	 * @param testDataExcelpath String
	 * @param backupFile        Path
	 * @param inputWorkbook     File
	 */
	private static void processFileOperation(final DashboardDetails dashboardDetails, final String sheetName,
			final String testDataExcelpath, Path backupFile, File inputWorkbook) {
		try (Workbook workbook = WorkbookFactory.create(inputWorkbook)) {
			Files.copy(Paths.get(testDataExcelpath, new String[0]), backupFile, new CopyOption[0]);
			processReadOperation(dashboardDetails, sheetName, testDataExcelpath, backupFile, inputWorkbook, workbook);
		} catch (EncryptedDocumentException | IOException exp) {
			logger.error(exp.getMessage(), exp);
			throw new CATTFileOperationException(exp.getMessage());
		}
	}

	/**
	 * This method check whether worksheet is present in workbook or not.
	 * 
	 * @param sheetName String
	 * @param workbook  Workbook
	 * @return boolean
	 */
	public static Boolean isWorksheetPresent(final String sheetName, Workbook workbook) {
		Boolean flag = Boolean.valueOf(false);
		for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
			if (workbook.getSheetName(i).equals(sheetName)) {
				flag = Boolean.valueOf(true);
				break;
			}
		}
		return flag;
	}

	/**
	 * This method perform read operation and delete the backup file.
	 * 
	 * @param dashboardDetails  DashboardDetails
	 * @param sheetName         String
	 * @param testDataExcelpath String
	 * @param backupFile        Path
	 * @param inputWorkbook     File
	 * @param workbook          Workbook
	 * @throws IOException
	 */
	private static void processReadOperation(final DashboardDetails dashboardDetails, final String sheetName,
			final String testDataExcelpath, Path backupFile, File inputWorkbook, Workbook workbook) throws IOException {
		Boolean flag = isWorksheetPresent(sheetName, workbook);
		if (flag.booleanValue()) {
			populateDashboardMap(dashboardDetails, sheetName, workbook);
			if (inputWorkbook.length() > 0L) {
				ExcelOperation.deleteExistingFile(backupFile);
			} else {
				Files.delete(inputWorkbook.toPath());
				Files.copy(backupFile, Paths.get(testDataExcelpath, new String[0]), new CopyOption[0]);
			}
		} else {
			logger.info(ReportLoggerConstant.SHEET_NAME_NOT_PRESENT_ON_EXCELWORKBOOK + sheetName);
			if (inputWorkbook.length() > 0L) {
				ExcelOperation.deleteExistingFile(backupFile);
			} else {
				logger.info(ReportLoggerConstant.DELETING_CORRUPTED_EXCEL_FILE_MESSAGE);

				Files.delete(inputWorkbook.toPath());
				Files.copy(backupFile, Paths.get(testDataExcelpath, new String[0]), new CopyOption[0]);
			}
		}
	}

	/**
	 * This method will populate map with row number as key and list as value.
	 * 
	 * @param dashboardDetails DashboardDetails
	 * @param sheetName        String
	 * @param workbook         Workbook
	 */
	private static void populateDashboardMap(final DashboardDetails dashboardDetails, final String sheetName,
			Workbook workbook) {
		Map<String, LinkedList<String>> projectTestCase = dashboardDetails.getProjectTestCase();
		String value;
		String key;
		DataFormatter dataFormatter = new DataFormatter();
		Sheet sheet = workbook.getSheet(sheetName);
		int noOfColumns = sheet.getRow(0).getLastCellNum();
		int noOfRows = sheet.getLastRowNum() + 1;
		for (int i = 1; i < noOfRows; i++) {
			Cell cell = sheet.getRow(i).getCell(0);
			key = String.valueOf(i);
			LinkedList<String> values = new LinkedList<>();
			for (int j = 0; j < noOfColumns; j++) {
				cell = sheet.getRow(i).getCell(j);
				value = dataFormatter.formatCellValue(cell);
				values.add(value);
			}
			if (CommonConstant.YES.equalsIgnoreCase(values.get(InitializeConstants.execution_required))) {
				projectTestCase.put(key, values);
			}
		}
	}

}
