/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class AssertStartsWithIgnoreCase implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String[] inputData=CommonUtility.splitStringUsingPattern( excelTestCaseFieldsTO.getInputTestData(), CommonConstant.PIPE_SEPARATOR);
		String referenceValue=VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]);
		String prefixValue=VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[1]);
		GenericAction.assertStartsWithIgnoreCase(referenceValue, prefixValue, excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
	}

}
