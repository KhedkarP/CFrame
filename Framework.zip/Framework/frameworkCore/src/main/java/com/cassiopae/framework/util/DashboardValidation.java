/**
 * 
 */
package com.cassiopae.framework.util;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.DashboardDetails;
import com.cassiopae.framework.to.ErrorValidation;
import com.cassiopae.framework.to.XlsFileRowDetails;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;

/**
 * This class will Validate the dashboard excel.
 * 
 * @author nbhil
 *
 */
public class DashboardValidation {

	private DashboardValidation() {

	}

	private static Logger logger = LogManager.getLogger(DashboardValidation.class);

	/**
	 * This method will validate the dashboard excel values.
	 * 
	 * @param dashboardDetails DashboardDetails
	 * @return List<ErrorValidation>
	 */
	public static List<ErrorValidation> validateDashboard(final DashboardDetails dashboardDetails) {
		final Map<String, LinkedList<XlsFileRowDetails>> xlsFileRowDetailsMap = dashboardDetails.getXlsFileRowDetailsMap();
		Map<String, Map<String, Integer>> mapOfClassWithMethodPriority = dashboardDetails
				.getMapOfClassWithMethodPriority();
		Map<String, ArrayList<String>> mapOfClassMethod = dashboardDetails.getMapOfClassMethod();
		List<ErrorValidation> errorMessageList = new ArrayList<>();
		for (Map.Entry<String, LinkedList<XlsFileRowDetails>> entry : xlsFileRowDetailsMap.entrySet()) {
			boolean isMethodNameDuplicate = false;
			boolean isPriorityDuplicate = false;
			List<XlsFileRowDetails> dataList = entry.getValue();
			if (dataList == null) {
				continue;
			}
			for (XlsFileRowDetails xlsFileRowDetails : dataList) {
				if (validateMandatoryValues(xlsFileRowDetails, errorMessageList)) {
					continue;
				}
				validateSyntanx(xlsFileRowDetails, errorMessageList, mapOfClassWithMethodPriority, mapOfClassMethod,
						isMethodNameDuplicate);

				validateDependentScenario(xlsFileRowDetails, errorMessageList, mapOfClassWithMethodPriority,
						isPriorityDuplicate);
				isMethodNameDuplicate = true;
				isPriorityDuplicate = true;
			}

		}
		return errorMessageList;
	}

	/**
	 * This method will validate for special characters.
	 * 
	 * @param value String
	 * @return boolean
	 */
	private static boolean validateSpecialCharacter(String value) {
		Pattern specialCharPattern = Pattern.compile("[!@#$%&*()+=|<>?{}\\[\\]~-]");
		Matcher hasSpecial = specialCharPattern.matcher(value);
		Pattern spacePattern = Pattern.compile("\\s");
		Matcher hasSpecial1 = spacePattern.matcher(value);
		return (hasSpecial.find() || hasSpecial1.find());
	}

	/**
	 * This method will validate mandatory values.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @return boolean
	 */
	private static boolean validateMandatoryValues(final XlsFileRowDetails xlsFileRowDetails,
			List<ErrorValidation> errorMessageList) {
		boolean result = false;
		if (StringUtils.isEmpty(xlsFileRowDetails.getClassName())) {
			result = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),ErrorMessageConstant.BLANK_WORKBOOK_NAME_ERROR_MESSAGE,
					xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (StringUtils.isEmpty(xlsFileRowDetails.getMethodName())) {
			result = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.BLANK_WORKSHEET_NAME_ERROR_MESSAGE,
					xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (StringUtils.isEmpty(xlsFileRowDetails.getTestType())) {
			result = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),
					ErrorMessageConstant.BLANK_TEST_TYPE_ERROR_MESSAGE+CommonConstant.REGRESSION_TEST_TYPE+CommonConstant.OR+CommonConstant.SANITY_TEST_TYPE,
					xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (StringUtils.isEmpty(xlsFileRowDetails.getBrowser())) {
			result = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.BLANK_BROWSER_NAME_ERROR_MESSAGE,
					xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (StringUtils.isEmpty(xlsFileRowDetails.getPriority())) {
			result = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.BLANK_PRIORITY_NAME_ERROR_MESSAGE,
					xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		return result;

	}

	private static boolean validateSyntanx(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList,
			Map<String, Map<String, Integer>> mapOfClassWithMethodPriority,
			Map<String, ArrayList<String>> mapOfClassMethod, boolean isMethodNameDuplicate) {

		ArrayList<String> methodList = new ArrayList<>();
		for (Map.Entry<String, Integer> entry : mapOfClassWithMethodPriority.get(xlsFileRowDetails.getClassName())
				.entrySet()) {
			methodList.add(entry.getKey());
		}

		boolean resultValue = false;
		resultValue = validateTestType(xlsFileRowDetails, errorMessageList, resultValue);
		resultValue = validateClassName(xlsFileRowDetails, errorMessageList, resultValue);
		resultValue = validateMethodName(xlsFileRowDetails, errorMessageList, mapOfClassMethod, resultValue,
				isMethodNameDuplicate);

		resultValue = validateBrowser(xlsFileRowDetails, errorMessageList, resultValue);
		//resultValue = validatePaymentSchedule(xlsFileRowDetails, errorMessageList, resultValue);
		return resultValue;
	}

	/*
	*//**
	 * This method will validate Payment schedule.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @return boolean
	 *//*
	private static boolean validatePaymentSchedule(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, boolean resultValue) {
		if (StringUtils.isEmpty(xlsFileRowDetails.getPaymentScheduleScenerio())) {
			xlsFileRowDetails.setPaymentScheduleScenerio(CommonConstant.NO);
		}
		if (!CommonConstant.YES.equalsIgnoreCase(xlsFileRowDetails.getPaymentScheduleScenerio())
				&& !CommonConstant.NO.equalsIgnoreCase(xlsFileRowDetails.getPaymentScheduleScenerio())) {
			resultValue = true;
			errorMessageList
					.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.INVALID_PAY_SCHED_VALUE,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		return resultValue;
	}
*/
	/**
	 * This method validate browser.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @return boolean
	 */
	private static boolean validateBrowser(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, boolean resultValue) {
		if (!CommonConstant.CHROME_BROWSER.equalsIgnoreCase(xlsFileRowDetails.getBrowser())
				&& !CommonConstant.IE_BROWSER.equalsIgnoreCase(xlsFileRowDetails.getBrowser())&& !CommonConstant.MS_EDGE_BROWSER.equalsIgnoreCase(xlsFileRowDetails.getBrowser())) {
			resultValue = true;
			errorMessageList
					.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.INVALID_BROWSER_NAME,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (validateSpecialCharacter(xlsFileRowDetails.getBrowser())) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.BROWSER_NAME_CONT_SPEC_CHAR,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		return resultValue;
	}

	/**
	 * This method validate method name.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @param mapOfClassMethod  Map<String, ArrayList<String>>
	 * @param tempList
	 * @return boolean
	 */
	private static boolean validateMethodName(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, Map<String, ArrayList<String>> mapOfClassMethod,
			boolean resultValue, boolean isMethodNameValidated) {
		if (!isMethodNameValidated) {
			resultValue = methodNameDuplicate(xlsFileRowDetails, errorMessageList, mapOfClassMethod, resultValue);
		}

		if (xlsFileRowDetails.getMethodName().length() > 31) {
			resultValue = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),
					ErrorMessageConstant.METHOD_NAME_MAX_LENGTH_CROSSED, xlsFileRowDetails.getMethodName(),
					xlsFileRowDetails.getClassName()));
		}
		if (validateSpecialCharacter(xlsFileRowDetails.getMethodName())) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.METHOD_NAME_CONT_SPEC_CHAR,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (!xlsFileRowDetails.getMethodName().contains(DBConstant.MO_MODULE) && !xlsFileRowDetails.getMethodName().contains(DBConstant.BO_MODULE)
				&& !xlsFileRowDetails.getMethodName().contains(DBConstant.POS_MODULE) && !xlsFileRowDetails.getMethodName().contains(DBConstant.API_APP_SHEET_NAME)) {
			resultValue = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),
					ErrorMessageConstant.METHOD_NAME_CONT_INVALID_WORD, xlsFileRowDetails.getMethodName(),
					xlsFileRowDetails.getClassName()));
		}
		return resultValue;
	}

	private static boolean methodNameDuplicate(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, Map<String, ArrayList<String>> mapOfClassMethod,
			boolean resultValue) {
		StringBuilder errorMessage = null;
		ArrayList<String> tempList = new ArrayList<>();
		for (String listOfMethod : mapOfClassMethod.get(xlsFileRowDetails.getClassName())) {
			if (!tempList.contains(listOfMethod)) {
				tempList.add(listOfMethod);
			} else {
				errorMessage = new StringBuilder();
				errorMessage.append(ErrorMessageConstant.DUPLICATE_METHOD_NAME_FOR_CLASS)
						.append(xlsFileRowDetails.getClassName()).append(" and ")
						.append(ErrorMessageConstant.DUPLICATE_METHOD_NAME).append(listOfMethod);
				resultValue = true;
				errorMessageList.add(getErrorValidation(CommonConstant.EMPTY_STRING, errorMessage.toString(),
						CommonConstant.EMPTY_STRING, CommonConstant.EMPTY_STRING));
			}
		}
		return resultValue;
	}

	private static boolean isPriorityDuplicate(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList,
			Map<String, Map<String, Integer>> mapOfClassWithMethodPriority, boolean resultValue) {
		StringBuilder errorMessage = null;
		ArrayList<Integer> priorityList = new ArrayList<>();
		for (Map.Entry<String, Integer> entry : mapOfClassWithMethodPriority.get(xlsFileRowDetails.getClassName())
				.entrySet()) {
			if (!priorityList.contains(entry.getValue())) {
				priorityList.add(entry.getValue());
			} else {
				errorMessage = new StringBuilder();
				errorMessage.append(ErrorMessageConstant.DUPLICATE_PIORITY_FOR_CLASS)
						.append(xlsFileRowDetails.getClassName())
						.append(ErrorMessageConstant.DUPLICATE_PRIORITY_FOR_METHOD).append(entry.getKey());
				resultValue = true;
				errorMessageList.add(getErrorValidation(CommonConstant.EMPTY_STRING, errorMessage.toString(),
						CommonConstant.EMPTY_STRING, CommonConstant.EMPTY_STRING));
			}

		}
		return resultValue;
	}

	/**
	 * This method will validate class Name.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @return boolean
	 */
	private static boolean validateClassName(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, boolean resultValue) {

		if (!xlsFileRowDetails.getClassName().startsWith(FrameworkConstant.TEST_TYPE_SAN_QA)
				&& !xlsFileRowDetails.getClassName().startsWith(FrameworkConstant.TEST_TYPE_REG_QA)) {
			resultValue = true;
			errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),
					ErrorMessageConstant.CLASS_NAME_SHOULD_START_WITH_REG_OR_SAN, xlsFileRowDetails.getMethodName(),
					xlsFileRowDetails.getClassName()));
		} else {
			if (xlsFileRowDetails.getTestType().contains(FrameworkConstant.TEST_TYPE_SAN_QA)
					&& !xlsFileRowDetails.getClassName().startsWith(FrameworkConstant.TEST_TYPE_SAN_QA)) {
				resultValue = true;
				errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.TYPE_SAN_QA,
						xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
			}
			if (xlsFileRowDetails.getTestType().contains(FrameworkConstant.TEST_TYPE_REG_QA)
					&& !xlsFileRowDetails.getClassName().startsWith(FrameworkConstant.TEST_TYPE_REG_QA)) {
				resultValue = true;
				errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.TYPE_REG_QA,
						xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
			}
		}

		if (xlsFileRowDetails.getClassName().length() > 150) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.CLASS_NAME_MAX_LENTH_CROSSED,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (validateSpecialCharacter(xlsFileRowDetails.getClassName())) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.CLASS_NAME_CONT_SPEC_CHAR,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (xlsFileRowDetails.getClassName().equals(xlsFileRowDetails.getMethodName())) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.SAME_CLASS_AND_METHOD_NAME,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		return resultValue;
	}

	/**
	 * This method validate Test Type.
	 * 
	 * @param xlsFileRowDetails XlsFileRowDetails
	 * @param errorMessageList  List<ErrorValidation>
	 * @return boolean
	 */
	private static boolean validateTestType(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList, boolean resultValue) {
		if (!xlsFileRowDetails.getTestType().contains(FrameworkConstant.TEST_TYPE_REG_QA)
				&& !xlsFileRowDetails.getTestType().contains(FrameworkConstant.TEST_TYPE_SAN_QA)) {
			resultValue = true;
			errorMessageList
					.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.BLANK_TEST_TYPE_ERROR_MESSAGE+CommonConstant.REGRESSION_TEST_TYPE+CommonConstant.OR+CommonConstant.SANITY_TEST_TYPE,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		if (validateSpecialCharacter(xlsFileRowDetails.getTestType())) {
			resultValue = true;
			errorMessageList.add(
					getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.TEST_TYPE_CONT_SPEC_CHAR,
							xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
		}
		return resultValue;
	}

	public static boolean validateDependentScenario(final XlsFileRowDetails xlsFileRowDetails,
			final List<ErrorValidation> errorMessageList,
			Map<String, Map<String, Integer>> mapOfClassWithMethodPriority, boolean isPriorityDuplicate) {

		ArrayList<String> methodList = new ArrayList<>();
		for (Map.Entry<String, Integer> entry : mapOfClassWithMethodPriority.get(xlsFileRowDetails.getClassName())
				.entrySet()) {
			methodList.add(entry.getKey());
		}

		boolean resultValue = false;

		if (!StringUtils.isEmpty(xlsFileRowDetails.getDependsOnScenerio())
				&& !xlsFileRowDetails.getDependsOnScenerio().equalsIgnoreCase("null")) {
			if (!methodList.contains(xlsFileRowDetails.getDependsOnScenerio())) {
				resultValue = true;
				errorMessageList.add(getErrorValidation(xlsFileRowDetails.getRowNum(),
						ErrorMessageConstant.DEPENDENT_METHOD_NOT_EXIST, xlsFileRowDetails.getMethodName(),
						xlsFileRowDetails.getClassName()));
				return resultValue;
			}
			if ((mapOfClassWithMethodPriority.get(xlsFileRowDetails.getClassName()).get(
					xlsFileRowDetails.getDependsOnScenerio())) >= Integer.valueOf(xlsFileRowDetails.getPriority())) {
				resultValue = true;
				errorMessageList
						.add(getErrorValidation(xlsFileRowDetails.getRowNum(), ErrorMessageConstant.INVALID_PRIORITY,
								xlsFileRowDetails.getMethodName(), xlsFileRowDetails.getClassName()));
			}
		}
		if (!isPriorityDuplicate) {
			resultValue = isPriorityDuplicate(xlsFileRowDetails, errorMessageList, mapOfClassWithMethodPriority,
					resultValue);
		}

		return resultValue;
	}

	/**
	 * This method will return the ErrorValidation instance.
	 * 
	 * @param rowNumber     String
	 * @param errorMessage  String
	 * @param workSheetName String
	 * @param workBookName  String
	 * @return ErrorValidation
	 */
	private static ErrorValidation getErrorValidation(String rowNumber, String errorMessage, String workSheetName,
			String workBookName) {

		ErrorValidation errorValidation = new ErrorValidation();
		errorValidation.setRowNumber(rowNumber);
		errorValidation.setErrorMassage(errorMessage);
		errorValidation.setWorkSheetName(workSheetName);
		errorValidation.setWorkBookName(workBookName);
		return errorValidation;
	}

}
