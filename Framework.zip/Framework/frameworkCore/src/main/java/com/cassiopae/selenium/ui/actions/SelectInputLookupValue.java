/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * @author skumar
 *
 */
public class SelectInputLookupValue implements PerformAction {

	/**
	 * This method execute action SelectInputLookupValue .
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		String inputTestDataValue = null;
		CommonUtility.logTransactions(testCaseDetail.getDriver(), excelTestCaseFields.getTestCaseSteps());
		inputTestDataValue = CommonFunctions.getInputTextBoxData(excelTestCaseFields);
		if (!StringUtils.isEmpty(inputTestDataValue)
				&& inputTestDataValue.trim().startsWith(CommonConstant.DOLER_WITH_OPENING_CULRY_BRACE_SEPERATOR)
				&& inputTestDataValue.trim().endsWith(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)) {
			inputTestDataValue = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					inputTestDataValue);
		}
		selectInputAddresslookUpvalue(inputTestDataValue, excelTestCaseFields, testCaseDetail);
	}

	/**
	 * This method will enter input value of look up field and select first value
	 * from it .
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	private void selectInputAddresslookUpvalue(String testDataValue, ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {
		final String logMessage = excelTestCaseFields.getTestCaseSteps();
		final String testData = testDataValue;
		final String xpathKey = excelTestCaseFields.getLocatorKey();
		final Map<String, List<String>> locatorHM = testCaseDetail.getLocatorHashMap();
		final WebDriver driver = testCaseDetail.getDriver();
		final Logger reportingLogger = testCaseDetail.getReportingLogger();
		reportingLogger.info(logMessage + ReportLoggerConstant.AS + testData);
		if (testData == null) {
			reportingLogger.error(CommonConstant.LEFT_CONSTANT + ReportLoggerConstant.TESTDATA_VALUE_NULL
					+ CommonConstant.RIGHT_CONSTANT);
			throw new CATTException(ReportLoggerConstant.TESTDATA_VALUE_NULL);
		}
		WebElement element = GenericAction.getWebElement(driver, GenericAction.locator(xpathKey, locatorHM),
				reportingLogger);
		if (GenericAction.checkElementOnUI(element, locatorHM, driver, reportingLogger)) {
			CommonUtility.logTransactions(driver, logMessage);
			try {
				if (testCaseDetail.getTestCaseCommonData().getBrowserName()
						.equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
					if (testCaseDetail.getTestCaseCommonData().getWorkSheetName().contains(FrameworkConstant.POS)
							|| StringUtils.startsWith(testCaseDetail.getTestCaseCommonData().getWorkSheetName(),
									DBConstant.CC_APP_SHEET_NAME)) {
						element.clear();
						driver.findElement(GenericAction.locator(xpathKey, locatorHM)).sendKeys(testData);
						CommonFunctions.explicitWait(3000);
						String xpathForSelection = "//div[contains(@class,'k-react-select__option')][1]";
						List<WebElement> optionsAvailable = testCaseDetail.getDriver()
								.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
						testCaseDetail.getReportingLogger().info("Total available drop-down values are: "+optionsAvailable.size());
						if (!optionsAvailable.isEmpty()) {
							WebElement webElement = testCaseDetail.getDriver().findElement(By.xpath(xpathForSelection));
							if (GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element,
									testCaseDetail.getDriver(), testCaseDetail.getReportingLogger())) {
								webElement.click();
							}
						}
					} else {
						String Edgelocator = locatorHM.get(xpathKey).get(0);
						Edgelocator = Edgelocator + FunctionLocatorConstant.LOOKUP_VALUE;
						element.click();
						element.clear();
						driver.findElement(GenericAction.locator(xpathKey, locatorHM)).sendKeys(testData);
						testCaseDetail.getDriver().findElement(By.xpath(Edgelocator)).click();
					}
				} else {
					if (testCaseDetail.getTestCaseCommonData().getWorkSheetName().contains(FrameworkConstant.POS)
							|| StringUtils.startsWith(testCaseDetail.getTestCaseCommonData().getWorkSheetName(),
									DBConstant.CC_APP_SHEET_NAME)) {
						element.clear();
						driver.findElement(GenericAction.locator(xpathKey, locatorHM)).sendKeys(testData);
						CommonFunctions.explicitWait(3000);
						String xpathForSelection = "//div[contains(@class,'k-react-select__option')][1]";
						List<WebElement> optionsAvailable = testCaseDetail.getDriver()
								.findElements(By.xpath(FunctionLocatorConstant.SELECT_CONTROl_KEY));
						testCaseDetail.getReportingLogger().info("Total matched drop-down values after entering '"+testData+"' are: "+optionsAvailable.size());
						if (!optionsAvailable.isEmpty()) {
							WebElement webElement = testCaseDetail.getDriver().findElement(By.xpath(xpathForSelection));
							if (GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(element,
									testCaseDetail.getDriver(), testCaseDetail.getReportingLogger())) {
								webElement.click();
							}
						} else {
							String errorMessage ="Drop-down value is not populated for data '"+testData+"' on lookup field";
							reportingLogger.error(errorMessage);
							throw new CATTException(errorMessage);
						}
					} else {
						String chromelocator = locatorHM.get(xpathKey).get(0);
						chromelocator = chromelocator + FunctionLocatorConstant.LOOKUP_VALUE;
						element.click();
						element.clear();
						driver.findElement(GenericAction.locator(xpathKey, locatorHM)).sendKeys(testData);
						CommonFunctions.explicitWait(4000);
						testCaseDetail.getDriver().findElement(By.xpath(chromelocator)).click();
					}
				}
			} catch (NoSuchElementException e2) {
				if (e2.getMessage().contains(CommonConstant.NO_SUCH_ELEMENT_FOUND)) {
					String error = e2.getMessage().split(CommonConstant.SELCTOR)[1]
							.split(CommonConstant.CLOSING_CULRY_BRACE_SEPERATOR)[0];
					error = ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_MESSAGE + error;
					reportingLogger.error(CommonConstant.LEFT_CONSTANT + error + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(ReportLoggerConstant.UNABLE_TO_LOCATE_ELEMENT_DETAILS);
				} else {
					reportingLogger
							.error(CommonConstant.LEFT_CONSTANT + e2.getMessage() + CommonConstant.RIGHT_CONSTANT);
					throw new CATTException(e2.getMessage());
				}
			} catch (IllegalArgumentException e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			} catch (Exception e) {
				reportingLogger.error(CommonConstant.LEFT_CONSTANT + e.getMessage() + CommonConstant.RIGHT_CONSTANT);
				throw new CATTException(e.getMessage());
			}
		} else {
			reportingLogger.error(ReportLoggerConstant.FIELD_DISABILITY);
			throw new CATTException(ReportLoggerConstant.FIELD_DISABILITY);
		}
	}
}
