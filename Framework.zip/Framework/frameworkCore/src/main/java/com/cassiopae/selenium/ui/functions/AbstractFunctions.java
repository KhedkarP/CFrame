package com.cassiopae.selenium.ui.functions;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public abstract class AbstractFunctions implements PerformFunctions {

	protected abstract void open(String reference, WebDriver driver, Logger logger);

	protected abstract void navigateTo(WebDriver driver, Logger logger);

	@Override
	public void perform(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		String[] inputData = null;

		inputData = excelTestCaseFields.getInputTestData() != null ? excelTestCaseFields.getInputTestData().split(CommonConstant.COLON_SEPERATOR)
				: null;
		String[] action = CommonUtility.splitString(excelTestCaseFields.getAction(), CommonConstant.UNDER_SCORE);

		if (FunctionConstant.NAVIGATE_TO.equals(action[2])) {
			navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		} else if (FunctionConstant.OPEN.equals(action[2])) {
			open(inputData[0], testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		}
	}

}
