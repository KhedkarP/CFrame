package com.cassiopae.webservices.action.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.excel.util.ExcelReader;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.utils.excel.ExcelOperation;

public class WSExcelReader {

	private WSExcelReader() {
		throw new IllegalAccessError();
	}

	private static Logger log = LogManager.getLogger(WSExcelReader.class);

	public static synchronized Map<String, String> readExcelData(String sheetName, String excelpath, int rowNum) {
		LinkedHashMap<String, String> map = new LinkedHashMap<>();
		Path backUpFilePath = Paths
				.get(excelpath.replace(CommonConstant.XLSX_FILE_EXTENSION, ReportLoggerConstant.EMPTY_STRING)
						+ ReportLoggerConstant.LAST_BACKUP_FILE);
		File inputWorkbook = new File(excelpath);
		if (inputWorkbook.exists() && inputWorkbook.length() > 0) {
			ExcelOperation.excelBackupCreate(excelpath, backUpFilePath);
			readTestData(sheetName, rowNum, map, inputWorkbook);
			if (inputWorkbook.length() > 0) {
				ExcelOperation.deleteExistingFile(backUpFilePath);
			} else {
				try {
					Files.delete(inputWorkbook.toPath());
					Files.copy(backUpFilePath, Paths.get(excelpath));
				} catch (IOException e) {
					log.error(e);
				}
			}
		} else {
			log.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT);
		}
		return map;
	}

	/**
	 * This method is used to read & create map of test data
	 * 
	 * @param sheetName
	 * @param rowNum
	 * @param map
	 * @param inputWorkbook
	 */
	private static void readTestData(String sheetName, int rowNum, LinkedHashMap<String, String> map,
			File inputWorkbook) {
		String value;
		String key;
		try (Workbook workbook = new XSSFWorkbook(inputWorkbook)) {
			if (ExcelReader.checkSheetIsPresent(workbook, sheetName)) {
				Sheet sheet = workbook.getSheet(sheetName);
				int noOfColumns = sheet.getRow(rowNum).getLastCellNum();
				for (int i = 3; i < noOfColumns; i++) {
					Cell cell = sheet.getRow(rowNum).getCell(i);
					key = cell.getStringCellValue();
					cell = sheet.getRow(rowNum + 1).getCell(i);
					DataFormatter formatter = new DataFormatter();
					value = formatter.formatCellValue(cell);
					map.put(key, value);
				}
			} else {
				log.info(ReportLoggerConstant.SHEET_IS_NOT_PRESENT_IN_WORKBOOK);
			}
		} catch (IOException | InvalidFormatException exp) {
			log.error(exp);
			throw new CATTException(exp.getMessage());
		}
	}

	/**
	 * This method is used to read web service data from test case excel file
	 * @param workSheetName excel sheetName where web service data is stored 
	 * @param dataFormatter
	 * @param locale
	 * @param filePath
	 * @param rowNumber
	 * @return Map which contains web service parameters
	 */
	public static Map<String, String> createTestDataMap(final String workSheetName, DataFormatter dataFormatter,
			String locale, String filePath, final int... rowNumber) {
		String value;
		String key;
		LinkedHashMap<String, String> value1 = new LinkedHashMap<>();
		try (FileInputStream input = new FileInputStream(filePath); XSSFWorkbook workbook = new XSSFWorkbook(input);) {
			Sheet sheet = workbook.getSheet(workSheetName);
			for (int singlerow : rowNumber) {
				if (singlerow > 0) {
					for (int i = 3; i <= sheet.getRow(singlerow).getLastCellNum() - 1; i++) {
						Cell cell = sheet.getRow(singlerow).getCell(i);
						key = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,workSheetName);
						cell = sheet.getRow(singlerow + 1).getCell(i);
						value = ExcelReader.formulaEvaluator(cell, dataFormatter, locale,workSheetName);
						if (null != key && null != value && !key.equals(ReportLoggerConstant.EMPTY_STRING)
								&& !value.equals(ReportLoggerConstant.EMPTY_STRING)) {

							value1.put(key, value);
						}
					}
				}
			}
		} catch (IOException e) {
			log.error(e);
			throw new CATTException(e.getMessage());
		}
		return value1;
	}
}
