package com.cassiopae.custom.action;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.date.DateUtils;

public class GenerateDynamicDateAction implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputTestDatas = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String inputDateValue = inputTestDatas[0];
		String givenDatevalue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputDateValue);
		String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String calculatedDate = DateUtils.generateDynamicDate(excelTestCaseFieldsTO, testCaseDetailTO, reqValues, givenDatevalue);

		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), calculatedDate);
		}
	}

}
