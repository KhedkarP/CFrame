/**
 * 
 */
package com.cassiopae.selenium.ui.functions.executor;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author nbhil
 *
 */
public interface FunctionExecutor {

	public void executeFunction(String methodName,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail);
	
}
