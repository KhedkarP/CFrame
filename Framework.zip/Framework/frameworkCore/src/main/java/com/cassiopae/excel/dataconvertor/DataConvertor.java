/**
 * 
 */
package com.cassiopae.excel.dataconvertor;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;

/**
 * @author nbhil
 *
 */
public interface DataConvertor {

	public String convertData(final Cell cellvalue, final DataFormatter dataFormatter,String locale,String worksheetName);
}
