package com.cassiopae.framework.xl.reader;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class EnvironmentXLFormat implements XlFileFormat {

	private static EnvironmentXLFormat _instance = null;
	private Map<String, Column> columnMap = new HashMap<>();
	private List<Column> columnList = null;

	private EnvironmentXLFormat() {
	}

	public static EnvironmentXLFormat getInstance() {
		if ( _instance == null ) {
			synchronized ( EnvironmentXLFormat.class ) {
				if ( _instance == null ) {
					_instance = new EnvironmentXLFormat();
				}
			}
		}
		return _instance;
	}

	public void setColumns( final String propertyFile ) {
		columnMap = initialize( propertyFile );
	}

	@Override
	public List<Column> getColumns() {
		if (columnList == null) {
			columnList = new ArrayList<>();
			Iterator it = columnMap.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry) it.next();
				columnList.add((Column) pair.getValue());
			}
		}
		return Collections.unmodifiableList(columnList);
	}

	public Column getColumn( final String columnName ) {
		return columnMap.get( columnName );
	}
}
