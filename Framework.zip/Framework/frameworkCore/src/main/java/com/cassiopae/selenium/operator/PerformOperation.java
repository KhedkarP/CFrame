/**
 * 
 */
package com.cassiopae.selenium.operator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

/**
 * @author jraut
 *
 */
public interface PerformOperation {
    /**
	 * This method execute operation.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	public void executeOperation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO);


}
