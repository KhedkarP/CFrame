package com.cassiopae.custom.action;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.logging.log4j.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;

public class UpdateXMLaction implements CustomAction {

	private static Logger tracelogger = LogManager.getLogger(UpdateXMLaction.class);

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String fileName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]);
		String pathOfXML = DomainInitialization.initializeDomainWiseUploadFilePath(testCaseDetailTO.getDomainName())
				+ File.separator + fileName;
		testCaseDetailTO.getReportingLogger().info("File to be updated: " + fileName);

		try {
			// creating a constructor of file class and parsing an XML file
			File file = new File(pathOfXML);
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			String rootElement = doc.getDocumentElement().getNodeName();
			NodeList nodeList = doc.getElementsByTagName(rootElement);

			for (int i = 1; i < inputData.length; i++) {
				String[] nodeDetails = CommonUtility.splitStringUsingPattern(inputData[i],
						CommonConstant.COMMA_SEPERATOR);
				String tagName = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
						nodeDetails[0]);
				int occurenceNoTobeUpdated = Integer.parseInt(VariableHolder
						.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), nodeDetails[1].trim()));
				String valueToBeReplaced = VariableHolder
						.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), nodeDetails[2]);
				updateTagValue(testCaseDetailTO, tagName, occurenceNoTobeUpdated, valueToBeReplaced, nodeList);
			}

			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(pathOfXML));
			transformer.transform(source, result);

		} catch (Exception e) {
			testCaseDetailTO.getReportingLogger().error(ReportLoggerConstant.XML_FILE_UPDATION_ERROR_MESSAGE, e);
			tracelogger.error(ReportLoggerConstant.XML_FILE_UPDATION_ERROR_MESSAGE, e);
			throw new CATTException(ReportLoggerConstant.XML_FILE_UPDATION_ERROR_MESSAGE + e.getMessage());
		}

	}

	/**
	 * This method is for updating values in XML file against Tag
	 * 
	 * @param testCaseDetailTO
	 * @param tagName
	 * @param occurenceNoTobeUpdated
	 * @param valueToBeReplaced
	 * @param nodeList
	 */
	private void updateTagValue(TestCaseDetail testCaseDetailTO, String tagName, int occurenceNoTobeUpdated,
			String valueToBeReplaced, NodeList nodeList) {
		for (int itr = 0; itr < nodeList.getLength(); itr++) {
			Node node = nodeList.item(itr);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) node;
				String initialValue = eElement.getElementsByTagName(tagName).item(occurenceNoTobeUpdated)
						.getTextContent();
				eElement.getElementsByTagName(tagName).item(occurenceNoTobeUpdated).setTextContent(valueToBeReplaced);
				String updatedValue = eElement.getElementsByTagName(tagName).item(occurenceNoTobeUpdated)
						.getTextContent();
				testCaseDetailTO.getReportingLogger().info("File updated successfully: Initial value for tag " + tagName
						+ " is: '" + initialValue + "', Updated value: '" + updatedValue + "'");
			}
		}
	}

}
