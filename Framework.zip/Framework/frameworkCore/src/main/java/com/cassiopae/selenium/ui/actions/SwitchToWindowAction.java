/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.services.SeleniumUtility;

/**
 * @author nbhil
 *
 */
public class SwitchToWindowAction implements PerformAction {

	/**
	 * This method execute action for switch to window action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields'
	 * @param testCaseDetailTO      TestCaseDetail
	 */
	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		WebDriver driver = SeleniumUtility.switchToWindow(excelTestCaseFieldsTO.getInputTestData(),testCaseDetailTO);
		testCaseDetailTO.setDriver(driver);

	}

}
