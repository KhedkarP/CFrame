package com.cassiopae.framework.dao.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.utils.excel.ExcelOperation;
import com.gembox.spreadsheet.ExcelFile;
import com.gembox.spreadsheet.ExcelWorksheet;
import com.gembox.spreadsheet.SpreadsheetInfo;

public class DumpValidationUtility {

	public static Logger sqlLogger = LogManager.getLogger("SQLLogger");

	public static void dumpValidationProcess(String[] domains) {
		sqlLogger.debug(ReportLoggerConstant.FORMAT_MESSAGE + ErrorMessageConstant.DUMPA_VALIDATION_STARTED_MESSAGE
				+ domains.length + CommonConstant.LINE_SEPERATER);
		Connection moConnection = null;
		Connection boConnection = null;
		Map<String, String> appDetail = new HashMap<>();
		for (int i = 0; i < domains.length; i++) {
			String domainName = domains[i];
			ApplicationConstant.initializeEnvspecificTestDataPath = DomainInitialization
					.initializeDomainTestDataExcelPath(domainName);
			ApplicationConstant.initializeTestEnvExcelPath = DomainInitialization
					.initializeDomainTestEnvDetailExcelPath(domainName);
			String sqlFilesPath = DomainInitialization.initializeDomainWiseDumpValidationFilePath(domainName);
			String dumpValidationExcelDetailFilePath = sqlFilesPath
					+ InitializeConstants.dump_validation_excel_file_name + CommonConstant.XLSX_FILE_EXTENSION;
			sqlLogger.info("Dump Validation excel file path : " + sqlFilesPath);
			calculateExcelFormulae(dumpValidationExcelDetailFilePath);
			Map<String, LinkedList<String>> procedureDetails = ExcelOperation.getDumpValdationData(
					InitializeConstants.dump_validation_excel_file_sheet_name, dumpValidationExcelDetailFilePath,
					appDetail);
			try {
				if (!procedureDetails.isEmpty() && appDetail.containsKey(DBConstant.MO_MODULE)) {
					moConnection = DatabaseUtility.getConnection(DBConstant.MO_MODULE);
				}
				if (!procedureDetails.isEmpty() && appDetail.containsKey(DBConstant.BO_MODULE)) {
					boConnection = DatabaseUtility.getConnection(DBConstant.BO_MODULE);
				}
			} catch (SQLException e) {
				sqlLogger.error(e.getMessage(), e);
				Assert.fail(ErrorMessageConstant.DATABASE_CONNECTION_ERROR_MESSAGE + e.getMessage());
			}

			SQLLauncherUtility.executeDumpValidationSQL(moConnection, boConnection, procedureDetails);
			if (!appDetail.isEmpty()) {
				SQLLauncherUtility.closeConnections(moConnection, boConnection, appDetail);
			}
			try {
				writeDumpExcel(dumpValidationExcelDetailFilePath, procedureDetails);
			} catch (IOException e) {
				sqlLogger.info(ErrorMessageConstant.DUMP_EXCEL_FILE_WRITE_ERROR_MESSAGE + e.getMessage());
			}
		}
	}

	public static void writeDumpExcel(String excelFilePath, Map<String, LinkedList<String>> procedureDetails)
			throws IOException {
		boolean flag = false;
		File inputWorkbook = new File(excelFilePath);
		if (!(inputWorkbook.exists()) && (inputWorkbook.length() > 0L)) {
			sqlLogger.info(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + excelFilePath);
			throw new CATTException(ReportLoggerConstant.EXCEL_FILE_EITHER_CORRUPTED_DOESNOT_EXIT + excelFilePath);
		}
		try (Workbook workbook1 = new XSSFWorkbook(new FileInputStream(excelFilePath))) {
			for (int i = 0; i < workbook1.getNumberOfSheets(); i++) {
				if (workbook1.getSheetName(i).equals(InitializeConstants.dump_validation_excel_file_sheet_name)) {
					flag = true;
					break;
				}
			}
			if (flag) {
				Sheet sheet = workbook1.getSheet(InitializeConstants.dump_validation_excel_file_sheet_name);
				for (Map.Entry<String, LinkedList<String>> entry : procedureDetails.entrySet()) {
					List<String> sqlData = entry.getValue();
					Row row = sheet.getRow(Integer.parseInt(entry.getKey()));
					row.getCell(4).setCellValue(sqlData.get(4));
					row.getCell(5).setCellValue(sqlData.get(5));
				}
				FileOutputStream fileOut = new FileOutputStream(excelFilePath);
				workbook1.write(fileOut);
				fileOut.flush();
				fileOut.close();
			} else {
				StringBuilder messsageBuilder = new StringBuilder();
				messsageBuilder.append(ErrorMessageConstant.WORK_SHEET_NOT_FOUND).append(CommonConstant.SPACE)
						.append(excelFilePath).append(CommonConstant.SPACE).append(CommonConstant.COLON_SEPERATOR)
						.append(InitializeConstants.dump_validation_excel_file_sheet_name);
				String message = messsageBuilder.toString();
				sqlLogger.info(message);
				throw new CATTFileOperationException(message);
			}
		}
	}

	private static void calculateExcelFormulae(String dumpValidationExcelDetailFilePath) {
		// If using Professional version, put your serial key below.
		SpreadsheetInfo.setLicense("FREE-LIMITED-KEY");
		ExcelFile workbook;
		try {
			workbook = ExcelFile.load(dumpValidationExcelDetailFilePath);
			ExcelWorksheet worksheet = workbook.getWorksheet(InitializeConstants.dump_validation_excel_file_sheet_name);
			worksheet.calculate();
			workbook.save(dumpValidationExcelDetailFilePath);
		} catch (IOException e) {
			sqlLogger.error(e.getMessage(), e);
		}
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			sqlLogger.error(e.getMessage(), e);
		}
	}
}
