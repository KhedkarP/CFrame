
package com.cassiopae.selenium.operator;

import java.math.BigDecimal;

import com.cassiopae.excel.dataconvertor.DataConvertorUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.operator.utils.OperatorUtility;
import com.cassiopae.selenium.util.common.CommonUtility;

public class ArthmaticOperations implements PerformOperation
{
	@Override
	public void executeOperation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		BigDecimal result1 = null;
		String result = null;
		if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR)) {

			String[] holder = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
					CommonConstant.PIPE_SEPARATOR);
			result1 = OperatorUtility.executeCalculation(holder, testCaseDetailTO);
		}
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null)
			result = String.format("%.02f", result1);
		result = DataConvertorUtility.covertDataToUIFormat(testCaseDetailTO, result);
		testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), result);
		testCaseDetailTO.getReportingLogger().info("Result is : " + result);
	}
}
