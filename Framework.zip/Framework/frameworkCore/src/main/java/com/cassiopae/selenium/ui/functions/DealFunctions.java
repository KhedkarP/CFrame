package com.cassiopae.selenium.ui.functions;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class DealFunctions {

	private static Logger traceLogger = LogManager.getLogger(DealFunctions.class);
	/*
	 * Deal Functions
	 */
	private static Map<String, List<String>> dealLocatorMap = ObjectRepoInitialization.masterLocatorMap
			.get(ObjectRepoInitialization.DEAL_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger reportingLogger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.DEAL_MOUSE_HOVER, FunctionLocatorConstant.DEAL_MENU,
				dealLocatorMap, driver, reportingLogger);
		GenericAction.clickOn(FunctionReportingConstant.DEAL_SUB_MENU, FunctionLocatorConstant.DEAL_SUB_MENU,
				dealLocatorMap, driver, reportingLogger);
	}

	public static void open(String reference, ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_DEAL_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.DEAL_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(dealLocatorMap);
		GenericAction.enterValueIn(reference, excelTestCaseFields, testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_DEAL_REFERENCE_ICON,
				FunctionLocatorConstant.DEAL_SEARCH_ICON, dealLocatorMap, testCaseDetail.getDriver(),
				testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_DEAL_REFERENCE_HYPERLINK + reference,
				FunctionLocatorConstant.DEAL_REFERNCE_HYPERLINK, dealLocatorMap, testCaseDetail.getDriver(),
				testCaseDetail.getReportingLogger());
	}

	public static void checkDealIsSaved(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		CurrentTestCase.getToastMessageOnPOS().set(true);
		Wait<WebDriver> toastPopUpWait = new FluentWait<WebDriver>(testCaseDetail.getDriver())
				.withTimeout(Duration.ofSeconds(InitializeConstants.toastMessageWaitingTimeForPOS))
				.pollingEvery(Duration.ofMillis(1)).ignoring(NoSuchElementException.class);
		
		try {
			toastPopUpWait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath(CommonConstant.TOAST_POPUP_XPATH_POS)));
			DealFunctions.checkToastMessagePopup(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		} catch (TimeoutException toe) {
			testCaseDetail.getReportingLogger().warn("No toast pop-up displayed after click on deal save icon");
		} catch (Exception exp) {
			traceLogger.info(exp);
		}
		//checkPopupForPOS(testCaseDetail.getDriver(),testCaseDetail.getReportingLogger());
		CurrentTestCase.getToastMessageOnPOS().set(false);
		Map<String, List<String>> posDealLocatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		String dealNumber = testCaseDetail.getDriver()
				.findElement(GenericAction.locator(excelTestCaseFields.getLocatorKey(), posDealLocatorMap)).getText();
		testCaseDetail.getReportingLogger().info("Deal Reference fetched from summary panel is: " + dealNumber);
		
		if (StringUtils.isBlank(dealNumber)) {
			String errorMessage = "Deal is not saved as deal reference is not generated in summary panel";
			testCaseDetail.getReportingLogger().error(errorMessage);
			throw new CATTException(errorMessage);
		} else {
			testCaseDetail.getReportingLogger().info("**** Deal saved successfully *****");
		}
		if (excelTestCaseFields.getStoreValuesInVariable() != null) {
			testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), dealNumber);
		}
	}

	public static void checkPopupForPOS(WebDriver webDriver , Logger reportingLogger) {
		try {
			DealFunctions.checkToastMessagePopup(webDriver, reportingLogger);
		} catch (Exception e) {}
	}

	/**
	 * check error or warning message pop-up is appeared or not
	 * 
	 * @param webDriver
	 */
	public static void checkToastMessagePopup(final WebDriver webDriver, Logger reportingLogger) {
		WebElement element = null;
		Actions act = new Actions(webDriver);
		try {
			element = webDriver.findElement(By.xpath(
					"//div[contains(@class,'toastr animated rrt-error')]//div[@class='rrt-middle-container']/div"));
			if (element.isDisplayed()) {
				reportingLogger.error("Error pop-up displayed: " + element.getText());
				act.moveToElement(webDriver.findElement(By.xpath(FunctionLocatorConstant.POS_MYDEALS))).build().perform();
				CommonFunctions.explicitWait(5000);
				checkPopupForPOS(webDriver,reportingLogger);
			}
		} catch (Exception e) {
			//traceLogger.warn("Issue occured while getting error toast message: " + e.getMessage());
		}
		try {
			element = webDriver.findElement(By.xpath("//div[contains(@class,'toastr animated rrt-warning')]//div[@class='rrt-middle-container']/div"));
			if (element.isDisplayed()) {
				reportingLogger.warn("Warning pop-up displayed: " + element.getText());
				act.moveToElement(webDriver.findElement(By.xpath(FunctionLocatorConstant.POS_MYDEALS))).build()
						.perform();
				CommonFunctions.explicitWait(5000);
				checkPopupForPOS(webDriver,reportingLogger);
			}
		} catch (Exception e) {
			//traceLogger.info("Exception occurred while getting warning toast message: " + e.getMessage());
		}
		try {
			element = webDriver.findElement(By.xpath(
					"//div[contains(@class,'toastr animated rrt-success')]//div[@class='rrt-middle-container']/div"));
			if (element.isDisplayed()) {
				reportingLogger.info("Alert pop-up displayed: " + element.getText());
				act.moveToElement(webDriver.findElement(By.xpath(FunctionLocatorConstant.POS_MYDEALS))).build()
						.perform();
				CommonFunctions.explicitWait(5000);
				checkPopupForPOS(webDriver,reportingLogger);
			}
		} catch (Exception e) {
			//traceLogger.info("Exception occured while getting success toast message: " + e.getMessage());
		}
		
	}
}
