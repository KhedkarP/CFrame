/**
 * 
 */

package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;

/**
 * @author jraut
 *
 */
public class AssertEqualsValidator implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		excelTestCaseFieldsTO.getInputTestData();
		String variableHolderExpectedValue = VariableHolder.getValueFromVariableHolder(
				testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getExpectedResult());
		if(variableHolderExpectedValue == null) {
	        variableHolderExpectedValue=CommonConstant.EMPTY_STRING; }
		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + variableHolderExpectedValue);
		String variableHolderActualValue = VariableHolder.getValueFromVariableHolder(
				testCaseDetailTO.getVariableHolder(), excelTestCaseFieldsTO.getActualValue());
		GenericAction.assertEquals(variableHolderActualValue, variableHolderExpectedValue,
				excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getReportingLogger());
	}

	/*
	 * public void performValidation(ExcelTestCaseFieldsTO excelTestCaseFieldsTO,
	 * TestCaseDetailTO testCaseDetailTO) { if
	 * (testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.
	 * getExpectedResult()) != null)
	 * testCaseDetailTO.getLogger().info(excelTestCaseFieldsTO.getTestCaseSteps() +
	 * " - " + testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.
	 * getExpectedResult())); else
	 * testCaseDetailTO.getLogger().info(excelTestCaseFieldsTO.getTestCaseSteps() +
	 * " - " + excelTestCaseFieldsTO.getExpectedResult());
	 * 
	 * String var1 = null; String var2 = null; if
	 * (testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.
	 * getActualValue()) != null) var1 =
	 * testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.getActualValue
	 * ()); if (testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.
	 * getExpectedResult()) != null) var2 =
	 * testCaseDetailTO.getVariableHolder().get(excelTestCaseFieldsTO.
	 * getExpectedResult()); if (var1 != null && var2 != null)
	 * GenericAction.assertEquals(var1, var2,
	 * excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getLogger()); else
	 * if (var1 != null) GenericAction.assertEquals(var1,
	 * excelTestCaseFieldsTO.getExpectedResult(),
	 * excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getLogger()); else
	 * if (var2 != null)
	 * GenericAction.assertEquals(excelTestCaseFieldsTO.getActualValue(), var2,
	 * excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getLogger()); else
	 * GenericAction.assertEquals(excelTestCaseFieldsTO.getActualValue(),
	 * excelTestCaseFieldsTO.getExpectedResult(),
	 * excelTestCaseFieldsTO.getErrorMessage(), testCaseDetailTO.getLogger());
	 * 
	 * }
	 */
}
