/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class DynamicCheckBoxValidation implements PerformValidation {

	@Override
	public void performValidation(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());
		String[] locatorKeys = excelTestCaseFields.getLocatorKey().split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		GenericAction.locator(locatorKeys[0], locatorMap);
		String[] inputDataColumnValues = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String[] inputTestDataRowNumbers = inputDataColumnValues[0]
				.split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		if (CommonFunctions.checkArrayElementAreNumeric(inputTestDataRowNumbers, testCaseDetail)) {
			testCaseDetail.getReportingLogger()
					.error(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE);
			throw new CATTException(ErrorMessageConstant.CSMZ_DYNAMIC_ACTION_INPUT_DATA_VALIDATION_ERROR_MESSAGE);
		}
		String statusofcheckbox = performIscheckboxselcted(testCaseDetail, locatorMap, locatorKeys,
				inputTestDataRowNumbers, excelTestCaseFields.getTestCaseSteps());
		if (StringUtils.isNotEmpty(excelTestCaseFields.getStoreValuesInVariable()) )
			testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(), statusofcheckbox);

	}

	/**
	 * This method will create dynamic Xpath and Verify whether check box isSelected
	 * or not on generated xpath
	 * 
	 * @param testCaseDetail
	 * @param locatorMap
	 * @param locatorKeys
	 * @param inputTestDataRowNumbers
	 * @param dataRowNumber
	 */
	private static String performIscheckboxselcted(TestCaseDetail testCaseDetail, Map<String, List<String>> locatorMap,
			String[] locatorKeys, String[] inputTestDataRowNumbers, String logMessage) {

		String checkboxStatus = CommonConstant.FALSE_VALUE;
		String selectCheckBoxXpath;
		String xpath = CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap);
		if (!xpath.contains(CommonConstant.QUESTION_MARK_SEPERATOR)) {
			String value = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					inputTestDataRowNumbers[0].trim());
			String[] prefixSufixID = SelectPanelTableEntryUtility
					.getPrefixAndSuffixID(CommonFunctions.getLocatorKeyValue(locatorKeys[0], locatorMap));
			selectCheckBoxXpath = SelectPanelTableEntryUtility.constructXPath(Integer.parseInt(value), prefixSufixID[0],
					prefixSufixID[1]);
		} else {
			selectCheckBoxXpath = CommonFunctions.parseQuestionMarkString(xpath, testCaseDetail.getVariableHolder(),
					inputTestDataRowNumbers);
		}
		WebElement webElement = GenericAction.getWebElement(testCaseDetail.getDriver(), By.xpath(selectCheckBoxXpath),
				testCaseDetail.getReportingLogger());
		GenericAction.checkGeneratedDynamicXpathOnUIWithEnabilityAndVisibility(webElement, testCaseDetail.getDriver(),
				testCaseDetail.getReportingLogger());
		CommonUtility.logTransactions(testCaseDetail.getDriver(), logMessage);
		if (webElement.isSelected()) {
			checkboxStatus = CommonConstant.TRUE_VALUE;
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.CHECKBOX_IS_CHECKED);
		} else {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.CHECKBOX_IS_UNCHECKED);
		}
		return checkboxStatus;
	}
}
