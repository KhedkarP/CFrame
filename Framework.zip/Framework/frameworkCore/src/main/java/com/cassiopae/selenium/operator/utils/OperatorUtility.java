package com.cassiopae.selenium.operator.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.commons.lang3.StringUtils;

import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.operator.constant.OperatorConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.CommonUtility;

public class OperatorUtility {
	
	private OperatorUtility() {
	}

	public static String executeOperator(String[] holder, TestCaseDetail testCaseDetail) {
		String operator = holder[0].trim();
		String[] operands = holder[1].split(CommonConstant.COMMA_SEPERATOR);
		String operand1 = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				operands[0].trim());
		String operand2 = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				operands[1].trim());
		operand1=getNumberAsdecimalFormat(operand1);
		operand2=getNumberAsdecimalFormat(operand2);
		String result = null;
		if (operator.equals(OperatorConstant.EQUAL_TO)) {
			result = checkEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.NOT_EQUALT_TO)) {
			result = checkNotEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.GREATER_THAN)) {
			result = checkGreaterThanOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.LESS_THAN)) {
			result = checkLessThanOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.GREATER_THAN_EQUAL_TO)) {
			result = checkGreaterThanEqualToOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.LESS_THAN_EQUAL_TO)) {
			result = checkLessThanEqualToOperation(operand1, operand2, testCaseDetail);
		}

		return result;

	}
	
	
	/**
	 * @param operand
	 * @return
	 */
	public static String getNumberAsdecimalFormat(String operand) {
		String finaDecimalValue = null;
		// Remove all whitespaces in String
		String removeWhiteSpace = operand.replaceAll("\\s", CommonConstant.EMPTY_STRING);
		// Get lastIndex of comma , character
		int lastChar = removeWhiteSpace.lastIndexOf(CommonConstant.COMMA_SEPERATOR);
		// Replace LastIndex comma to period
		if(lastChar > 0) {
		StringBuilder valueWithoutSpace = new StringBuilder(removeWhiteSpace);
		valueWithoutSpace.setCharAt(lastChar, '.');
		removeWhiteSpace = valueWithoutSpace.toString();
		}
		finaDecimalValue = removeWhiteSpace.replace(CommonConstant.COMMA_SEPERATOR, CommonConstant.EMPTY_STRING);
		return finaDecimalValue;
	}
	
	

	private static String checkEqualToOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) == convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			if (Float.compare(convertDataToFloat(operand1), convertDataToFloat(operand2)) == 0) {
				return CommonConstant.TRUE_VALUE;
			} else {
				return CommonConstant.FALSE_VALUE;
			}
		} else {
			result = operand1.equals(operand2) ? CommonConstant.TRUE_VALUE : CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkNotEqualToOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is not equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) != convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			result = convertDataToFloat(operand1) != convertDataToFloat(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkGreaterThanOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is greater than '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) > convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			result = convertDataToFloat(operand1) > convertDataToFloat(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkLessThanOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		testCaseDetail.getReportingLogger().info("Checking '" + operand1 + "' is less than '" + operand2 + "'");
		String result = null;
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) < convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			result = convertDataToFloat(operand1) < convertDataToFloat(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkGreaterThanEqualToOperation(String operand1, String operand2,
			TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger()
				.info("Checking '" + operand1 + "' is greater than equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) >= convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			result = convertDataToFloat(operand1) >= convertDataToFloat(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static String checkLessThanEqualToOperation(String operand1, String operand2,
			TestCaseDetail testCaseDetail) {
		String result = null;
		testCaseDetail.getReportingLogger()
				.info("Checking '" + operand1 + "' is less than equal to '" + operand2 + "'");
		if (StringUtils.isNumeric(operand1) && StringUtils.isNumeric(operand2)) {
			result = convertDataToInteger(operand1) <= convertDataToInteger(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		} else if (CommonUtility.checkForFloating(operand1) || CommonUtility.checkForFloating(operand2)) {
			result = convertDataToFloat(operand1) <= convertDataToFloat(operand2) ? CommonConstant.TRUE_VALUE
					: CommonConstant.FALSE_VALUE;
		}
		return result;
	}

	private static Float convertDataToFloat(String value) {
		return Float.parseFloat(value);

	}
	private static BigDecimal convertDataToBigDecimal(String value)
	{
	return new BigDecimal(value);

	 }
	private static int convertDataToInteger(String value) {
		return Integer.parseInt(value);
	}

	public static BigDecimal executeCalculation(String[] holder, TestCaseDetail testCaseDetail) {
		String operator = holder[0].trim();
		String[] operands = holder[1].split(CommonConstant.COMMA_SEPERATOR);
		String initialOperand1=VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),operands[0]);
        String initialOperand2=VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),operands[1]);
        String operand1=org.apache.commons.lang.StringUtils.remove(initialOperand1," ").replaceAll(CommonConstant.COMMA_SEPERATOR,CommonConstant.DOT_OPERATOR);
        String operand2=org.apache.commons.lang.StringUtils.remove(initialOperand2," ").replaceAll(CommonConstant.COMMA_SEPERATOR,CommonConstant.DOT_OPERATOR);
		BigDecimal result = null;
		if (operator.equals(OperatorConstant.ADD)) {
			result = additionOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.SUB)) {
			result = minusOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.MUL)) {
			result = multiplicationOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.DIV)) {
			result = divisionOperation(operand1, operand2, testCaseDetail);
		} else if (operator.equals(OperatorConstant.MOD)) {
			result = modOperation(operand1, operand2, testCaseDetail);
		}
		return result;

	}

	private static BigDecimal additionOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		BigDecimal result = null;
		testCaseDetail.getReportingLogger().info("Performing Addition of '" + operand1 + "' and '" + operand2 + "'");
		if (CommonUtility.checkForNumericFloatValue(operand1) && CommonUtility.checkForNumericFloatValue(operand2)) {
			result =convertDataToBigDecimal(operand1).add(convertDataToBigDecimal(operand2));
		}
		return result;
	}

	private static BigDecimal minusOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		BigDecimal result = null;
		testCaseDetail.getReportingLogger().info("Performing Subtraction of '" + operand1 + "' and '" + operand2 + "'");
		if (CommonUtility.checkForNumericFloatValue(operand1) && CommonUtility.checkForNumericFloatValue(operand2)) {
			result =convertDataToBigDecimal(operand1).subtract(convertDataToBigDecimal(operand2));
		}
		return result;
	}

	private static BigDecimal multiplicationOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		BigDecimal result = null;
		testCaseDetail.getReportingLogger()
				.info("Performing Multiplication of '" + operand1 + "' and '" + operand2 + "'");
		if (CommonUtility.checkForNumericFloatValue(operand1) && CommonUtility.checkForNumericFloatValue(operand2)) {
			result =convertDataToBigDecimal(operand1).multiply(convertDataToBigDecimal(operand2));
		}
		return result;
	}

	private static BigDecimal divisionOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		BigDecimal result = null;
		testCaseDetail.getReportingLogger().info("Performing Division of '" + operand1 + "' and '" + operand2 + "'");
		if (CommonUtility.checkForNumericFloatValue(operand1) && CommonUtility.checkForNumericFloatValue(operand2)) {
			 BigDecimal bg1 = convertDataToBigDecimal(operand1);
		      BigDecimal bg2 = convertDataToBigDecimal(operand2);
		      result = bg1.divide(bg2, 3, RoundingMode.CEILING);
		}
		return result;
	}

	private static BigDecimal modOperation(String operand1, String operand2, TestCaseDetail testCaseDetail) {
		BigDecimal result = null;
		testCaseDetail.getReportingLogger().info("Performing MOD of  '" + operand1 + "' and'" + operand2 + "'");
		if (CommonUtility.checkForNumericFloatValue(operand1) && CommonUtility.checkForNumericFloatValue(operand2)) {
			result =convertDataToBigDecimal(operand1).remainder(convertDataToBigDecimal(operand2));
		}
		return result;
	}
}
