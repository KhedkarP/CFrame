/**
 * 
 */

package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author nbhil
 *
 */
public class ExecuteQueryAction implements PerformAction {

	/**
	 * This method execute action for execute query action.
	 * 
	 * @param excelTestCaseFieldsTO ExcelTestCaseFields
	 * @param testCaseDetailTO      TestCaseDetail
	 */

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		testCaseDetailTO.getReportingLogger()
				.info(excelTestCaseFieldsTO.getTestCaseSteps() + " - " + excelTestCaseFieldsTO.getInputTestData());

		String[] storeRetrievedValues = null;
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			storeRetrievedValues = CommonUtility.splitStringUsingPattern(
					excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.COMMA_SEPERATOR);
		}
		String schema = CommonUtility.getApplicationNameFromWorksheetName(testCaseDetailTO.getWorkSheetName());

		if (excelTestCaseFieldsTO.getInputTestData().contains(CommonConstant.PIPE_SEPARATOR)) {
			String[] inputQuery = CommonUtility.splitStringUsingPatternWithLastAvailable(excelTestCaseFieldsTO.getInputTestData(),
					CommonConstant.PIPE_SEPARATOR);
			CommonFunctions.executeQuery(inputQuery, storeRetrievedValues, testCaseDetailTO.getVariableHolder(),
					testCaseDetailTO.getReportingLogger(), schema);
		} else {
			CommonFunctions.executeQuery(excelTestCaseFieldsTO.getInputTestData(), storeRetrievedValues,
					testCaseDetailTO.getVariableHolder(), testCaseDetailTO.getReportingLogger(), schema);
		}

	}

}
