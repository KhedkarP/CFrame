/**
 * 
 */
package com.cassiopae.framework.util;

import com.cassiopae.excel.dataconvertor.AbstractDataConvertor;
import com.cassiopae.excel.dataconvertor.constant.ConvertorConstant;
import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.dao.utility.DatabaseUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.to.*;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.FrameworkConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.ui.functions.CommonFunctions;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.driver.DriverDefination;
import com.cassiopae.selenium.utils.excel.ExcelOperation;
import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import java.util.Map;

/**
 * @author nbhil
 *
 */
public class FrameworkCommonUtility {
	private FrameworkCommonUtility() {

	}

	private static Logger logger = LogManager.getLogger(FrameworkCommonUtility.class);

	/**
	 * This method will populate TestCaseDetail from TestCaseCommonData.
	 * 
	 * @param testCaseCommonData TestCaseCommonData
	 * @param testCaseDetail     TestCaseDetail
	 * @return TestCaseDetail
	 */
	public static void updateTestCaseDetails(final TestCaseCommonData testCaseCommonData,
			TestCaseDetail testCaseDetail) {
		testCaseDetail.setReportingLogger(testCaseCommonData.getReportingLogger());
		testCaseDetail.setDriver(testCaseCommonData.getDriver());
		testCaseDetail.setWorkSheetName(testCaseCommonData.getWorkSheetName());
		testCaseDetail.setVariableHolder(testCaseCommonData.getVariableHolder());
		testCaseDetail.setDomainName(testCaseCommonData.getDomainName());
		testCaseDetail.setWorkBookName(testCaseCommonData.getWorkBookName());
		testCaseDetail.setTestCaseCommonData(testCaseCommonData);
	}

	/**
	 * This method will print the logger information.
	 * 
	 * @param testCaseCommonDataTO
	 */
	public static void printLogger(final TestCaseCommonData testCaseCommonDataTO) {
		StringBuilder message = new StringBuilder();
		message.append(CommonConstant.EXECUTION_STARTED).append(CommonConstant.SPACE)
				.append(CommonConstant.COLON_SEPERATOR).append(CommonConstant.SPACE)
				.append(testCaseCommonDataTO.getWorkSheetName()).append(CommonConstant.SPACE).append(" on ")
				.append(testCaseCommonDataTO.getBrowserName()).append(CommonConstant.BROWSER_ON)
				.append(ApplicationConstant.platform).append(CommonConstant.PLATFROM_MSG);
		testCaseCommonDataTO.getReportingLogger().info(message.toString());
	}

	/**
	 * Populate the CurrentTestCase from TestCaseCommonData.
	 * 
	 * @param testCaseCommonData
	 */
	public static void populateCurrentTestCase(TestCaseCommonData testCaseCommonData) {
		CurrentTestCase.getBrowsername().set(testCaseCommonData.getBrowserName());
		CurrentTestCase.getReportinglogger().set(testCaseCommonData.getReportingLogger());
		CurrentTestCase.getDomainname().set(testCaseCommonData.getDomainName());
		CurrentTestCase.getCurrentworksheetname().set(testCaseCommonData.getWorkSheetName());
		CurrentTestCase.getCurrentworkbook().set(testCaseCommonData.getWorkBookName());
		CurrentTestCase.getToastMessageOnPOS().set(false);
		CurrentTestCase.getConsolelogs().set(testCaseCommonData.getIssueReproduceStepsLogs());
		CurrentTestCase.getAppsynchronizationswitch().set(testCaseCommonData.getWorkSheetName());
	}

	/**
	 * Populate the VariableHolder with application information.
	 * 
	 * @param testCaseDetail populates BO,MO,POS url's in variable holder
	 */
	public static void populateAppInfoOfEnv(TestCaseDetail testCaseDetail) {
		testCaseDetail.getVariableHolder().put(FrameworkConstant.BO_URL, ApplicationContext.baseUrlBO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.MO_URL, ApplicationContext.baseUrlMO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.POS_URL, ApplicationContext.posURL);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.ConfigConsole_URL,
				ApplicationContext.configConsoleURL);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.username_DB_BO, ApplicationContext.username_DB_BO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.password_DB_BO, ApplicationContext.password_DB_BO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.PortBO, ApplicationContext.PortBO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.iphostBO, ApplicationContext.iphostBO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.dbsidBO, ApplicationContext.dbsidBO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.username_DB_MO, ApplicationContext.username_DB_MO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.password_DB_MO, ApplicationContext.password_DB_MO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.PortMO, ApplicationContext.PortMO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.iphostMO, ApplicationContext.iphostMO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.dbsidMO, ApplicationContext.dbsidMO);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.installationDirectoryName,
				ApplicationContext.applicationServerUsername);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.tcUsername,
				testCaseDetail.getTestCaseCommonData().getDefaultUserName());
		testCaseDetail.getVariableHolder().put(FrameworkConstant.tcPassword,
				testCaseDetail.getTestCaseCommonData().getDefaultPassword());
		
		testCaseDetail.getVariableHolder().put(FrameworkConstant.applicationServerHostname,
				ApplicationContext.applicationServerHostname);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.applicationServerUsername,
				ApplicationContext.applicationServerUsername);
		
		testCaseDetail.getVariableHolder().put(FrameworkConstant.engageoneConnectorPort,
				ApplicationContext.engageoneConnectorPort);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.ariadnextdigisignConnectorPort,
				ApplicationContext.ariadnextdigisignConnectorPort);
		testCaseDetail.getVariableHolder().put(FrameworkConstant.externalratingprotectelConnectorPort,
				ApplicationContext.externalratingprotectelConnectorPort);

	}

	/**
	 * Populate the CurrentTestCase from TestCaseCommonData.
	 * 
	 * @param testCaseCommonData
	 */
	public static void populateCurrentTestCaseDetails(TestCaseDetail testCaseDetail) {
		CurrentTestCase.getReportinglogger().set(testCaseDetail.getReportingLogger());
		CurrentTestCase.getCurrentworksheetname().set(testCaseDetail.getWorkSheetName());
	}

	/**
	 * This method will update the TestCaseCommonData
	 * 
	 * @param testCaseCommonData TestCaseCommonData
	 * @param workSheetName      String
	 * @param variableHolder     Map<String, String>
	 * @param testCaseRepoPath   String
	 */
	public static void updateTestCaseCommonData(TestCaseCommonData testCaseCommonData, String workSheetName,
			String testCaseRepoPath) {
		testCaseCommonData.setWorkSheetName(workSheetName);
		testCaseCommonData.setBaseWorksheetName(workSheetName);
		String testCaseExcelPath = testCaseRepoPath + testCaseCommonData.getWorkBookName()
				+ CommonConstant.XLSX_FILE_EXTENSION;
		testCaseCommonData.setTestCaseExcelPath(testCaseExcelPath);

		String issueReproduceStepsLogs = CommonUtility.getPathOfTestCaseLogs(testCaseCommonData.getDomainName(),
				testCaseCommonData.getWorkBookName(), testCaseCommonData.getWorkSheetName(),
				testCaseCommonData.getBrowserName());
		testCaseCommonData.setIssueReproduceStepsLogs(issueReproduceStepsLogs);
		String uaidFilePath = CommonUtility.getPathOfUAIDLogFile(testCaseCommonData.getDomainName(),
				testCaseCommonData.getWorkBookName(), testCaseCommonData.getWorkSheetName(),
				testCaseCommonData.getBrowserName());
		if (FileUtility
				.checkFileExists(uaidFilePath + CommonConstant.UAID_FILE_NAME + CommonConstant.TXT_FILE_EXTENSION)) {
			FileUtility.deleteFile(uaidFilePath,
					uaidFilePath + CommonConstant.UAID_FILE_NAME + CommonConstant.TXT_FILE_EXTENSION, logger);
		}
		Logger reportingLogger = SeleniumUtility.loggerFile(testCaseCommonData.getWorkSheetName(),
				testCaseCommonData.getWorkBookName(), testCaseCommonData.getIssueReproduceStepsLogs(),
				testCaseCommonData.getDomainName());
		testCaseCommonData.setReportingLogger(reportingLogger);
		
		Map<String, String> rowNumUserPass = ExcelOperation.getRowNumUsernamePassword(
				InitializeConstants.dashboard_excel_status_sheet_name, workSheetName,
				testCaseCommonData.getDomainName());
		int excelDashBoardRowNo = Integer.parseInt(rowNumUserPass.get(CommonConstant.DASHBOARD_ROW_NUMBER));
		testCaseCommonData.setExcelRowNo(excelDashBoardRowNo);
		if (excelDashBoardRowNo == 0) {
			throw new ValidatorException(ErrorMessageConstant.WORK_SHEET_NAME_NOT_EXIST);
		}
		String userName = rowNumUserPass.get(CommonConstant.USERNAME);
		testCaseCommonData.setUserName(userName);
		testCaseCommonData.setDefaultUserName(userName);
		String password = rowNumUserPass.get(CommonConstant.PASSWORD);
		testCaseCommonData.setDefaultPassword(password);
		testCaseCommonData.setPassword(password);

		String locale = configureLocaleSettings(testCaseCommonData, workSheetName, userName);
		updateDateAmountFormat(testCaseCommonData, workSheetName, locale);
		Map<String, TestCaseDataRow> testData = ExcelOperation.getTestData(testCaseCommonData.getTestCaseExcelPath(),
				testCaseCommonData.getDomainName(), locale, testCaseCommonData.getTestDataHeaderRowNum(),
				testCaseCommonData.getMaxDataSetRowNum(), testCaseCommonData.getWorkSheetName());
		testCaseCommonData.setTestData(testData);

	}

	public static void updateDateAmountFormat(TestCaseCommonData testCaseCommonData, String workSheetName,
			String locale) {
		if(workSheetName.contains(DBConstant.POS_MODULE) || workSheetName.contains(DBConstant.CC_APP_SHEET_NAME)) {
			Map<String, String> formatorMap = AbstractDataConvertor.getLocaleMap().get("POS_"+locale);
			String dateFormate = formatorMap.get(ConvertorConstant.DATE_FORMATE_KEY);
			testCaseCommonData.getVariableHolder().put(FrameworkConstant.APP_DATE_FORMAT, dateFormate);
		} else {
			Map<String, String> formatorMap = AbstractDataConvertor.getLocaleMap().get(locale);
			String dateFormate = formatorMap.get(ConvertorConstant.DATE_FORMATE_KEY);
			testCaseCommonData.getVariableHolder().put(FrameworkConstant.APP_DATE_FORMAT, dateFormate);
		}
	}

	public static String configureLocaleSettings(TestCaseCommonData testCaseCommonData, String workSheetName,
			String userName) {
		String locale = null;
		if (InitializeConstants.setLocaleThroughDBQueryForEachTestCase.equalsIgnoreCase(CommonConstant.YES)) {
			locale = DatabaseUtility.getUPRSTRINGVALUE(testCaseCommonData.getUserName());
			if (locale == null) {
				logger.info(testCaseCommonData.getUserName() + " - User is not present in Database");
				throw new CATTException(testCaseCommonData.getUserName() + " - User is not present in Database");
			}
			logger.info("Current locale of application for "+testCaseCommonData.getUserName()+" user is:" + locale);
			CommonFunctions.updateUserLocale(workSheetName, userName, testCaseCommonData.getDomainName());
			locale = DatabaseUtility.getUPRSTRINGVALUE(testCaseCommonData.getUserName());
			logger.info("Updated locale of application for "+testCaseCommonData.getUserName()+" user is:" + locale);
		} else {
			locale = InitializeConstants.localeDetails.get("DEFAULT");
		}
		testCaseCommonData.setLocale(locale);
		testCaseCommonData.getVariableHolder().put(FrameworkConstant.LOCALE, locale);
		return locale;
	}

	/**
	 * This method will populate the reporting logger for error messge.
	 * 
	 * @param excelMasterData ExcelMasterData
	 * @param testCaseDetail  TestCaseDetail
	 * @return String
	 */
	public static String logError(ExcelMasterData excelMasterData, TestCaseDetail testCaseDetail) {
		StringBuilder errorMessage = new StringBuilder();
		for (ErrorValidation errorValidation : excelMasterData.getErroValidationList()) {
			errorMessage.append(errorValidation.getRowNumber())
					.append(CommonConstant.DOT_OPERATOR + CommonConstant.SPACE)
					.append(errorValidation.getErrorMassage()).append(CommonConstant.SPACE)
					.append(CommonConstant.WORK_SHEET_NAME).append(CommonConstant.SPACE)
					.append(errorValidation.getWorkSheetName()).append(CommonConstant.COMMA_SEPERATOR)
					.append(CommonConstant.WORK_BOOK_NAME).append(CommonConstant.SPACE)
					.append(errorValidation.getWorkBookName()).append(CommonConstant.LINE_SEPERATER);

		}
		testCaseDetail.getReportingLogger().error(errorMessage.toString());
		return errorMessage.toString();
	}

	public static void launchBrowser(TestCaseCommonData testCaseCommonData) {

		WebDriver webDriver = DriverDefination.eventFiringWebDriver(testCaseCommonData.getBrowserName(),
				testCaseCommonData.getDomainName(), testCaseCommonData.getWorkBookName(),
				testCaseCommonData.getWorkSheetName(), testCaseCommonData.getNeoLoadProjectsPath(),
				testCaseCommonData.getNewDriverInstance().get(InitializeConstants.NEW_DRIVER_INSTANCE),testCaseCommonData);
		testCaseCommonData.setDriver(webDriver);
		CurrentTestCase.getCurrentdriver().set(testCaseCommonData.getDriver());
	}

}
