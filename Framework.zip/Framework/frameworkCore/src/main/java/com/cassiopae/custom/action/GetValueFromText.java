/**
 * 
 */
package com.cassiopae.custom.action;

import java.util.regex.Pattern;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author meenakshi
 *
 */
public class GetValueFromText implements CustomAction {
	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		String[] inputTestDatas = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String []occurenceslist=CommonUtility.splitStringUsingPattern(inputTestDatas[2], CommonConstant.COMMA_SEPERATOR);
		int []prefixSufixcount=getPrifixSufixoccurence(occurenceslist, testCaseDetailTO);
		
		String givenstringValue = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputTestDatas[0]);
		String retrivedValue = null;
		String prifix = new String();
		String suffix = new String();
		try {
			if (!(inputTestDatas[1].isEmpty())) {
				if (inputTestDatas[1].contains(",")) {
					String[] reqValues = inputTestDatas[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
					prifix = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
							reqValues[0]);
					suffix = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
							reqValues[1]);
				} else {
					prifix = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
							inputTestDatas[1].trim());

				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.INVALID_INPUT_MSG);
			throw new CATTException(ReportLoggerConstant.INVALID_INPUT_MSG);
		}
		String[] summaryReporToken = givenstringValue.split("\n");
		retrivedValue = CommonUtility.getStringValueFromText(summaryReporToken, prifix, suffix,prefixSufixcount);
		testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.RETRIEVED_MSG + retrivedValue);
		String[] variableHolderColumnData = CommonUtility.splitStringUsingPattern(
				excelTestCaseFieldsTO.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);

		if (!(retrivedValue.isEmpty())) {
			try {
				String[] resultSet = retrivedValue.split("\n");
				for (int i = 0; i < resultSet.length; i++) {
					testCaseDetailTO.getVariableHolder().put(variableHolderColumnData[i].trim(),
							String.valueOf(resultSet[i]));

				}
			} catch (Exception e) {
				throw new CATTException(ReportLoggerConstant.OUTPUT_VARIABLE_NOT_MATCH);
			}
		}

		else {
			throw new CATTException(ReportLoggerConstant.VALUE_NOT_FOUND_IN_Text);

		}

	}

	public static int[] getPrifixSufixoccurence(String []occurenceslist,TestCaseDetail testCaseDetailTO) {
		int[] occurlist= new int[2];
			try {
				if(occurenceslist[0].equals("0")){
					occurlist[0]=1;
					occurlist[1]=Integer.parseInt(occurenceslist[1]);
				}else if(occurenceslist[1].equals("0")) {
					occurlist[0]=Integer.parseInt(occurenceslist[0]);
					occurlist[1]=1;
				}else if(!occurenceslist[0].equals("0") && !occurenceslist[1].equals("0")) {
					occurlist[0]=Integer.parseInt(occurenceslist[0]);
					occurlist[1]=Integer.parseInt(occurenceslist[1]);
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.PRIFIX_SUFFIX);
				throw new CATTException(ReportLoggerConstant.PRIFIX_SUFFIX);
			}catch (NumberFormatException e) {
				testCaseDetailTO.getReportingLogger().info(ReportLoggerConstant.PRIFIX_SUFFIX);
				throw new CATTException(ReportLoggerConstant.PRIFIX_SUFFIX);
			}
		return occurlist;
	}
}