
/**
 * 
 */
package com.cassiopae.selenium.excel.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cassiopae.excel.dataconvertor.DataConvertor;
import com.cassiopae.excel.dataconvertor.factory.DataConvertorFactory;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.ValidatorException;
import com.cassiopae.framework.to.ExcelMasterData;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseCommonData;
import com.cassiopae.framework.to.TestCaseDataRow;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.cassiopae.selenium.utils.excel.ExcelOperation;
import com.cassiopae.selenium.utils.excel.ExcelReaderConstant;

/**
 * This ExcelReader.java class is responsible for reading the Test Case File.
 * 
 * @author nbhil
 *
 */
public class ExcelReader {

	private static Logger logger = LogManager.getLogger(ExcelReader.class);

	private ExcelReader() {

	}

	/**
	 * This method read the data from Test Case file.
	 * 
	 * @param testCaseExcelPath String
	 * @param workSheetName     String
	 * @param workBookName      String
	 * @param locale            String
	 * @return Map<String, ExcelMasterData>
	 */
	public static Map<String, ExcelMasterData> readTestCaseDataFile(TestCaseCommonData testCaseCommonData) {

		String testCaseExcelPath = testCaseCommonData.getTestCaseExcelPath();
		String workSheetName = testCaseCommonData.getWorkSheetName();
		String workBookName = testCaseCommonData.getWorkBookName();
		String locale = testCaseCommonData.getLocale();
		Map<String, TestCaseDataRow> testDataMap = testCaseCommonData.getTestData();

		List<ExcelTestCaseFields> testCaseFieldList = new ArrayList<>();
		Map<String, ExcelMasterData> workSheetMap = new HashMap<>();
		ExcelMasterData excelMasterData = new ExcelMasterData();

		try (Workbook workbook = WorkbookFactory.create(new File(testCaseExcelPath))) {
			workbook.setForceFormulaRecalculation(true);
			HSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);
			excelMasterData.setWorkBookName(workBookName);
			excelMasterData.setWorkSheetName(workSheetName);
			ExcelValidator.isSheetPresentInExcel(workSheetName, workBookName, workbook);
			Sheet sheet = workbook.getSheet(workSheetName);

			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			if (CommonConstant.YES.equals(ApplicationConstant.EXECUTION_MODE_TEST_DATA)) {
				populateExcelTestCaseFields(testCaseFieldList, evaluator, sheet, locale, testDataMap,
						testCaseCommonData);
			} else {
				populateExcelTestCaseFields(testCaseFieldList, evaluator, sheet, locale,
						testCaseCommonData.getWorkSheetName());
			}
			excelMasterData.setExcelTestCaseFieldsList(testCaseFieldList);
			ExcelValidator.validateExcelData(excelMasterData);
			workSheetMap.put(excelMasterData.getWorkSheetName(), excelMasterData);
		} catch (EncryptedDocumentException | IOException exception) {
			logger.error(ErrorMessageConstant.EXCEL_READING_FAILED, exception);
			throw new ValidatorException(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
		}
		return workSheetMap;
	}

	/**
	 * This method populate the ExcelTestCaseFields.
	 * 
	 * @param testCaseFieldList List<ExcelTestCaseFields>
	 * @param evaluator         FormulaEvaluator
	 * @param sheet             Sheet
	 * @param locale            String
	 */
	private static void populateExcelTestCaseFields(List<ExcelTestCaseFields> testCaseFieldList,
			FormulaEvaluator evaluator, Sheet sheet, String locale, String workSheetName) {
		ExcelTestCaseFields excelTestCaseFields;

		DataFormatter dataFormatter = new DataFormatter();
		for (Row row : sheet) {
			excelTestCaseFields = new ExcelTestCaseFields();
			excelTestCaseFields.setSrNo(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.SR_NO)));
			excelTestCaseFields
					.setModule(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.LOCATOR_MODULE)));
			excelTestCaseFields
					.setLocatorKey(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.LOCATOR_KEY)));
			excelTestCaseFields
					.setTestCaseSteps(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.TEST_CASE_STEP)));
			excelTestCaseFields.setAction(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.ACTION_TYPE)));
			excelTestCaseFields.setInputTestData(formulaEvaluator(row.getCell(ExcelReaderConstant.INPUT_TEST_DATA),
					dataFormatter, locale, workSheetName));
			excelTestCaseFields.setStoreValuesInVariable(
					dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.STORE_VALUE)));

			excelTestCaseFields.setActualValue(formulaEvaluator(row.getCell(ExcelReaderConstant.ACTUAL_VALUE),
					dataFormatter, locale, workSheetName));
			excelTestCaseFields.setExpectedResult(formulaEvaluator(row.getCell(ExcelReaderConstant.EXPECTED_RESULT),
					dataFormatter, locale, workSheetName));
			excelTestCaseFields
					.setErrorMessage(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.ERROR_MESSAGE)));
			if (ExcelValidator.validateExcelTestCaseFields(excelTestCaseFields)) {
				testCaseFieldList.add(excelTestCaseFields);
			}

		}
	}

	/**
	 * This method populate the ExcelTestCaseFields.
	 * 
	 * @param testCaseFieldList List<ExcelTestCaseFields>
	 * @param evaluator         FormulaEvaluator
	 * @param sheet             Sheet
	 * @param locale            String
	 */
	private static void populateExcelTestCaseFields(List<ExcelTestCaseFields> testCaseFieldList,
			FormulaEvaluator evaluator, Sheet sheet, String locale, Map<String, TestCaseDataRow> testDataMap,
			TestCaseCommonData testCaseCommonData) {
		ExcelTestCaseFields excelTestCaseFields;

		DataFormatter dataFormatter = new DataFormatter();
		for (Row row : sheet) {
			dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.SR_NO));
			excelTestCaseFields = new ExcelTestCaseFields();
			excelTestCaseFields.setSrNo(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.SR_NO)));
			excelTestCaseFields
					.setModule(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.LOCATOR_MODULE)));
			excelTestCaseFields
					.setLocatorKey(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.LOCATOR_KEY)));
			excelTestCaseFields
					.setTestCaseSteps(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.TEST_CASE_STEP)));
			excelTestCaseFields.setAction(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.ACTION_TYPE)));

			String inputTestDataKey = dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.INPUT_TEST_DATA));
			excelTestCaseFields.setInputTestData(inputTestDataKey);

			excelTestCaseFields.setStoreValuesInVariable(
					dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.STORE_VALUE)));

			excelTestCaseFields.setActualValue(formulaEvaluator(row.getCell(ExcelReaderConstant.ACTUAL_VALUE),
					dataFormatter, locale, testCaseCommonData.getWorkSheetName()));
			excelTestCaseFields.setExpectedResult(formulaEvaluator(row.getCell(ExcelReaderConstant.EXPECTED_RESULT),
					dataFormatter, locale, testCaseCommonData.getWorkSheetName()));

			excelTestCaseFields
					.setErrorMessage(dataFormatter.formatCellValue(row.getCell(ExcelReaderConstant.ERROR_MESSAGE)));
			if (ExcelValidator.validateExcelTestCaseFields(excelTestCaseFields)) {
				testCaseFieldList.add(excelTestCaseFields);
			}

		}
	}

	/**
	 * This method return the dash board number.
	 * 
	 * @param domainName    String
	 * @param workSheetName String
	 * @param workBookName  String
	 * @return int
	 */
	public static int dashboardRowNumber(final String domainName, final String workSheetName,
			final String workBookName) {
		String fileName = DomainInitialization.initializeDomainTestDataExcelPath(domainName);
		int count = 0;
		count = getRowNumberForScenario(workBookName, fileName, workSheetName,
				InitializeConstants.test_case_worksheet_name_column);
		return count;
	}

	/**
	 * @param workBookName
	 * @param filename
	 * @param regressionTC
	 */
	private static synchronized int getRowNumberForScenario(final String workBookName, String filename,
			String workSheetName, int cellNumber) {
		int count = 0;
		boolean flag = false;
		ExcelOperation.waitForFileAvailability(filename);
		try (Workbook workbook = WorkbookFactory.create(new File(filename))) {
			Sheet sheet = workbook.getSheet(workBookName);
			if (null != sheet) {
				Iterator<Row> rows = sheet.rowIterator();
				while (rows.hasNext()) {
					Row row = rows.next();
					Cell cell = row.getCell(cellNumber);
					if (cell != null) {
						if (!StringUtils.isEmpty(cell.getStringCellValue())
								&& workSheetName.equalsIgnoreCase(cell.getStringCellValue())) {
							count = row.getRowNum();
							flag = true;
							break;
						}
					}
				}
			}
		} catch (FileNotFoundException exception) {
			String errorMessage = "File is not present for processing : " + filename;
			logger.error(errorMessage);
			FileUtility.appendLogMessageToFile(InitializeConstants.currentPackageDirectoryPath + File.separator
					+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
					+ "DashBoardValidation.log", errorMessage);
			throw new CATTException(errorMessage);
		} catch (IOException exception) {
			FileUtility.appendLogMessageToFile(
					InitializeConstants.currentPackageDirectoryPath + File.separator
							+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
							+ "DashBoardValidation.log",
					ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
			throw new CATTException(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
		}
		if (!flag) {
			logger.info(ReportLoggerConstant.NOW_ROW_PROVIDED_FOR_TEST_SCENARIO + workSheetName
					+ ReportLoggerConstant.IN + workBookName + ReportLoggerConstant.SHEET_LABEL);
		}
		return count;
	}

	/**
	 * @param workBookName
	 * @param filename
	 * @param regressionTC
	 */
	private static Map<String, Integer> getTestDataRowDetails(final String workBookName, String filename,
			String workSheetName, int cellNumber) {
		Integer headerRowNumber = Integer.valueOf(0);
		boolean flag = false;
		Map<String, Integer> rowData = new HashMap<>();
		Integer maxRowNumber = Integer.valueOf(0);
		DataFormatter dataFormatter = new DataFormatter();
		try (Workbook workbook = WorkbookFactory.create(new File(filename))) {
			Sheet sheet = workbook.getSheet(workBookName);
			if (null != sheet) {
				Iterator<Row> rows = sheet.rowIterator();
				while (rows.hasNext()) {
					Row row = rows.next();
					Cell cell = row.getCell(cellNumber);
					if (!flag && cell != null) {
						if (!StringUtils.isEmpty(dataFormatter.formatCellValue(cell))
								&& workSheetName.equalsIgnoreCase(cell.getStringCellValue())) {
							headerRowNumber = Integer.valueOf(row.getRowNum());
							flag = true;
							row = rows.next();
						}
					}
					if (flag) {
						Cell cell2 = row.getCell(cellNumber + 1);
						String data = dataFormatter.formatCellValue(cell2);
						if (data != null && !StringUtils.isEmpty(data)
								&& data.contains(CommonConstant.DATA_FIELD_NAME)) {
							maxRowNumber = Integer.valueOf(row.getRowNum());
						} else {
							break;
						}
					}
				}
				if (maxRowNumber == 0) {
					logger.info("Kindly check label of \r\n Field Name -->>\r\n" + "Field Value -->>\r\n"
							+ " for data row: " + headerRowNumber);
				}
				rowData.put(CommonConstant.MAX_DATA_SET_ROW_NUM, maxRowNumber);
				rowData.put(CommonConstant.DATA_SET_HEADER_ROW_NUM, headerRowNumber);
			}
		} catch (FileNotFoundException exception) {
			String errorMessage = "File is not present for processing : " + filename + CommonConstant.LINE_SEPERATER
					+ exception.getMessage();
			logger.error(errorMessage);
			FileUtility.appendLogMessageToFile(InitializeConstants.currentPackageDirectoryPath + File.separator
					+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
					+ "DashBoardValidation.log", errorMessage);
			throw new CATTException(errorMessage);
		} catch (IOException exception) {
			FileUtility.appendLogMessageToFile(
					InitializeConstants.currentPackageDirectoryPath + File.separator
							+ InitializeConstants.cattProjectName + File.separator + "log" + File.separator
							+ "DashBoardValidation.log",
					ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
			throw new CATTException(ErrorMessageConstant.EXCEL_READING_FAILED + exception.getMessage());
		}
		if (!flag) {
			logger.info(ReportLoggerConstant.NOW_ROW_PROVIDED_FOR_TEST_SCENARIO + workSheetName
					+ ReportLoggerConstant.IN + workBookName + ReportLoggerConstant.SHEET_LABEL);
		}
		return rowData;
	}

	public static int getTestDataRowNumber(final String workSheetName, final String workBookName,
			final String domainName) {
		String fileName = DomainInitialization.initializeDomainWiseTestCasesPath(domainName) + workBookName
				+ CommonConstant.XLSX_FILE_EXTENSION;
		return getRowNumberForScenario(ApplicationConstant.excelTestDataSheetName, fileName, workSheetName, 1);
	}

	public static Map<String, Integer> getTestDataRowDetails(final String workSheetName, final String workBookName,
			final String domainName) {
		String fileName = DomainInitialization.initializeDomainWiseTestCasesPath(domainName) + workBookName
				+ CommonConstant.XLSX_FILE_EXTENSION;
		return getTestDataRowDetails(ApplicationConstant.excelTestDataSheetName, fileName, workSheetName, 1);
	}

	public static String formulaEvaluator(final Cell cellvalue, final DataFormatter dataFormatter, String locale,
			String testCaseSheetName) {
		String calculatedValue = null;
		if (cellvalue != null) {
			DataConvertor dataConvertor = DataConvertorFactory.getDataConvertorInstance(cellvalue.getCellType().name());
			if (dataConvertor != null) {
				calculatedValue = dataConvertor.convertData(cellvalue, dataFormatter, locale, testCaseSheetName);
			}
		} else {
			calculatedValue = dataFormatter.formatCellValue(cellvalue);
		}
		return convertEmptyToNull(calculatedValue);
	}

	/**
	 * This method convert empty string to null.
	 * 
	 * @param value String
	 * @return String
	 */
	private static String convertEmptyToNull(final String value) {
		String returnValue = value;

		if (StringUtils.isEmpty(value)) {
			returnValue = null;
		}
		return returnValue;
	}

	public static String isExcelFilesEmpty(String excelName, String sheetName, Logger reportinglogger) {
		String status = CommonConstant.FALSE_VALUE;
		XSSFWorkbook wBook;
		try {
			wBook = new XSSFWorkbook(new FileInputStream(excelName));
			if (isSheetEmpty(wBook.getSheet(sheetName))) {
				reportinglogger.info(
						ErrorMessageConstant.GIVEN_EXCEL_SHEET_MSG + sheetName + ErrorMessageConstant.HAS_DATA_MSG);
				status = CommonConstant.TRUE_VALUE;
			} else {
				reportinglogger.info(ErrorMessageConstant.GIVEN_EXCEL_SHEET_MSG + sheetName
						+ ErrorMessageConstant.DOESNOT_NOT_HAVE_ANY_DATA);
				status = CommonConstant.FALSE_VALUE;
			}
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}
		return status;
	}

	public static boolean isSheetEmpty(XSSFSheet xssfSheet) {
		Iterator rows = xssfSheet.rowIterator();
		while (rows.hasNext()) {
			XSSFRow row = (XSSFRow) rows.next();
			Iterator cells = row.cellIterator();
			while (cells.hasNext()) {
				XSSFCell cell = (XSSFCell) cells.next();
				if (!cell.getStringCellValue().isEmpty()) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method is used to check whether the sheet is present or not in given
	 * excel file
	 * 
	 * @param workbook
	 * @param sheetName
	 * @return if sheet is present in workbook , then it will return true else false
	 */
	public static boolean checkSheetIsPresent(Workbook workbook, String sheetName) {
		for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
			if (workbook.getSheetAt(i).getSheetName().equals(sheetName)) {
				return Boolean.valueOf(true);
			}
		}
		return false;
	}
}
