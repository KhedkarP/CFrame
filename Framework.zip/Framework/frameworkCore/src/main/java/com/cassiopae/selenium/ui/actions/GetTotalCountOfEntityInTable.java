/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class GetTotalCountOfEntityInTable implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String worksheetName = testCaseDetailTO.getTestCaseCommonData().getWorkSheetName();
		int totalEntityEntries = 0;
		if (worksheetName.contains(DBConstant.BO_APP_SHEET_NAME)
				|| worksheetName.contains(DBConstant.MO_APP_SHEET_NAME)) {
			totalEntityEntries = CommonUtility.getCountOfTotalEntityFromUI(excelTestCaseFieldsTO, testCaseDetailTO);
		} else if (worksheetName.contains(DBConstant.POS_MODULE)
				|| worksheetName.contains(DBConstant.CC_APP_SHEET_NAME)) {
			totalEntityEntries = CommonUtility.getTotalEntriesPresetInTableForPOS(excelTestCaseFieldsTO,
					testCaseDetailTO);
		}
		if (excelTestCaseFieldsTO.getStoreValuesInVariable() != null) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(),
					String.valueOf(totalEntityEntries));
		}
	}
}
