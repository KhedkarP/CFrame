/**
 * 
 */
package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cassiopae.custom.action.util.SelectPanelTableEntryUtility;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.PanelTableDetails;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

/**
 * @author jraut
 *
 */
public class PanelTableFunctions {
	
	
	public static void validatePanelTableEntries(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDetail testCaseDetail) {

		Map<String, List<String>> locatorMap = ObjectRepoInitialization.masterLocatorMap
				.get(excelTestCaseFields.getModule());
		testCaseDetail.getReportingLogger().info(excelTestCaseFields.getTestCaseSteps());

		String[] locatorKeys = CommonUtility.splitStringUsingPattern(excelTestCaseFields.getLocatorKey(),
				CommonConstant.HASH_SEPERATOR);

		String[] inputTestDatas = excelTestCaseFields.getInputTestData()
				.split(Pattern.quote(CommonConstant.HASH_SEPERATOR));

		String[] conditionInputData = CommonUtility.splitStringUsingPattern(inputTestDatas[0],
				CommonConstant.PIPE_SEPARATOR);

		String[] conditionLocators = CommonUtility.splitStringUsingPattern(locatorKeys[0],
				CommonConstant.PIPE_SEPARATOR);

		String[] checkPointsLocators = CommonUtility.splitStringUsingPattern(locatorKeys[1],
				CommonConstant.PIPE_SEPARATOR);

		String[] checkPointsInputData = CommonUtility.splitStringUsingPattern(inputTestDatas[1],
				CommonConstant.PIPE_SEPARATOR);

		int globtotalEntryCount = Integer.parseInt(SelectPanelTableEntryUtility.getCountOfEntries(testCaseDetail,
				locatorMap.get(conditionLocators[0].trim()).get(0)));

		String[] seleniumActions = conditionInputData[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] reqValues = conditionInputData[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		String[] checkpointSelActions = checkPointsInputData[0].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		String[] checkPointsreqValues = checkPointsInputData[1].split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));

		String clickableRowNum = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
				inputTestDatas[2].trim());

		List<PanelTableDetails> conditionTableDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap,
				conditionLocators, seleniumActions, reqValues, testCaseDetail);

		List<PanelTableDetails> checkPointsDetailList = SelectPanelTableEntryUtility.getPanelTableDetails(locatorMap,
				checkPointsLocators, checkpointSelActions, checkPointsreqValues, testCaseDetail);

		int rowNumber = SelectPanelTableEntryUtility.validateEnrtyInTable(conditionTableDetailList,
				checkPointsDetailList, clickableRowNum, globtotalEntryCount, testCaseDetail);
		
		if (rowNumber == -1) {
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.ENTRY_IS_NOT_LISTED_IN_TABLE);
		} else {
			testCaseDetail.getReportingLogger().info("Validation passed successfully for the entries present in table");
		}
		
		if (excelTestCaseFields.getStoreValuesInVariable() != null) {
			if (rowNumber == -1) {
				testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(),
						CommonConstant.FALSE_VALUE);
			} else {
				testCaseDetail.getVariableHolder().put(excelTestCaseFields.getStoreValuesInVariable(),
						CommonConstant.TRUE_VALUE);
			}
		}

	}
	
}
