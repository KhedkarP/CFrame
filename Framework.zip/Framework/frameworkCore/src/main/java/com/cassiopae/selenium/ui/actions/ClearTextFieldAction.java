/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import org.apache.commons.lang.StringUtils;

import com.cassiopae.framework.dao.constant.DBConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.FrameworkConstant;

/**
 * @author jraut
 *
 */
public class ClearTextFieldAction implements PerformAction {

	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		if (testCaseDetailTO.getWorkSheetName().contains(FrameworkConstant.POS)
				|| StringUtils.startsWith(testCaseDetailTO.getWorkSheetName(), DBConstant.CC_APP_SHEET_NAME)) {
			GenericAction.clearTextPOSField(excelTestCaseFieldsTO.getTestCaseSteps(),
					excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
					testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		} else {
			GenericAction.clearTextField(excelTestCaseFieldsTO.getTestCaseSteps(),
					excelTestCaseFieldsTO.getLocatorKey(), testCaseDetailTO.getLocatorHashMap(),
					testCaseDetailTO.getDriver(), testCaseDetailTO.getReportingLogger());
		}
	}

}
