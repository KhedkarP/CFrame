package com.cassiopae.selenium.ui.functions;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;

public interface PerformFunctions {
	
	void perform(ExcelTestCaseFields excelTestCaseFieldsTO,TestCaseDetail testCaseDetailTO);

}
