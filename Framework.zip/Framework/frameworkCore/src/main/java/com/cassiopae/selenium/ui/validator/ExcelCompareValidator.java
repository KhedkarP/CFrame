/**
 * 
 */
package com.cassiopae.selenium.ui.validator;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.util.common.FileStructureConstants;

/**
 * @author ragrawal
 */
public class ExcelCompareValidator implements PerformValidation {

	/* (non-Javadoc)
	 * @see com.selenium.ui.actions.IPerformValidation#performValidation(com.selenium.service.model.ExcelTestCaseFieldsTO, com.selenium.common.to.TestCaseDetailTO)
	 */
	@Override
	public void performValidation( final ExcelTestCaseFields excelTestCaseFields, final TestCaseDetail testCaseDetail ) {
		if (testCaseDetail.getTestCaseCommonData().getBrowserName().equalsIgnoreCase(CommonConstant.IE_BROWSER)) {
			SeleniumUtility.downloadPaymentSchedule(FileStructureConstants.autoITExecutalePathForFileDownload,
					FileStructureConstants.closeAutoITInstancesBatFilePath,
					testCaseDetail.getTestCaseCommonData().getReportingLogger());
		}
		PaymentScheduleValidationUtility.compareExcelCoulumnData(excelTestCaseFields, testCaseDetail);
	}

}
