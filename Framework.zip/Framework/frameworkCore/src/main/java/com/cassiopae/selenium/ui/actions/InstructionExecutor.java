
package com.cassiopae.selenium.ui.actions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.CustomAction;
import com.cassiopae.custom.action.CustomType;
import com.cassiopae.custom.action.constant.CustomConstant;
import com.cassiopae.custom.action.factory.CustomActionFactory;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.CurrentTestCase;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDataRow;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.FrameworkCommonUtility;
import com.cassiopae.framework.util.PostTestCaseExecutorUtility;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.operator.OperationType;
import com.cassiopae.selenium.operator.PerformOperation;
import com.cassiopae.selenium.operator.factory.OperatorFactory;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.services.SeleniumUtility;
import com.cassiopae.selenium.services.VideoCreationUtility;
import com.cassiopae.selenium.ui.actions.factory.ActionFactory;
import com.cassiopae.selenium.ui.functions.FunctionType;
import com.cassiopae.selenium.ui.functions.executor.FunctionExecutor;
import com.cassiopae.selenium.ui.functions.factory.FunctionFactory;
import com.cassiopae.selenium.ui.validator.PerformValidation;
import com.cassiopae.selenium.ui.validator.ValidationType;
import com.cassiopae.selenium.ui.validator.factory.ValidatorFactory;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;
import com.cassiopae.webservices.action.WSAction;
import com.cassiopae.webservices.action.WSCustomType;
import com.cassiopae.webservices.action.factory.WSActionFactory;

/**
 * @author nbhil
 */
public class InstructionExecutor {

	private static Logger logger = LogManager.getLogger(InstructionExecutor.class);

	static final int LOCATOR_KEY = 1;
	static final int LOGGING_MESSAGE = 2;
	static final int TESTDATA = 4;
	static final int ERROR_MESSAGE = 7;
	static final int LOCATOR_MODULE = 0;
	static final int ACTION_TYPE = 3;
	static final int EXPECTED_TESTDATA = 5;
	static final int TEST_OUTPUT = 6;
	private static Set<String> actionSet = ActionType.getActionType();
	private static Set<String> validationSet = ValidationType.getValidationType();
	private static Set<String> customActionSet = CustomType.getActionType();
	private static Set<String> operationTypeSet = OperationType.getOperationType();
	private static Set<String> functionTypeSet = FunctionType.getFunctionType();
	private static Set<String> WSActionSet = WSCustomType.getWSActionType();

	public static void executeTestAction(final TestCaseDetail testCaseDetailTO) {

		Map<String, TestCaseDataRow> dataSetMap = testCaseDetailTO.getTestCaseCommonData().getTestData();
		Set<Entry<String, TestCaseDataRow>> dataSets = dataSetMap.entrySet();
		if (dataSets.size() > 1) {
			String defaultWorksheetName = testCaseDetailTO.getWorkSheetName();
			processMultipleDataSet(testCaseDetailTO, dataSets,defaultWorksheetName);
			testCaseDetailTO.setWorkSheetName(defaultWorksheetName);
			
		} else {
			for (Entry<String, TestCaseDataRow> entry : dataSets) {
				processDataSet(testCaseDetailTO, entry.getValue());
			}
		}
	}

	/**
	 * @param testCaseDetailTO
	 * @param dataSets
	 */
	private static void processMultipleDataSet(final TestCaseDetail testCaseDetailTO,
			Set<Entry<String, TestCaseDataRow>> dataSets, String defaultWorksheetName) {
		Map<String , String > multiDataSetResultMap = new HashMap<>();
		String status = CommonConstant.TEST_CASE_PASSED;
		String videoLocation="";
		Map<String,String> defaultMap = new HashMap<>();
		testCaseDetailTO.getTestCaseCommonData().getVariableHolder().putAll(defaultMap);
		testCaseDetailTO.getVariableHolder().putAll(defaultMap);
		
		for (Entry<String, TestCaseDataRow> entry : dataSets) {
			String errorMessage = null;
			testCaseDetailTO.getTestCaseCommonData().getVariableHolder().clear();
			testCaseDetailTO.getVariableHolder().clear();
			defaultMap.forEach((k, v) -> testCaseDetailTO.getVariableHolder().put(k, v));
			defaultMap.forEach((k, v) -> testCaseDetailTO.getTestCaseCommonData().getVariableHolder().put(k, v));
			
			testCaseDetailTO.setWorkSheetName(defaultWorksheetName+CommonConstant.UNDER_SCORE +entry.getKey());
			Logger reportingLogger = SeleniumUtility.loggerFile(
					testCaseDetailTO.getTestCaseCommonData().getWorkSheetName(),
					testCaseDetailTO.getTestCaseCommonData().getWorkBookName() + entry.getKey(),
					testCaseDetailTO.getTestCaseCommonData().getIssueReproduceStepsLogs(),
					testCaseDetailTO.getTestCaseCommonData().getDomainName());
			testCaseDetailTO.setReportingLogger(reportingLogger);
			FrameworkCommonUtility.populateCurrentTestCaseDetails(testCaseDetailTO);
			
			try {
				FileUtility.deleteExistingScreenshotFolder(
						CommonUtility.getScrenshotFolderPath(testCaseDetailTO.getDomainName(), testCaseDetailTO.getWorkBookName(), testCaseDetailTO.getWorkSheetName()));
			} catch (Exception e) {}
			
			try {
				processDataSet(testCaseDetailTO, entry.getValue());
			} catch (Exception e) {
				status = CommonConstant.TEST_CASE_FAILED;
				errorMessage = e.getMessage();
				testCaseDetailTO.getReportingLogger().error("Test execution failed for " + entry.getKey() + "");
				testCaseDetailTO.getReportingLogger().error(errorMessage);
			}
			multiDataSetResultMap.put(entry.getKey(), status);
			videoLocation = postDataSetExecutionActivity(testCaseDetailTO);
		}
		multiDataSetResultMap.put(CommonConstant.VIDEO_LOCATION_FOR_MULTI_DATA_SET, videoLocation);
		multiDataSetResultMap.put(CommonConstant.MULTI_DATA_SET_EXECUTION_STATUS, status);
		testCaseDetailTO.getTestCaseCommonData().setMultiDataSetResult(multiDataSetResultMap);
		StringBuilder datasetResultMessage = new StringBuilder();
		Map<String, String> dataSetResultaStatus = testCaseDetailTO.getTestCaseCommonData().getMultiDataSetResult();
		if (status.contains(CommonConstant.TEST_CASE_FAILED)) {
			datasetResultMessage.append("Test case execution for multiple data set is failed. PFB status of dataset execution : ").append(CommonConstant.LINE_SEPERATER);
			for (Map.Entry<String, String> dataSet : dataSetResultaStatus.entrySet()) {
				if (dataSet.getKey().contains(CommonConstant.DATA_SET_NAME)) {
					datasetResultMessage.append(dataSet.getKey()).append(CommonConstant.COLON_SEPERATOR+CommonConstant.SPACE).append(dataSet.getValue())
							.append(CommonConstant.LINE_SEPERATER);
				}
			}
			datasetResultMessage.append("Please refer automation logs/videos for more details");
			throw new CATTException(datasetResultMessage.toString());
		} else if (status.contains(CommonConstant.TEST_CASE_PASSED)) {
			datasetResultMessage.append("Test case execution for multiple data set is Passed. PFB status of dataset execution : ").append(CommonConstant.LINE_SEPERATER);
			for (Map.Entry<String, String> dataSet : dataSetResultaStatus.entrySet()) {
				if (dataSet.getKey().contains(CommonConstant.DATA_SET_NAME)) {
					datasetResultMessage.append(dataSet.getKey()).append(CommonConstant.COLON_SEPERATOR+CommonConstant.SPACE).append(dataSet.getValue())
							.append(CommonConstant.LINE_SEPERATER);
				}
			}
			multiDataSetResultMap.put(CommonConstant.MULTI_DATA_SET_EXECUTION_RESULT, datasetResultMessage.toString());
		}
	}

	/**
	 * @param testCaseDetailTO
	 * @param entry
	 */
	private static void processDataSet(final TestCaseDetail testCaseDetailTO, TestCaseDataRow testCaseDataRow) {
		Map<String, String> testDataMap = createTestDataMap(testCaseDataRow);
		List<ExcelTestCaseFields> excelTestCaseFieldsList = populateExcelTestCaseFields(
				testCaseDetailTO.getExcelTestCaseFieldsList(), testCaseDataRow);
		testDataMap.forEach((k, v) -> testCaseDetailTO.getTestCaseCommonData().getVariableHolder().put(k, v));
		testDataMap.forEach((k, v) -> testCaseDetailTO.getVariableHolder().put(k, v));
		for (ExcelTestCaseFields excelTestCaseFieldsTO : excelTestCaseFieldsList) {
			Map<String, List<String>> locatorHashMap = ObjectRepoInitialization.masterLocatorMap
					.get(excelTestCaseFieldsTO.getModule());
			testCaseDetailTO.setLocatorHashMap(locatorHashMap);
			CurrentTestCase.getCurrentrownumber().set(excelTestCaseFieldsTO.getSrNo());
			String skipStatement = testCaseDetailTO.getVariableHolder().get(CustomConstant.START_STATEMENT);
			if (CommonConstant.YES.equals(skipStatement)
					&& !CustomConstant.STOP_STATEMENT.equals(excelTestCaseFieldsTO.getAction())) {
				continue;
			}
			executeAction(testCaseDetailTO, excelTestCaseFieldsTO);
		}
	}

	/**
	 * @param testCaseDetailTO
	 * @param entry
	 */
	private static String postDataSetExecutionActivity(final TestCaseDetail testCaseDetailTO) {
		String videoLocation = null;
		try {
				String newVideoLocation = VideoCreationUtility.videoCreation(PostTestCaseExecutorUtility.getFolderPathForExecutionVideo(testCaseDetailTO.getTestCaseCommonData()),
						PostTestCaseExecutorUtility.getFolderPathForScrrenShot(testCaseDetailTO.getTestCaseCommonData()), testCaseDetailTO.getWorkSheetName(),testCaseDetailTO.getTestCaseCommonData().getBrowserName());
				testCaseDetailTO.getReportingLogger().info("Video Location : " + newVideoLocation);
		} catch (Exception e) {
			logger.info("Video Creation Failed", e);
		}
		return videoLocation;
	}

	/**
	 * @param testCaseDetailTO
	 * @param excelTestCaseFieldsTO
	 */
	private static void executeAction(final TestCaseDetail testCaseDetailTO,
			ExcelTestCaseFields excelTestCaseFieldsTO) {
		PerformAction performAction;
		PerformValidation performValidation;
		FunctionExecutor executeFunction;
		if (StringUtils.isNotEmpty(excelTestCaseFieldsTO.getAction())) {
			if (actionSet.contains(excelTestCaseFieldsTO.getAction())) {
				performAction = ActionFactory.getActionInstance(excelTestCaseFieldsTO.getAction());
				performAction.executeAction(excelTestCaseFieldsTO, testCaseDetailTO);
			} else if (validationSet.contains(excelTestCaseFieldsTO.getAction())) {
				performValidation = ValidatorFactory.getValidatorInstance(excelTestCaseFieldsTO.getAction());
				performValidation.performValidation(excelTestCaseFieldsTO, testCaseDetailTO);
			} else if (functionTypeSet.contains(excelTestCaseFieldsTO.getAction())) {
				CommonUtility.logTransactions(testCaseDetailTO.getDriver(), excelTestCaseFieldsTO.getTestCaseSteps());
				String[] action = excelTestCaseFieldsTO.getAction().split(CommonConstant.UNDER_SCORE);
				executeFunction = FunctionFactory.getFunctionInstance(action[1]);
				executeFunction.executeFunction(action[2], excelTestCaseFieldsTO, testCaseDetailTO);
			} else if (customActionSet.contains(excelTestCaseFieldsTO.getAction())) {
				CustomAction customAction = CustomActionFactory.getCustomAction(excelTestCaseFieldsTO.getAction());
				customAction.performCustomAction(excelTestCaseFieldsTO, testCaseDetailTO);
			} else if (operationTypeSet.contains(excelTestCaseFieldsTO.getAction())) {
				PerformOperation performOperation = OperatorFactory
						.getOperationInstance(excelTestCaseFieldsTO.getAction());
				performOperation.executeOperation(excelTestCaseFieldsTO, testCaseDetailTO);
			}else if (WSActionSet.contains(excelTestCaseFieldsTO.getAction())) {
				WSAction wsAction= WSActionFactory.getWSActionInstance(excelTestCaseFieldsTO.getAction());
				wsAction.performWSAction(excelTestCaseFieldsTO, testCaseDetailTO);
			}
		} else {
			testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		}
	}

	private static List<ExcelTestCaseFields> populateExcelTestCaseFields(
			List<ExcelTestCaseFields> excelTestCaseFieldsList, TestCaseDataRow testCaseDataRow) {
		List<ExcelTestCaseFields> resultExcelTestCaseFieldsList = new ArrayList<>();
		for (ExcelTestCaseFields excelTestCaseFields : excelTestCaseFieldsList) {
			ExcelTestCaseFields excelTestCaseField = getExcelTestCaseFields(excelTestCaseFields, testCaseDataRow);
			resultExcelTestCaseFieldsList.add(excelTestCaseField);
		}
		return resultExcelTestCaseFieldsList;
	}

	private static ExcelTestCaseFields getExcelTestCaseFields(ExcelTestCaseFields excelTestCaseFields,
			TestCaseDataRow testCaseDataRow) {
		ExcelTestCaseFields resultExcelTestCaseField = new ExcelTestCaseFields();
		String dataValue = null;
		resultExcelTestCaseField.setSrNo(excelTestCaseFields.getSrNo());
		resultExcelTestCaseField.setModule(excelTestCaseFields.getModule());
		resultExcelTestCaseField.setLocatorKey(excelTestCaseFields.getLocatorKey());
		resultExcelTestCaseField.setTestCaseSteps(excelTestCaseFields.getTestCaseSteps());
		resultExcelTestCaseField.setAction(excelTestCaseFields.getAction());
		resultExcelTestCaseField.setStoreValuesInVariable(excelTestCaseFields.getStoreValuesInVariable());

		String inputTestDataKey = excelTestCaseFields.getInputTestData();
		if (!StringUtils.isEmpty(inputTestDataKey) && testCaseDataRow.getHeaderMap().containsKey(inputTestDataKey)) {
			Integer colIndex = testCaseDataRow.getHeaderMap().get(inputTestDataKey);
			dataValue = testCaseDataRow.getCellValue(colIndex);
			resultExcelTestCaseField.setInputTestData(dataValue);
		} else {
			resultExcelTestCaseField.setInputTestData(inputTestDataKey);
		}

		String actualValue = excelTestCaseFields.getActualValue();
		if (!StringUtils.isEmpty(actualValue) && testCaseDataRow.getHeaderMap().containsKey(actualValue)) {
			Integer colIndex = testCaseDataRow.getHeaderMap().get(actualValue);
			dataValue = testCaseDataRow.getCellValue(colIndex);
			resultExcelTestCaseField.setActualValue(dataValue);
		} else {
			resultExcelTestCaseField.setActualValue(actualValue);
		}

		String expectedResult = excelTestCaseFields.getExpectedResult();
		if (!StringUtils.isEmpty(expectedResult) && testCaseDataRow.getHeaderMap().containsKey(expectedResult)) {
			Integer colIndex = testCaseDataRow.getHeaderMap().get(expectedResult);
			dataValue = testCaseDataRow.getCellValue(colIndex);
			resultExcelTestCaseField.setExpectedResult(dataValue);
		} else {
			resultExcelTestCaseField.setExpectedResult(expectedResult);
		}
		resultExcelTestCaseField.setErrorMessage(excelTestCaseFields.getErrorMessage());
		return resultExcelTestCaseField;
	}

	private static Map<String, String> createTestDataMap(TestCaseDataRow dataset) {
		Map<String, String> testDataMap = new HashMap<>();
		Map<String, Integer> headerMap = dataset.getHeaderMap();
		for (Map.Entry<String, Integer> header : headerMap.entrySet()) {
			testDataMap.put(header.getKey(), dataset.getCellValue(header.getValue()));
		}
		return testDataMap;
	}

}
