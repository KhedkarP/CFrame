package com.cassiopae.selenium.ui.functions;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.openqa.selenium.WebDriver;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.selenium.ui.actions.GenericAction;
import com.cassiopae.selenium.ui.functions.constant.FunctionLocatorConstant;
import com.cassiopae.selenium.ui.functions.constant.FunctionReportingConstant;
import com.cassiopae.selenium.utils.excel.ObjectRepoInitialization;

public class ActorFunctions {
	/*
	 * Actor Functions
	 */
	private static Map<String, List<String>> actorLocatorMap = ObjectRepoInitialization.masterLocatorMap
			.get(ObjectRepoInitialization.ACTOR_LOCATOR);

	public static void navigateTo(WebDriver driver, Logger reportingLogger) {
		GenericAction.mouseHoverOn(FunctionReportingConstant.ACTOR_MOUSE_HOVER, FunctionLocatorConstant.ACTOR_MENU,
				actorLocatorMap, driver, reportingLogger);
		GenericAction.clickOn(FunctionReportingConstant.ACTOR_SUB_MENU, FunctionLocatorConstant.ACTOR_SUB_MENU, actorLocatorMap,
				driver, reportingLogger);
	}

	public static void open(String reference,ExcelTestCaseFields excelTestCaseFields,TestCaseDetail testCaseDetail)
	{
		navigateTo(testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		excelTestCaseFields.setTestCaseSteps(FunctionReportingConstant.ENTER_ACTOR_REFERENCE_NUMBER);
		excelTestCaseFields.setLocatorKey(FunctionLocatorConstant.ACTOR_INPUT_REFERENCE);
		testCaseDetail.setLocatorHashMap(actorLocatorMap);
		GenericAction.enterValueIn(reference,excelTestCaseFields,testCaseDetail);
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_SEARCH_ACTOR_REFERENCE_ICON,
				FunctionLocatorConstant.ACTOR_SEARCH_ICON, actorLocatorMap, testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
		GenericAction.clickOn(FunctionReportingConstant.CLICK_ON_ACTOR_REFERENCE_HYPERLINK + reference,
				FunctionLocatorConstant.ACTOR_REFERNCE_HYPERLINK, actorLocatorMap,testCaseDetail.getDriver(), testCaseDetail.getReportingLogger());
	}
}
