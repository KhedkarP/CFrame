/**
 * 
 */
package com.cassiopae.framework.to;

/**
 * @author jraut
 *
 */
public class PanelTableDetails {

	public String xPath;
	public String selAction;
	public String reqValue;
	public String getxPath() {
		return xPath;
	}
	public void setxPath(String xPath) {
		this.xPath = xPath;
	}
	public String getSelAction() {
		return selAction;
	}
	public void setSelAction(String selAction) {
		this.selAction = selAction;
	}
	public String getReqValue() {
		return reqValue;
	}
	public void setReqValue(String reqValue) {
		this.reqValue = reqValue;
	}

}
