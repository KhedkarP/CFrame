/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.HashSet;
import java.util.Set;

/**
 * @author nbhil
 *
 */
public enum ActionType {
	SLAC_NavigateToURL,
	SLAC_Click, 
	SLAC_EnterTextboxValue,
	SLAC_MouseHover,
	SLAC_GetText,
	SLAC_SelectDropdown, 
	SLAC_SelectValueContains,
	SLAC_SelectCheckbox,
	SLAC_UnSelectCheckbox,
	SLAC_GetAttributeValue,
	DB_ExecuteQuery,
	SLAC_GetAttributeTitle,
	SLAC_GetRowCountOfTable,
	SLAC_CheckAlert,
	SLAC_WindowSwitch,
	DB_ExecuteProcedure,
	SLAC_ClearTextField,
	SLAC_GetAttributeInnerText,
	SLAC_GetTotalCountOfEntries,
	SLAC_GetValueFromEventSummary,
	SLAC_CheckValueIsBlank,
	SLAC_GetWindowCount,
	SLAC_ConvertDBAmountToUIFormat,
	SLAC_UploadFile,
	SLAC_GetCountOfElement,
	SLAC_OpenNewTab_NavigateToURL,
	SLAC_CheckToastPopUp,
	
	SLAC_GetAttributeClass,
	CSMZ_ConcatenateInputs,
	CSMZ_SelectTableEntry,
	CSMZ_CheckTableEntry,
	CSMZ_GenerateRandomData,
	CSMZ_GenerateXpath_PerformAction,
	
	SLAC_GetDropDownValueCount,
	SLAC_EnterTextAreaInputValue,
	SLAC_GetAttributeSrc,
	SLAC_GetAttributeName,
	SLAC_WindowSwitchByFlowid,
	SLAC_GetToastMessage,
	SLAC_Wait,
	SLAC_CheckUnorderTableEntry,
	DB_UpdateQuery,
	XLS_PutDataInTestCaseSummaryXL,
	XLS_GetDataFromTestCaseSummaryXL,
	SLAC_GetValuesFromJasperReport,
	SLAC_ReadValuesFromExcel,
	SLAC_DragAndDrop,
	SLAC_SelectDropdownValueContains,
	SLAC_SwitchToWindowAndClose,
	SLAC_LaunchEvent,
	SLAC_Right_Click,
	SLAC_SelectInputLookupValue,
	SLAC_EnterDate,
	SLAC_NavigateToServiceAccount,
	SLAC_GetAttributeHref;
	
	private static HashSet<String> actionTypeSet = null;

	public static Set<String> getActionType() {
		if (actionTypeSet == null) {
			actionTypeSet = new HashSet<>();
			for (ActionType action : ActionType.values()) {
				actionTypeSet.add(action.name());
			}
		}
		return actionTypeSet;
	}

}
