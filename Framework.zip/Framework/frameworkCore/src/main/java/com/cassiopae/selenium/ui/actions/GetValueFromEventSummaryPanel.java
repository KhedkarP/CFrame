/**
 * 
 */
package com.cassiopae.selenium.ui.actions;

import java.util.List;
import java.util.regex.Pattern;

import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

/**
 * @author jraut
 *
 */
public class GetValueFromEventSummaryPanel implements PerformAction {


	@Override
	public void executeAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {
		String inputData = excelTestCaseFieldsTO.getInputTestData();
		testCaseDetailTO.getReportingLogger().info(excelTestCaseFieldsTO.getTestCaseSteps());
		String summaryText = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(),
				inputData.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))[0].trim());

		String dataType = inputData.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))[1].trim();
		String prefix = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))[2]
				.split(Pattern.quote(CommonConstant.COMMA_SEPERATOR))[0]);
		String suffix = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))[2]
				.split(Pattern.quote(CommonConstant.COMMA_SEPERATOR))[1]);
		int occurenceNo = Integer.parseInt(VariableHolder.getValueFromVariableHolder(
				testCaseDetailTO.getVariableHolder(), inputData.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR))[2]
						.split(Pattern.quote(CommonConstant.COMMA_SEPERATOR))[2].trim()));

		String[] summaryReporToken = summaryText.split("\n");
		List<String> foundEntriesList = null;

		if (dataType.equalsIgnoreCase(CommonConstant.STRING_DATA_TYPE)) {
			foundEntriesList = CommonUtility.getStringValue(summaryReporToken, prefix, suffix);
		} else if (dataType.equalsIgnoreCase(CommonConstant.DATE_DATA_TYPE)) {
			foundEntriesList = CommonUtility.getDateValue(summaryReporToken, prefix);
		}
		CommonUtility.validateAndUpdateVariableMap(excelTestCaseFieldsTO, testCaseDetailTO, occurenceNo,
				foundEntriesList);
	}

	
}
