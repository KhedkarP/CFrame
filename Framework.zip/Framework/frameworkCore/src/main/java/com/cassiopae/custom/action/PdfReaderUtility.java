package com.cassiopae.custom.action;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.logging.log4j.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.PDFTextStripperByArea;

import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.ErrorMessageConstant;
import com.cassiopae.selenium.services.FileUtility;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.ui.actions.constant.ReportLoggerConstant;
import com.cassiopae.selenium.util.common.CommonUtility;

public class PdfReaderUtility {

	private static Logger tracelogger = LogManager.getLogger(PdfReaderUtility.class);

	/**
	 * @author mshaik
	 * @param renamedPDFFilePath
	 * @param downlodedPath
	 * @param randomString
	 * @param testCaseDetail
	 */
	public static List<String> extractDatafromPDFAndConvertlog(String renamedPDFFilePath, String downlodedPath,
			String randomString, TestCaseDetail testCaseDetail, String pdfFileName) {
		List<String> arrayList = null;
		try {
			PDDocument document = PDDocument.load(new File(renamedPDFFilePath));
			PDFTextStripperByArea stripper = new PDFTextStripperByArea();
			stripper.setSortByPosition(true);
			PDFTextStripper Tstripper = new PDFTextStripper();
			String linseperate = Tstripper.getLineSeparator();
			String parsedText = Tstripper.getText(document);
			String data[] = parsedText.split(linseperate);
			arrayList = Arrays.asList(data);
			// create New file name
			String logFileName = downlodedPath + pdfFileName + CommonConstant.UNDER_SCORE + randomString
					+ CommonConstant.LOG_FILE_EXTENSION;
			FileUtility.createNewFile(logFileName);
			FileOutputStream fos = new FileOutputStream(logFileName);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			int count = 1;
			for (String string : arrayList) {
				bw.write(string);
				bw.newLine();
				tracelogger.info(ReportLoggerConstant.LINE_MSG + count + CommonConstant.COLON_SEPERATOR + string);
				count++;
			}
			bw.close();
			testCaseDetail.getReportingLogger().info(ReportLoggerConstant.PDF_DATA_CONVERTED_SUCESS_MSG + logFileName);
		} catch (IOException e) {
			tracelogger.info(ErrorMessageConstant.ISSUE_OCCURED_PDF_EXTRACTION_MSG);
			throw new CATTException(ErrorMessageConstant.ISSUE_OCCURED_PDF_EXTRACTION_MSG + e.getMessage());
		}
		return arrayList;
	}

	/**
	 * @author mshaik
	 * @param excelTestCaseFields
	 * @param testCaseDetail
	 */
	public static void validatePDFData(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail,
			List<String> arrayList, String renamedPDFFileName) {
		String[] inputTextData = excelTestCaseFields.getInputTestData().trim()
				.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));
		String inputParameterList[] = inputTextData[1].trim().split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
		Logger reportingLogger = testCaseDetail.getReportingLogger();
		String[] variableHolderColumnData = CommonUtility
				.splitStringUsingPattern(excelTestCaseFields.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
		boolean elementStatus = false;
		ArrayList<Boolean> condition = new ArrayList<Boolean>();
		for (int i = 0; i < inputParameterList.length; i++) {
			// process parameter
			String parameter1[] = inputParameterList[i].split(Pattern.quote(CommonConstant.COLON_SEPERATOR));
			String expectedValue = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					parameter1[0]);
			String expectedOccurence = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
					parameter1[1]);
			int expOccurenceCount = Integer.parseInt(expectedOccurence);
			int count = 0;
			for (String pdfLine : arrayList) {
				String pdfEntry = pdfLine;
				if (pdfEntry.contains(expectedValue)) {
					elementStatus = true;
					count++;
				}
			}
			if (elementStatus == true && count == expOccurenceCount) {

				reportingLogger.info(ReportLoggerConstant.EXPECTED_VALUE + expectedValue
						+ ReportLoggerConstant.PDF_OCCURENCE_MSG + expOccurenceCount);
				condition.add(true);

			} else {
				reportingLogger.info(ReportLoggerConstant.EXPECTED_VALUE + expectedValue
						+ ReportLoggerConstant.PDF_DATA_NOT_PRESENT);
				condition.add(false);
			}
		}
		if (condition.contains(false)) {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0], renamedPDFFileName);
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1], CommonConstant.FALSE_VALUE);
		} else {
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[0], renamedPDFFileName);
			testCaseDetail.getVariableHolder().put(variableHolderColumnData[1], CommonConstant.TRUE_VALUE);
		}
	}

	/**
	 * @author mshaik
	 * @param excelTestCaseFields
	 * @param testCaseDetail
	 * @return
	 */
	public static void validateInputParameters(ExcelTestCaseFields excelTestCaseFields, TestCaseDetail testCaseDetail) {
		Logger reportingLogger = testCaseDetail.getReportingLogger();
		try {
			String[] inputTextData = excelTestCaseFields.getInputTestData().trim()
					.split(Pattern.quote(CommonConstant.PIPE_SEPARATOR));

			String[] variableHolderColumnData = CommonUtility.splitStringUsingPattern(
					excelTestCaseFields.getStoreValuesInVariable(), CommonConstant.PIPE_SEPARATOR);
			String inputParameterList[] = inputTextData[1].trim().split(Pattern.quote(CommonConstant.COMMA_SEPERATOR));
			if (variableHolderColumnData.length != 2) {
				throw new CATTException(ErrorMessageConstant.INPUT_PARAMENTER_INCORRECT_MESSAGE);
			}
			for (int i = 0; i < inputParameterList.length; i++) {
				String parameter1[] = inputParameterList[i].split(Pattern.quote(CommonConstant.COLON_SEPERATOR));
				VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(), parameter1[0]);
				String expectedOccurence = VariableHolder.getValueFromVariableHolder(testCaseDetail.getVariableHolder(),
						parameter1[1]);
				Integer.parseInt(expectedOccurence);
			}
		} catch (NumberFormatException e) {
			reportingLogger.info(ErrorMessageConstant.INPUT_PARAMENTER_INCORRECT_MESSAGE);
			throw new CATTException(ErrorMessageConstant.INPUT_PARAMENTER_INCORRECT_MESSAGE);
		} catch (Exception e) {
			reportingLogger.info(ErrorMessageConstant.INPUT_PARAMENTER_INCORRECT_MESSAGE);
			throw new CATTException(ErrorMessageConstant.INPUT_PARAMENTER_INCORRECT_MESSAGE);
		}
	}
}
