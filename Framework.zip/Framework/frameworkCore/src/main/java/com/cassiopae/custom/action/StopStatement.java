/**
 *
 */
package com.cassiopae.custom.action;

import com.cassiopae.custom.action.constant.CustomConstant;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;

/**
 * @author nbhil
 */
public class StopStatement implements CustomAction {

	@Override
	public void performCustomAction( final ExcelTestCaseFields p_excelTestCaseFieldsTO, final TestCaseDetail p_testCaseDetailTO ) {
		p_testCaseDetailTO.getVariableHolder().put( CustomConstant.START_STATEMENT, CommonConstant.NO );

	}

}
