/**
 * 
 */
package com.cassiopae.custom.action;

import java.io.File;
import java.util.Vector;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.*;

import com.cassiopae.custom.action.constant.ServerConnectionConstants;
import com.cassiopae.framework.dao.utility.SFTPConnectionUtility;
import com.cassiopae.framework.exception.CATTException;
import com.cassiopae.framework.exception.CATTFileOperationException;
import com.cassiopae.framework.to.ExcelTestCaseFields;
import com.cassiopae.framework.to.TestCaseDetail;
import com.cassiopae.framework.util.constant.CommonConstant;
import com.cassiopae.framework.util.constant.InitializeConstants;
import com.cassiopae.selenium.service.model.ApplicationContext;
import com.cassiopae.selenium.ui.actions.VariableHolder;
import com.cassiopae.selenium.util.common.BatchAutomationUtility;
import com.cassiopae.selenium.util.common.CommonUtility;
import com.cassiopae.selenium.util.common.DomainInitialization;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

/**
 * @author jraut
 *
 */
public class DownloadFileFromServer implements CustomAction {

	@Override
	public void performCustomAction(ExcelTestCaseFields excelTestCaseFieldsTO, TestCaseDetail testCaseDetailTO) {

		Logger logger = testCaseDetailTO.getReportingLogger();
		logger.info(excelTestCaseFieldsTO.getTestCaseSteps());

		String[] inputData = CommonUtility.splitStringUsingPattern(excelTestCaseFieldsTO.getInputTestData(),
				CommonConstant.PIPE_SEPARATOR);
		String filename = VariableHolder.getValueFromVariableHolder(testCaseDetailTO.getVariableHolder(), inputData[0]);
		String sourcePath =  BatchAutomationUtility.getUpdatedCommand(inputData[1],
				testCaseDetailTO.getVariableHolder());
				
		String destinationPath = DomainInitialization.initializeDomainwiseDownloadPath(testCaseDetailTO.getDomainName())
				+ InitializeConstants.fileSeparator + testCaseDetailTO.getWorkBookName()
				+ InitializeConstants.fileSeparator + testCaseDetailTO.getWorkSheetName()
				+ InitializeConstants.fileSeparator;

		logger.info(ServerConnectionConstants.CONNECTING_TO + ApplicationContext.applicationServerHostname);
		Session session = SFTPConnectionUtility.createSessionObject();
		SFTPConnectionUtility.configureSessionObject(session);
		ChannelSftp sftpChannel = SFTPConnectionUtility.sftpChannelCreation(session);
		SFTPConnectionUtility.configureChannel(sftpChannel);
		boolean isFilePresent = Boolean.FALSE;
		try {
			isFilePresent = downloadFile(logger, filename, sourcePath, destinationPath, sftpChannel);
		} catch (SftpException e) {
			throw new CATTException("Error occured while downloading file from app server: " + e.getMessage());
		}

		if (!isFilePresent) {
			String errorMsg = "File is not present on app server: '" + filename + "' at location: " + sourcePath;
			logger.warn(errorMsg);
			throw new CATTFileOperationException(errorMsg);
		}
		sftpChannel.disconnect();
		session.disconnect();
		// put status & filepath
		if (!StringUtils.isEmpty(excelTestCaseFieldsTO.getStoreValuesInVariable())) {
			testCaseDetailTO.getVariableHolder().put(excelTestCaseFieldsTO.getStoreValuesInVariable(), destinationPath+filename);
		}
	}

	/**
	 * @param logger
	 * @param sourcePath
	 * @param destinationPath
	 * @param sftpChannel
	 * @throws SftpException
	 */
	private boolean downloadFile(Logger logger, String sourcefilename, String sourcePath, String destinationPath,
			ChannelSftp sftpChannel) throws SftpException {
		Vector<ChannelSftp.LsEntry> fileAndFolderList = sftpChannel.ls(sourcePath); // list of folder content

		Boolean isFilePresent = Boolean.FALSE;
		String linuxPathSeparator = "/";

		// Iterate through list of folder content
		for (ChannelSftp.LsEntry item : fileAndFolderList) {
			String fileName = item.getFilename();
			if (!item.getAttrs().isDir()) {
				if (fileName.equals(sourcefilename)) {
					new File(destinationPath + InitializeConstants.fileSeparator + fileName);
					logger.info("Copying file from: " + sourcePath + linuxPathSeparator + fileName +" to: "+destinationPath);
					sftpChannel.get(sourcePath + linuxPathSeparator + fileName,
							destinationPath + InitializeConstants.fileSeparator + fileName);
					isFilePresent = Boolean.TRUE;
				}
			}
		}
		return isFilePresent;
	}

}
